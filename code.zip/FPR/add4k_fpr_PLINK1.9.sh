#!/bin/bash
#SBATCH --job-name=add4k_fpr_pooled_eur
#SBATCH --mem=200G
#SBATCH --cpus-per-task=20
#SBATCH --array=1-50
#SBATCH --output=/work/home/chengzesong/simu_gwas/add4k_fpr/logs/add4k_fpr_%A_%a.log
#SBATCH --error=/work/home/chengzesong/simu_gwas/add4k_fpr/logs/add4k_fpr_%A_%a.err

set -euo pipefail
export LC_ALL=C

############################################################
# Additional 4,000 null simulations for FPR analysis
#
# Phenotype matrix:
#   /work/home/chengzesong/simu_gwas/add4k_fpr/random_N01_10000x4000.tsv
#
# Matrix format:
#   10,000 rows x 4,000 phenotype columns
#   header: V1, V2, ..., V4000
#   every phenotype column follows N(0,1)
#
# Array design:
#   50 array tasks
#   80 phenotype columns per array task
#
#   task 1  -> phenotype V1-V80,     output loops 1001-1080
#   task 2  -> phenotype V81-V160,   output loops 1081-1160
#   ...
#   task 50 -> phenotype V3921-V4000, output loops 4921-5000
#
# For every phenotype, run six GWAS:
#
#   Pooled EUR5K+AFR5K:
#     1. all variants
#     2. common variants
#     3. rare variants
#
#   EUR10K:
#     4. all variants
#     5. common variants
#     6. rare variants
#
# GWAS model:
#   phenotype ~ SNP + PC1 + ... + PC10
#
# Output per GWAS:
#   loop    lead_SNP    lead_P
#
# All retained results are under:
#   /work/home/chengzesong/simu_gwas/add4k_fpr
#
# IMPORTANT:
# Create the log directory BEFORE submission because Slurm opens
# --output/--error before this script starts:
#
# mkdir -p /work/home/chengzesong/simu_gwas/add4k_fpr/logs
############################################################


############################################################
# 1. Basic paths and array settings
############################################################

ROOT=/work/home/chengzesong/simu_gwas
OUT_ROOT=${ROOT}/add4k_fpr

PHENO_TSV=${OUT_ROOT}/random_N01_10000x4000.tsv

POOLED_RESULT_DIR=${OUT_ROOT}/pooled_results
EUR_RESULT_DIR=${OUT_ROOT}/eur_results
TMP_ROOT=${OUT_ROOT}/tmp
LOG_DIR=${OUT_ROOT}/logs

mkdir -p \
    "${POOLED_RESULT_DIR}" \
    "${EUR_RESULT_DIR}" \
    "${TMP_ROOT}" \
    "${LOG_DIR}"

TASK_ID=${SLURM_ARRAY_TASK_ID:-}
JOB_ID=${SLURM_ARRAY_JOB_ID:-manual}

if [ -z "${TASK_ID}" ]; then
    echo "[ERROR] SLURM_ARRAY_TASK_ID is empty."
    echo "[ERROR] Submit this script as an array job with --array=1-50."
    exit 1
fi

LOOPS_PER_ARRAY=80
LOOP_OFFSET=1000

PHENO_START=$(( (TASK_ID - 1) * LOOPS_PER_ARRAY + 1 ))
PHENO_END=$(( TASK_ID * LOOPS_PER_ARRAY ))

LOOP_START=$(( LOOP_OFFSET + PHENO_START ))
LOOP_END=$(( LOOP_OFFSET + PHENO_END ))

if [ "${PHENO_START}" -lt 1 ] || [ "${PHENO_END}" -gt 4000 ]; then
    echo "[ERROR] Unexpected phenotype range: ${PHENO_START}-${PHENO_END}"
    exit 1
fi

if [ "${LOOP_START}" -lt 1001 ] || [ "${LOOP_END}" -gt 5000 ]; then
    echo "[ERROR] Unexpected output loop range: ${LOOP_START}-${LOOP_END}"
    exit 1
fi

TMP=${TMP_ROOT}/add4k_fpr_${JOB_ID}_${TASK_ID}
mkdir -p "${TMP}"

THREADS=20
PLINK=/work/home/ac3xibpp15/software/bin/plink

PC_NAMES=PC1,PC2,PC3,PC4,PC5,PC6,PC7,PC8,PC9,PC10


############################################################
# 2. Pooled EUR5K + AFR5K genotype inputs
############################################################

POOLED_ALL=/work/home/chengzesong/data/gwas/EUR_AFR_QC
POOLED_COMMON=/work/home/chengzesong/data/gwas/EUR5K_AFR_common
POOLED_RARE=/work/home/chengzesong/data/gwas/EUR5K_AFR_rare

POOLED_PC_COVAR=/work/home/chengzesong/simu_gwas/new_pooled/fpr/pca/pooled_common.PC1_10.covariates.txt


############################################################
# 3. EUR10K genotype inputs
############################################################

EUR_ALL=/work/home/chengzesong/data/gwas/EUR/EUR_10k_QC
EUR_COMMON=/work/home/chengzesong/data/gwas/EUR/EUR_10k_common
EUR_RARE=/work/home/chengzesong/data/gwas/EUR/EUR_10k_rare

EUR_PC_COVAR=/work/home/chengzesong/simu_gwas/new_eur/PCA/EUR_10k_QC.PC1_10.covariates.txt


############################################################
# 4. Output files for this array task
############################################################

POOLED_ALL_OUT=${POOLED_RESULT_DIR}/pooled_allvar_minP_${TASK_ID}.txt
POOLED_COMMON_OUT=${POOLED_RESULT_DIR}/pooled_common_minP_${TASK_ID}.txt
POOLED_RARE_OUT=${POOLED_RESULT_DIR}/pooled_rare_minP_${TASK_ID}.txt

EUR_ALL_OUT=${EUR_RESULT_DIR}/allvariants_EUR_minP_${TASK_ID}.txt
EUR_COMMON_OUT=${EUR_RESULT_DIR}/common_EUR_minP_${TASK_ID}.txt
EUR_RARE_OUT=${EUR_RESULT_DIR}/rare_EUR_minP_${TASK_ID}.txt


############################################################
# 5. Error handling and checks
############################################################

fatal_exit()
{
    echo
    echo "============================================================"
    echo "[FATAL ERROR] $1"
    echo "[TASK_ID] ${TASK_ID}"
    echo "[TMP retained at] ${TMP}"
    echo "============================================================"
    exit 1
}

check_bfile()
{
    local BFILE=$1
    local LABEL=$2

    [ -s "${BFILE}.bed" ] || fatal_exit "Missing BED for ${LABEL}: ${BFILE}.bed"
    [ -s "${BFILE}.bim" ] || fatal_exit "Missing BIM for ${LABEL}: ${BFILE}.bim"
    [ -s "${BFILE}.fam" ] || fatal_exit "Missing FAM for ${LABEL}: ${BFILE}.fam"
}


############################################################
# 6. Extract FID/IID from one bfile
############################################################

make_fid_iid()
{
    local BFILE=$1
    local OUT=$2

    awk 'BEGIN{OFS="	"} {print $1,$2}' "${BFILE}.fam" > "${OUT}"

    if [ ! -s "${OUT}" ]; then
        fatal_exit "Failed to extract FID/IID from ${BFILE}.fam"
    fi
}


############################################################
# 7. Check genotype samples against the appropriate PC file
############################################################

check_sample_match()
{
    local BFILE=$1
    local COVAR=$2
    local LABEL=$3

    local CHECK_DIR=${TMP}/sample_check
    mkdir -p "${CHECK_DIR}"

    local BFILE_SAMPLES=${CHECK_DIR}/${LABEL}.bfile.samples
    local COVAR_SAMPLES=${CHECK_DIR}/${LABEL}.covar.samples

    make_fid_iid "${BFILE}" "${BFILE_SAMPLES}.raw"

    LC_ALL=C sort -u "${BFILE_SAMPLES}.raw" > "${BFILE_SAMPLES}"
    awk 'NR>1{print $1"\t"$2}' "${COVAR}" | LC_ALL=C sort -u > "${COVAR_SAMPLES}"

    local N_BFILE N_COVAR N_DIFF

    N_BFILE=$(wc -l < "${BFILE_SAMPLES}")
    N_COVAR=$(wc -l < "${COVAR_SAMPLES}")
    N_DIFF=$(LC_ALL=C comm -3 "${BFILE_SAMPLES}" "${COVAR_SAMPLES}" | wc -l)

    echo "[INFO] Sample check: ${LABEL}"
    echo "[INFO]   genotype samples = ${N_BFILE}"
    echo "[INFO]   covariate samples = ${N_COVAR}"
    echo "[INFO]   unmatched entries = ${N_DIFF}"

    if [ "${N_DIFF}" -ne 0 ]; then
        fatal_exit "Sample mismatch between genotype and covariate for ${LABEL}"
    fi
}


############################################################
# 8. Validate phenotype matrix
############################################################

check_phenotype_matrix()
{
    [ -s "${PHENO_TSV}" ] || fatal_exit "Phenotype TSV missing or empty: ${PHENO_TSV}"

    local N_COL
    local N_ROW
    local FIRST_HEADER
    local LAST_HEADER

    N_COL=$(head -1 "${PHENO_TSV}" | awk -F'\t' '{print NF}')
    N_ROW=$(( $(wc -l < "${PHENO_TSV}") - 1 ))

    FIRST_HEADER=$(head -1 "${PHENO_TSV}" | cut -f1 | tr -d '\r')
    LAST_HEADER=$(head -1 "${PHENO_TSV}" | cut -f4000 | tr -d '\r')

    echo "[INFO] Phenotype matrix: ${PHENO_TSV}"
    echo "[INFO] Phenotype rows: ${N_ROW}"
    echo "[INFO] Phenotype columns: ${N_COL}"
    echo "[INFO] First header: ${FIRST_HEADER}"
    echo "[INFO] Last header: ${LAST_HEADER}"

    [ "${N_ROW}" -eq 10000 ] || fatal_exit "Phenotype matrix must contain exactly 10,000 data rows; observed ${N_ROW}"
    [ "${N_COL}" -eq 4000 ] || fatal_exit "Phenotype matrix must contain exactly 4,000 columns; observed ${N_COL}"
    [ "${FIRST_HEADER}" = "V1" ] || fatal_exit "First phenotype header must be V1; observed ${FIRST_HEADER}"
    [ "${LAST_HEADER}" = "V4000" ] || fatal_exit "Last phenotype header must be V4000; observed ${LAST_HEADER}"
}


############################################################
# 9. Run one PLINK GWAS
#
# The same phenotype VALUE vector is used for pooled and EUR
# analyses. FID/IID are generated from the corresponding bfile.
############################################################

run_one_gwas()
{
    local ANALYSIS=$1
    local TYPE=$2
    local LOOP_ID=$3
    local PHENO_IDX=$4
    local BFILE=$5
    local COVAR=$6
    local PHENO_VALUES=$7
    local OUT_FILE=$8

    local TYPE_DIR=${TMP}/loop_${LOOP_ID}/${ANALYSIS}_${TYPE}
    local SAMPLE_ID_FILE=${TYPE_DIR}/fid_iid.txt
    local PHENO_FILE=${TYPE_DIR}/sim.phen

    mkdir -p "${TYPE_DIR}"

    echo
    echo "============================================================"
    echo "[INFO] Analysis: ${ANALYSIS}"
    echo "[INFO] Variant type: ${TYPE}"
    echo "[INFO] Phenotype: V${PHENO_IDX}"
    echo "[INFO] Output loop: ${LOOP_ID}"
    echo "[INFO] BFILE: ${BFILE}"
    echo "[INFO] PC covariate: ${COVAR}"
    echo "============================================================"

    make_fid_iid "${BFILE}" "${SAMPLE_ID_FILE}"

    local N_ID N_PHENO
    N_ID=$(wc -l < "${SAMPLE_ID_FILE}")
    N_PHENO=$(wc -l < "${PHENO_VALUES}")

    if [ "${N_ID}" -ne "${N_PHENO}" ]; then
        fatal_exit "Sample number mismatch for analysis=${ANALYSIS} type=${TYPE} loop=${LOOP_ID}: fam=${N_ID}, phenotype=${N_PHENO}"
    fi

    printf "FID\tIID\tPHENO\n" > "${PHENO_FILE}"
    paste "${SAMPLE_ID_FILE}" "${PHENO_VALUES}" >> "${PHENO_FILE}"

    "${PLINK}" \
        --bfile "${BFILE}" \
        --pheno "${PHENO_FILE}" \
        --pheno-name PHENO \
        --covar "${COVAR}" \
        --covar-name "${PC_NAMES}" \
        --linear hide-covar \
        --allow-no-sex \
        --threads "${THREADS}" \
        --out "${TYPE_DIR}/gwas"

    local GWAS_FILE=${TYPE_DIR}/gwas.assoc.linear

    [ -s "${GWAS_FILE}" ] || fatal_exit "GWAS output missing or empty for analysis=${ANALYSIS} type=${TYPE} loop=${LOOP_ID}"

    local ID_COL
    local P_COL

    ID_COL=$(head -1 "${GWAS_FILE}" | awk '
    {
        for (i = 1; i <= NF; i++) {
            col = $i
            gsub(/^#/, "", col)
            if (col == "SNP") {
                print i
                exit
            }
        }
    }')

    P_COL=$(head -1 "${GWAS_FILE}" | awk '
    {
        for (i = 1; i <= NF; i++) {
            if ($i == "P") {
                print i
                exit
            }
        }
    }')

    [ -n "${ID_COL}" ] || fatal_exit "Cannot detect SNP column for analysis=${ANALYSIS} type=${TYPE} loop=${LOOP_ID}"
    [ -n "${P_COL}" ] || fatal_exit "Cannot detect P column for analysis=${ANALYSIS} type=${TYPE} loop=${LOOP_ID}"

    local LEAD_LINE

    LEAD_LINE=$(awk \
        -v loop="${LOOP_ID}" \
        -v idcol="${ID_COL}" \
        -v pcol="${P_COL}" '
    NR > 1 &&
    $pcol != "NA" &&
    $pcol != "." &&
    $idcol != "NA" &&
    $idcol != "." {
        p = $pcol + 0

        if (min == "" || p < min) {
            min = p
            lead = $idcol
        }
    }
    END {
        if (lead != "") {
            print loop"\t"lead"\t"min
        }
    }
    ' "${GWAS_FILE}")

    if [ -z "${LEAD_LINE}" ]; then
        printf "%s\tNO_VALID_SNP\tNA\n" "${LOOP_ID}" >> "${OUT_FILE}"
    else
        printf "%s\n" "${LEAD_LINE}" >> "${OUT_FILE}"
    fi

    rm -rf "${TYPE_DIR}"
}


############################################################
# 10. Check all input files
############################################################

[ -x "${PLINK}" ] || fatal_exit "PLINK is not executable: ${PLINK}"

check_bfile "${POOLED_ALL}" "pooled all variants"
check_bfile "${POOLED_COMMON}" "pooled common"
check_bfile "${POOLED_RARE}" "pooled rare"

check_bfile "${EUR_ALL}" "EUR10K all variants"
check_bfile "${EUR_COMMON}" "EUR10K common"
check_bfile "${EUR_RARE}" "EUR10K rare"

check_covar_header "${POOLED_PC_COVAR}" "pooled"
check_covar_header "${EUR_PC_COVAR}" "EUR10K"

check_phenotype_matrix

check_sample_match "${POOLED_ALL}" "${POOLED_PC_COVAR}" "pooled_all"
check_sample_match "${POOLED_COMMON}" "${POOLED_PC_COVAR}" "pooled_common"
check_sample_match "${POOLED_RARE}" "${POOLED_PC_COVAR}" "pooled_rare"

check_sample_match "${EUR_ALL}" "${EUR_PC_COVAR}" "eur_all"
check_sample_match "${EUR_COMMON}" "${EUR_PC_COVAR}" "eur_common"
check_sample_match "${EUR_RARE}" "${EUR_PC_COVAR}" "eur_rare"


############################################################
# 11. Initialise task-specific output files
############################################################

HEADER="loop\tlead_SNP\tlead_P"

printf "%b\n" "${HEADER}" > "${POOLED_ALL_OUT}"
printf "%b\n" "${HEADER}" > "${POOLED_COMMON_OUT}"
printf "%b\n" "${HEADER}" > "${POOLED_RARE_OUT}"

printf "%b\n" "${HEADER}" > "${EUR_ALL_OUT}"
printf "%b\n" "${HEADER}" > "${EUR_COMMON_OUT}"
printf "%b\n" "${HEADER}" > "${EUR_RARE_OUT}"


############################################################
# 12. Main loop
############################################################

echo
echo "============================================================"
echo "[INFO] ADD4K FPR combined pooled + EUR analysis"
echo "[INFO] TASK_ID: ${TASK_ID} / 50"
echo "[INFO] Phenotype range: V${PHENO_START}-V${PHENO_END}"
echo "[INFO] Output loop range: ${LOOP_START}-${LOOP_END}"
echo "[INFO] 80 phenotypes per array task"
echo "[INFO] Phenotype matrix: ${PHENO_TSV}"
echo "[INFO] Pooled result directory: ${POOLED_RESULT_DIR}"
echo "[INFO] EUR result directory: ${EUR_RESULT_DIR}"
echo "============================================================"

for ((pheno_idx=PHENO_START; pheno_idx<=PHENO_END; pheno_idx++)); do

    LOOP_ID=$(( LOOP_OFFSET + pheno_idx ))

    echo
    echo "############################################################"
    echo "[INFO] START PHENOTYPE V${pheno_idx} -> LOOP ${LOOP_ID}"
    echo "############################################################"

    LOOP_DIR=${TMP}/loop_${LOOP_ID}
    PHENO_VALUES=${LOOP_DIR}/pheno_V${pheno_idx}.txt

    mkdir -p "${LOOP_DIR}"

    # Input is TAB-delimited with header V1-V4000.
    # Column pheno_idx corresponds to phenotype Vpheno_idx.
    # Output loop ID is pheno_idx + 1000.
    tail -n +2 "${PHENO_TSV}" \
        | cut -f"${pheno_idx}" \
        | tr -d '\r' \
        | awk '{if ($0 == "") print "NA"; else print $0}' \
        > "${PHENO_VALUES}"

    [ -s "${PHENO_VALUES}" ] || fatal_exit "Phenotype extraction failed for V${pheno_idx}"

    N_PHENO=$(wc -l < "${PHENO_VALUES}")

    if [ "${N_PHENO}" -ne 10000 ]; then
        fatal_exit "Phenotype V${pheno_idx} has ${N_PHENO} rows; expected 10000"
    fi

    ########################################################
    # Pooled EUR5K + AFR5K
    ########################################################

    run_one_gwas \
        "pooled" \
        "allvariants" \
        "${LOOP_ID}" \
        "${pheno_idx}" \
        "${POOLED_ALL}" \
        "${POOLED_PC_COVAR}" \
        "${PHENO_VALUES}" \
        "${POOLED_ALL_OUT}"

    run_one_gwas \
        "pooled" \
        "common" \
        "${LOOP_ID}" \
        "${pheno_idx}" \
        "${POOLED_COMMON}" \
        "${POOLED_PC_COVAR}" \
        "${PHENO_VALUES}" \
        "${POOLED_COMMON_OUT}"

    run_one_gwas \
        "pooled" \
        "rare" \
        "${LOOP_ID}" \
        "${pheno_idx}" \
        "${POOLED_RARE}" \
        "${POOLED_PC_COVAR}" \
        "${PHENO_VALUES}" \
        "${POOLED_RARE_OUT}"

    ########################################################
    # EUR10K
    ########################################################

    run_one_gwas \
        "EUR10K" \
        "allvariants" \
        "${LOOP_ID}" \
        "${pheno_idx}" \
        "${EUR_ALL}" \
        "${EUR_PC_COVAR}" \
        "${PHENO_VALUES}" \
        "${EUR_ALL_OUT}"

    run_one_gwas \
        "EUR10K" \
        "common" \
        "${LOOP_ID}" \
        "${pheno_idx}" \
        "${EUR_COMMON}" \
        "${EUR_PC_COVAR}" \
        "${PHENO_VALUES}" \
        "${EUR_COMMON_OUT}"

    run_one_gwas \
        "EUR10K" \
        "rare" \
        "${LOOP_ID}" \
        "${pheno_idx}" \
        "${EUR_RARE}" \
        "${EUR_PC_COVAR}" \
        "${PHENO_VALUES}" \
        "${EUR_RARE_OUT}"

    rm -rf "${LOOP_DIR}"

    echo "############################################################"
    echo "[INFO] END PHENOTYPE V${pheno_idx} -> LOOP ${LOOP_ID}"
    echo "############################################################"

done


############################################################
# 13. Cleanup
############################################################

rm -rf "${TMP}"


############################################################
# 14. Final report
############################################################

echo
echo "============================================================"
echo "[INFO] TASK COMPLETED"
echo "[INFO] Array task: ${TASK_ID}"
echo "[INFO] Phenotype range: V${PHENO_START}-V${PHENO_END}"
echo "[INFO] Output loop range: ${LOOP_START}-${LOOP_END}"
echo
echo "[INFO] Pooled input bfiles:"
echo "  ALL    = ${POOLED_ALL}"
echo "  COMMON = ${POOLED_COMMON}"
echo "  RARE   = ${POOLED_RARE}"
echo
echo "[INFO] EUR10K input bfiles:"
echo "  ALL    = ${EUR_ALL}"
echo "  COMMON = ${EUR_COMMON}"
echo "  RARE   = ${EUR_RARE}"
echo
echo "[INFO] Pooled outputs:"
echo "  ${POOLED_ALL_OUT}"
echo "  ${POOLED_COMMON_OUT}"
echo "  ${POOLED_RARE_OUT}"
echo
echo "[INFO] EUR outputs:"
echo "  ${EUR_ALL_OUT}"
echo "  ${EUR_COMMON_OUT}"
echo "  ${EUR_RARE_OUT}"
echo "============================================================"

date
