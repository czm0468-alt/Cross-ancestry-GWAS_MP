#!/usr/bin/env bash
#SBATCH --job-name=match_varsize_bfile_chr
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=1
#SBATCH --cpus-per-task=16
#SBATCH --mem=120G
#SBATCH --time=72:00:00
#SBATCH --output=/work/home/chengzesong/simu_gwas/logs/match_varsize_bfile_chr_%j.log
#SBATCH --error=/work/home/chengzesong/simu_gwas/logs/match_varsize_bfile_chr_%j.err

set -euo pipefail
export LC_ALL=C

############################################################
# Generate matched-variant-size FPR BFILEs using PLINK 1.9 only
#
# Workflow
# --------
# 1. All genotype inputs are PLINK 1.9 BFILEs (.bed/.bim/.fam).
# 2. Shared variants are matched across EUR5K, AFR5K and EUR10K.
# 3. Because BIM does not preserve REF/ALT semantics, matching uses:
#      ID + CHR + BP + unordered allele pair(A1/A2)
#    Duplicate variant IDs and missing alleles are excluded.
# 4. EUR5K and AFR5K are extracted and merged chromosome-by-chromosome
#    with PLINK 1.9 --bmerge.
# 5. Chromosome-level BFILEs are concatenated with PLINK 1.9
#    --merge-list.
# 6. EUR10K is extracted using the final variants retained in the
#    pooled EUR5K+AFR5K BFILE, ensuring identical final variant IDs.
#
# Variant classes
# ---------------
#   allvariants
#   common
#   rare
#
# Final outputs
# -------------
#   /work/home/chengzesong/simu_gwas/match_varsize_FPR/bfile/
#       merged_EUR5K_AFR5K_shared_variants/
#       EUR10K_shared_variants/
#       final_shared_variant_lists/
############################################################

############################################################
# Software
############################################################

PLINK=/work/home/ac3xibpp15/software/bin/plink
THREADS=5
PLINK_MEMORY_MB=100000

############################################################
# Input BFILE prefixes
#
# IMPORTANT
# ---------
# Each prefix below must have .bed, .bim and .fam files.
############################################################

EUR5_ALL=/work/home/chengzesong/data/gwas/EUR/EUR_5k_QC
AFR5_ALL=/work/home/chengzesong/data/gwas/AFR/AFR_5k_QC
EUR10_ALL=/work/home/chengzesong/data/gwas/EUR/EUR_10k_QC

EUR5_COMMON=/work/home/chengzesong/data/gwas/EUR/EUR_5k_common
AFR5_COMMON=/work/home/chengzesong/data/gwas/AFR/AFR_common
EUR10_COMMON=/work/home/chengzesong/data/gwas/EUR/EUR_10k_common

EUR5_RARE=/work/home/chengzesong/data/gwas/EUR/EUR_5k_rare
AFR5_RARE=/work/home/chengzesong/data/gwas/AFR/AFR_rare
EUR10_RARE=/work/home/chengzesong/data/gwas/EUR/EUR_10k_rare

############################################################
# Output directories
############################################################

OUT_ROOT=/work/home/chengzesong/simu_gwas/match_varsize_FPR/bfile

POOLED_OUT_DIR=$OUT_ROOT/merged_EUR5K_AFR5K_shared_variants
EUR10K_OUT_DIR=$OUT_ROOT/EUR10K_shared_variants
LIST_OUT_DIR=$OUT_ROOT/final_shared_variant_lists
SUMMARY_FILE=$OUT_ROOT/matched_variant_bfile_generation_summary.tsv

mkdir -p "$POOLED_OUT_DIR" "$EUR10K_OUT_DIR" "$LIST_OUT_DIR"
mkdir -p /work/home/chengzesong/simu_gwas/logs

JOB_ID=${SLURM_JOB_ID:-manual}
TMP=$OUT_ROOT/tmp_match_varsize_chr_${JOB_ID}
mkdir -p "$TMP"

############################################################
# Fatal-error handler
############################################################

fatal_exit()
{
    echo
    echo "============================================================"
    echo "[FATAL ERROR] $1"
    echo "[INFO] Temporary files retained in:"
    echo "$TMP"
    echo "============================================================"
    exit 1
}

############################################################
# Basic checks
############################################################

if [ ! -x "$PLINK" ]; then
    fatal_exit "PLINK is not executable: $PLINK"
fi

############################################################
# Utility functions
############################################################

check_bfile()
{
    local BFILE=$1
    local LABEL=$2

    if [ ! -s "${BFILE}.bed" ] || \
       [ ! -s "${BFILE}.bim" ] || \
       [ ! -s "${BFILE}.fam" ]; then
        fatal_exit "Incomplete BFILE for ${LABEL}: ${BFILE}"
    fi
}

write_bfile_variant_ids()
{
    local BFILE=$1
    local OUT=$2

    awk 'NF >= 2 && $2 != "." && $2 != "" {print $2}' "${BFILE}.bim" \
        | sort -u > "$OUT"

    if [ ! -s "$OUT" ]; then
        fatal_exit "No variant IDs were written from ${BFILE}.bim"
    fi
}

############################################################
# Write strict BIM-based variant map
#
# BIM columns
#   CHR SNP CM BP A1 A2
#
# Since PLINK 1.9 BIM does not preserve REF/ALT roles, the two
# alleles are sorted lexicographically before comparison.
# Output columns
#   ID CHR BP ALLELE_LOW ALLELE_HIGH
############################################################

write_bfile_variant_map_strict()
{
    local BFILE=$1
    local OUT=$2
    local LABEL=$3

    echo "[INFO] Writing strict BIM-based variant map for $LABEL"
    echo "[INFO] BFILE: $BFILE"
    echo "[INFO] OUT  : $OUT"

    awk '
    BEGIN {OFS="\t"}
    NF >= 6 {
        chr = $1
        id  = $2
        bp  = $4
        a1  = toupper($5)
        a2  = toupper($6)

        gsub(/^chr/, "", chr)

        if (id == "." || id == "") next
        if (bp == "." || bp == "") next
        if (a1 == "0" || a1 == "." || a1 == "") next
        if (a2 == "0" || a2 == "." || a2 == "") next

        if (a1 <= a2) {
            lo = a1
            hi = a2
        } else {
            lo = a2
            hi = a1
        }

        print id, chr, bp, lo, hi
    }
    ' "${BFILE}.bim" \
    | sort -k1,1 \
    | awk '
      BEGIN {FS=OFS="\t"}
      {
          n[$1]++
          line[$1]=$0
      }
      END {
          for (id in n) {
              if (n[id] == 1) print line[id]
          }
      }
      ' \
    | sort -k1,1 > "$OUT"

    if [ ! -s "$OUT" ]; then
        fatal_exit "Strict variant map is empty for $LABEL"
    fi
}

############################################################
# Build exact shared variant map across EUR5K, AFR5K, EUR10K
############################################################

make_exact_shared_map()
{
    local TYPE=$1
    local EUR5_BFILE=$2
    local AFR5_BFILE=$3
    local EUR10_BFILE=$4
    local OUT_MAP=$5
    local OUT_LIST=$6

    local TYPE_TMP=$TMP/$TYPE
    mkdir -p "$TYPE_TMP"

    local EUR5_MAP=$TYPE_TMP/${TYPE}.EUR5.strict.map.tsv
    local AFR5_MAP=$TYPE_TMP/${TYPE}.AFR5.strict.map.tsv
    local EUR10_MAP=$TYPE_TMP/${TYPE}.EUR10.strict.map.tsv
    local EA_MAP=$TYPE_TMP/${TYPE}.EUR5_AFR5.strict.shared.map.tsv

    echo
    echo "============================================================"
    echo "[INFO] Building exact shared variant map for $TYPE"
    echo "[INFO] Matching rule: ID + CHR + BP + unordered A1/A2 pair"
    echo "[INFO] Duplicate IDs and missing alleles are excluded"
    echo "============================================================"

    check_bfile "$EUR5_BFILE" "EUR5 $TYPE"
    check_bfile "$AFR5_BFILE" "AFR5 $TYPE"
    check_bfile "$EUR10_BFILE" "EUR10 $TYPE"

    write_bfile_variant_map_strict "$EUR5_BFILE" "$EUR5_MAP" "EUR5 $TYPE"
    write_bfile_variant_map_strict "$AFR5_BFILE" "$AFR5_MAP" "AFR5 $TYPE"
    write_bfile_variant_map_strict "$EUR10_BFILE" "$EUR10_MAP" "EUR10 $TYPE"

    awk '
    BEGIN {FS=OFS="\t"}
    NR == FNR {
        key[$1] = $2 OFS $3 OFS $4 OFS $5
        next
    }
    {
        this_key = $2 OFS $3 OFS $4 OFS $5
        if (($1 in key) && key[$1] == this_key) print $0
    }
    ' "$EUR5_MAP" "$AFR5_MAP" | sort -k1,1 > "$EA_MAP"

    awk '
    BEGIN {FS=OFS="\t"}
    NR == FNR {
        key[$1] = $2 OFS $3 OFS $4 OFS $5
        next
    }
    {
        this_key = $2 OFS $3 OFS $4 OFS $5
        if (($1 in key) && key[$1] == this_key) print $0
    }
    ' "$EA_MAP" "$EUR10_MAP" \
        | sort -k2,2V -k3,3n -k1,1 > "$OUT_MAP"

    awk 'BEGIN{FS=OFS="\t"}{print $1}' "$OUT_MAP" | sort -u > "$OUT_LIST"

    local N_EUR5 N_AFR5 N_EUR10 N_EA N_FINAL
    N_EUR5=$(wc -l < "$EUR5_MAP")
    N_AFR5=$(wc -l < "$AFR5_MAP")
    N_EUR10=$(wc -l < "$EUR10_MAP")
    N_EA=$(wc -l < "$EA_MAP")
    N_FINAL=$(wc -l < "$OUT_LIST")

    echo "[INFO] EUR5 eligible variants: $N_EUR5"
    echo "[INFO] AFR5 eligible variants: $N_AFR5"
    echo "[INFO] EUR10 eligible variants: $N_EUR10"
    echo "[INFO] EUR5 ∩ AFR5 exact count: $N_EA"
    echo "[INFO] EUR5 ∩ AFR5 ∩ EUR10 exact count: $N_FINAL"

    if [ "$N_FINAL" -eq 0 ]; then
        fatal_exit "No exact shared variants for $TYPE"
    fi
}

make_chr_variant_list()
{
    local MAP_FILE=$1
    local CHR=$2
    local OUT_LIST=$3

    awk -v c="$CHR" '
    BEGIN {FS=OFS="\t"}
    {
        chrom=$2
        gsub(/^chr/, "", chrom)
        if (chrom == c) print $1
    }
    ' "$MAP_FILE" | sort -u > "$OUT_LIST"
}

############################################################
# Extract one chromosome to BFILE
############################################################

extract_to_bed()
{
    local BFILE=$1
    local CHR=$2
    local VAR_LIST=$3
    local OUT_BED=$4
    local LABEL=$5

    echo
    echo "[INFO] Extracting $LABEL"
    echo "[INFO] Input BFILE : $BFILE"
    echo "[INFO] Chromosome  : $CHR"
    echo "[INFO] Variant list: $VAR_LIST"
    echo "[INFO] Output BFILE: $OUT_BED"

    rm -f "${OUT_BED}.bed" "${OUT_BED}.bim" "${OUT_BED}.fam" \
          "${OUT_BED}.log" "${OUT_BED}.nosex"

    "$PLINK" \
        --bfile "$BFILE" \
        --chr "$CHR" \
        --extract "$VAR_LIST" \
        --make-bed \
        --threads "$THREADS" \
        --out "$OUT_BED"

    check_bfile "$OUT_BED" "$LABEL"
}

############################################################
# Merge EUR5K and AFR5K chromosome BFILEs
############################################################

merge_chr()
{
    local TYPE=$1
    local CHR=$2
    local EUR_BED=$3
    local AFR_BED=$4
    local OUT_BED=$5

    echo
    echo "[INFO] Merging EUR5K + AFR5K"
    echo "[INFO] TYPE=$TYPE CHR=$CHR"

    rm -f "${OUT_BED}.bed" "${OUT_BED}.bim" "${OUT_BED}.fam" \
          "${OUT_BED}.log" "${OUT_BED}.nosex" \
          "${OUT_BED}-merge.missnp"

    set +e

    "$PLINK" \
        --bfile "$EUR_BED" \
        --bmerge "${AFR_BED}.bed" "${AFR_BED}.bim" "${AFR_BED}.fam" \
        --memory "$PLINK_MEMORY_MB" \
        --threads "$THREADS" \
        --make-bed \
        --out "$OUT_BED"

    local EXIT_CODE=$?
    set -e

    if [ "$EXIT_CODE" -ne 0 ]; then
        if [ -s "${OUT_BED}-merge.missnp" ]; then
            echo "[ERROR] Merge mismatch SNP file: ${OUT_BED}-merge.missnp"
            echo "[ERROR] First mismatched SNPs:"
            head -20 "${OUT_BED}-merge.missnp"
        fi
        fatal_exit "PLINK chromosome merge failed for TYPE=$TYPE CHR=$CHR"
    fi

    check_bfile "$OUT_BED" "$TYPE chr$CHR pooled"
}

############################################################
# Concatenate chromosome BFILEs with PLINK 1.9 --merge-list
############################################################

concat_chr_bfiles()
{
    local PREFIX_LIST=$1
    local OUT_BFILE=$2
    local LABEL=$3

    if [ ! -s "$PREFIX_LIST" ]; then
        fatal_exit "Empty chromosome BFILE list for $LABEL"
    fi

    mapfile -t PREFIXES < "$PREFIX_LIST"

    local N_PREFIX=${#PREFIXES[@]}

    if [ "$N_PREFIX" -eq 0 ]; then
        fatal_exit "No chromosome BFILE prefix for $LABEL"
    fi

    local BASE=${PREFIXES[0]}

    rm -f "${OUT_BFILE}.bed" "${OUT_BFILE}.bim" "${OUT_BFILE}.fam" \
          "${OUT_BFILE}.log" "${OUT_BFILE}.nosex" \
          "${OUT_BFILE}-merge.missnp"

    if [ "$N_PREFIX" -eq 1 ]; then
        cp "${BASE}.bed" "${OUT_BFILE}.bed"
        cp "${BASE}.bim" "${OUT_BFILE}.bim"
        cp "${BASE}.fam" "${OUT_BFILE}.fam"
        check_bfile "$OUT_BFILE" "$LABEL"
        return 0
    fi

    local MERGE_LIST=$TMP/$(basename "$OUT_BFILE").merge_list.txt
    : > "$MERGE_LIST"

    local IDX
    for ((IDX=1; IDX<N_PREFIX; IDX++)); do
        local P=${PREFIXES[$IDX]}
        printf "%s %s %s\n" "${P}.bed" "${P}.bim" "${P}.fam" >> "$MERGE_LIST"
    done

    echo
    echo "============================================================"
    echo "[INFO] Concatenating chromosome BFILEs for $LABEL"
    echo "[INFO] Base BFILE: $BASE"
    echo "[INFO] Additional chromosome BFILEs: $((N_PREFIX - 1))"
    echo "[INFO] Output: $OUT_BFILE"
    echo "============================================================"

    set +e

    "$PLINK" \
        --bfile "$BASE" \
        --merge-list "$MERGE_LIST" \
        --memory "$PLINK_MEMORY_MB" \
        --threads "$THREADS" \
        --make-bed \
        --out "$OUT_BFILE"

    local EXIT_CODE=$?
    set -e

    if [ "$EXIT_CODE" -ne 0 ]; then
        if [ -s "${OUT_BFILE}-merge.missnp" ]; then
            echo "[ERROR] Concatenation mismatch list: ${OUT_BFILE}-merge.missnp"
            head -20 "${OUT_BFILE}-merge.missnp"
        fi
        fatal_exit "Failed to concatenate chromosome BFILEs for $LABEL"
    fi

    check_bfile "$OUT_BFILE" "$LABEL"
}

############################################################
# Build pooled EUR5K + AFR5K BFILE chromosome by chromosome
############################################################

merge_eur_afr_by_chr()
{
    local TYPE=$1
    local EUR5_BFILE=$2
    local AFR5_BFILE=$3
    local EXACT_MAP=$4
    local OUT_BFILE=$5
    local FINAL_LIST=$6

    local TYPE_TMP=$TMP/$TYPE
    local CHR_ROOT=$TYPE_TMP/chr_bfiles
    local CHR_BFILE_LIST=$TYPE_TMP/${TYPE}.chr_merged_bfiles.list

    mkdir -p "$TYPE_TMP" "$CHR_ROOT"
    rm -f "$CHR_BFILE_LIST"

    local CHR
    for CHR in {1..22}; do
        local CHR_DIR=$CHR_ROOT/chr${CHR}
        local CHR_LIST=$CHR_DIR/${TYPE}.chr${CHR}.variants.txt
        local EUR_BED=$CHR_DIR/EUR5_${TYPE}_chr${CHR}
        local AFR_BED=$CHR_DIR/AFR5_${TYPE}_chr${CHR}
        local MERGED_BED=$CHR_DIR/EUR5K_AFR5K_${TYPE}_chr${CHR}
        local N_CHR

        mkdir -p "$CHR_DIR"

        make_chr_variant_list "$EXACT_MAP" "$CHR" "$CHR_LIST"
        N_CHR=$(wc -l < "$CHR_LIST")

        echo
        echo "############################################################"
        echo "[INFO] TYPE=$TYPE CHR=$CHR"
        echo "[INFO] Exact shared variants on chromosome: $N_CHR"
        echo "############################################################"

        if [ "$N_CHR" -eq 0 ]; then
            rm -rf "$CHR_DIR"
            continue
        fi

        extract_to_bed "$EUR5_BFILE" "$CHR" "$CHR_LIST" "$EUR_BED" "EUR5 $TYPE chr$CHR"
        extract_to_bed "$AFR5_BFILE" "$CHR" "$CHR_LIST" "$AFR_BED" "AFR5 $TYPE chr$CHR"

        merge_chr "$TYPE" "$CHR" "$EUR_BED" "$AFR_BED" "$MERGED_BED"

        printf "%s\n" "$MERGED_BED" >> "$CHR_BFILE_LIST"
    done

    concat_chr_bfiles "$CHR_BFILE_LIST" "$OUT_BFILE" "pooled EUR5K_AFR5K $TYPE"

    write_bfile_variant_ids "$OUT_BFILE" "$FINAL_LIST"

    local N_FINAL
    N_FINAL=$(wc -l < "$FINAL_LIST")

    echo
    echo "[INFO] Final pooled EUR5K_AFR5K BFILE generated for $TYPE"
    echo "[INFO] BFILE: $OUT_BFILE"
    echo "[INFO] Final variant list: $FINAL_LIST"
    echo "[INFO] Final variant count: $N_FINAL"
}

############################################################
# Extract final pooled variant set from EUR10K
############################################################

extract_eur10k_bfile()
{
    local EUR10_BFILE=$1
    local FINAL_LIST=$2
    local OUT_BFILE=$3
    local LABEL=$4

    echo
    echo "[INFO] Extracting final matched variants from EUR10K for $LABEL"
    echo "[INFO] EUR10K input: $EUR10_BFILE"
    echo "[INFO] Variant list: $FINAL_LIST"
    echo "[INFO] Output BFILE: $OUT_BFILE"

    rm -f "${OUT_BFILE}.bed" "${OUT_BFILE}.bim" "${OUT_BFILE}.fam" \
          "${OUT_BFILE}.log" "${OUT_BFILE}.nosex"

    "$PLINK" \
        --bfile "$EUR10_BFILE" \
        --extract "$FINAL_LIST" \
        --make-bed \
        --threads "$THREADS" \
        --out "$OUT_BFILE"

    check_bfile "$OUT_BFILE" "$LABEL EUR10K matched"
}

############################################################
# Assert final pooled and EUR10K variant IDs are identical
############################################################

assert_same_variants()
{
    local TYPE=$1
    local POOLED_BFILE=$2
    local EUR10_BFILE=$3
    local ASSERT_DIR=$TMP/${TYPE}_assert

    mkdir -p "$ASSERT_DIR"

    local POOLED_IDS=$ASSERT_DIR/pooled.ids.txt
    local EUR10_IDS=$ASSERT_DIR/eur10k.ids.txt
    local POOLED_NOT_EUR10=$ASSERT_DIR/pooled_not_in_eur10k.txt
    local EUR10_NOT_POOLED=$ASSERT_DIR/eur10k_not_in_pooled.txt

    write_bfile_variant_ids "$POOLED_BFILE" "$POOLED_IDS"
    write_bfile_variant_ids "$EUR10_BFILE" "$EUR10_IDS"

    comm -23 "$POOLED_IDS" "$EUR10_IDS" > "$POOLED_NOT_EUR10"
    comm -13 "$POOLED_IDS" "$EUR10_IDS" > "$EUR10_NOT_POOLED"

    local N_POOLED N_EUR10 N_POOLED_NOT N_EUR10_NOT
    N_POOLED=$(wc -l < "$POOLED_IDS")
    N_EUR10=$(wc -l < "$EUR10_IDS")
    N_POOLED_NOT=$(wc -l < "$POOLED_NOT_EUR10")
    N_EUR10_NOT=$(wc -l < "$EUR10_NOT_POOLED")

    if [ "$N_POOLED" -ne "$N_EUR10" ] || \
       [ "$N_POOLED_NOT" -ne 0 ] || \
       [ "$N_EUR10_NOT" -ne 0 ]; then

        echo "[ERROR] Variant sets are not identical for $TYPE"
        echo "[ERROR] Pooled variant count: $N_POOLED"
        echo "[ERROR] EUR10K variant count: $N_EUR10"
        echo "[ERROR] Pooled not in EUR10K: $N_POOLED_NOT"
        echo "[ERROR] EUR10K not in pooled: $N_EUR10_NOT"
        fatal_exit "Final variant matching assertion failed for $TYPE"
    fi

    echo "[PASS] $TYPE final variant sets are identical. N=$N_POOLED"
}

############################################################
# Process one variant class
############################################################

process_one_type()
{
    local TYPE=$1
    local EUR5_BFILE=$2
    local AFR5_BFILE=$3
    local EUR10_BFILE=$4
    local POOLED_OUT=$5
    local EUR10_OUT=$6

    local TYPE_TMP=$TMP/$TYPE
    mkdir -p "$TYPE_TMP"

    local EXACT_MAP=$LIST_OUT_DIR/${TYPE}.exact_shared_variant_map.tsv
    local INITIAL_LIST=$LIST_OUT_DIR/${TYPE}.exact_shared_variants.initial.txt
    local FINAL_LIST=$LIST_OUT_DIR/${TYPE}.final_shared_variants_used_by_both_bfiles.txt

    echo
    echo "############################################################"
    echo "[INFO] Processing variant class: $TYPE"
    echo "############################################################"

    make_exact_shared_map \
        "$TYPE" \
        "$EUR5_BFILE" \
        "$AFR5_BFILE" \
        "$EUR10_BFILE" \
        "$EXACT_MAP" \
        "$INITIAL_LIST"

    merge_eur_afr_by_chr \
        "$TYPE" \
        "$EUR5_BFILE" \
        "$AFR5_BFILE" \
        "$EXACT_MAP" \
        "$POOLED_OUT" \
        "$FINAL_LIST"

    extract_eur10k_bfile \
        "$EUR10_BFILE" \
        "$FINAL_LIST" \
        "$EUR10_OUT" \
        "EUR10K $TYPE"

    assert_same_variants "$TYPE" "$POOLED_OUT" "$EUR10_OUT"

    local N_POOLED_SAMPLE N_EUR10_SAMPLE N_VARIANT
    N_POOLED_SAMPLE=$(wc -l < "${POOLED_OUT}.fam")
    N_EUR10_SAMPLE=$(wc -l < "${EUR10_OUT}.fam")
    N_VARIANT=$(wc -l < "$FINAL_LIST")

    printf "%s\t%s\t%s\t%s\t%s\t%s\t%s\n" \
        "$TYPE" \
        "$N_VARIANT" \
        "$N_POOLED_SAMPLE" \
        "$N_EUR10_SAMPLE" \
        "$POOLED_OUT" \
        "$EUR10_OUT" \
        "$FINAL_LIST" >> "$SUMMARY_FILE"

    echo
    echo "[DONE] $TYPE completed"
    echo "[INFO] Final variant count: $N_VARIANT"
    echo "[INFO] Pooled BFILE: $POOLED_OUT"
    echo "[INFO] EUR10K BFILE: $EUR10_OUT"
}

############################################################
# Main
############################################################

echo
echo "============================================================"
echo "[INFO] Matched-variant-size FPR BFILE generation started"
echo "[INFO] Job ID: $JOB_ID"
echo "[INFO] Output root: $OUT_ROOT"
echo "[INFO] Temporary directory: $TMP"
echo "[INFO] All genotype operations use PLINK 1.9"
echo "[INFO] PLINK memory: ${PLINK_MEMORY_MB} MB"
echo "============================================================"

printf "variant_type\tn_final_variants\tn_pooled_samples\tn_eur10k_samples\tpooled_bfile\teur10k_bfile\tfinal_variant_list\n" > "$SUMMARY_FILE"

process_one_type \
    allvariants \
    "$EUR5_ALL" \
    "$AFR5_ALL" \
    "$EUR10_ALL" \
    "$POOLED_OUT_DIR/EUR5K_AFR5K_shared_allvariants" \
    "$EUR10K_OUT_DIR/EUR10K_shared_allvariants"

process_one_type \
    common \
    "$EUR5_COMMON" \
    "$AFR5_COMMON" \
    "$EUR10_COMMON" \
    "$POOLED_OUT_DIR/EUR5K_AFR5K_shared_common" \
    "$EUR10K_OUT_DIR/EUR10K_shared_common"

process_one_type \
    rare \
    "$EUR5_RARE" \
    "$AFR5_RARE" \
    "$EUR10_RARE" \
    "$POOLED_OUT_DIR/EUR5K_AFR5K_shared_rare" \
    "$EUR10K_OUT_DIR/EUR10K_shared_rare"

############################################################
# Cleanup
############################################################

rm -rf "$TMP"

############################################################
# Final summary
############################################################

echo
echo "============================================================"
echo "[DONE] All matched-variant-size BFILEs generated successfully"
echo "[INFO] Summary file:"
echo "$SUMMARY_FILE"
echo
cat "$SUMMARY_FILE"
echo "============================================================"
