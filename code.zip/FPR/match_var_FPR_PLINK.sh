#!/bin/bash
#SBATCH --job-name=match_varsize_fpr_PC
#SBATCH --mem=200G
#SBATCH --cpus-per-task=5
#SBATCH --array=1-50
#SBATCH --output=/work/home/chengzesong/simu_gwas/logs/match_varsize_fpr_PC_%A_%a.log
#SBATCH --error=/work/home/chengzesong/simu_gwas/logs/match_varsize_fpr_PC_%A_%a.err

set -euo pipefail

############################################################
# Matched variant-size FPR GWAS with common-variant PC1-PC10
#
# CSV remains unchanged:
#   /work/home/chengzesong/simu_gwas/pooled_1w_fpr.csv
#
# Each array runs 20 phenotype columns.
#
# Array 1  : phenotype columns 1-20
# Array 2  : phenotype columns 21-40
# ...
# Array 50 : phenotype columns 981-1000
#
# PC logic:
#   pooled_common.PC1_10.covariates.txt
#     -> pooled allvariants, pooled common, pooled rare
#
#   EUR10K_common.PC1_10.covariates.txt
#     -> EUR10K allvariants, EUR10K common, EUR10K rare
#
# Output:
#   loop    lead_SNP    lead_P
############################################################

############################################################
# Paths
############################################################

ROOT=/work/home/chengzesong/simu_gwas

CSV=$ROOT/pooled_1w_fpr.csv

BFILE_ROOT=$ROOT/match_varsize_FPR/bfile

POOLED_DIR=$BFILE_ROOT/merged_EUR5K_AFR5K_shared_variants
EUR10K_DIR=$BFILE_ROOT/EUR10K_shared_variants

PCA_DIR=$ROOT/match_varsize_FPR/pca
RESULT_DIR=$ROOT/match_varsize_FPR/results

mkdir -p "$RESULT_DIR"
mkdir -p "$ROOT/logs"

TASK_ID=${SLURM_ARRAY_TASK_ID:-}

if [ -z "$TASK_ID" ]; then
    echo "[ERROR] SLURM_ARRAY_TASK_ID is empty"
    echo "[ERROR] Submit this script with sbatch as an array job"
    exit 1
fi

JOB_ID=${SLURM_ARRAY_JOB_ID:-manual}

TMP=$ROOT/match_varsize_FPR/tmp_fpr_PC_${JOB_ID}_${TASK_ID}

mkdir -p "$TMP"

############################################################
# Array range
############################################################

LOOPS_PER_ARRAY=20

START=$(( (TASK_ID - 1) * LOOPS_PER_ARRAY + 1 ))
END=$(( TASK_ID * LOOPS_PER_ARRAY ))

############################################################
# Software
############################################################

PLINK=/work/home/ac3xibpp15/software/bin/plink
THREADS=3

############################################################
# Input bfiles
############################################################

POOLED_ALL=$POOLED_DIR/EUR5K_AFR5K_shared_allvariants
POOLED_COMMON=$POOLED_DIR/EUR5K_AFR5K_shared_common
POOLED_RARE=$POOLED_DIR/EUR5K_AFR5K_shared_rare

EUR10K_ALL=$EUR10K_DIR/EUR10K_shared_allvariants
EUR10K_COMMON=$EUR10K_DIR/EUR10K_shared_common
EUR10K_RARE=$EUR10K_DIR/EUR10K_shared_rare

############################################################
# Common-variant PC covariate files
############################################################

POOLED_COVAR=$PCA_DIR/pooled_common.PC1_10.covariates.txt
EUR10K_COVAR=$PCA_DIR/EUR10K_common.PC1_10.covariates.txt

PC_NAMES=PC1,PC2,PC3,PC4,PC5,PC6,PC7,PC8,PC9,PC10

############################################################
# Output files
############################################################

POOLED_ALL_OUT=$RESULT_DIR/pooled_allvariants_minP_${TASK_ID}.txt
POOLED_COMMON_OUT=$RESULT_DIR/pooled_common_minP_${TASK_ID}.txt
POOLED_RARE_OUT=$RESULT_DIR/pooled_rare_minP_${TASK_ID}.txt

EUR10K_ALL_OUT=$RESULT_DIR/EUR10K_allvariants_minP_${TASK_ID}.txt
EUR10K_COMMON_OUT=$RESULT_DIR/EUR10K_common_minP_${TASK_ID}.txt
EUR10K_RARE_OUT=$RESULT_DIR/EUR10K_rare_minP_${TASK_ID}.txt

############################################################
# Number of phenotype columns
############################################################

COLS=$(head -1 "$CSV" | awk -F',' '{print NF}')

############################################################
# Fatal-error handler
############################################################

fatal_exit()
{
    echo
    echo "[FATAL ERROR] $1"
    echo "[ABORT] TASK_ID=$TASK_ID"
    echo "[TMP retained at] $TMP"
    exit 1
}

############################################################
# Check bfile
############################################################

check_bfile()
{
    local BFILE=$1
    local LABEL=$2

    if [ ! -s "${BFILE}.bed" ] || [ ! -s "${BFILE}.bim" ] || [ ! -s "${BFILE}.fam" ]; then
        fatal_exit "Incomplete bfile for ${LABEL}: ${BFILE}"
    fi
}

############################################################
# Check covariate file
############################################################

check_covar()
{
    local COVAR=$1
    local LABEL=$2

    if [ ! -s "$COVAR" ]; then
        fatal_exit "Missing covariate file for ${LABEL}: $COVAR"
    fi

    for PC in PC1 PC2 PC3 PC4 PC5 PC6 PC7 PC8 PC9 PC10; do
        if ! head -1 "$COVAR" | tr '\t' '\n' | grep -qx "$PC"; then
            fatal_exit "Column ${PC} not found in covariate file for ${LABEL}: $COVAR"
        fi
    done
}

############################################################
# Count samples in fam or covar
############################################################

count_fam_samples()
{
    local BFILE=$1
    wc -l < "${BFILE}.fam"
}

count_covar_samples()
{
    local COVAR=$1
    awk 'NR > 1 {n++} END {print n + 0}' "$COVAR"
}

############################################################
# Check inputs
############################################################

if [ ! -s "$CSV" ]; then
    fatal_exit "Phenotype CSV does not exist or is empty: $CSV"
fi

if [ ! -x "$PLINK" ]; then
    fatal_exit "PLINK is not executable: $PLINK"
fi

check_bfile "$POOLED_ALL" "pooled allvariants"
check_bfile "$POOLED_COMMON" "pooled common"
check_bfile "$POOLED_RARE" "pooled rare"

check_bfile "$EUR10K_ALL" "EUR10K allvariants"
check_bfile "$EUR10K_COMMON" "EUR10K common"
check_bfile "$EUR10K_RARE" "EUR10K rare"

check_covar "$POOLED_COVAR" "pooled common PC"
check_covar "$EUR10K_COVAR" "EUR10K common PC"

N_POOLED=$(count_fam_samples "$POOLED_COMMON")
N_POOLED_COVAR=$(count_covar_samples "$POOLED_COVAR")

if [ "$N_POOLED" -ne "$N_POOLED_COVAR" ]; then
    fatal_exit "Sample count mismatch for pooled covariates: fam=${N_POOLED}, covar=${N_POOLED_COVAR}"
fi

N_EUR10K=$(count_fam_samples "$EUR10K_COMMON")
N_EUR10K_COVAR=$(count_covar_samples "$EUR10K_COVAR")

if [ "$N_EUR10K" -ne "$N_EUR10K_COVAR" ]; then
    fatal_exit "Sample count mismatch for EUR10K covariates: fam=${N_EUR10K}, covar=${N_EUR10K_COVAR}"
fi

############################################################
# Output headers
############################################################

printf "loop\tlead_SNP\tlead_P\n" > "$POOLED_ALL_OUT"
printf "loop\tlead_SNP\tlead_P\n" > "$POOLED_COMMON_OUT"
printf "loop\tlead_SNP\tlead_P\n" > "$POOLED_RARE_OUT"

printf "loop\tlead_SNP\tlead_P\n" > "$EUR10K_ALL_OUT"
printf "loop\tlead_SNP\tlead_P\n" > "$EUR10K_COMMON_OUT"
printf "loop\tlead_SNP\tlead_P\n" > "$EUR10K_RARE_OUT"

############################################################
# Run one GWAS
############################################################

run_one_gwas()
{
    local GROUP=$1
    local TYPE=$2
    local LOOP_ID=$3
    local BFILE=$4
    local COVAR_FILE=$5
    local PHENO_FILE=$6
    local OUT_FILE=$7

    local TYPE_DIR
    local N_ID
    local N_PHENO
    local FILE
    local P_COL
    local ID_COL
    local TEST_COL
    local LEAD_LINE

    TYPE_DIR=$TMP/loop_${LOOP_ID}/${GROUP}_${TYPE}

    mkdir -p "$TYPE_DIR"

    echo
    echo "============================================================"
    echo "[INFO] Group: $GROUP"
    echo "[INFO] Variant type: $TYPE"
    echo "[INFO] Phenotype column: $LOOP_ID"
    echo "[INFO] Bfile: $BFILE"
    echo "[INFO] Covariates: $COVAR_FILE"
    echo "============================================================"

    ########################################################
    # Extract FID and IID from fam
    ########################################################

    awk 'BEGIN{OFS="	"}{print $1,$2}' "${BFILE}.fam" > "$TYPE_DIR/fid_iid.txt"

    ########################################################
    # Check sample number
    ########################################################

    N_ID=$(wc -l < "$TYPE_DIR/fid_iid.txt")
    N_PHENO=$(wc -l < "$PHENO_FILE")

    echo "[INFO] GROUP=$GROUP TYPE=$TYPE N_ID=$N_ID"
    echo "[INFO] GROUP=$GROUP TYPE=$TYPE N_PHENO=$N_PHENO"

    if [ "$N_ID" -ne "$N_PHENO" ]; then
        fatal_exit "Sample number mismatch for group=$GROUP type=$TYPE loop=$LOOP_ID: fam=$N_ID phenotype=$N_PHENO"
    fi

    ########################################################
    # Construct phenotype file
    ########################################################

    printf "FID\tIID\tPHENO\n" > "$TYPE_DIR/sim.phen"

    paste "$TYPE_DIR/fid_iid.txt" "$PHENO_FILE" >> "$TYPE_DIR/sim.phen"

    ########################################################
    # Run PLINK 1.9 GWAS with PC1-PC10
    ########################################################

    echo "[INFO] Running PLINK for group=$GROUP type=$TYPE loop=$LOOP_ID"
    date

    "$PLINK" \
        --bfile "$BFILE" \
        --pheno "$TYPE_DIR/sim.phen" \
        --pheno-name PHENO \
        --covar "$COVAR_FILE" \
        --covar-name "$PC_NAMES" \
        --linear hide-covar \
        --allow-no-sex \
        --threads "$THREADS" \
        --out "$TYPE_DIR/gwas"

    ########################################################
    # Check GWAS output
    ########################################################

    FILE=$TYPE_DIR/gwas.assoc.linear

    if [ ! -f "$FILE" ]; then
        echo "[ERROR] GWAS file not found: $FILE"
        echo "[DEBUG] Directory contents:"
        ls -lh "$TYPE_DIR"
        fatal_exit "Missing GWAS output for group=$GROUP type=$TYPE loop=$LOOP_ID"
    fi

    if [ ! -s "$FILE" ]; then
        fatal_exit "GWAS output is empty for group=$GROUP type=$TYPE loop=$LOOP_ID"
    fi

    ########################################################
    # Detect P-value column and SNP ID column
    ########################################################

    P_COL=$(head -1 "$FILE" | awk '
    {
        for (i = 1; i <= NF; i++) {
            if ($i == "P") {
                print i
                exit
            }
        }
    }')

    ID_COL=$(head -1 "$FILE" | awk '
    {
        for (i = 1; i <= NF; i++) {
            if ($i == "SNP") {
                print i
                exit
            }
        }
    }')

    TEST_COL=$(head -1 "$FILE" | awk '
    {
        for (i = 1; i <= NF; i++) {
            if ($i == "TEST") {
                print i
                exit
            }
        }
    }')

    if [ -z "$P_COL" ]; then
        fatal_exit "Cannot detect P column for group=$GROUP type=$TYPE loop=$LOOP_ID"
    fi

    if [ -z "$ID_COL" ]; then
        fatal_exit "Cannot detect SNP column for group=$GROUP type=$TYPE loop=$LOOP_ID"
    fi

    if [ -z "$TEST_COL" ]; then
        fatal_exit "Cannot detect TEST column for group=$GROUP type=$TYPE loop=$LOOP_ID"
    fi

    ########################################################
    # Extract lead SNP with the smallest P value
    ########################################################

    LEAD_LINE=$(awk -v loop="$LOOP_ID" -v pcol="$P_COL" -v idcol="$ID_COL" -v testcol="$TEST_COL" '
    NR > 1 && $testcol == "ADD" && $pcol != "NA" && $pcol != "." {
        p = $pcol + 0

        if (min == "" || p < min) {
            min = p
            lead = $idcol
        }
    }
    END {
        if (lead != "") {
            print loop"\t"lead"\t"min
        }
    }
    ' "$FILE")

    if [ -z "$LEAD_LINE" ]; then
        printf "%s\tNO_VALID_SNP\tNA\n" "$LOOP_ID" >> "$OUT_FILE"
        echo "[WARNING] No valid SNP result for group=$GROUP type=$TYPE loop=$LOOP_ID"
    else
        printf "%s\n" "$LEAD_LINE" >> "$OUT_FILE"
        echo "[INFO] Lead result: $LEAD_LINE"
    fi

    echo "[INFO] GWAS completed for group=$GROUP type=$TYPE loop=$LOOP_ID"

    rm -rf "$TYPE_DIR"
}

############################################################
# Main loop
############################################################

echo
echo "============================================================"
echo "[INFO] Matched variant-size FPR GWAS with PC1-PC10 started"
echo "[INFO] TASK_ID: $TASK_ID"
echo "[INFO] Phenotype CSV: $CSV"
echo "[INFO] Loops per array: $LOOPS_PER_ARRAY"
echo "[INFO] Phenotype range: $START-$END"
echo "[INFO] Result directory: $RESULT_DIR"
echo "[INFO] Pooled PC file: $POOLED_COVAR"
echo "[INFO] EUR10K PC file: $EUR10K_COVAR"
echo "============================================================"

for ((i=START; i<=END; i++)); do

    echo
    echo "############################################################"
    echo "[INFO] LOOP START: $i"
    echo "############################################################"

    LOOP_DIR=$TMP/loop_${i}

    mkdir -p "$LOOP_DIR"

    PHO_COL=$i
    PHENO_FILE=$LOOP_DIR/phenos.txt

    echo "[INFO] Phenotype column: $PHO_COL"

    ########################################################
    # Check phenotype-column range
    ########################################################

    if [ "$PHO_COL" -gt "$COLS" ]; then

        echo "[SKIP] Phenotype column $PHO_COL exceeds CSV column count $COLS"

        printf "%s\tOUT_OF_RANGE\tNA\n" "$i" >> "$POOLED_ALL_OUT"
        printf "%s\tOUT_OF_RANGE\tNA\n" "$i" >> "$POOLED_COMMON_OUT"
        printf "%s\tOUT_OF_RANGE\tNA\n" "$i" >> "$POOLED_RARE_OUT"

        printf "%s\tOUT_OF_RANGE\tNA\n" "$i" >> "$EUR10K_ALL_OUT"
        printf "%s\tOUT_OF_RANGE\tNA\n" "$i" >> "$EUR10K_COMMON_OUT"
        printf "%s\tOUT_OF_RANGE\tNA\n" "$i" >> "$EUR10K_RARE_OUT"

        rm -rf "$LOOP_DIR"

        continue
    fi

    ########################################################
    # Extract phenotype column from CSV
    ########################################################

    tail -n +2 "$CSV" \
        | cut -d',' -f"$PHO_COL" \
        | tr -d '"' \
        | awk 'NF > 0' \
        > "$PHENO_FILE"

    if [ ! -s "$PHENO_FILE" ]; then
        fatal_exit "Phenotype extraction failed at loop $i"
    fi

    ########################################################
    # Pooled EUR5K + AFR5K GWAS
    ########################################################

    run_one_gwas \
        pooled \
        allvariants \
        "$i" \
        "$POOLED_ALL" \
        "$POOLED_COVAR" \
        "$PHENO_FILE" \
        "$POOLED_ALL_OUT"

    run_one_gwas \
        pooled \
        common \
        "$i" \
        "$POOLED_COMMON" \
        "$POOLED_COVAR" \
        "$PHENO_FILE" \
        "$POOLED_COMMON_OUT"

    run_one_gwas \
        pooled \
        rare \
        "$i" \
        "$POOLED_RARE" \
        "$POOLED_COVAR" \
        "$PHENO_FILE" \
        "$POOLED_RARE_OUT"

    ########################################################
    # EUR10K GWAS
    ########################################################

    run_one_gwas \
        EUR10K \
        allvariants \
        "$i" \
        "$EUR10K_ALL" \
        "$EUR10K_COVAR" \
        "$PHENO_FILE" \
        "$EUR10K_ALL_OUT"

    run_one_gwas \
        EUR10K \
        common \
        "$i" \
        "$EUR10K_COMMON" \
        "$EUR10K_COVAR" \
        "$PHENO_FILE" \
        "$EUR10K_COMMON_OUT"

    run_one_gwas \
        EUR10K \
        rare \
        "$i" \
        "$EUR10K_RARE" \
        "$EUR10K_COVAR" \
        "$PHENO_FILE" \
        "$EUR10K_RARE_OUT"

    echo
    echo "############################################################"
    echo "[INFO] LOOP END: $i"
    echo "############################################################"

    rm -rf "$LOOP_DIR"

done

############################################################
# Cleanup
############################################################

rm -rf "$TMP"

############################################################
# Final message
############################################################

echo
echo "============================================================"
echo "[INFO] TASK COMPLETED"
echo "[INFO] Array task: $TASK_ID"
echo "[INFO] Phenotype range: $START-$END"
echo "[INFO] Result directory: $RESULT_DIR"
echo
echo "[INFO] Output files:"
echo "$POOLED_ALL_OUT"
echo "$POOLED_COMMON_OUT"
echo "$POOLED_RARE_OUT"
echo "$EUR10K_ALL_OUT"
echo "$EUR10K_COMMON_OUT"
echo "$EUR10K_RARE_OUT"
echo "============================================================"

date
