#!/usr/bin/env bash
set -euo pipefail
export LC_ALL=C

############################################################
# Merge ADD4K FPR array outputs by exact filename prefixes.
#
# Fixed version:
#   - avoids `sort | head` under `set -o pipefail`
#   - avoids `comm` with numerically sorted loop IDs
#
# Inputs:
#   /work/home/chengzesong/simu_gwas/add4k_fpr/pooled_results
#   /work/home/chengzesong/simu_gwas/add4k_fpr/eur_results
#
# Each prefix must contain task files 1-50.
#
# Expected merged result:
#   4000 rows
#   loops 1001-5000 exactly once
#   header: loop  lead_SNP  lead_P
############################################################

ROOT="/work/home/chengzesong/simu_gwas/add4k_fpr"

POOLED_DIR="${ROOT}/pooled_results"
EUR_DIR="${ROOT}/eur_results"

OUT_DIR="${ROOT}/merged_results"
mkdir -p "${OUT_DIR}"

N_TASKS=50
EXPECTED_ROWS=4000
EXPECTED_FIRST_LOOP=1001
EXPECTED_LAST_LOOP=5000
EXPECTED_HEADER=$'loop\tlead_SNP\tlead_P'


############################################################
# Merge one exact prefix
############################################################

merge_one_prefix()
{
    local IN_DIR=$1
    local PREFIX=$2
    local OUT_FILE=$3

    echo
    echo "============================================================"
    echo "[INFO] Prefix     : ${PREFIX}"
    echo "[INFO] Input dir  : ${IN_DIR}"
    echo "[INFO] Output file: ${OUT_FILE}"
    echo "============================================================"

    local TMP_DATA
    local TMP_SORTED

    TMP_DATA=$(mktemp)
    TMP_SORTED=$(mktemp)

    ########################################################
    # 1. Require all task files 1-50 and identical headers
    ########################################################

    local TASK_ID
    local FILE
    local HEADER

    for TASK_ID in $(seq 1 "${N_TASKS}"); do

        FILE="${IN_DIR}/${PREFIX}_${TASK_ID}.txt"

        if [ ! -s "${FILE}" ]; then
            echo "[ERROR] Missing or empty file:"
            echo "        ${FILE}"
            rm -f "${TMP_DATA}" "${TMP_SORTED}"
            exit 1
        fi

        HEADER=$(head -n 1 "${FILE}" | tr -d '\r')

        if [ "${HEADER}" != "${EXPECTED_HEADER}" ]; then
            echo "[ERROR] Header mismatch:"
            echo "        ${FILE}"
            echo "[EXPECTED] ${EXPECTED_HEADER}"
            echo "[OBSERVED] ${HEADER}"
            rm -f "${TMP_DATA}" "${TMP_SORTED}"
            exit 1
        fi

        awk 'NR > 1' "${FILE}" >> "${TMP_DATA}"

    done

    ########################################################
    # 2. Check total row number
    ########################################################

    local N_ROWS
    N_ROWS=$(wc -l < "${TMP_DATA}")

    echo "[INFO] Total data rows collected: ${N_ROWS}"

    if [ "${N_ROWS}" -ne "${EXPECTED_ROWS}" ]; then
        echo "[ERROR] Expected ${EXPECTED_ROWS} rows, observed ${N_ROWS}"
        rm -f "${TMP_DATA}" "${TMP_SORTED}"
        exit 1
    fi

    ########################################################
    # 3. Validate loop IDs:
    #    - numeric
    #    - within 1001-5000
    #    - no duplicate
    #    - no missing loop
    #
    # Do this in ONE awk pass to avoid pipefail/SIGPIPE issues.
    ########################################################

    awk -F'\t' \
        -v first="${EXPECTED_FIRST_LOOP}" \
        -v last="${EXPECTED_LAST_LOOP}" '
    BEGIN {
        bad = 0
    }

    {
        loop = $1

        if (loop !~ /^[0-9]+$/) {
            print "[ERROR] Non-numeric loop ID at data row " NR ": " loop > "/dev/stderr"
            bad = 1
            next
        }

        loop += 0

        if (loop < first || loop > last) {
            print "[ERROR] Loop ID outside expected range at data row " NR ": " loop > "/dev/stderr"
            bad = 1
        }

        if (seen[loop]++) {
            print "[ERROR] Duplicate loop ID: " loop > "/dev/stderr"
            bad = 1
        }
    }

    END {
        for (i = first; i <= last; i++) {
            if (!(i in seen)) {
                print "[ERROR] Missing loop ID: " i > "/dev/stderr"
                bad = 1
            }
        }

        exit(bad ? 1 : 0)
    }
    ' "${TMP_DATA}" || {
        rm -f "${TMP_DATA}" "${TMP_SORTED}"
        exit 1
    }

    echo "[INFO] Loop QC passed: ${EXPECTED_FIRST_LOOP}-${EXPECTED_LAST_LOOP}, no duplicates, no missing loops"

    ########################################################
    # 4. Sort rows numerically by loop
    ########################################################

    sort -t $'\t' -k1,1n "${TMP_DATA}" > "${TMP_SORTED}"

    ########################################################
    # 5. Write final merged file
    ########################################################

    {
        printf "%s\n" "${EXPECTED_HEADER}"
        cat "${TMP_SORTED}"
    } > "${OUT_FILE}"

    ########################################################
    # 6. Final QC of written file
    ########################################################

    local FINAL_ROWS
    local FIRST_LOOP
    local LAST_LOOP

    FINAL_ROWS=$(( $(wc -l < "${OUT_FILE}") - 1 ))

    read -r FIRST_LOOP LAST_LOOP < <(
        awk -F'\t' '
        NR == 2 {
            first = $1
        }
        NR > 1 {
            last = $1
        }
        END {
            print first, last
        }
        ' "${OUT_FILE}"
    )

    if [ "${FINAL_ROWS}" -ne "${EXPECTED_ROWS}" ]; then
        echo "[ERROR] Final merged file has ${FINAL_ROWS} data rows; expected ${EXPECTED_ROWS}"
        rm -f "${TMP_DATA}" "${TMP_SORTED}"
        exit 1
    fi

    if [ "${FIRST_LOOP}" -ne "${EXPECTED_FIRST_LOOP}" ] || \
       [ "${LAST_LOOP}" -ne "${EXPECTED_LAST_LOOP}" ]; then
        echo "[ERROR] Final merged loop range is ${FIRST_LOOP}-${LAST_LOOP}; expected ${EXPECTED_FIRST_LOOP}-${EXPECTED_LAST_LOOP}"
        rm -f "${TMP_DATA}" "${TMP_SORTED}"
        exit 1
    fi

    rm -f "${TMP_DATA}" "${TMP_SORTED}"

    echo "[DONE] ${OUT_FILE}"
    echo "[INFO] Final data rows: ${FINAL_ROWS}"
    echo "[INFO] Loop range     : ${FIRST_LOOP}-${LAST_LOOP}"
}


############################################################
# Pooled EUR5K + AFR5K
############################################################

merge_one_prefix \
    "${POOLED_DIR}" \
    "pooled_allvar_minP" \
    "${OUT_DIR}/pooled_allvar_minP_1001_5000.txt"

merge_one_prefix \
    "${POOLED_DIR}" \
    "pooled_common_minP" \
    "${OUT_DIR}/pooled_common_minP_1001_5000.txt"

merge_one_prefix \
    "${POOLED_DIR}" \
    "pooled_rare_minP" \
    "${OUT_DIR}/pooled_rare_minP_1001_5000.txt"


############################################################
# EUR10K
############################################################

merge_one_prefix \
    "${EUR_DIR}" \
    "allvariants_EUR_minP" \
    "${OUT_DIR}/allvariants_EUR_minP_1001_5000.txt"

merge_one_prefix \
    "${EUR_DIR}" \
    "common_EUR_minP" \
    "${OUT_DIR}/common_EUR_minP_1001_5000.txt"

merge_one_prefix \
    "${EUR_DIR}" \
    "rare_EUR_minP" \
    "${OUT_DIR}/rare_EUR_minP_1001_5000.txt"


############################################################
# Final report
############################################################

echo
echo "============================================================"
echo "[DONE] All six ADD4K FPR result sets were merged."
echo "[INFO] Output directory:"
echo "       ${OUT_DIR}"
echo
echo "[INFO] Merged files:"
echo "  ${OUT_DIR}/pooled_allvar_minP_1001_5000.txt"
echo "  ${OUT_DIR}/pooled_common_minP_1001_5000.txt"
echo "  ${OUT_DIR}/pooled_rare_minP_1001_5000.txt"
echo "  ${OUT_DIR}/allvariants_EUR_minP_1001_5000.txt"
echo "  ${OUT_DIR}/common_EUR_minP_1001_5000.txt"
echo "  ${OUT_DIR}/rare_EUR_minP_1001_5000.txt"
echo "============================================================"
