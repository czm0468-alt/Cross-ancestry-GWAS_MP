#!/bin/bash
#SBATCH --job-name=match_varsize_commonPCA
#SBATCH --mem=120G
#SBATCH --cpus-per-task=16
#SBATCH --time=24:00:00
#SBATCH --output=/work/home/chengzesong/simu_gwas/logs/match_varsize_commonPCA_%j.log
#SBATCH --error=/work/home/chengzesong/simu_gwas/logs/match_varsize_commonPCA_%j.err

set -euo pipefail

############################################################
# PCA for matched variant-size FPR analysis
#
# Principle:
#   PC is used to adjust for sample structure, not variant class.
#   Therefore, one common-variant PCA is calculated for each
#   sample set, and the same PC1-PC10 are used for allvariants,
#   common and rare GWAS within that sample set.
#
# PCA inputs:
#   1. EUR5K + AFR5K pooled shared common variants
#   2. EUR10K shared common variants
#
# Outputs:
#   pooled_common.PC1_10.covariates.txt
#   EUR10K_common.PC1_10.covariates.txt
############################################################

############################################################
# Paths
############################################################

ROOT=/work/home/chengzesong/simu_gwas

BFILE_ROOT=$ROOT/match_varsize_FPR/bfile

POOLED_DIR=$BFILE_ROOT/merged_EUR5K_AFR5K_shared_variants
EUR10K_DIR=$BFILE_ROOT/EUR10K_shared_variants

PCA_DIR=$ROOT/match_varsize_FPR/pca
TMP=$ROOT/match_varsize_FPR/tmp_commonPCA_${SLURM_JOB_ID:-manual}

mkdir -p "$ROOT/logs"
mkdir -p "$PCA_DIR"
mkdir -p "$TMP"

############################################################
# Software
############################################################

PLINK=/work/home/ac3xibpp15/software/bin/plink
THREADS=5

############################################################
# Input bfiles for PCA
############################################################

POOLED_COMMON=$POOLED_DIR/EUR5K_AFR5K_shared_common
EUR10K_COMMON=$EUR10K_DIR/EUR10K_shared_common

############################################################
# Fatal-error handler
############################################################

fatal_exit()
{
    echo
    echo "[FATAL ERROR] $1"
    echo "[TMP retained at] $TMP"
    exit 1
}

############################################################
# Check bfile
############################################################

check_bfile()
{
    local BFILE=$1
    local LABEL=$2

    if [ ! -s "${BFILE}.bed" ] || [ ! -s "${BFILE}.bim" ] || [ ! -s "${BFILE}.fam" ]; then
        fatal_exit "Incomplete bfile for ${LABEL}: ${BFILE}"
    fi
}

############################################################
# Count samples in fam
############################################################

count_fam_samples()
{
    local BFILE=$1
    wc -l < "${BFILE}.fam"
}

############################################################
# Convert PLINK 1.9 eigenvec to covariate file
############################################################

make_covar_from_eigenvec()
{
    local EIGENVEC=$1
    local COVAR=$2

    awk '
    BEGIN {
        OFS = "\t"
        print "FID", "IID", "PC1", "PC2", "PC3", "PC4", "PC5", "PC6", "PC7", "PC8", "PC9", "PC10"
    }
    NF >= 12 {
        print $1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12
    }
    ' "$EIGENVEC" > "$COVAR"

    if [ ! -s "$COVAR" ]; then
        fatal_exit "Covariate file was not generated: $COVAR"
    fi
}

############################################################
# Run PCA for one sample set
#
# Arguments:
#   1. label
#   2. bfile prefix
############################################################

run_one_pca()
{
    local LABEL=$1
    local BFILE=$2

    local WORK_DIR=$TMP/$LABEL
    local PRUNE_PREFIX=$WORK_DIR/${LABEL}.prune
    local PCA_PREFIX=$WORK_DIR/${LABEL}.pca
    local COVAR_OUT=$PCA_DIR/${LABEL}.PC1_10.covariates.txt
    local N_SAMPLE
    local N_COVAR
    local N_PRUNED

    mkdir -p "$WORK_DIR"

    echo
    echo "============================================================"
    echo "[INFO] Running common-variant PCA"
    echo "[INFO] Label: $LABEL"
    echo "[INFO] Input bfile: $BFILE"
    echo "[INFO] Output covariate file: $COVAR_OUT"
    echo "============================================================"

    check_bfile "$BFILE" "$LABEL"

    N_SAMPLE=$(count_fam_samples "$BFILE")
    echo "[INFO] Number of samples in ${LABEL}: $N_SAMPLE"

    ########################################################
    # LD pruning on common variants
    ########################################################

    "$PLINK" \
        --bfile "$BFILE" \
        --maf 0.01 \
        --geno 0.05 \
        --indep-pairwise 50 5 0.2 \
        --allow-no-sex \
        --threads "$THREADS" \
        --out "$PRUNE_PREFIX"

    if [ ! -s "${PRUNE_PREFIX}.prune.in" ]; then
        fatal_exit "No variants retained after LD pruning for ${LABEL}"
    fi

    N_PRUNED=$(wc -l < "${PRUNE_PREFIX}.prune.in")
    echo "[INFO] Number of variants retained for PCA in ${LABEL}: $N_PRUNED"

    ########################################################
    # PCA using pruned common variants
    ########################################################

    "$PLINK" \
        --bfile "$BFILE" \
        --extract "${PRUNE_PREFIX}.prune.in" \
        --pca 10 \
        --allow-no-sex \
        --threads "$THREADS" \
        --out "$PCA_PREFIX"

    if [ ! -s "${PCA_PREFIX}.eigenvec" ]; then
        fatal_exit "Missing eigenvec output for ${LABEL}: ${PCA_PREFIX}.eigenvec"
    fi

    make_covar_from_eigenvec "${PCA_PREFIX}.eigenvec" "$COVAR_OUT"

    N_COVAR=$(( $(wc -l < "$COVAR_OUT") - 1 ))

    if [ "$N_SAMPLE" -ne "$N_COVAR" ]; then
        fatal_exit "Sample count mismatch in PCA covariate file for ${LABEL}: fam=${N_SAMPLE}, covar=${N_COVAR}"
    fi

    echo
    echo "[INFO] PCA completed for ${LABEL}"
    echo "[INFO] Covariate file: $COVAR_OUT"
    echo "[INFO] Covariate sample count: $N_COVAR"
}

############################################################
# Main
############################################################

echo
 echo "============================================================"
echo "[INFO] Matched variant-size FPR PCA started"
echo "[INFO] Start time: $(date)"
echo "[INFO] PCA directory: $PCA_DIR"
echo "[INFO] Temporary directory: $TMP"
echo "============================================================"

if [ ! -x "$PLINK" ]; then
    fatal_exit "PLINK is not executable: $PLINK"
fi

run_one_pca "pooled_common" "$POOLED_COMMON"
run_one_pca "EUR10K_common" "$EUR10K_COMMON"

rm -rf "$TMP"

echo
echo "============================================================"
echo "[INFO] All PCA jobs completed successfully"
echo "[INFO] End time: $(date)"
echo
echo "[INFO] Output covariate files:"
echo "$PCA_DIR/pooled_common.PC1_10.covariates.txt"
echo "$PCA_DIR/EUR10K_common.PC1_10.covariates.txt"
echo "============================================================"
