############################################################
# COMPLETE SIMULATION ANALYSIS | GWAS 5000; NO SuSiE/SuSiEx
# Heritability unchanged. Ancestry-composition and matched FPR unchanged.
# Adapted from user's original full R analysis, preserving plotting modules.
############################################################
rm(list=ls()); gc()
suppressPackageStartupMessages(library(data.table))
ROOT <- "C:/Users/ASUS/Desktop/GWAS/gwas/模拟3"
FINAL <- file.path(ROOT,"results/new_results/real_final_plot")
ADD3K <- file.path(ROOT,"new_pooled/add3k")
STAGE <- file.path(FINAL,"_prepared_5000")
dir.create(STAGE,recursive=TRUE,showWarnings=FALSE)

read_batch <- function(file, label) {
 if (!file.exists(file)) stop("Missing ",label,": ",file)
 d <- fread(file,fill=TRUE)
 if (!"loop" %in% names(d)) stop("Missing loop column: ",file)
 d[,loop:=suppressWarnings(as.integer(loop))]
 if(anyNA(d$loop)) stop("Invalid loop: ",file)
 d
}
merge_5k <- function(paths, dst, label, batch_sizes) {
 dat <- Map(function(path,lab)read_batch(path,lab),paths,paste0(label," batch ",seq_along(paths)))
 ref <- names(dat[[1]])
 for(i in seq_along(dat)) {
   if (!setequal(names(dat[[i]]),ref)) stop("Column schema mismatch: ",label," batch ",i,
       " missing: ",paste(setdiff(ref,names(dat[[i]])),collapse=","),
       " extra: ",paste(setdiff(names(dat[[i]]),ref),collapse=","))
   setcolorder(dat[[i]],ref)
   if(uniqueN(dat[[i]]$loop)!=batch_sizes[i]) stop(label," batch ",i,
         " has ",uniqueN(dat[[i]]$loop)," unique loops, expected ",batch_sizes[i])
 }
 offset<-0L
 for(i in seq_along(dat)) {
   ids<-sort(unique(dat[[i]]$loop))
   n<-batch_sizes[i]
   if(identical(ids,seq_len(n))) dat[[i]][,loop:=loop+offset]
   else if(!identical(ids,seq.int(offset+1L,offset+n))) {
     stop("Unrecognised loop numbering for ",label," batch ",i,
          ": expected 1:",n," or ",offset+1L,":",offset+n)
   }
   offset<-offset+n
 }
 d<-rbindlist(dat,use.names=TRUE,fill=FALSE)
 if(!identical(sort(unique(d$loop)),seq_len(5000L))) stop("Incomplete 5000 loops: ",label)
 dir.create(dirname(dst),recursive=TRUE,showWarnings=FALSE)
 fwrite(d,dst,sep="\t",na="NA")
 message("[5000] ",label," -> ",dst," (",nrow(d)," rows)")
 invisible(dst)
}
# Original GWAS inputs contain 1000 loops each; add1k contains another 1000.
for(sp in list(
 c("common_EUR","new_EUR/common_EUR_sig.with_ld_r2.txt","new_EUR/add1k/common_EUR_sig.merged.with_ld_r2.txt","common_EUR.txt"),
 c("rare_EUR","new_EUR/rare_EUR_sig.with_ld_r2.txt","new_EUR/add1k/rare_EUR_sig.merged.with_ld_r2.txt","rare_EUR.txt"),
 c("common_pooled","new_pooled/common_pooled_ld.csv","new_pooled/add1k/common_pooled_sig.merged.with_ld_r2.txt","common_pooled.txt"),
 c("rare_pooled","new_pooled/rare_pooled_ld.csv","new_pooled/add1k/rare_pooled_sig.merged.with_ld_r2.txt","rare_pooled.txt")
)) merge_5k(c(file.path(ROOT,sp[2]),file.path(ROOT,sp[3]),file.path(ADD3K,sp[4])),
 file.path(STAGE,paste0(sp[1],"_5k.txt")),sp[1],c(1000L,1000L,3000L))


# Alias staged 5k files to original data basenames so GWAS grouping
# logic and original population labels remain unchanged.
ALIASES <- c(common_EUR='common_EUR_sig.with_ld_r2.txt',
             rare_EUR='rare_EUR_sig.with_ld_r2.txt',
             common_pooled='common_pooled_ld.csv',
             rare_pooled='rare_pooled_ld.csv')
for (nm in names(ALIASES)) {
  source <- file.path(STAGE,paste0(nm,'_5k.txt'))
  target <- file.path(STAGE,ALIASES[[nm]])
  if(!file.copy(source,target,overwrite=TRUE)) stop('Cannot create GWAS alias: ',target)
}


# ===== PRESERVED ORIGINAL GWAS MODULE 2 =====

rm(list = ls())
gc()

suppressPackageStartupMessages({
  library(data.table)
})

############################################################
# 1. Input files
############################################################

files <- c(
  "C:/Users/ASUS/Desktop/GWAS/gwas/模拟3/new_pooled/common_EUR6k_AFR4k_pooled_sig.with_ld_r2.txt",
  "C:/Users/ASUS/Desktop/GWAS/gwas/模拟3/new_pooled/common_EUR7k_AFR3k_pooled_sig.with_ld_r2.txt",
  "C:/Users/ASUS/Desktop/GWAS/gwas/模拟3/new_pooled/common_EUR8k_AFR2k_pooled_sig.with_ld_r2.txt",
  "C:/Users/ASUS/Desktop/GWAS/gwas/模拟3/new_pooled/common_EUR9k_AFR1k_pooled_sig.with_ld_r2.txt",
  "C:/Users/ASUS/Desktop/GWAS/gwas/模拟3/new_pooled/rare_EUR6k_AFR4k_pooled_sig.with_ld_r2.txt",
  "C:/Users/ASUS/Desktop/GWAS/gwas/模拟3/new_pooled/rare_EUR7k_AFR3k_pooled_sig.with_ld_r2.txt",
  "C:/Users/ASUS/Desktop/GWAS/gwas/模拟3/new_pooled/rare_EUR8k_AFR2k_pooled_sig.with_ld_r2.txt",
  "C:/Users/ASUS/Desktop/GWAS/gwas/模拟3/new_pooled/rare_EUR9k_AFR1k_pooled_sig.with_ld_r2.txt",
  "C:/Users/ASUS/Desktop/GWAS/gwas/模拟3/results/new_results/real_final_plot/_prepared_5000/common_EUR_sig.with_ld_r2.txt",
  "C:/Users/ASUS/Desktop/GWAS/gwas/模拟3/results/new_results/real_final_plot/_prepared_5000/rare_EUR_sig.with_ld_r2.txt",
  "C:/Users/ASUS/Desktop/GWAS/gwas/模拟3/results/new_results/real_final_plot/_prepared_5000/common_pooled_ld.csv",
  "C:/Users/ASUS/Desktop/GWAS/gwas/模拟3/results/new_results/real_final_plot/_prepared_5000/rare_pooled_ld.csv"
)

OUT_DIR <- "C:/Users/ASUS/Desktop/GWAS/gwas/模拟3/results/new_results/real_final_plot"
dir.create(OUT_DIR, showWarnings = FALSE, recursive = TRUE)

############################################################
# 2. Settings
############################################################

P_THRESHOLD <- 5e-8

BP_BREAKS <- seq(0, 100000, length.out = 21)
COMMON_MAF_BREAKS <- seq(0, 0.05, length.out = 21)
RARE_MAF_BREAKS <- seq(0, 0.003, length.out = 21)
LD_THRESHOLDS <- seq(1, 0, by = -0.05)

REQUIRED_COLS <- c(
  "loop",
  "lead_SNP", "lead_CHR", "lead_BP", "lead_P", "lead_MAF",
  "causal_SNP", "causal_CHR", "causal_BP", "causal_P", "causal_MAF",
  "MAF_diff", "BP_diff", "ld_r2"
)

############################################################
# 3. Helper functions
############################################################

resolve_file <- function(file) {
  candidates <- unique(c(
    file,
    gsub("/dif_afr/", "/diff_afr/", file, fixed = TRUE),
    gsub("/diff_afr/", "/dif_afr/", file, fixed = TRUE)
  ))
  
  hit <- candidates[file.exists(candidates)]
  
  if (length(hit) == 0) {
    stop(
      "Input file does not exist. Tried:\n  ",
      paste(candidates, collapse = "\n  ")
    )
  }
  
  return(hit[1])
}

clean_population_name <- function(x) {
  x <- basename(x)
  x <- sub("\\.csv$", "", x)
  x <- sub("\\.txt$", "", x)
  x <- sub("\\.with_ld_r2$", "", x)
  x <- sub("_ld$", "", x)
  return(x)
}

get_variant_type <- function(population_name) {
  population_name <- as.character(population_name)[1]
  
  if (grepl("^common_", population_name)) return("common")
  if (grepl("^rare_", population_name)) return("rare")
  
  stop("Cannot infer variant type from file name: ", population_name)
}

get_analysis_group <- function(population_name) {
  population_name <- as.character(population_name)[1]
  
  if (grepl("_EUR_sig$", population_name)) return("EUR")
  if (grepl("_pooled", population_name)) return("pooled")
  
  return("unknown")
}

get_ancestry_composition <- function(population_name) {
  population_name <- as.character(population_name)[1]
  
  m <- regexec("EUR([0-9]+)k_AFR([0-9]+)k", population_name)
  r <- regmatches(population_name, m)[[1]]
  
  if (length(r) == 3) {
    return(paste0("EUR", r[2], "k_AFR", r[3], "k"))
  }
  
  if (grepl("_EUR_sig$", population_name)) {
    return("EUR10k")
  }
  
  if (grepl("_pooled$", population_name)) {
    return("EUR5k_AFR5k")
  }
  
  return("unknown")
}

standardise_column_names <- function(dt) {
  rename_map <- c(
    lead_snp = "lead_SNP",
    causal_snp = "causal_SNP",
    lead_p = "lead_P",
    causal_p = "causal_P",
    maf_diff = "MAF_diff",
    bp_diff = "BP_diff",
    LD_R2 = "ld_r2",
    r2 = "ld_r2"
  )
  
  old_names <- names(rename_map)
  
  for (old in old_names) {
    new <- rename_map[[old]]
    if (old %in% names(dt) && !(new %in% names(dt))) {
      setnames(dt, old, new)
    }
  }
  
  return(dt)
}

check_required_columns <- function(dt, file) {
  missing_cols <- setdiff(REQUIRED_COLS, names(dt))
  
  if (length(missing_cols) > 0) {
    stop(
      "Missing required columns in file:\n", file,
      "\nMissing columns: ", paste(missing_cols, collapse = ", "),
      "\nCurrent columns: ", paste(names(dt), collapse = ", ")
    )
  }
}

read_one_file <- function(file) {
  actual_file <- resolve_file(file)
  
  message("[INFO] Reading: ", actual_file)
  
  dt <- fread(actual_file, data.table = TRUE)
  dt <- standardise_column_names(dt)
  check_required_columns(dt, actual_file)
  
  pop_name <- clean_population_name(actual_file)
  var_type <- get_variant_type(pop_name)
  ana_group <- get_analysis_group(pop_name)
  anc_comp <- get_ancestry_composition(pop_name)
  
  dt[, population := pop_name]
  dt[, variant_type := var_type]
  dt[, analysis_group := ana_group]
  dt[, ancestry_composition := anc_comp]
  dt[, source_file := actual_file]
  
  numeric_cols <- c(
    "lead_BP", "lead_P", "lead_MAF",
    "causal_BP", "causal_P", "causal_MAF",
    "MAF_diff", "BP_diff", "ld_r2"
  )
  
  for (cc in numeric_cols) {
    dt[, (cc) := suppressWarnings(as.numeric(get(cc)))]
  }
  
  dt[!is.na(lead_SNP) & !is.na(causal_SNP) & lead_SNP == causal_SNP, ld_r2 := 1.0]
  
  return(dt)
}

############################################################
# 4. Cumulative functions
############################################################

make_cumulative_le <- function(dt, metric, breaks_vec) {
  groups <- unique(dt[, .(variant_type, analysis_group, ancestry_composition, population)])
  
  if (nrow(groups) == 0) {
    return(data.table())
  }
  
  out_list <- vector("list", nrow(groups))
  
  for (i in seq_len(nrow(groups))) {
    vt <- groups$variant_type[i]
    ag <- groups$analysis_group[i]
    ac <- groups$ancestry_composition[i]
    pp <- groups$population[i]
    
    tmp <- dt[
      variant_type == vt &
        analysis_group == ag &
        ancestry_composition == ac &
        population == pp
    ]
    
    x <- as.numeric(tmp[[metric]])
    denominator <- nrow(tmp)
    cumulative_count <- sapply(breaks_vec, function(th) sum(x <= th, na.rm = TRUE))
    
    if (denominator > 0) {
      cumulative_prop <- cumulative_count / denominator
      cumulative_percent <- cumulative_prop * 100
    } else {
      cumulative_prop <- rep(NA_real_, length(breaks_vec))
      cumulative_percent <- rep(NA_real_, length(breaks_vec))
    }
    
    out_list[[i]] <- data.table(
      variant_type = vt,
      analysis_group = ag,
      ancestry_composition = ac,
      population = pp,
      metric = metric,
      direction = "<=",
      threshold = breaks_vec,
      denominator = denominator,
      cumulative_count = cumulative_count,
      cumulative_prop = cumulative_prop,
      cumulative_percent = cumulative_percent
    )
  }
  
  rbindlist(out_list, use.names = TRUE, fill = TRUE)
}

make_cumulative_ld <- function(dt, thresholds) {
  ldt <- copy(dt)
  ldt <- ldt[!is.na(ld_r2)]
  
  groups <- unique(ldt[, .(variant_type, analysis_group, ancestry_composition, population)])
  
  if (nrow(groups) == 0) {
    return(data.table())
  }
  
  out_list <- vector("list", nrow(groups))
  
  for (i in seq_len(nrow(groups))) {
    vt <- groups$variant_type[i]
    ag <- groups$analysis_group[i]
    ac <- groups$ancestry_composition[i]
    pp <- groups$population[i]
    
    tmp <- ldt[
      variant_type == vt &
        analysis_group == ag &
        ancestry_composition == ac &
        population == pp
    ]
    
    x <- as.numeric(tmp$ld_r2)
    denominator <- length(x)
    cumulative_count <- sapply(thresholds, function(th) sum(x >= th, na.rm = TRUE))
    
    if (denominator > 0) {
      cumulative_prop <- cumulative_count / denominator
      cumulative_percent <- cumulative_prop * 100
    } else {
      cumulative_prop <- rep(NA_real_, length(thresholds))
      cumulative_percent <- rep(NA_real_, length(thresholds))
    }
    
    out_list[[i]] <- data.table(
      variant_type = vt,
      analysis_group = ag,
      ancestry_composition = ac,
      population = pp,
      metric = "ld_r2",
      direction = ">=",
      threshold = thresholds,
      denominator = denominator,
      cumulative_count = cumulative_count,
      cumulative_prop = cumulative_prop,
      cumulative_percent = cumulative_percent
    )
  }
  
  rbindlist(out_list, use.names = TRUE, fill = TRUE)
}

make_wide <- function(cum_dt, value_col) {
  if (nrow(cum_dt) == 0) {
    return(data.table())
  }
  
  dcast(
    cum_dt,
    variant_type + analysis_group + ancestry_composition + metric + direction + threshold ~ population,
    value.var = value_col
  )
}

find_first_threshold <- function(cum_dt, target_prop = 0.80) {
  if (nrow(cum_dt) == 0) {
    return(data.table())
  }
  
  tmp <- cum_dt[cumulative_prop >= target_prop]
  
  if (nrow(tmp) == 0) {
    return(data.table())
  }
  
  tmp[
    order(threshold),
    .SD[1],
    by = .(variant_type, analysis_group, ancestry_composition, population, metric, direction)
  ][
    , .(
      variant_type,
      analysis_group,
      ancestry_composition,
      population,
      metric,
      direction,
      first_threshold_reaching_80_percent = threshold,
      cumulative_prop,
      cumulative_percent,
      cumulative_count,
      denominator
    )
  ]
}

############################################################
# 5. Read all files
############################################################

message("============================================================")
message("[INFO] Reading input files")
message("============================================================")

dt_list <- lapply(files, read_one_file)
all_dt <- rbindlist(dt_list, use.names = TRUE, fill = TRUE)

############################################################
# 6. Filter significant GWAS associations
############################################################

all_dt[, is_significant := !is.na(lead_P) & lead_P < P_THRESHOLD &
         !is.na(lead_SNP) & lead_SNP != "" & lead_SNP != "." & lead_SNP != "NA" &
         lead_SNP != "NO_VALID_SNP"]

sig_dt <- all_dt[is_significant == TRUE]

if (nrow(sig_dt) == 0) {
  stop("No rows passed the significance filter lead_P < ", P_THRESHOLD)
}

message("[INFO] Total rows before filtering: ", nrow(all_dt))
message("[INFO] Rows with lead_P < ", P_THRESHOLD, ": ", nrow(sig_dt))

############################################################
# 7. Input summary before and after P-value filtering
############################################################

input_summary_all_rows <- all_dt[
  ,
  .(
    n_rows_all = .N,
    n_valid_lead_P_all = sum(!is.na(lead_P)),
    n_lead_P_lt_5e8 = sum(is_significant, na.rm = TRUE),
    prop_lead_P_lt_5e8 = sum(is_significant, na.rm = TRUE) / .N,
    percent_lead_P_lt_5e8 = sum(is_significant, na.rm = TRUE) / .N * 100
  ),
  by = .(variant_type, analysis_group, ancestry_composition, population, source_file)
]

setorder(input_summary_all_rows, variant_type, analysis_group, ancestry_composition, population)
fwrite(input_summary_all_rows, file.path(OUT_DIR, "input_file_summary_all_rows.csv"))

input_summary_Plt5e8 <- sig_dt[
  ,
  .(
    n_rows_Plt5e8 = .N,
    n_valid_BP_diff = sum(!is.na(BP_diff)),
    n_valid_MAF_diff = sum(!is.na(MAF_diff)),
    n_valid_ld_r2 = sum(!is.na(ld_r2)),
    n_exact_lead_causal = sum(lead_SNP == causal_SNP, na.rm = TRUE),
    exact_lead_causal_prop = sum(lead_SNP == causal_SNP, na.rm = TRUE) / .N,
    exact_lead_causal_percent = sum(lead_SNP == causal_SNP, na.rm = TRUE) / .N * 100
  ),
  by = .(variant_type, analysis_group, ancestry_composition, population, source_file)
]

setorder(input_summary_Plt5e8, variant_type, analysis_group, ancestry_composition, population)
fwrite(input_summary_Plt5e8, file.path(OUT_DIR, "input_file_summary_Plt5e8.csv"))

exact_match_summary_Plt5e8 <- input_summary_Plt5e8[
  ,
  .(
    variant_type,
    analysis_group,
    ancestry_composition,
    population,
    n_rows_Plt5e8,
    n_exact_lead_causal,
    exact_lead_causal_prop,
    exact_lead_causal_percent
  )
]

fwrite(exact_match_summary_Plt5e8, file.path(OUT_DIR, "exact_match_summary_Plt5e8.csv"))

############################################################
# 8. Cumulative BP_diff among lead_P < 5e-8 rows
############################################################

bp_cum <- make_cumulative_le(
  dt = sig_dt,
  metric = "BP_diff",
  breaks_vec = BP_BREAKS
)

setorder(bp_cum, variant_type, analysis_group, ancestry_composition, population, threshold)

fwrite(bp_cum, file.path(OUT_DIR, "cumulative_BP_diff_long_Plt5e8.csv"))
fwrite(make_wide(bp_cum, "cumulative_prop"), file.path(OUT_DIR, "cumulative_BP_diff_wide_prop_Plt5e8.csv"))
fwrite(make_wide(bp_cum, "cumulative_percent"), file.path(OUT_DIR, "cumulative_BP_diff_wide_percent_Plt5e8.csv"))

bp_threshold_80 <- find_first_threshold(bp_cum, target_prop = 0.80)
fwrite(bp_threshold_80, file.path(OUT_DIR, "BP_diff_first_threshold_reaching_80_percent_Plt5e8.csv"))

############################################################
# 9. Cumulative MAF_diff among lead_P < 5e-8 rows
############################################################

maf_cum_common <- make_cumulative_le(
  dt = sig_dt[variant_type == "common"],
  metric = "MAF_diff",
  breaks_vec = COMMON_MAF_BREAKS
)

maf_cum_rare <- make_cumulative_le(
  dt = sig_dt[variant_type == "rare"],
  metric = "MAF_diff",
  breaks_vec = RARE_MAF_BREAKS
)

maf_cum <- rbindlist(list(maf_cum_common, maf_cum_rare), use.names = TRUE, fill = TRUE)

setorder(maf_cum, variant_type, analysis_group, ancestry_composition, population, threshold)

fwrite(maf_cum, file.path(OUT_DIR, "cumulative_MAF_diff_long_Plt5e8.csv"))
fwrite(make_wide(maf_cum, "cumulative_prop"), file.path(OUT_DIR, "cumulative_MAF_diff_wide_prop_Plt5e8.csv"))
fwrite(make_wide(maf_cum, "cumulative_percent"), file.path(OUT_DIR, "cumulative_MAF_diff_wide_percent_Plt5e8.csv"))

maf_threshold_80 <- find_first_threshold(maf_cum, target_prop = 0.80)
fwrite(maf_threshold_80, file.path(OUT_DIR, "MAF_diff_first_threshold_reaching_80_percent_Plt5e8.csv"))

############################################################
# 10. Cumulative LD r2 among lead_P < 5e-8 rows
############################################################

ld_cum <- make_cumulative_ld(
  dt = sig_dt,
  thresholds = LD_THRESHOLDS
)

setorder(ld_cum, variant_type, analysis_group, ancestry_composition, population, -threshold)

fwrite(ld_cum, file.path(OUT_DIR, "cumulative_LD_r2_long_Plt5e8.csv"))
fwrite(make_wide(ld_cum, "cumulative_prop"), file.path(OUT_DIR, "cumulative_LD_r2_wide_prop_Plt5e8.csv"))
fwrite(make_wide(ld_cum, "cumulative_percent"), file.path(OUT_DIR, "cumulative_LD_r2_wide_percent_Plt5e8.csv"))

ld_previous_style <- ld_cum[
  ,
  .(
    threshold,
    cum_pct = cumulative_prop,
    population,
    variant_type,
    analysis_group,
    ancestry_composition,
    cumulative_count,
    denominator,
    cumulative_percent
  )
]

fwrite(ld_previous_style, file.path(OUT_DIR, "LD_r2_previous_style_long_Plt5e8.csv"))

############################################################
# 11. Previous-style wide BP and MAF tables
############################################################

bp_previous_style <- copy(bp_cum)
bp_previous_style[, value_name := paste0(population, "_bp_percentage")]
bp_previous_style_wide <- dcast(
  bp_previous_style,
  variant_type + analysis_group + ancestry_composition + metric + direction + threshold ~ value_name,
  value.var = "cumulative_prop"
)
fwrite(bp_previous_style_wide, file.path(OUT_DIR, "BP_diff_previous_style_wide_Plt5e8.csv"))

maf_previous_style <- copy(maf_cum)
maf_previous_style[, value_name := paste0(population, "_maf_percentage")]
maf_previous_style_wide <- dcast(
  maf_previous_style,
  variant_type + analysis_group + ancestry_composition + metric + direction + threshold ~ value_name,
  value.var = "cumulative_prop"
)
fwrite(maf_previous_style_wide, file.path(OUT_DIR, "MAF_diff_previous_style_wide_Plt5e8.csv"))

############################################################
# 12. Save filtered significant rows for traceability
############################################################

fwrite(sig_dt, file.path(OUT_DIR, "all_input_rows_after_leadP_filter_Plt5e8.csv"))

############################################################
# 13. Sanity check
############################################################

check_dt <- rbindlist(
  list(
    bp_cum[, .(metric, threshold, denominator, cumulative_count, cumulative_prop, cumulative_percent)],
    maf_cum[, .(metric, threshold, denominator, cumulative_count, cumulative_prop, cumulative_percent)],
    ld_cum[, .(metric, threshold, denominator, cumulative_count, cumulative_prop, cumulative_percent)]
  ),
  use.names = TRUE,
  fill = TRUE
)

check_dt[, recalculated_prop := fifelse(denominator > 0, cumulative_count / denominator, NA_real_)]
check_dt[, recalculated_percent := recalculated_prop * 100]
check_dt[, diff_prop := abs(cumulative_prop - recalculated_prop)]
check_dt[, diff_percent := abs(cumulative_percent - recalculated_percent)]

bad_check <- check_dt[
  (!is.na(diff_prop) & diff_prop > 1e-12) |
    (!is.na(diff_percent) & diff_percent > 1e-10)
]

if (nrow(bad_check) > 0) {
  fwrite(bad_check, file.path(OUT_DIR, "sanity_check_failed_rows.csv"))
  stop("Sanity check failed. Check: ", file.path(OUT_DIR, "sanity_check_failed_rows.csv"))
}

############################################################
# 14. Final message
############################################################

message("============================================================")
message("[INFO] All calculations finished")
message("[INFO] P-value filter: lead_P < ", P_THRESHOLD)
message("[INFO] Output directory:")
message(OUT_DIR)
message("============================================================")

print(input_summary_all_rows)
print(input_summary_Plt5e8)






























# ===== PRESERVED ORIGINAL GWAS MODULE 3 =====

rm(list = ls())
gc()

suppressPackageStartupMessages({
  library(data.table)
})

############################################################
# MAF-bin exact causal-variant identification
#
# Statistics are restricted to lead_P < 5e-8.
#
# Exact match is defined as:
#   MAF_diff == 0 and BP_diff == 0
#
# Common variants:
#   causal_MAF bins from 0 to 0.5, n_bins = 14
#
# Rare variants:
#   causal_MAF bins from 0.002 to 0.01, n_bins = 7
############################################################

############################################################
# 1. Input files
############################################################

files <- c(
  common_EUR = "C:/Users/ASUS/Desktop/GWAS/gwas/模拟3/results/new_results/real_final_plot/_prepared_5000/common_EUR_5k.txt",
  rare_EUR = "C:/Users/ASUS/Desktop/GWAS/gwas/模拟3/results/new_results/real_final_plot/_prepared_5000/rare_EUR_5k.txt",
  common_pooled = "C:/Users/ASUS/Desktop/GWAS/gwas/模拟3/results/new_results/real_final_plot/_prepared_5000/common_pooled_5k.txt",
  rare_pooled = "C:/Users/ASUS/Desktop/GWAS/gwas/模拟3/results/new_results/real_final_plot/_prepared_5000/rare_pooled_5k.txt"
)

OUT_DIR <- "C:/Users/ASUS/Desktop/GWAS/gwas/模拟3/results/new_results/real_final_plot"
dir.create(OUT_DIR, showWarnings = FALSE, recursive = TRUE)

P_THRESHOLD <- 5e-8

############################################################
# 2. Required columns
############################################################

required_cols <- c(
  "lead_P",
  "causal_MAF",
  "MAF_diff",
  "BP_diff"
)

############################################################
# 3. Helper functions
############################################################

get_variant_type <- function(dataset) {
  if (grepl("^common_", dataset)) return("common")
  if (grepl("^rare_", dataset)) return("rare")
  stop("Cannot infer variant type from dataset name: ", dataset)
}

get_analysis_group <- function(dataset) {
  if (grepl("_EUR$", dataset)) return("EUR")
  if (grepl("_pooled$", dataset)) return("pooled")
  stop("Cannot infer analysis group from dataset name: ", dataset)
}

get_breaks <- function(variant_type) {
  if (variant_type == "common") {
    return(seq(0, 0.5, length.out = 16 + 1))
  }
  
  if (variant_type == "rare") {
    return(seq(0.002, 0.01, length.out = 5 + 1))
  }
  
  stop("Unknown variant type: ", variant_type)
}

check_required_cols <- function(dt, file) {
  missing_cols <- setdiff(required_cols, names(dt))
  
  if (length(missing_cols) > 0) {
    stop(
      "Missing required columns in file:\n", file,
      "\nMissing columns: ", paste(missing_cols, collapse = ", "),
      "\nCurrent columns: ", paste(names(dt), collapse = ", ")
    )
  }
}

read_one_file <- function(dataset, file) {
  message("============================================================")
  message("[INFO] Reading dataset: ", dataset)
  message("[INFO] File: ", file)
  message("============================================================")
  
  if (!file.exists(file)) {
    stop("Input file does not exist: ", file)
  }
  
  dt <- fread(file, data.table = TRUE)
  check_required_cols(dt, file)
  
  variant_type <- get_variant_type(dataset)
  analysis_group <- get_analysis_group(dataset)
  
  dt[, dataset := dataset]
  dt[, variant_type := variant_type]
  dt[, analysis_group := analysis_group]
  dt[, source_file := file]
  
  dt[, lead_P := suppressWarnings(as.numeric(lead_P))]
  dt[, causal_MAF := suppressWarnings(as.numeric(causal_MAF))]
  dt[, MAF_diff := suppressWarnings(as.numeric(MAF_diff))]
  dt[, BP_diff := suppressWarnings(as.numeric(BP_diff))]
  
  return(dt)
}

calc_prop <- function(dt, variant_type, dataset, analysis_group) {
  breaks <- get_breaks(variant_type)
  labels <- sprintf("%.3f-%.3f", head(breaks, -1), tail(breaks, -1))
  
  # right = FALSE follows the user's original logic.
  # Include causal_MAF == max(breaks) in the last bin to avoid losing MAF = 0.5 or 0.01.
  dt[, maf_bin := cut(
    causal_MAF,
    breaks = breaks,
    labels = labels,
    include.lowest = TRUE,
    right = FALSE
  )]
  
  dt[!is.na(causal_MAF) & causal_MAF == max(breaks), maf_bin := tail(labels, 1)]
  
  res <- dt[
    ,
    .(
      total = .N,
      matched = sum(MAF_diff == 0 & BP_diff == 0, na.rm = TRUE),
      prop = sum(MAF_diff == 0 & BP_diff == 0, na.rm = TRUE) / .N,
      percent = sum(MAF_diff == 0 & BP_diff == 0, na.rm = TRUE) / .N * 100,
      maf_mean = mean(causal_MAF, na.rm = TRUE)
    ),
    by = .(maf_bin)
  ]
  
  # Keep empty bins so that every dataset has the same bin rows.
  bin_template <- data.table(
    maf_bin = factor(labels, levels = labels)
  )
  
  res[, maf_bin := factor(as.character(maf_bin), levels = labels)]
  res <- merge(bin_template, res, by = "maf_bin", all.x = TRUE, sort = FALSE)
  
  res[is.na(total), total := 0L]
  res[is.na(matched), matched := 0L]
  res[total == 0, prop := NA_real_]
  res[total == 0, percent := NA_real_]
  
  res[, dataset := dataset]
  res[, variant_type := variant_type]
  res[, analysis_group := analysis_group]
  
  setcolorder(
    res,
    c(
      "dataset", "variant_type", "analysis_group", "maf_bin",
      "total", "matched", "prop", "percent", "maf_mean"
    )
  )
  
  return(res)
}

############################################################
# 4. Read all files
############################################################

dt_list <- Map(read_one_file, names(files), files)
all_dt <- rbindlist(dt_list, use.names = TRUE, fill = TRUE)

############################################################
# 5. Summary before and after P-value filtering
############################################################

summary_all <- all_dt[
  ,
  .(
    n_all_rows = .N,
    n_valid_lead_P = sum(!is.na(lead_P)),
    n_lead_P_lt_5e8 = sum(!is.na(lead_P) & lead_P < P_THRESHOLD),
    prop_lead_P_lt_5e8 = sum(!is.na(lead_P) & lead_P < P_THRESHOLD) / .N,
    percent_lead_P_lt_5e8 = sum(!is.na(lead_P) & lead_P < P_THRESHOLD) / .N * 100
  ),
  by = .(dataset, variant_type, analysis_group, source_file)
]

fwrite(summary_all, file.path(OUT_DIR, "input_summary_all_rows_and_Plt5e8.csv"))

############################################################
# 6. Restrict all statistics to lead_P < 5e-8
############################################################

sig_dt <- all_dt[
  !is.na(lead_P) &
    lead_P < P_THRESHOLD &
    !is.na(causal_MAF) &
    !is.na(MAF_diff) &
    !is.na(BP_diff)
]

if (nrow(sig_dt) == 0) {
  stop("No rows remain after filtering lead_P < 5e-8.")
}

fwrite(sig_dt, file.path(OUT_DIR, "all_rows_used_for_maf_bin_statistics_Plt5e8.csv"))

############################################################
# 7. Calculate MAF-bin exact match proportion
############################################################

res_list <- list()

groups <- unique(sig_dt[, .(dataset, variant_type, analysis_group)])
setorder(groups, variant_type, analysis_group, dataset)

for (i in seq_len(nrow(groups))) {
  dataset_i <- groups$dataset[i]
  variant_type_i <- groups$variant_type[i]
  analysis_group_i <- groups$analysis_group[i]
  
  tmp <- sig_dt[dataset == dataset_i]
  
  res_list[[dataset_i]] <- calc_prop(
    dt = tmp,
    variant_type = variant_type_i,
    dataset = dataset_i,
    analysis_group = analysis_group_i
  )
}

all_res <- rbindlist(res_list, use.names = TRUE, fill = TRUE)
setorder(all_res, variant_type, analysis_group, dataset, maf_bin)

############################################################
# 8. Output long and wide tables
############################################################

fwrite(all_res, file.path(OUT_DIR, "maf_bin_exact_match_long_Plt5e8.csv"))

wide_prop <- dcast(
  all_res,
  variant_type + maf_bin ~ dataset,
  value.var = "prop"
)

wide_percent <- dcast(
  all_res,
  variant_type + maf_bin ~ dataset,
  value.var = "percent"
)

wide_total <- dcast(
  all_res,
  variant_type + maf_bin ~ dataset,
  value.var = "total"
)

wide_matched <- dcast(
  all_res,
  variant_type + maf_bin ~ dataset,
  value.var = "matched"
)

fwrite(wide_prop, file.path(OUT_DIR, "maf_bin_exact_match_wide_prop_Plt5e8.csv"))
fwrite(wide_percent, file.path(OUT_DIR, "maf_bin_exact_match_wide_percent_Plt5e8.csv"))
fwrite(wide_total, file.path(OUT_DIR, "maf_bin_total_wide_Plt5e8.csv"))
fwrite(wide_matched, file.path(OUT_DIR, "maf_bin_matched_wide_Plt5e8.csv"))

############################################################
# 9. Overall exact match summary after P-value filtering
############################################################

overall_summary <- sig_dt[
  ,
  .(
    total = .N,
    matched = sum(MAF_diff == 0 & BP_diff == 0, na.rm = TRUE),
    prop = sum(MAF_diff == 0 & BP_diff == 0, na.rm = TRUE) / .N,
    percent = sum(MAF_diff == 0 & BP_diff == 0, na.rm = TRUE) / .N * 100,
    mean_causal_MAF = mean(causal_MAF, na.rm = TRUE)
  ),
  by = .(dataset, variant_type, analysis_group)
]

setorder(overall_summary, variant_type, analysis_group, dataset)
fwrite(overall_summary, file.path(OUT_DIR, "overall_exact_match_summary_Plt5e8.csv"))

############################################################
# 10. Final message
############################################################

message("============================================================")
message("[INFO] MAF-bin exact match statistics finished")
message("[INFO] P-value threshold: lead_P < ", P_THRESHOLD)
message("[INFO] Output directory:")
message(OUT_DIR)
message("============================================================")

print(all_res)
print(overall_summary)























############################################################
# Plot mapping precision curves in a Genome Biology-like style
#
# Inputs:
#   cumulative_MAF_diff_long_Plt5e8.csv
#   cumulative_BP_diff_long_Plt5e8.csv
#   cumulative_LD_r2_long_Plt5e8.csv
#
# Outputs:
#   PDF and PNG figures saved to:
#   C:/Users/ASUS/Desktop/GWAS/gwas/模拟3/results/new_results/real_final_plot
#
# Main design:
#   1. EUR10K single-ancestry vs EUR5K+AFR5K multi-ancestry
#   2. EUR10K single-ancestry vs matched multi-ancestry designs
#      EUR9K+AFR1K, EUR8K+AFR2K, EUR7K+AFR3K, EUR6K+AFR4K
#   3. For each metric, common and rare are saved separately and as a
#      two-panel grouped figure.
#
# Style in this version:
#   - All y-axes are fixed at 0-100 with breaks every 20%.
#   - No panel border.
#   - Legends are inside the plotting area at the lower right.
#   - The single-ancestry style is identical in all figures.
#   - All connecting lines are solid.
#   - Multi-ancestry groups are distinguished by colour and hollow point shape.
#   - Lines are drawn as shortened segments, leaving a visible gap around
#     each point. This prevents the connecting line from touching or passing
#     through the point markers.
#   - Point markers are reduced in size for a cleaner publication-style layout.
#   - Legend keys retain connecting lines while plotting lines remain gapped around points.
#   - Gaps between points and connecting lines are fixed in normalised panel units.
#   - Axis origins are fixed so x = 0 and y = 0 intersect at the lower-left origin.
#   - Grouped a/b figures are assembled from two independent ggplots so both
#     panels keep their own x-axis title, y-axis title and y-axis.
############################################################





# ===== RESTORED ORIGINAL GWAS MAPPING-PRECISION FIGURES (module 4) =====
rm(list = ls())
gc()

suppressPackageStartupMessages({
  library(data.table)
  library(ggplot2)
  library(grid)
})

############################################################
# 1. Input and output paths
############################################################

MAF_FILE <- file.path("C:/Users/ASUS/Desktop/GWAS/gwas/模拟3/results/new_results/real_final_plot", "cumulative_MAF_diff_long_Plt5e8.csv")
BP_FILE  <- file.path("C:/Users/ASUS/Desktop/GWAS/gwas/模拟3/results/new_results/real_final_plot", "cumulative_BP_diff_long_Plt5e8.csv")
LD_FILE  <- file.path("C:/Users/ASUS/Desktop/GWAS/gwas/模拟3/results/new_results/real_final_plot", "cumulative_LD_r2_long_Plt5e8.csv")

OUT_DIR <- "C:/Users/ASUS/Desktop/GWAS/gwas/模拟3/results/new_results/real_final_plot"
dir.create(OUT_DIR, showWarnings = FALSE, recursive = TRUE)

############################################################
# 2. Plot settings
############################################################

COL_SINGLE <- "#1F4E79"
COL_MULTI  <- "#E69F00"

COL_MAIN <- c(
  "single-ancestry" = COL_SINGLE,
  "multi-ancestry"  = COL_MULTI
)

COL_COMPOSITION <- c(
  "single-ancestry" = COL_SINGLE,
  "EUR9K + AFR1K"  = "#009E73",
  "EUR8K + AFR2K"  = "#E69F00",
  "EUR7K + AFR3K"  = "#CC79A7",
  "EUR6K + AFR4K"  = "#D55E00"
)

# Filled symbols 21-25 support both colour and fill.
# Multi-ancestry points are hollow with white fill.
SHAPE_MAIN <- c(
  "single-ancestry" = 21,
  "multi-ancestry"  = 24
)

FILL_MAIN <- c(
  "single-ancestry" = COL_SINGLE,
  "multi-ancestry"  = "white"
)

SHAPE_COMPOSITION <- c(
  "single-ancestry" = 21,
  "EUR9K + AFR1K"  = 24,
  "EUR8K + AFR2K"  = 22,
  "EUR7K + AFR3K"  = 23,
  "EUR6K + AFR4K"  = 25
)

FILL_COMPOSITION <- c(
  "single-ancestry" = COL_SINGLE,
  "EUR9K + AFR1K"  = "white",
  "EUR8K + AFR2K"  = "white",
  "EUR7K + AFR3K"  = "white",
  "EUR6K + AFR4K"  = "white"
)

LINETYPE_COMPOSITION <- c(
  "single-ancestry" = "solid",
  "EUR9K + AFR1K"  = "solid",
  "EUR8K + AFR2K"  = "solid",
  "EUR7K + AFR3K"  = "solid",
  "EUR6K + AFR4K"  = "solid"
)

MAIN_LABEL_LEVELS <- c("single-ancestry", "multi-ancestry")

COMPOSITION_LABEL_LEVELS <- c(
  "single-ancestry",
  "EUR9K + AFR1K",
  "EUR8K + AFR2K",
  "EUR7K + AFR3K",
  "EUR6K + AFR4K"
)

Y_LIMITS_FIXED <- c(0, 100)
Y_BREAKS_FIXED <- seq(0, 100, by = 20)

# Fixed blank space between each point and the adjacent connecting line.
# This is measured in normalised panel units, so the visual gap is stable
# across different x-axis scales and different distances between points.
FIXED_LINE_GAP_NPC <- 0.018

POINT_SIZE <- 1.25
POINT_STROKE <- 0.45
LEGEND_POINT_SIZE <- 1.45
LEGEND_LINE_WIDTH <- 0.55

# Unified legend standard used throughout the script:
#   line plots   -> colour + correct point shape/fill + solid connecting line
#   point plots  -> colour + correct point shape/fill, no line
# single-ancestry is always a blue filled circle; multi-ancestry is always
# an orange hollow triangle whenever those two methods are displayed as points.

############################################################
# 3. Helper functions
############################################################

fatal <- function(...) {
  stop(paste0(...), call. = FALSE)
}

safe_chr <- function(x) {
  x <- as.character(x)
  x[is.na(x)] <- ""
  x
}

panel_title_for_variant <- function(vt) {
  if (vt == "common") {
    return("common (MAF > 0.01)")
  }
  if (vt == "rare") {
    return("rare (MAF ≤ 0.01)")
  }
  as.character(vt)
}

read_cumulative_file <- function(file, metric_label) {
  if (!file.exists(file)) {
    fatal("Input file does not exist: ", file)
  }
  
  dt <- fread(file, data.table = TRUE)
  setnames(dt, trimws(names(dt)))
  
  required_cols <- c("variant_type", "population", "threshold")
  missing_cols <- setdiff(required_cols, names(dt))
  if (length(missing_cols) > 0) {
    fatal(
      "Missing required columns in ", file,
      "\nMissing columns: ", paste(missing_cols, collapse = ", "),
      "\nCurrent columns: ", paste(names(dt), collapse = ", ")
    )
  }
  
  if (!("cumulative_percent" %in% names(dt))) {
    if ("cumulative_prop" %in% names(dt)) {
      dt[, cumulative_percent := as.numeric(cumulative_prop) * 100]
    } else {
      fatal("Neither cumulative_percent nor cumulative_prop is present in: ", file)
    }
  }
  
  if (!("analysis_group" %in% names(dt))) {
    dt[, analysis_group := NA_character_]
  }
  
  if (!("ancestry_composition" %in% names(dt))) {
    dt[, ancestry_composition := NA_character_]
  }
  
  dt[, variant_type := safe_chr(variant_type)]
  dt[, population := safe_chr(population)]
  dt[, analysis_group := safe_chr(analysis_group)]
  dt[, ancestry_composition := safe_chr(ancestry_composition)]
  dt[, threshold := as.numeric(threshold)]
  dt[, cumulative_percent := as.numeric(cumulative_percent)]
  # Keep percentages within the plotting range and prevent tiny numerical
  # values above 100 from being dropped by fixed 0-100 y-axis limits.
  dt[, cumulative_percent := pmax(pmin(cumulative_percent, 100), 0)]
  dt[, metric := metric_label]
  
  dt <- dt[variant_type %in% c("common", "rare")]
  
  if (nrow(dt) == 0) {
    fatal("No common or rare rows were detected in: ", file)
  }
  
  dt[]
}

normalise_population_fields <- function(dt) {
  dt <- copy(dt)
  
  pop <- safe_chr(dt$population)
  ag  <- safe_chr(dt$analysis_group)
  ac  <- safe_chr(dt$ancestry_composition)
  
  key <- tolower(paste(pop, ag, ac, sep = "|"))
  
  ancestry_clean <- rep(NA_character_, length(pop))
  
  idx_eur10 <- grepl("eur10", key) |
    grepl("_eur_sig", key) |
    grepl("common_eur_sig", key) |
    grepl("rare_eur_sig", key) |
    ag == "EUR"
  
  idx_eur5_afr5 <- grepl("eur5k_afr5k", key) |
    grepl("common_pooled($|_ld)", key) |
    grepl("rare_pooled($|_ld)", key) |
    pop %in% c("common_pooled", "rare_pooled", "common_pooled_ld", "rare_pooled_ld")
  
  idx_eur9_afr1 <- grepl("eur9k_afr1k", key)
  idx_eur8_afr2 <- grepl("eur8k_afr2k", key)
  idx_eur7_afr3 <- grepl("eur7k_afr3k", key)
  idx_eur6_afr4 <- grepl("eur6k_afr4k", key)
  
  ancestry_clean[idx_eur10] <- "EUR10K"
  ancestry_clean[idx_eur5_afr5] <- "EUR5K_AFR5K"
  ancestry_clean[idx_eur9_afr1] <- "EUR9K_AFR1K"
  ancestry_clean[idx_eur8_afr2] <- "EUR8K_AFR2K"
  ancestry_clean[idx_eur7_afr3] <- "EUR7K_AFR3K"
  ancestry_clean[idx_eur6_afr4] <- "EUR6K_AFR4K"
  
  plot_label_main <- rep(NA_character_, length(pop))
  plot_label_main[ancestry_clean == "EUR10K"] <- "single-ancestry"
  plot_label_main[ancestry_clean == "EUR5K_AFR5K"] <- "multi-ancestry"
  
  plot_label_comp <- rep(NA_character_, length(pop))
  plot_label_comp[ancestry_clean == "EUR10K"] <- "single-ancestry"
  plot_label_comp[ancestry_clean == "EUR9K_AFR1K"] <- "EUR9K + AFR1K"
  plot_label_comp[ancestry_clean == "EUR8K_AFR2K"] <- "EUR8K + AFR2K"
  plot_label_comp[ancestry_clean == "EUR7K_AFR3K"] <- "EUR7K + AFR3K"
  plot_label_comp[ancestry_clean == "EUR6K_AFR4K"] <- "EUR6K + AFR4K"
  
  dt[, ancestry_comp_clean := ancestry_clean]
  dt[, plot_label_main := plot_label_main]
  dt[, plot_label_comp := plot_label_comp]
  
  dt[]
}

metric_axis_settings <- function(metric_name, variant_type) {
  if (metric_name == "BP_diff") {
    return(list(
      xlab = "Distance (Kb)",
      ylab = "Proportion (%)",
      x_transform = function(x) x / 1000,
      x_breaks = seq(0, 100, by = 20),
      x_limits = c(0, 100)
    ))
  }
  
  if (metric_name == "MAF_diff") {
    if (variant_type == "common") {
      return(list(
        xlab = "MAF difference",
        ylab = "Proportion (%)",
        x_transform = function(x) x,
        x_breaks = seq(0, 0.05, by = 0.01),
        x_limits = c(0, 0.05)
      ))
    }
    
    return(list(
      xlab = "MAF difference",
      ylab = "Proportion (%)",
      x_transform = function(x) x,
      x_breaks = seq(0, 0.003, by = 0.001),
      x_limits = c(0, 0.003)
    ))
  }
  
  if (metric_name == "LD_r2") {
    return(list(
      xlab = expression(LD~"(" * plain(r)^2 * ")"),
      ylab = "Proportion (%)",
      x_transform = function(x) x,
      x_breaks = seq(0, 1, by = 0.2),
      x_limits = c(0, 1)
    ))
  }
  
  fatal("Unknown metric: ", metric_name)
}

make_gap_segments <- function(d, label_col, x_limits, y_limits, gap_npc = FIXED_LINE_GAP_NPC) {
  d2 <- copy(d)
  d2 <- d2[is.finite(x_plot) & is.finite(cumulative_percent)]
  
  lab <- safe_chr(d2[[label_col]])
  d2[, label_tmp_for_segment := lab]
  d2 <- d2[label_tmp_for_segment != ""]
  
  if (nrow(d2) == 0) {
    return(data.table())
  }
  
  x_range <- diff(x_limits)
  y_range <- diff(y_limits)
  
  if (!is.finite(x_range) || !is.finite(y_range) || x_range <= 0 || y_range <= 0) {
    fatal("Invalid axis limits for fixed-gap segment construction.")
  }
  
  setorder(d2, label_tmp_for_segment, x_plot)
  
  seg <- d2[, {
    if (.N < 2) {
      NULL
    } else {
      x1 <- x_plot[-.N]
      x2 <- x_plot[-1]
      y1 <- cumulative_percent[-.N]
      y2 <- cumulative_percent[-1]
      
      dx_data <- x2 - x1
      dy_data <- y2 - y1
      
      dx_npc <- dx_data / x_range
      dy_npc <- dy_data / y_range
      len_npc <- sqrt(dx_npc^2 + dy_npc^2)
      
      keep <- is.finite(len_npc) & len_npc > 0
      
      if (!any(keep)) {
        NULL
      } else {
        shrink_npc <- pmin(gap_npc, len_npc * 0.45)
        
        ux_npc <- dx_npc / len_npc
        uy_npc <- dy_npc / len_npc
        
        data.table(
          x = x1 + ux_npc * shrink_npc * x_range,
          y = y1 + uy_npc * shrink_npc * y_range,
          xend = x2 - ux_npc * shrink_npc * x_range,
          yend = y2 - uy_npc * shrink_npc * y_range,
          label = label_tmp_for_segment[1]
        )[keep]
      }
    }
  }, by = label_tmp_for_segment]
  
  if (nrow(seg) > 0) {
    seg[, label_tmp_for_segment := NULL]
  }
  
  seg[]
}

gb_theme <- function(base_size = 8, show_legend = TRUE) {
  th <- theme_classic(base_size = base_size, base_family = "sans") +
    theme(
      aspect.ratio = 1,
      axis.line = element_line(linewidth = 0.35, colour = "black"),
      axis.ticks = element_line(linewidth = 0.35, colour = "black"),
      axis.ticks.length = unit(1.6, "mm"),
      axis.title.x = element_text(size = 11.0, colour = "black", margin = margin(t = 5)),
      axis.title.y = element_text(size = 11.0, colour = "black", margin = margin(r = 6), lineheight = 0.95),
      axis.text = element_text(size = 9.5, colour = "black"),
      plot.title = element_text(size = 11.5, hjust = 0.5, vjust = 1, colour = "black", face = "plain", margin = margin(b = 6)),
      plot.title.position = "panel",
      plot.tag.position = c(0.002, 0.995),
      plot.tag = element_text(size = 11.5, colour = "black", face = "bold", hjust = 0, vjust = 1, margin = margin(0, 0, 0, 0)),
      plot.subtitle = element_text(size = base_size, hjust = 0.5, colour = "black"),
      legend.title = element_blank(),
      legend.text = element_text(size = 9.5, colour = "black"),
      legend.key.width = unit(0.62, "cm"),
      legend.key.height = unit(0.34, "cm"),
      legend.background = element_blank(),
      legend.box.background = element_blank(),
      legend.key = element_rect(fill = "white", colour = NA),
      legend.margin = margin(0, 0, 0, 0),
      legend.spacing.y = unit(0.055, "cm"),
      panel.border = element_blank(),
      panel.background = element_blank(),
      plot.background = element_rect(fill = "white", colour = NA),
      plot.margin = margin(16, 10, 8, 20)
    )
  
  if (show_legend) {
    th <- th +
      theme(
        legend.position = "bottom",
        legend.direction = "horizontal",
        legend.justification = "center",
        legend.box = "horizontal",
        legend.box.spacing = unit(5.5, "pt")
      )
  } else {
    th <- th +
      theme(
        legend.position = "none"
      )
  }
  
  th
}

save_plot_pdf_png <- function(p, out_prefix, width = 3.35, height = 5.0) {
  pdf_file <- paste0(out_prefix, ".pdf")
  png_file <- paste0(out_prefix, ".png")
  
  if (capabilities("cairo")) {
    grDevices::cairo_pdf(filename = pdf_file, width = width, height = height, bg = "white")
  } else {
    grDevices::pdf(file = pdf_file, width = width, height = height, useDingbats = FALSE, bg = "white")
  }
  print(p)
  grDevices::dev.off()
  
  grDevices::png(filename = png_file, width = width, height = height, units = "in", res = 600, bg = "white")
  print(p)
  grDevices::dev.off()
}

save_combined_pdf_png <- function(p_left, p_right, out_prefix, width = 8.4, height = 5.0) {
  pdf_file <- paste0(out_prefix, ".pdf")
  png_file <- paste0(out_prefix, ".png")

  get_bottom_legend <- function(p) {
    g <- ggplotGrob(
      p +
        theme(
          legend.position = "bottom",
          legend.direction = "horizontal",
          legend.justification = "center",
          legend.box = "horizontal",
          legend.box.spacing = unit(0, "pt")
        )
    )

    idx <- which(grepl("^guide-box", g$layout$name))
    if (length(idx) == 0) return(grid::nullGrob())

    valid <- idx[
      !vapply(
        g$grobs[idx],
        inherits,
        logical(1),
        what = "zeroGrob"
      )
    ]

    if (length(valid) == 0) return(grid::nullGrob())
    g$grobs[[valid[1]]]
  }

  # In grouped figures, use one shared legend at the bottom.
  legend <- get_bottom_legend(p_right)
  p_left_no_legend  <- p_left  + theme(legend.position = "none")
  p_right_no_legend <- p_right + theme(legend.position = "none")

  draw_combined <- function() {
    grid.newpage()
    pushViewport(
      viewport(
        layout = grid.layout(
          nrow = 3,
          ncol = 2,
          heights = unit.c(
            unit(1, "null"),
            unit(5.5, "pt"),
            grobHeight(legend)
          ),
          widths = unit(c(1, 1), "null"),
          respect = TRUE)
      )
    )

    print(
      p_left_no_legend,
      vp = viewport(layout.pos.row = 1, layout.pos.col = 1)
    )

    print(
      p_right_no_legend,
      vp = viewport(layout.pos.row = 1, layout.pos.col = 2)
    )

    pushViewport(
      viewport(layout.pos.row = 3, layout.pos.col = 1:2)
    )
    grid.draw(legend)
    popViewport()
  }

  device_height <- height + 0.35

  if (capabilities("cairo")) {
    grDevices::cairo_pdf(
      filename = pdf_file,
      width = width,
      height = device_height,
      bg = "white"
    )
  } else {
    grDevices::pdf(
      file = pdf_file,
      width = width,
      height = device_height,
      useDingbats = FALSE,
      bg = "white"
    )
  }

  draw_combined()
  grDevices::dev.off()

  grDevices::png(
    filename = png_file,
    width = width,
    height = device_height,
    units = "in",
    res = 600,
    bg = "white"
  )

  draw_combined()
  grDevices::dev.off()
}

############################################################
# 4. Plot builders
############################################################

build_main_two_line <- function(dt, metric_name, vt_select, show_legend = TRUE, title_prefix = NULL) {
  d <- copy(dt)
  d <- d[variant_type == vt_select & !is.na(plot_label_main)]
  d <- d[ancestry_comp_clean %in% c("EUR10K", "EUR5K_AFR5K")]
  
  if (nrow(d) == 0) {
    warning("No rows for main comparison: ", metric_name, " ", vt_select)
    return(NULL)
  }
  
  axis <- metric_axis_settings(metric_name, vt_select)
  d[, x_plot := axis$x_transform(threshold)]
  d[, plot_label_main := factor(plot_label_main, levels = MAIN_LABEL_LEVELS)]
  setorder(d, plot_label_main, x_plot)
  
  seg <- make_gap_segments(d, "plot_label_main", axis$x_limits, Y_LIMITS_FIXED)
  if (nrow(seg) > 0) {
    seg[, plot_label_main := factor(label, levels = MAIN_LABEL_LEVELS)]
  }
  
  title_use <- panel_title_for_variant(vt_select)
  tag_use <- if (!is.null(title_prefix) && nzchar(as.character(title_prefix))) as.character(title_prefix) else NULL
  
  p <- ggplot() +
    # Invisible line layer used only to make the legend display a connecting line.
    # Actual visible lines are drawn by the shortened segment layer below.
    geom_line(
      data = d,
      aes(x = x_plot, y = cumulative_percent, colour = plot_label_main, group = plot_label_main),
      linewidth = LEGEND_LINE_WIDTH,
      alpha = 0,
      show.legend = TRUE,
      na.rm = TRUE
    ) +
    geom_segment(
      data = seg,
      aes(x = x, y = y, xend = xend, yend = yend, colour = plot_label_main, group = plot_label_main),
      linewidth = LEGEND_LINE_WIDTH,
      lineend = "butt",
      show.legend = FALSE,
      na.rm = TRUE
    ) +
    geom_point(
      data = d,
      aes(x = x_plot, y = cumulative_percent, colour = plot_label_main, fill = plot_label_main, shape = plot_label_main),
      size = POINT_SIZE,
      stroke = POINT_STROKE,
      show.legend = TRUE,
      na.rm = TRUE
    ) +
    scale_colour_manual(name = NULL, values = COL_MAIN, breaks = MAIN_LABEL_LEVELS,
                        labels = c("Single-ancestry", "Multi-ancestry"), drop = FALSE) +
    scale_shape_manual(name = NULL, values = SHAPE_MAIN, breaks = MAIN_LABEL_LEVELS,
                       labels = c("Single-ancestry", "Multi-ancestry"), drop = FALSE, guide = "none") +
    scale_fill_manual(name = NULL, values = FILL_MAIN, breaks = MAIN_LABEL_LEVELS,
                      labels = c("Single-ancestry", "Multi-ancestry"), drop = FALSE, guide = "none") +
    scale_x_continuous(limits = axis$x_limits, breaks = axis$x_breaks, expand = expansion(mult = c(0, 0.02))) +
    scale_y_continuous(limits = Y_LIMITS_FIXED, breaks = Y_BREAKS_FIXED, expand = expansion(mult = c(0, 0.04))) +
    coord_cartesian(clip = "off") +
    labs(x = axis$xlab, y = axis$ylab, title = title_use, tag = tag_use) +
    guides(
      colour = guide_legend(
        nrow = 1,
        byrow = TRUE,
        override.aes = list(
          alpha = 1,
          linewidth = LEGEND_LINE_WIDTH,
          linetype = 1,
          size = LEGEND_POINT_SIZE,
          stroke = POINT_STROKE,
          shape = unname(SHAPE_MAIN[MAIN_LABEL_LEVELS]),
          fill = unname(FILL_MAIN[MAIN_LABEL_LEVELS])
        )
      )
    ) +
    gb_theme(base_size = 8, show_legend = show_legend)
  
  p
}

build_composition_line <- function(dt, metric_name, vt_select, show_legend = TRUE, title_prefix = NULL, zoom_y = FALSE) {
  d <- copy(dt)
  d <- d[variant_type == vt_select & !is.na(plot_label_comp)]
  d <- d[plot_label_comp %in% COMPOSITION_LABEL_LEVELS]
  
  if (nrow(d) == 0) {
    warning("No rows for composition comparison: ", metric_name, " ", vt_select)
    return(NULL)
  }
  
  d[, plot_label_comp := factor(plot_label_comp, levels = COMPOSITION_LABEL_LEVELS)]
  
  axis <- metric_axis_settings(metric_name, vt_select)
  d[, x_plot := axis$x_transform(threshold)]
  setorder(d, plot_label_comp, x_plot)
  
  seg <- make_gap_segments(d, "plot_label_comp", axis$x_limits, Y_LIMITS_FIXED)
  if (nrow(seg) > 0) {
    seg[, plot_label_comp := factor(label, levels = COMPOSITION_LABEL_LEVELS)]
  }
  
  title_use <- panel_title_for_variant(vt_select)
  tag_use <- if (!is.null(title_prefix) && nzchar(as.character(title_prefix))) as.character(title_prefix) else NULL
  
  p <- ggplot() +
    # This invisible line layer is only used to force the legend to show
    # the same line + point style as the actual curves.
    geom_line(
      data = d,
      aes(
        x = x_plot,
        y = cumulative_percent,
        colour = plot_label_comp,
        linetype = plot_label_comp,
        group = plot_label_comp
      ),
      linewidth = LEGEND_LINE_WIDTH,
      alpha = 0,
      show.legend = TRUE,
      na.rm = TRUE
    ) +
    geom_segment(
      data = seg,
      aes(
        x = x,
        y = y,
        xend = xend,
        yend = yend,
        colour = plot_label_comp,
        linetype = plot_label_comp,
        group = plot_label_comp
      ),
      linewidth = LEGEND_LINE_WIDTH,
      lineend = "butt",
      show.legend = FALSE,
      na.rm = TRUE
    ) +
    geom_point(
      data = d,
      aes(
        x = x_plot,
        y = cumulative_percent,
        colour = plot_label_comp,
        fill = plot_label_comp,
        shape = plot_label_comp
      ),
      size = POINT_SIZE,
      stroke = POINT_STROKE,
      show.legend = TRUE,
      na.rm = TRUE
    ) +
    scale_colour_manual(name = NULL, values = COL_COMPOSITION, breaks = COMPOSITION_LABEL_LEVELS,
                        labels = c("Single-ancestry", "EUR9K + AFR1K", "EUR8K + AFR2K", "EUR7K + AFR3K", "EUR6K + AFR4K"),
                        drop = FALSE) +
    scale_linetype_manual(name = NULL, values = LINETYPE_COMPOSITION, breaks = COMPOSITION_LABEL_LEVELS,
                          labels = c("Single-ancestry", "EUR9K + AFR1K", "EUR8K + AFR2K", "EUR7K + AFR3K", "EUR6K + AFR4K"),
                          drop = FALSE, guide = "none") +
    scale_shape_manual(name = NULL, values = SHAPE_COMPOSITION, breaks = COMPOSITION_LABEL_LEVELS,
                       labels = c("Single-ancestry", "EUR9K + AFR1K", "EUR8K + AFR2K", "EUR7K + AFR3K", "EUR6K + AFR4K"),
                       drop = FALSE, guide = "none") +
    scale_fill_manual(name = NULL, values = FILL_COMPOSITION, breaks = COMPOSITION_LABEL_LEVELS,
                      labels = c("Single-ancestry", "EUR9K + AFR1K", "EUR8K + AFR2K", "EUR7K + AFR3K", "EUR6K + AFR4K"),
                      drop = FALSE, guide = "none") +
    scale_x_continuous(limits = axis$x_limits, breaks = axis$x_breaks, expand = expansion(mult = c(0, 0.02))) +
    scale_y_continuous(limits = Y_LIMITS_FIXED, breaks = Y_BREAKS_FIXED, expand = expansion(mult = c(0, 0.04))) +
    coord_cartesian(clip = "off") +
    labs(x = axis$xlab, y = axis$ylab, title = title_use, tag = tag_use) +
    guides(
      colour = guide_legend(
        nrow = 1,
        byrow = TRUE,
        override.aes = list(
          alpha = 1,
          linewidth = LEGEND_LINE_WIDTH,
          linetype = unname(LINETYPE_COMPOSITION[COMPOSITION_LABEL_LEVELS]),
          size = LEGEND_POINT_SIZE,
          stroke = POINT_STROKE,
          shape = unname(SHAPE_COMPOSITION[COMPOSITION_LABEL_LEVELS]),
          fill = unname(FILL_COMPOSITION[COMPOSITION_LABEL_LEVELS])
        )
      )
    ) +
    gb_theme(base_size = 8, show_legend = show_legend) +
    theme(
      legend.text = element_text(size = 9.5, colour = "black"),
      legend.key.width = unit(0.78, "cm"),
      legend.key.height = unit(0.34, "cm"),
      legend.spacing.x = unit(0.14, "cm"),
      legend.spacing.y = unit(0.07, "cm")
    )
  
  attr(p, "y_limits") <- Y_LIMITS_FIXED
  p
}

############################################################
# 5. Read data
############################################################

message("============================================================")
message("[INFO] Reading cumulative input files")
message("============================================================")

bp_dt  <- read_cumulative_file(BP_FILE,  "BP_diff")
maf_dt <- read_cumulative_file(MAF_FILE, "MAF_diff")
ld_dt  <- read_cumulative_file(LD_FILE,  "LD_r2")

bp_dt  <- normalise_population_fields(bp_dt)
maf_dt <- normalise_population_fields(maf_dt)
ld_dt  <- normalise_population_fields(ld_dt)

all_cum <- rbindlist(list(bp_dt, maf_dt, ld_dt), use.names = TRUE, fill = TRUE)

summary_dt <- all_cum[
  ,
  .(
    n_rows = .N,
    min_threshold = min(threshold, na.rm = TRUE),
    max_threshold = max(threshold, na.rm = TRUE),
    min_percent = min(cumulative_percent, na.rm = TRUE),
    max_percent = max(cumulative_percent, na.rm = TRUE)
  ),
  by = .(metric, variant_type, population, analysis_group, ancestry_composition, ancestry_comp_clean)
]

fwrite(summary_dt, file.path(OUT_DIR, "plot_input_summary.csv"))

############################################################
# 6. Main comparison: EUR10K vs EUR5K+AFR5K
############################################################

message("============================================================")
message("[INFO] Plotting EUR10K vs EUR5K+AFR5K curves")
message("============================================================")

p1a <- build_main_two_line(bp_dt, "BP_diff", "common", show_legend = TRUE)
p1b <- build_main_two_line(bp_dt, "BP_diff", "rare", show_legend = TRUE)
if (!is.null(p1a)) save_plot_pdf_png(p1a, file.path(OUT_DIR, "Fig1A_BP_common_single_vs_multi"), width = 3.35, height = 5.0)
if (!is.null(p1b)) save_plot_pdf_png(p1b, file.path(OUT_DIR, "Fig1B_BP_rare_single_vs_multi"), width = 3.35, height = 5.0)

p2a <- build_main_two_line(maf_dt, "MAF_diff", "common", show_legend = TRUE)
p2b <- build_main_two_line(maf_dt, "MAF_diff", "rare", show_legend = TRUE)
if (!is.null(p2a)) save_plot_pdf_png(p2a, file.path(OUT_DIR, "Fig2A_MAF_common_single_vs_multi"), width = 3.35, height = 5.0)
if (!is.null(p2b)) save_plot_pdf_png(p2b, file.path(OUT_DIR, "Fig2B_MAF_rare_single_vs_multi"), width = 3.35, height = 5.0)

p3a <- build_main_two_line(ld_dt, "LD_r2", "common", show_legend = TRUE)
p3b <- build_main_two_line(ld_dt, "LD_r2", "rare", show_legend = TRUE)
if (!is.null(p3a)) save_plot_pdf_png(p3a, file.path(OUT_DIR, "Fig3A_LD_common_single_vs_multi"), width = 3.35, height = 5.0)
if (!is.null(p3b)) save_plot_pdf_png(p3b, file.path(OUT_DIR, "Fig3B_LD_rare_single_vs_multi"), width = 3.35, height = 5.0)

# Grouped figures. Both panels are independent ggplots, so both retain
# x-axis title, y-axis title and y-axis.
p1a_g <- build_main_two_line(bp_dt, "BP_diff", "common", show_legend = FALSE, title_prefix = "a")
p1b_g <- build_main_two_line(bp_dt, "BP_diff", "rare", show_legend = TRUE, title_prefix = "b")
if (!is.null(p1a_g) && !is.null(p1b_g)) {
  save_combined_pdf_png(p1a_g, p1b_g, file.path(OUT_DIR, "Fig1_BP_single_vs_multi_common_rare_two_panel"), width = 8.4, height = 5.0)
}

p2a_g <- build_main_two_line(maf_dt, "MAF_diff", "common", show_legend = FALSE, title_prefix = "a")
p2b_g <- build_main_two_line(maf_dt, "MAF_diff", "rare", show_legend = TRUE, title_prefix = "b")
if (!is.null(p2a_g) && !is.null(p2b_g)) {
  save_combined_pdf_png(p2a_g, p2b_g, file.path(OUT_DIR, "Fig2_MAF_single_vs_multi_common_rare_two_panel"), width = 8.4, height = 5.0)
}

p3a_g <- build_main_two_line(ld_dt, "LD_r2", "common", show_legend = FALSE, title_prefix = "a")
p3b_g <- build_main_two_line(ld_dt, "LD_r2", "rare", show_legend = TRUE, title_prefix = "b")
if (!is.null(p3a_g) && !is.null(p3b_g)) {
  save_combined_pdf_png(p3a_g, p3b_g, file.path(OUT_DIR, "Fig3_LD_single_vs_multi_common_rare_two_panel"), width = 8.4, height = 5.0)
}

############################################################
# AFR-PROPORTION PLOTS INCLUDED
# EUR10K versus EUR9K+AFR1K / EUR8K+AFR2K / EUR7K+AFR3K / EUR6K+AFR4K
# Grouped legends are placed below the figure and arranged horizontally.
############################################################

############################################################
# 7. Matched ancestry-composition comparison
#    EUR10K vs EUR9K+AFR1K, EUR8K+AFR2K,
#    EUR7K+AFR3K and EUR6K+AFR4K.
############################################################

message("============================================================")
message("[INFO] Plotting ancestry-composition curves")
message("============================================================")

composition_y_summary <- list()
record_y <- function(fig, metric, variant_type, p) {
  yl <- attr(p, "y_limits")
  if (is.null(yl)) yl <- c(NA_real_, NA_real_)
  data.table(
    figure = fig,
    metric = metric,
    variant_type = variant_type,
    y_min = yl[1],
    y_max = yl[2]
  )
}

p4a <- build_composition_line(bp_dt, "BP_diff", "common", show_legend = TRUE, zoom_y = FALSE)
p4b <- build_composition_line(bp_dt, "BP_diff", "rare", show_legend = TRUE, zoom_y = FALSE)
if (!is.null(p4a)) {
  save_plot_pdf_png(p4a, file.path(OUT_DIR, "Fig4A_BP_common_EUR10K_vs_matched_multi_ancestry"), width = 4.2, height = 5.0)
  composition_y_summary[[length(composition_y_summary) + 1]] <- record_y("Fig4A", "BP_diff", "common", p4a)
}
if (!is.null(p4b)) {
  save_plot_pdf_png(p4b, file.path(OUT_DIR, "Fig4B_BP_rare_EUR10K_vs_matched_multi_ancestry"), width = 4.2, height = 5.0)
  composition_y_summary[[length(composition_y_summary) + 1]] <- record_y("Fig4B", "BP_diff", "rare", p4b)
}

p5a <- build_composition_line(maf_dt, "MAF_diff", "common", show_legend = TRUE, zoom_y = FALSE)
p5b <- build_composition_line(maf_dt, "MAF_diff", "rare", show_legend = TRUE, zoom_y = FALSE)
if (!is.null(p5a)) {
  save_plot_pdf_png(p5a, file.path(OUT_DIR, "Fig5A_MAF_common_EUR10K_vs_matched_multi_ancestry"), width = 4.2, height = 5.0)
  composition_y_summary[[length(composition_y_summary) + 1]] <- record_y("Fig5A", "MAF_diff", "common", p5a)
}
if (!is.null(p5b)) {
  save_plot_pdf_png(p5b, file.path(OUT_DIR, "Fig5B_MAF_rare_EUR10K_vs_matched_multi_ancestry"), width = 4.2, height = 5.0)
  composition_y_summary[[length(composition_y_summary) + 1]] <- record_y("Fig5B", "MAF_diff", "rare", p5b)
}

p6a <- build_composition_line(ld_dt, "LD_r2", "common", show_legend = TRUE, zoom_y = FALSE)
p6b <- build_composition_line(ld_dt, "LD_r2", "rare", show_legend = TRUE, zoom_y = FALSE)
if (!is.null(p6a)) {
  save_plot_pdf_png(p6a, file.path(OUT_DIR, "Fig6A_LD_common_EUR10K_vs_matched_multi_ancestry"), width = 4.2, height = 5.0)
  composition_y_summary[[length(composition_y_summary) + 1]] <- record_y("Fig6A", "LD_r2", "common", p6a)
}
if (!is.null(p6b)) {
  save_plot_pdf_png(p6b, file.path(OUT_DIR, "Fig6B_LD_rare_EUR10K_vs_matched_multi_ancestry"), width = 4.2, height = 5.0)
  composition_y_summary[[length(composition_y_summary) + 1]] <- record_y("Fig6B", "LD_r2", "rare", p6b)
}

# Figure 4 and later grouped two-panel versions.
p4a_g <- build_composition_line(bp_dt, "BP_diff", "common", show_legend = FALSE, title_prefix = "a", zoom_y = FALSE)
p4b_g <- build_composition_line(bp_dt, "BP_diff", "rare", show_legend = TRUE, title_prefix = "b", zoom_y = FALSE)
if (!is.null(p4a_g) && !is.null(p4b_g)) {
  save_combined_pdf_png(p4a_g, p4b_g, file.path(OUT_DIR, "Fig4_BP_EUR10K_vs_matched_multi_ancestry_common_rare_two_panel"), width = 8.8, height = 5.0)
}

p5a_g <- build_composition_line(maf_dt, "MAF_diff", "common", show_legend = FALSE, title_prefix = "a", zoom_y = FALSE)
p5b_g <- build_composition_line(maf_dt, "MAF_diff", "rare", show_legend = TRUE, title_prefix = "b", zoom_y = FALSE)
if (!is.null(p5a_g) && !is.null(p5b_g)) {
  save_combined_pdf_png(p5a_g, p5b_g, file.path(OUT_DIR, "Fig5_MAF_EUR10K_vs_matched_multi_ancestry_common_rare_two_panel"), width = 8.8, height = 5.0)
}

p6a_g <- build_composition_line(ld_dt, "LD_r2", "common", show_legend = FALSE, title_prefix = "a", zoom_y = FALSE)
p6b_g <- build_composition_line(ld_dt, "LD_r2", "rare", show_legend = TRUE, title_prefix = "b", zoom_y = FALSE)
if (!is.null(p6a_g) && !is.null(p6b_g)) {
  save_combined_pdf_png(p6a_g, p6b_g, file.path(OUT_DIR, "Fig6_LD_EUR10K_vs_matched_multi_ancestry_common_rare_two_panel"), width = 8.8, height = 5.0)
}

if (length(composition_y_summary) > 0) {
  y_dt <- rbindlist(composition_y_summary, use.names = TRUE, fill = TRUE)
  fwrite(y_dt, file.path(OUT_DIR, "composition_figure_y_axis_limits.csv"))
}

############################################################
# 8. Final message
############################################################

message("============================================================")
message("[INFO] All plots finished")
message("[INFO] Output directory:")
message(OUT_DIR)
message("============================================================")





































############################################################
# Plot SuSiE/SuSiEx mapping precision curves
# Genome Biology-like style
#
# Inputs:
#   1) cumulative_BP_diff_PIPgt0.95_long.csv
#   2) cumulative_MAF_diff_PIPgt0.95_long.csv
#   3) cumulative_ld_r2_PIPgt0.95_long.csv
#
# Interpretation:
#   SuSiE  -> single-ancestry
#   SuSiEx -> multi-ancestry
#
# Outputs:
#   PDF and PNG figures saved to:
#   C:/Users/ASUS/Desktop/GWAS/gwas/模拟3/results/new_results/susie_susiex_focused_PIPgt0.95_with_ld_r2/plot
#
# Figure outputs (common variants only):
#   Fig1A_BP_common_susie_vs_susiex.pdf/png
#   Fig2A_MAF_common_susie_vs_susiex.pdf/png
#   Fig3A_LD_common_susie_vs_susiex.pdf/png
#
# Style:
#   - White background
#   - No panel border
#   - y-axis fixed at 0-100 with breaks every 20%
#   - x=0 and y=0 intersect at the lower-left origin
#   - Legend inside lower-right corner, with solid line and marker
#   - Lines are shortened around each point to leave a fixed gap
#   - single-ancestry style is kept identical across all figures
############################################################





# ===== ORIGINAL USER MAF-BIN MODULE RESTORED, 5K GWAS INPUTS =====
######################################################################################################################################MAF bin
rm(list = ls())
gc()

suppressPackageStartupMessages({
  library(data.table)
  library(dplyr)
  library(ggplot2)
  library(grid)
})

############################################################
# 1. Input / output paths
############################################################

OUT_DIR <- "C:/Users/ASUS/Desktop/GWAS/gwas/模拟3/results/new_results/real_final_plot"

dir.create(
  OUT_DIR,
  recursive = TRUE,
  showWarnings = FALSE
)


############################################################
# Filtering thresholds
#
# GWAS MAF-bin:
#   lead_P < 5e-8
#
# Fine-mapping MAF-bin:
#   pip_max > 0.9
############################################################

P_THRESHOLD <- 5e-8
PIP_THRESHOLD <- 0.9

############################################################
# 2. Input files
#
# GWAS:
#   common + rare
#   MAF-bin statistics restricted to lead_P < 5e-8
#
# Fine-mapping:
#   common only
#   MAF-bin statistics restricted to PIP > 0.9
############################################################

files_info <- data.frame(
  file_path = file.path(
    "C:/Users/ASUS/Desktop/GWAS/gwas/模拟3/results/new_results/real_final_plot/_prepared_5000",
    c("common_EUR_5k.txt", "rare_EUR_5k.txt", "common_pooled_5k.txt", "rare_pooled_5k.txt")
  ),
  analysis_type = rep("GWAS", 4),
  ancestry_type = c("single-ancestry", "single-ancestry", "multi-ancestry", "multi-ancestry"),
  variant_type = c("common", "rare", "common", "rare"),
  source_name = c("EUR_GWAS_common", "EUR_GWAS_rare", "Pooled_GWAS_common", "Pooled_GWAS_rare"),
  stringsAsFactors = FALSE
)

############################################################
# 3. Figure settings
############################################################

COL_METHOD <- c(
  "single-ancestry" = "#1F4E79",
  "multi-ancestry"  = "#E69F00"
)

# single-ancestry: blue filled circle
# multi-ancestry: orange hollow triangle
SHAPE_METHOD <- c(
  "single-ancestry" = 21,
  "multi-ancestry"  = 24
)

FILL_METHOD <- c(
  "single-ancestry" = "#1F4E79",
  "multi-ancestry"  = "white"
)

METHOD_LEVELS <- c(
  "single-ancestry",
  "multi-ancestry"
)

POINT_SIZE <- 1.15
POINT_STROKE <- 0.45
LEGEND_POINT_SIZE <- 1.45

Y_LIMITS <- c(
  0,
  100
)

Y_BREAKS <- seq(
  0,
  100,
  by = 20
)

############################################################
# 4. Calculate exact-match proportion
#
# Exact match:
# MAF_diff == 0 AND BP_diff == 0
#
# IMPORTANT:
# NA MAF_diff / BP_diff remain in the denominator.
# They are counted as non-matches.
############################################################

calc_prop_common <- function(dat) {
  
  max_val <- 0.5
  n_bins <- 14
  
  breaks <- seq(
    0,
    max_val,
    length.out = n_bins + 1
  )
  
  labels <- sprintf(
    "%.3f-%.3f",
    head(breaks, -1),
    tail(breaks, -1)
  )
  
  dat %>%
    
    filter(
      !is.na(causal_MAF),
      is.finite(causal_MAF)
    ) %>%
    
    mutate(
      
      maf_bin = cut(
        causal_MAF,
        breaks = breaks,
        labels = labels,
        include.lowest = TRUE,
        right = FALSE
      )
      
    ) %>%
    
    filter(
      !is.na(maf_bin)
    ) %>%
    
    group_by(
      maf_bin
    ) %>%
    
    summarise(
      
      total = n(),
      
      matched = sum(
        MAF_diff == 0 &
          BP_diff == 0,
        na.rm = TRUE
      ),
      
      prop = matched / total,
      
      maf_mean = mean(
        causal_MAF,
        na.rm = TRUE
      ),
      
      .groups = "drop"
    )
}


calc_prop_rare <- function(dat) {
  
  min_val <- 0.002
  max_val <- 0.01
  n_bins <- 7
  
  breaks <- seq(
    min_val,
    max_val,
    length.out = n_bins + 1
  )
  
  labels <- sprintf(
    "%.3f-%.3f",
    head(breaks, -1),
    tail(breaks, -1)
  )
  
  dat %>%
    
    filter(
      !is.na(causal_MAF),
      is.finite(causal_MAF)
    ) %>%
    
    mutate(
      
      maf_bin = cut(
        causal_MAF,
        breaks = breaks,
        labels = labels,
        include.lowest = TRUE,
        right = FALSE
      )
      
    ) %>%
    
    filter(
      !is.na(maf_bin)
    ) %>%
    
    group_by(
      maf_bin
    ) %>%
    
    summarise(
      
      total = n(),
      
      matched = sum(
        MAF_diff == 0 &
          BP_diff == 0,
        na.rm = TRUE
      ),
      
      prop = matched / total,
      
      maf_mean = mean(
        causal_MAF,
        na.rm = TRUE
      ),
      
      .groups = "drop"
    )
}

############################################################
# 5. Read one file and calculate proportions
############################################################

read_and_summarise <- function(
    file_path,
    analysis_type,
    ancestry_type,
    variant_type,
    source_name) {

  if (!file.exists(file_path)) {

    stop(
      "File not found: ",
      file_path
    )
  }

  message(
    "Processing: ",
    file_path
  )

  dt <- fread(
    file_path,
    data.table = FALSE
  )

  names(dt) <- trimws(
    names(dt)
  )

  ##########################################################
  # Apply the correct analysis-specific filter:
  #
  # GWAS:
  #   lead_P < 5e-8
  #
  # Fine-mapping:
  #   pip_max > 0.9
  ##########################################################

  if (analysis_type == "GWAS") {

    needed_cols <- c(
      "lead_P",
      "causal_MAF",
      "MAF_diff",
      "BP_diff"
    )

    missing_cols <- setdiff(
      needed_cols,
      names(dt)
    )

    if (length(missing_cols) > 0) {

      stop(
        "Missing required GWAS columns in ",
        file_path,
        ": ",
        paste(
          missing_cols,
          collapse = ", "
        )
      )
    }

    df <- dt %>%
      transmute(

        lead_P = suppressWarnings(
          as.numeric(lead_P)
        ),

        causal_MAF = suppressWarnings(
          as.numeric(causal_MAF)
        ),

        MAF_diff = suppressWarnings(
          as.numeric(MAF_diff)
        ),

        BP_diff = suppressWarnings(
          as.numeric(BP_diff)
        )
      ) %>%
      filter(
        !is.na(lead_P),
        lead_P < P_THRESHOLD
      )

    message(
      "  GWAS rows retained after lead_P < 5e-8: ",
      nrow(df)
    )

  } else if (analysis_type == "Fine-mapping") {

    needed_cols <- c(
      "pip_max",
      "causal_MAF",
      "MAF_diff",
      "BP_diff"
    )

    missing_cols <- setdiff(
      needed_cols,
      names(dt)
    )

    if (length(missing_cols) > 0) {

      stop(
        "Missing required fine-mapping columns in ",
        file_path,
        ": ",
        paste(
          missing_cols,
          collapse = ", "
        )
      )
    }

    df <- dt %>%
      transmute(

        pip_max = suppressWarnings(
          as.numeric(pip_max)
        ),

        causal_MAF = suppressWarnings(
          as.numeric(causal_MAF)
        ),

        MAF_diff = suppressWarnings(
          as.numeric(MAF_diff)
        ),

        BP_diff = suppressWarnings(
          as.numeric(BP_diff)
        )
      ) %>%
      filter(
        !is.na(pip_max),
        pip_max > PIP_THRESHOLD
      )

    message(
      "  Fine-mapping rows retained after PIP > 0.9: ",
      nrow(df)
    )

  } else {

    stop(
      "Unknown analysis_type: ",
      analysis_type
    )
  }

  ##########################################################
  # Common
  ##########################################################

  if (variant_type == "common") {

    res <- calc_prop_common(
      df
    )

  ##########################################################
  # Rare
  ##########################################################

  } else if (variant_type == "rare") {

    res <- calc_prop_rare(
      df
    )

  } else {

    stop(
      "Unknown variant_type: ",
      variant_type
    )
  }

  res %>%

    mutate(

      analysis_type =
        analysis_type,

      ancestry_type =
        ancestry_type,

      variant_type =
        variant_type,

      source_name =
        source_name
    ) %>%

    select(
      analysis_type,
      ancestry_type,
      variant_type,
      source_name,
      maf_bin,
      maf_mean,
      total,
      matched,
      prop
    )
}

############################################################
# 6. Process all files
############################################################

all_res_list <- lapply(
  
  seq_len(
    nrow(files_info)
  ),
  
  function(i) {
    
    read_and_summarise(
      
      file_path =
        files_info$file_path[i],
      
      analysis_type =
        files_info$analysis_type[i],
      
      ancestry_type =
        files_info$ancestry_type[i],
      
      variant_type =
        files_info$variant_type[i],
      
      source_name =
        files_info$source_name[i]
    )
  }
)

all_res <- bind_rows(
  all_res_list
)

############################################################
# 7. Print statistics
############################################################

print(
  all_res,
  n = Inf
)

############################################################
# 8. Save summary tables
############################################################

write.csv(
  all_res,
  file = file.path(
    OUT_DIR,
    "causal_MAF_bin_exact_match_summary_all.csv"
  ),
  row.names = FALSE
)

############################################################
# GWAS statistics
############################################################

write.csv(
  all_res %>%
    filter(
      analysis_type == "GWAS"
    ),
  file = file.path(
    OUT_DIR,
    "causal_MAF_bin_exact_match_summary_GWAS.csv"
  ),
  row.names = FALSE
)

############################################################
# 9. Figure theme
############################################################

gb_theme <- function(
    base_size = 8,
    show_legend = TRUE) {
  
  th <- theme_classic(
    base_size = base_size,
    base_family = "sans"
  ) +
    
    theme(
      aspect.ratio = 1,
      
      ######################################################
      # Axis
      ######################################################
      
      axis.line = element_line(
        linewidth = 0.35,
        colour = "black"
      ),
      
      axis.ticks = element_line(
        linewidth = 0.35,
        colour = "black"
      ),
      
      axis.ticks.length = unit(
        1.6,
        "mm"
      ),
      
      axis.title.x = element_text(size = 11.0, colour = "black", margin = margin(t = 5)),
      
      axis.title.y = element_text(size = 11.0, colour = "black", margin = margin(r = 6), lineheight = 0.95),
      
      axis.text.x = element_text(
        size = 9.5,
        colour = "black"
      ),
      
      axis.text.y = element_text(
        size = 9.5,
        colour = "black"
      ),
      
      ######################################################
      # Panel title
      ######################################################
      
      plot.title = element_text(size = 11.5, hjust = 0.5, vjust = 1, colour = "black", face = "plain", margin = margin(b = 6)),
      plot.title.position = "panel",
      plot.tag.position = c(0.002, 0.995),
      plot.tag = element_text(size = 11.5, colour = "black", face = "bold", hjust = 0, vjust = 1, margin = margin(0, 0, 0, 0)),
      
      ######################################################
      # Legend
      ######################################################
      
      legend.title =
        element_blank(),
      
      legend.text = element_text(
        size = 9.5,
        colour = "black"
      ),
      
      legend.key.width = unit(
        0.78,
        "cm"
      ),
      
      legend.key.height = unit(
        0.44,
        "cm"
      ),
      
      legend.background =
        element_blank(),
      
      legend.box.background =
        element_blank(),
      
      legend.key =
        element_rect(
          fill = "white",
          colour = NA
        ),
      
      legend.margin = margin(
        0,
        0,
        0,
        0
      ),
      
      ######################################################
      # Background
      ######################################################
      
      panel.border =
        element_blank(),
      
      panel.grid =
        element_blank(),
      
      panel.background =
        element_blank(),
      
      plot.background =
        element_rect(
          fill = "white",
          colour = NA
        ),
      
      plot.margin = margin(16, 10, 8, 20)
    )
  
  ##########################################################
  # Legend position
  ##########################################################
  
  if (show_legend) {
    th <- th +
      theme(
        legend.position = "bottom",
        legend.direction = "horizontal",
        legend.justification = "center",
        legend.box = "horizontal",
        legend.box.spacing = unit(5.5, "pt")
      )
  } else {
    th <- th +
      theme(
        legend.position = "none"
      )
  }
  
  th
}

############################################################
# 10. Build one MAF panel
############################################################

build_maf_panel <- function(
    dat,
    vt_select,
    panel_label = "",
    show_legend = FALSE) {
  
  d <- dat %>%
    
    filter(
      variant_type == vt_select
    ) %>%
    
    mutate(
      
      ancestry_type = factor(
        ancestry_type,
        levels = METHOD_LEVELS
      ),
      
      prop_percent =
        prop * 100
    )
  
  if (nrow(d) == 0) {
    
    stop(
      "No data available for variant_type = ",
      vt_select
    )
  }
  
  ##########################################################
  # Common
  ##########################################################
  
  if (vt_select == "common") {
    
    x_limits <- c(
      0,
      0.5
    )
    
    x_breaks <- seq(
      0,
      0.5,
      by = 0.1
    )
    
    title_use <- "common (MAF > 0.01)"
    
    ##########################################################
    # Rare
    #
    # IMPORTANT:
    # x-axis starts from 0.002
    ##########################################################
    
  } else if (vt_select == "rare") {
    
    x_limits <- c(
      0.002,
      0.01
    )
    
    x_breaks <- seq(
      0.002,
      0.01,
      by = 0.002
    )
    
    title_use <- "rare (MAF ≤ 0.01)"
    
  } else {
    
    stop(
      "Unknown variant type: ",
      vt_select
    )
  }
  
  ##########################################################
  # Plot
  ##########################################################
  
  p <- ggplot(
    d,
    aes(
      x = maf_mean,
      y = prop_percent,
      colour = ancestry_type,
      fill = ancestry_type,
      shape = ancestry_type
    )
  ) +
    
    ########################################################
  # Scatter points only
  # NO connecting lines
  ########################################################
  
  geom_point(
    size = POINT_SIZE,
    stroke = POINT_STROKE,
    na.rm = TRUE
  ) +
    
    ########################################################
  # Colours
  ########################################################
  
  scale_colour_manual(
    name = NULL,
    values = COL_METHOD,
    breaks = METHOD_LEVELS,
    labels = c("Single-ancestry", "Multi-ancestry"),
    drop = FALSE
  ) +
    
    ########################################################
  # Shapes
  ########################################################
  
  scale_shape_manual(
    name = NULL,
    values = SHAPE_METHOD,
    breaks = METHOD_LEVELS,
    labels = c("Single-ancestry", "Multi-ancestry"),
    drop = FALSE
  ) +
    
    ########################################################
  # Fills
  ########################################################
  
  scale_fill_manual(
    name = NULL,
    values = FILL_METHOD,
    breaks = METHOD_LEVELS,
    labels = c("Single-ancestry", "Multi-ancestry"),
    drop = FALSE
  ) +
    
    ########################################################
  # X axis
  ########################################################
  
  scale_x_continuous(
    limits = x_limits,
    breaks = x_breaks,
    expand = expansion(
      mult = c(
        0,
        0.02
      )
    )
  ) +
    
    ########################################################
  # Y axis
  ########################################################
  
  scale_y_continuous(
    limits = Y_LIMITS,
    breaks = Y_BREAKS,
    expand = expansion(
      mult = c(
        0,
        0.06
      )
    )
  ) +
    
    coord_cartesian(
      clip = "off"
    ) +
    
    ########################################################
  # Axis labels
  ########################################################
  
  labs(
    x = "MAF",
    y = "Exact causal match (%)",
    title = title_use,
    tag = if (nzchar(panel_label)) panel_label else NULL
  ) +
    
    ########################################################
  # Legend
  ########################################################
  
  guides(
    
    colour = guide_legend(
      
      override.aes = list(
        
        alpha =
          1,
        
        linetype =
          0,
        
        linewidth =
          0,
        
        size =
          LEGEND_POINT_SIZE,
        
        stroke =
          POINT_STROKE,
        
        shape =
          unname(
            SHAPE_METHOD[
              METHOD_LEVELS
            ]
          ),
        
        fill =
          unname(
            FILL_METHOD[
              METHOD_LEVELS
            ]
          )
      )
    ),
    
    shape = "none",
    
    fill = "none"
  ) +
    
    ########################################################
  # Theme
  ########################################################
  
  gb_theme(
    base_size = 8,
    show_legend = show_legend
  )
  
  return(p)
}

############################################################
# 11. Save GWAS common + rare group figure
############################################################

save_gwas_group_plot <- function(
    dat,
    out_prefix) {

  # Build both panels with the same legend specification, then extract one
  # shared legend and place it below the grouped figure.
  p_common <- build_maf_panel(
    dat = dat,
    vt_select = "common",
    panel_label = "a",
    show_legend = TRUE
  )

  p_rare <- build_maf_panel(
    dat = dat,
    vt_select = "rare",
    panel_label = "b",
    show_legend = TRUE
  )

  get_bottom_legend <- function(p) {
    g <- ggplotGrob(
      p +
        theme(
          legend.position = "bottom",
          legend.direction = "horizontal",
          legend.justification = "center",
          legend.box = "horizontal",
          legend.box.spacing = unit(0, "pt")
        )
    )

    idx <- which(grepl("^guide-box", g$layout$name))
    if (length(idx) == 0) return(grid::nullGrob())

    valid <- idx[
      !vapply(
        g$grobs[idx],
        inherits,
        logical(1),
        what = "zeroGrob"
      )
    ]

    if (length(valid) == 0) return(grid::nullGrob())
    g$grobs[[valid[1]]]
  }

  legend <- get_bottom_legend(p_common)
  p_common_no_legend <- p_common + theme(legend.position = "none")
  p_rare_no_legend <- p_rare + theme(legend.position = "none")

  pdf_file <- paste0(out_prefix, ".pdf")
  png_file <- paste0(out_prefix, ".png")

  draw_group <- function() {
    grid.newpage()

    pushViewport(
      viewport(
        layout = grid.layout(
          nrow = 3,
          ncol = 2,
          heights = unit.c(
            unit(1, "null"),
            unit(5.5, "pt"),
            grobHeight(legend)
          ),
          widths = unit(c(1, 1), "null"),
          respect = TRUE)
      )
    )

    print(
      p_common_no_legend,
      vp = viewport(layout.pos.row = 1, layout.pos.col = 1)
    )

    print(
      p_rare_no_legend,
      vp = viewport(layout.pos.row = 1, layout.pos.col = 2)
    )

    pushViewport(
      viewport(layout.pos.row = 3, layout.pos.col = 1:2)
    )
    grid.draw(legend)
    popViewport()
  }

  if (capabilities("cairo")) {
    cairo_pdf(
      filename = pdf_file,
      width = 8.6,
      height = 5.0,
      bg = "white"
    )
  } else {
    pdf(
      file = pdf_file,
      width = 8.6,
      height = 5.0,
      useDingbats = FALSE,
      bg = "white"
    )
  }

  draw_group()
  dev.off()

  png(
    filename = png_file,
    width = 8.6,
    height = 5.0,
    units = "in",
    res = 600,
    bg = "white"
  )

  draw_group()
  dev.off()

  message("Saved: ", pdf_file)
  message("Saved: ", png_file)
}


# 13. GWAS figure, original MAF-bin style and shared-legend grouping
gwas_dat <- all_res %>% filter(analysis_type == "GWAS")
save_gwas_group_plot(gwas_dat, file.path(OUT_DIR, "GWAS_exact_match_by_causal_MAF"))

# ===== PRESERVED ORIGINAL GWAS MODULE 7 =====

rm(list = ls())
gc()

suppressPackageStartupMessages({
  library(data.table)
  library(ggplot2)
  library(grid)
})

############################################################
# 1. Paths
############################################################

EUR_DIR <- "C:/Users/ASUS/Desktop/GWAS/gwas/模拟3/new_EUR"
POOLED_DIR <- "C:/Users/ASUS/Desktop/GWAS/gwas/模拟3/new_pooled"

FILES <- list(
  allvariants = c(
    "single-ancestry" = file.path(EUR_DIR, "allvariants_EUR_minP.merged.txt"),
    "multi-ancestry"  = file.path(POOLED_DIR, "pooled_allvar_minP.merged.txt")
  ),
  common = c(
    "single-ancestry" = file.path(EUR_DIR, "common_EUR_minP.merged.txt"),
    "multi-ancestry"  = file.path(POOLED_DIR, "pooled_common_minP.merged.txt")
  ),
  rare = c(
    "single-ancestry" = file.path(EUR_DIR, "rare_EUR_minP.merged.txt"),
    "multi-ancestry"  = file.path(POOLED_DIR, "pooled_rare_minP.merged.txt")
  )
)

OUT_DIR <- "C:/Users/ASUS/Desktop/GWAS/gwas/模拟3/results/new_results/real_final_plot"
dir.create(OUT_DIR, recursive = TRUE, showWarnings = FALSE)

PREFIX <- "original_var_size_fpr"

############################################################
# 2. Plot settings
#    Keep legend/style identical to previous single/multi plots
############################################################

COL_SINGLE <- "#1F4E79"
COL_MULTI  <- "#E69F00"

COL_MAIN <- c(
  "single-ancestry" = COL_SINGLE,
  "multi-ancestry"  = COL_MULTI
)

SHAPE_MAIN <- c(
  "single-ancestry" = 21,
  "multi-ancestry"  = 24
)

FILL_MAIN <- c(
  "single-ancestry" = COL_SINGLE,
  "multi-ancestry"  = "white"
)

MAIN_LABEL_LEVELS <- c("single-ancestry", "multi-ancestry")

POINT_SIZE <- 1.25
POINT_STROKE <- 0.45
LEGEND_POINT_SIZE <- 1.45
LEGEND_LINE_WIDTH <- 0.55

# Fixed visual distance between point and connecting curve,
# measured in normalised panel coordinates.
# Increased by 50% from 0.018 to 0.027.
FIXED_POINT_LINE_GAP_NPC <- 0.027

# Legend is placed at the upper-right of each panel.
# Y-axis: Genome-wide false positive rate.

# Horizontal reference line.
REF_Y <- 0.05
REF_LINE_COLOUR <- "#D62728"

# Points shown at these fixed P thresholds.
MARKER_P_FIXED <- c(1e-7, 5e-8, 1e-8, 1e-9, 1e-10)
MARKER_X_FIXED <- -log10(MARKER_P_FIXED)

# Requested x-axis.
X_MIN <- 7
X_MAX <- 10
X_BREAKS <- c(7, 8, 9, 10)

# Smooth-curve resolution.
SMOOTH_N <- 1201

############################################################
# 3. Helper functions
############################################################

fatal <- function(...) {
  stop(paste0(...), call. = FALSE)
}

panel_title <- function(vt, prefix = NULL) {
  txt <- switch(
    vt,
    allvariants = "all variants",
    common      = "common (MAF > 0.01)",
    rare        = "rare (MAF ≤ 0.01)",
    vt
  )
  
  if (!is.null(prefix)) {
    txt <- paste0(prefix, "  ", txt)
  }
  
  txt
}

read_lead_p <- function(file, variant_type, method) {
  if (!file.exists(file)) {
    fatal("Input file not found: ", file)
  }
  
  dt <- fread(file, data.table = TRUE)
  setnames(dt, trimws(names(dt)))
  
  p_col <- NULL
  candidates <- c("lead_P", "lead_p", "P", "p")
  
  for (cc in candidates) {
    if (cc %in% names(dt)) {
      p_col <- cc
      break
    }
  }
  
  if (is.null(p_col)) {
    fatal(
      "Cannot find a P-value column in: ", file,
      "\nCurrent columns: ", paste(names(dt), collapse = ", ")
    )
  }
  
  p <- suppressWarnings(as.numeric(dt[[p_col]]))
  p <- p[is.finite(p) & p > 0 & p <= 1]
  
  if (length(p) == 0) {
    fatal("No valid P values in: ", file)
  }
  
  data.table(
    variant_type = variant_type,
    method = method,
    lead_P = p
  )
}

calc_prop <- function(p_values, p_threshold) {
  mean(p_values < p_threshold, na.rm = TRUE)
}

# Empirical P threshold corresponding to y = 0.05.
# This follows the user's previous quantile-based definition.
calc_y005_threshold <- function(p_values) {
  q <- as.numeric(
    quantile(
      p_values,
      probs = REF_Y,
      na.rm = TRUE,
      names = FALSE,
      type = 7
    )
  )
  
  data.table(
    P_at_y005 = q,
    neglog10P_at_y005 = -log10(q),
    observed_prop_strict_lt = mean(p_values < q, na.rm = TRUE)
  )
}

make_fixed_points <- function(p_values, variant_type, method) {
  data.table(
    variant_type = variant_type,
    method = method,
    neglog10P = MARKER_X_FIXED,
    P_threshold = MARKER_P_FIXED,
    proportion = vapply(
      MARKER_P_FIXED,
      function(pp) calc_prop(p_values, pp),
      numeric(1)
    ),
    point_type = "fixed_threshold"
  )
}

make_y005_point <- function(p_values, variant_type, method) {
  th <- calc_y005_threshold(p_values)
  
  data.table(
    variant_type = variant_type,
    method = method,
    neglog10P = th$neglog10P_at_y005,
    P_threshold = th$P_at_y005,
    proportion = REF_Y,
    observed_prop_strict_lt = th$observed_prop_strict_lt,
    point_type = "empirical_y005"
  )
}

# If the empirical y=0.05 threshold exactly coincides with one of the
# fixed thresholds, retain the y=0.05 anchor at that x coordinate.
deduplicate_anchor_points <- function(dt) {
  d <- copy(dt)
  
  d[, priority := ifelse(point_type == "empirical_y005", 1L, 2L)]
  setorder(d, variant_type, method, neglog10P, priority)
  
  d <- d[
    ,
    .SD[1],
    by = .(variant_type, method, neglog10P)
  ]
  
  d[, priority := NULL]
  d[]
}

# Determine y-axis maximum using the two curves at x = 7.
# Round upward to the nearest 0.05 as requested previously.
get_ymax_from_x7 <- function(anchor_dt, vt) {
  d <- anchor_dt[
    variant_type == vt &
      abs(neglog10P - 7) < 1e-10
  ]
  
  if (nrow(d) == 0) {
    ymax <- 0.10
  } else {
    ymax <- max(d$proportion, na.rm = TRUE)
    ymax <- ceiling(ymax / 0.05) * 0.05
    ymax <- max(ymax, 0.10)
  }
  
  min(ymax, 1)
}

make_ybreaks <- function(ymax) {
  if (ymax <= 0.10) {
    return(seq(0, ymax, by = 0.025))
  }
  
  if (ymax <= 0.30) {
    return(seq(0, ymax, by = 0.05))
  }
  
  if (ymax <= 0.60) {
    return(seq(0, ymax, by = 0.10))
  }
  
  seq(0, ymax, by = 0.20)
}

# Build smooth curves using ONLY the displayed points.
# No intermediate empirical proportions are used.
build_smooth_curve_from_points <- function(anchor_dt, vt, ymax) {
  d0 <- anchor_dt[variant_type == vt]
  out <- list()
  
  for (mm in MAIN_LABEL_LEVELS) {
    d <- copy(d0[method == mm])
    d <- d[
      is.finite(neglog10P) &
        is.finite(proportion)
    ]
    
    if (nrow(d) < 2) {
      next
    }
    
    setorder(d, neglog10P)
    
    # Keep anchors relevant to constructing the visible x=7..10 curve.
    # A y=0.05 point outside this range is retained in statistics but
    # cannot be displayed because the requested plotting range is 7..10.
    d_fit <- d[neglog10P >= X_MIN & neglog10P <= X_MAX]
    
    if (nrow(d_fit) < 2) {
      next
    }
    
    # Enforce non-increasing proportions as -log10(P) becomes more stringent.
    # In well-formed empirical FPR data this should already hold.
    d_fit[, proportion_for_spline := cummin(proportion)]
    
    # Monotone cubic Hermite spline. It passes through the anchor points
    # and avoids oscillations typical of an unconstrained cubic spline.
    sf <- splinefun(
      x = d_fit$neglog10P,
      y = d_fit$proportion_for_spline,
      method = "monoH.FC"
    )
    
    x_grid <- seq(
      min(d_fit$neglog10P),
      max(d_fit$neglog10P),
      length.out = SMOOTH_N
    )
    
    y_grid <- sf(x_grid)
    
    # Keep the smooth curve inside the meaningful probability range.
    y_grid <- pmax(pmin(y_grid, 1), 0)
    
    cur <- data.table(
      variant_type = vt,
      method = mm,
      neglog10P = x_grid,
      proportion = y_grid
    )
    
    ##########################################################
    # Create a fixed-size blank region around every displayed
    # anchor point using normalised panel coordinates.
    ##########################################################
    
    anchor_visible <- d[
      neglog10P >= X_MIN &
        neglog10P <= X_MAX
    ]
    
    x_range <- X_MAX - X_MIN
    y_range <- ymax
    
    if (!is.finite(y_range) || y_range <= 0) {
      y_range <- 1
    }
    
    gap_flag <- rep(FALSE, nrow(cur))
    
    for (ii in seq_len(nrow(anchor_visible))) {
      xp <- anchor_visible$neglog10P[ii]
      yp <- anchor_visible$proportion[ii]
      
      dist_npc <- sqrt(
        ((cur$neglog10P - xp) / x_range)^2 +
          ((cur$proportion - yp) / y_range)^2
      )
      
      gap_flag <- gap_flag |
        (is.finite(dist_npc) & dist_npc < FIXED_POINT_LINE_GAP_NPC)
    }
    
    cur[, keep_curve := !gap_flag]
    
    # Split kept curve portions into independent path segments so ggplot
    # never reconnects across a point gap.
    cur[, run_id := rleid(keep_curve)]
    cur <- cur[keep_curve == TRUE]
    cur[, segment_id := paste0(mm, "_", run_id)]
    
    out[[mm]] <- cur
  }
  
  if (length(out) == 0) {
    return(data.table())
  }
  
  rbindlist(out, use.names = TRUE, fill = TRUE)
}

gb_theme <- function(base_size = 8, show_legend = TRUE) {
  th <- theme_classic(base_size = base_size, base_family = "sans") +
    theme(
      aspect.ratio = 1,
      axis.line = element_line(linewidth = 0.35, colour = "black"),
      axis.ticks = element_line(linewidth = 0.35, colour = "black"),
      axis.ticks.length = unit(1.6, "mm"),
      axis.title.x = element_text(size = 11.0, colour = "black", margin = margin(t = 5)),
      axis.title.y = element_text(size = 11.0, colour = "black", margin = margin(r = 6), lineheight = 0.95),
      axis.text = element_text(
        size = 9.5,
        colour = "black"
      ),
      plot.title = element_text(size = 11.5, hjust = 0.5, vjust = 1, colour = "black", face = "plain", margin = margin(b = 6)),
      plot.title.position = "panel",
      plot.tag.position = c(0.002, 0.995),
      plot.tag = element_text(size = 11.5, colour = "black", face = "bold", hjust = 0, vjust = 1, margin = margin(0, 0, 0, 0)),
      legend.title = element_blank(),
      legend.text = element_text(
        size = 9.5,
        colour = "black"
      ),
      legend.key.width = unit(0.62, "cm"),
      legend.key.height = unit(0.34, "cm"),
      legend.background = element_blank(),
      legend.box.background = element_blank(),
      legend.key = element_rect(fill = "white", colour = NA),
      legend.margin = margin(0, 0, 0, 0),
      legend.spacing.y = unit(0.055, "cm"),
      panel.border = element_blank(),
      panel.background = element_blank(),
      plot.background = element_rect(fill = "white", colour = NA),
      plot.margin = margin(16, 10, 8, 20)
    )
  
  if (show_legend) {
    th <- th +
      theme(
        legend.position = "bottom",
        legend.direction = "horizontal",
        legend.justification = "center",
        legend.box = "horizontal",
        legend.box.spacing = unit(5.5, "pt")
      )
  } else {
    th <- th +
      theme(
        legend.position = "none"
      )
  }
  
  th
}

build_plot <- function(
    anchor_dt,
    variant_type,
    show_legend = TRUE,
    title_prefix = NULL
) {
  vt <- variant_type
  
  d_point <- copy(
    anchor_dt[
      variant_type == vt &
        neglog10P >= X_MIN &
        neglog10P <= X_MAX
    ]
  )
  
  if (nrow(d_point) == 0) {
    warning("No visible anchor points for: ", vt)
    return(NULL)
  }
  
  ymax <- get_ymax_from_x7(anchor_dt, vt)
  ybreaks <- make_ybreaks(ymax)
  
  d_curve <- build_smooth_curve_from_points(
    anchor_dt = anchor_dt,
    vt = vt,
    ymax = ymax
  )
  
  if (nrow(d_curve) == 0) {
    warning("No smooth curve could be generated for: ", vt)
    return(NULL)
  }
  
  d_point[, method := factor(method, levels = MAIN_LABEL_LEVELS)]
  d_curve[, method := factor(method, levels = MAIN_LABEL_LEVELS)]
  
  p <- ggplot() +
    
    ##########################################################
  # Smooth connecting curve constructed only from anchor points
  ##########################################################
  
  geom_line(
    data = d_curve,
    aes(
      x = neglog10P,
      y = proportion,
      colour = method,
      group = segment_id
    ),
    linewidth = LEGEND_LINE_WIDTH,
    lineend = "round",
    show.legend = TRUE,
    na.rm = TRUE
  ) +
    
    ##########################################################
  # y = 0.05 reference line
  ##########################################################
  
  geom_hline(
    yintercept = REF_Y,
    colour = REF_LINE_COLOUR,
    linetype = "dashed",
    linewidth = 0.45,
    show.legend = FALSE
  ) +
    
    ##########################################################
  # Points ONLY at requested P thresholds plus BOTH methods
  # at BOTH empirical y=0.05 x positions
  ##########################################################
  
  geom_point(
    data = d_point,
    aes(
      x = neglog10P,
      y = proportion,
      colour = method,
      fill = method,
      shape = method
    ),
    size = POINT_SIZE,
    stroke = POINT_STROKE,
    show.legend = TRUE,
    na.rm = TRUE
  ) +
    
    scale_colour_manual(
      name = NULL,
      values = COL_MAIN,
      breaks = MAIN_LABEL_LEVELS,
      labels = c("Single-ancestry", "Multi-ancestry"),
      drop = FALSE
    ) +
    
    scale_shape_manual(
      name = NULL,
      values = SHAPE_MAIN,
      breaks = MAIN_LABEL_LEVELS,
      labels = c("Single-ancestry", "Multi-ancestry"),
      drop = FALSE,
      guide = "none"
    ) +
    
    scale_fill_manual(
      name = NULL,
      values = FILL_MAIN,
      breaks = MAIN_LABEL_LEVELS,
      labels = c("Single-ancestry", "Multi-ancestry"),
      drop = FALSE,
      guide = "none"
    ) +
    
    ##########################################################
  # Only 7, 8, 9, 10 are shown on x axis
  ##########################################################
  
  scale_x_continuous(
    limits = c(X_MIN, X_MAX),
    breaks = X_BREAKS,
    labels = c("7", "8", "9", "10"),
    expand = expansion(mult = c(0, 0.02))
  ) +
    
    scale_y_continuous(
      limits = c(0, ymax),
      breaks = ybreaks,
      expand = expansion(mult = c(0, 0.035)),
      labels = function(x) format(
        x,
        trim = TRUE,
        scientific = FALSE
      )
    ) +
    
    coord_cartesian(clip = "off") +
    
    labs(
      x = expression(-log[10](italic(P)~threshold)),
      y = "Genome-wide false positive rate",
      title = panel_title(vt),
      tag = if (!is.null(title_prefix) && nzchar(as.character(title_prefix))) as.character(title_prefix) else NULL
    ) +
    
    ##########################################################
  # Legend: line + point, identical single/multi style
  ##########################################################
  
  guides(
    colour = guide_legend(
      nrow = 1,
      byrow = TRUE,
      override.aes = list(
        alpha = 1,
        linewidth = LEGEND_LINE_WIDTH,
        linetype = 1,
        size = LEGEND_POINT_SIZE,
        stroke = POINT_STROKE,
        shape = unname(
          SHAPE_MAIN[MAIN_LABEL_LEVELS]
        ),
        fill = unname(
          FILL_MAIN[MAIN_LABEL_LEVELS]
        )
      )
    )
  ) +
    
    gb_theme(
      base_size = 8,
      show_legend = show_legend
    )
  
  p
}

save_plot_pdf_png <- function(
    p,
    out_prefix,
    width = 4.0,
    height = 5.0
) {
  pdf_file <- paste0(out_prefix, ".pdf")
  png_file <- paste0(out_prefix, ".png")
  
  if (capabilities("cairo")) {
    grDevices::cairo_pdf(
      filename = pdf_file,
      width = width,
      height = height,
      bg = "white"
    )
  } else {
    grDevices::pdf(
      file = pdf_file,
      width = width,
      height = height,
      useDingbats = FALSE,
      bg = "white"
    )
  }
  
  print(p)
  grDevices::dev.off()
  
  grDevices::png(
    filename = png_file,
    width = width,
    height = height,
    units = "in",
    res = 600,
    bg = "white"
  )
  
  print(p)
  grDevices::dev.off()
}

save_combined_three <- function(
    p1,
    p2,
    p3,
    out_prefix,
    width = 11.8,
    height = 5.0
) {
  pdf_file <- paste0(out_prefix, ".pdf")
  png_file <- paste0(out_prefix, ".png")

  get_bottom_legend <- function(p) {
    g <- ggplotGrob(
      p +
        theme(
          legend.position = "bottom",
          legend.direction = "horizontal",
          legend.justification = "center",
          legend.box = "horizontal",
          legend.box.spacing = unit(0, "pt")
        )
    )

    idx <- which(grepl("^guide-box", g$layout$name))
    if (length(idx) == 0) return(grid::nullGrob())

    valid <- idx[
      !vapply(
        g$grobs[idx],
        inherits,
        logical(1),
        what = "zeroGrob"
      )
    ]

    if (length(valid) == 0) return(grid::nullGrob())
    g$grobs[[valid[1]]]
  }

  legend <- get_bottom_legend(p3)
  p1_no_legend <- p1 + theme(legend.position = "none")
  p2_no_legend <- p2 + theme(legend.position = "none")
  p3_no_legend <- p3 + theme(legend.position = "none")

  draw_three <- function() {
    grid.newpage()

    pushViewport(
      viewport(
        layout = grid.layout(
          nrow = 3,
          ncol = 3,
          heights = unit.c(
            unit(1, "null"),
            unit(5.5, "pt"),
            grobHeight(legend)
          ),
          widths = unit(c(1, 1, 1), "null"),
          respect = TRUE)
      )
    )

    print(
      p1_no_legend,
      vp = viewport(layout.pos.row = 1, layout.pos.col = 1)
    )

    print(
      p2_no_legend,
      vp = viewport(layout.pos.row = 1, layout.pos.col = 2)
    )

    print(
      p3_no_legend,
      vp = viewport(layout.pos.row = 1, layout.pos.col = 3)
    )

    pushViewport(
      viewport(layout.pos.row = 3, layout.pos.col = 1:3)
    )
    grid.draw(legend)
    popViewport()
  }

  device_height <- height + 0.35

  if (capabilities("cairo")) {
    grDevices::cairo_pdf(
      filename = pdf_file,
      width = width,
      height = device_height,
      bg = "white"
    )
  } else {
    grDevices::pdf(
      file = pdf_file,
      width = width,
      height = device_height,
      useDingbats = FALSE,
      bg = "white"
    )
  }

  draw_three()
  dev.off()

  grDevices::png(
    filename = png_file,
    width = width,
    height = device_height,
    units = "in",
    res = 600,
    bg = "white"
  )

  draw_three()
  dev.off()
}

############################################################
# 4. Read input files
############################################################

raw_list <- list()

for (vt in names(FILES)) {
  for (mm in names(FILES[[vt]])) {
    raw_list[[paste(vt, mm, sep = "__")]] <- read_lead_p(
      FILES[[vt]][[mm]],
      variant_type = vt,
      method = mm
    )
  }
}

raw_dt <- rbindlist(
  raw_list,
  use.names = TRUE,
  fill = TRUE
)

raw_summary <- raw_dt[
  ,
  .(
    n = .N,
    min_P = min(lead_P),
    median_P = median(lead_P),
    max_P = max(lead_P)
  ),
  by = .(
    variant_type,
    method
  )
]

fwrite(
  raw_summary,
  file.path(
    OUT_DIR,
    paste0(
      PREFIX,
      "_input_leadP_summary.csv"
    )
  )
)

############################################################
# 5. Fixed threshold anchor points
############################################################

fixed_point_list <- list()

for (vt in unique(raw_dt$variant_type)) {
  for (mm in MAIN_LABEL_LEVELS) {
    
    pp <- raw_dt[
      variant_type == vt &
        method == mm,
      lead_P
    ]
    
    fixed_point_list[[paste(vt, mm, sep = "__")]] <- make_fixed_points(
      pp,
      vt,
      mm
    )
  }
}

fixed_point_dt <- rbindlist(
  fixed_point_list,
  use.names = TRUE,
  fill = TRUE
)

fwrite(
  fixed_point_dt,
  file.path(
    OUT_DIR,
    paste0(
      PREFIX,
      "_requested_marker_threshold_proportions.csv"
    )
  )
)

############################################################
# 6. y = 0.05 empirical threshold points
############################################################

y005_list <- list()

for (vt in unique(raw_dt$variant_type)) {
  for (mm in MAIN_LABEL_LEVELS) {
    
    pp <- raw_dt[
      variant_type == vt &
        method == mm,
      lead_P
    ]
    
    y005_list[[paste(vt, mm, sep = "__")]] <- make_y005_point(
      pp,
      vt,
      mm
    )
  }
}

y005_dt <- rbindlist(
  y005_list,
  use.names = TRUE,
  fill = TRUE
)

y005_dt[
  ,
  P_at_y005_scientific := format(
    P_threshold,
    scientific = TRUE,
    digits = 6
  )
]

fwrite(
  y005_dt,
  file.path(
    OUT_DIR,
    paste0(
      PREFIX,
      "_empirical_P_threshold_at_y005_single_vs_multi.csv"
    )
  )
)

############################################################
# 7. Evaluate both methods at each y=0.05 anchor threshold
############################################################

cross_eval_list <- list()

for (vt in unique(raw_dt$variant_type)) {
  
  anchors <- y005_dt[
    variant_type == vt
  ]
  
  for (anchor_method in MAIN_LABEL_LEVELS) {
    
    anchor_row <- anchors[
      method == anchor_method
    ]
    
    if (nrow(anchor_row) != 1) {
      next
    }
    
    anchor_p <- anchor_row$P_threshold
    anchor_x <- anchor_row$neglog10P
    
    for (eval_method in MAIN_LABEL_LEVELS) {
      
      eval_p <- raw_dt[
        variant_type == vt &
          method == eval_method,
        lead_P
      ]
      
      cross_eval_list[[length(cross_eval_list) + 1]] <- data.table(
        variant_type = vt,
        anchor_method = anchor_method,
        evaluated_method = eval_method,
        anchor_P_threshold = anchor_p,
        anchor_neglog10P = anchor_x,
        proportion_at_anchor = calc_prop(
          eval_p,
          anchor_p
        )
      )
    }
  }
}

cross_eval_dt <- rbindlist(
  cross_eval_list,
  use.names = TRUE,
  fill = TRUE
)

fwrite(
  cross_eval_dt,
  file.path(
    OUT_DIR,
    paste0(
      PREFIX,
      "_cross_method_proportions_at_each_y005_threshold.csv"
    )
  )
)

############################################################
# 8. Build cross-method y=0.05-position points
#
# At the x coordinate where single-ancestry reaches y=0.05,
# also plot the multi-ancestry value.
# At the x coordinate where multi-ancestry reaches y=0.05,
# also plot the single-ancestry value.
############################################################

cross_y005_point_dt <- cross_eval_dt[
  anchor_method != evaluated_method,
  .(
    variant_type,
    method = evaluated_method,
    neglog10P = anchor_neglog10P,
    P_threshold = anchor_P_threshold,
    proportion = proportion_at_anchor,
    point_type = paste0("cross_at_", anchor_method, "_y005")
  )
]

fwrite(
  cross_y005_point_dt,
  file.path(
    OUT_DIR,
    paste0(
      PREFIX,
      "_cross_method_points_at_both_y005_xpositions.csv"
    )
  )
)

############################################################
# 9. Combine anchor points used for BOTH points and curves
############################################################

anchor_dt <- rbindlist(
  list(
    fixed_point_dt[
      ,
      .(
        variant_type,
        method,
        neglog10P,
        P_threshold,
        proportion,
        point_type
      )
    ],
    y005_dt[
      ,
      .(
        variant_type,
        method,
        neglog10P,
        P_threshold,
        proportion,
        point_type
      )
    ],
    cross_y005_point_dt[
      ,
      .(
        variant_type,
        method,
        neglog10P,
        P_threshold,
        proportion,
        point_type
      )
    ]
  ),
  use.names = TRUE,
  fill = TRUE
)

anchor_dt <- deduplicate_anchor_points(anchor_dt)

fwrite(
  anchor_dt,
  file.path(
    OUT_DIR,
    paste0(
      PREFIX,
      "_all_anchor_points_used_for_smooth_curves_with_cross_y005.csv"
    )
  )
)

############################################################
# 10. Draw separate figures
############################################################

p_all <- build_plot(
  anchor_dt,
  "allvariants",
  show_legend = TRUE
)

p_common <- build_plot(
  anchor_dt,
  "common",
  show_legend = TRUE
)

p_rare <- build_plot(
  anchor_dt,
  "rare",
  show_legend = TRUE
)

if (!is.null(p_all)) {
  save_plot_pdf_png(
    p_all,
    file.path(
      OUT_DIR,
      paste0(
        "Fig_",
        PREFIX,
        "_allvariants_single_vs_multi_smooth"
      )
    )
  )
}

if (!is.null(p_common)) {
  save_plot_pdf_png(
    p_common,
    file.path(
      OUT_DIR,
      paste0(
        "Fig_",
        PREFIX,
        "_common_single_vs_multi_smooth"
      )
    )
  )
}

if (!is.null(p_rare)) {
  save_plot_pdf_png(
    p_rare,
    file.path(
      OUT_DIR,
      paste0(
        "Fig_",
        PREFIX,
        "_rare_single_vs_multi_smooth"
      )
    )
  )
}

############################################################
# 11. Grouped figure
#     a/b/c use the same format as previous grouped figures.
#     Each panel retains complete x/y axes and axis titles.
############################################################

p_all_g <- build_plot(
  anchor_dt,
  "allvariants",
  show_legend = FALSE,
  title_prefix = "a"
)

p_common_g <- build_plot(
  anchor_dt,
  "common",
  show_legend = FALSE,
  title_prefix = "b"
)

p_rare_g <- build_plot(
  anchor_dt,
  "rare",
  show_legend = TRUE,
  title_prefix = "c"
)

if (
  !is.null(p_all_g) &&
  !is.null(p_common_g) &&
  !is.null(p_rare_g)
) {
  save_combined_three(
    p_all_g,
    p_common_g,
    p_rare_g,
    file.path(
      OUT_DIR,
      paste0(
        "Fig_",
        PREFIX,
        "_all_common_rare_grouped_smooth"
      )
    )
  )
}

############################################################
# 12. Console summary
############################################################

message("============================================================")
message("[INFO] Analysis completed")
message("[INFO] Output directory:")
message(OUT_DIR)
message("")
message("[INFO] Curves use ONLY these displayed anchor points:")
message("       P = 1e-7, 5e-8, 1e-8, 1e-9, 1e-10")
message("       + single-ancestry empirical y=0.05 threshold")
message("         and multi-ancestry evaluated at that same P threshold")
message("       + multi-ancestry empirical y=0.05 threshold")
message("         and single-ancestry evaluated at that same P threshold")
message("")
message("[INFO] x-axis labels shown only at 7, 8, 9, 10")
message("")
message("[INFO] Empirical y=0.05 thresholds:")
print(
  y005_dt[
    ,
    .(
      variant_type,
      method,
      P_at_y005 = P_threshold,
      neglog10P_at_y005 = neglog10P,
      observed_prop_strict_lt
    )
  ]
)
message("============================================================")
































######################################################################################################################################MAF bin




# ===== PRESERVED ORIGINAL GWAS MODULE 10 =====

rm(list = ls())
gc()

suppressPackageStartupMessages({
  library(data.table)
  library(ggplot2)
  library(grid)
})

############################################################
# 1. Paths
############################################################

BASE_DIR <- "C:/Users/ASUS/Desktop/GWAS/gwas/模拟3/match_varsize_FPR"

FILES <- list(
  allvariants = c(
    "single-ancestry" = file.path(BASE_DIR, "EUR10K_allvariants_minP.merged.txt"),
    "multi-ancestry"  = file.path(BASE_DIR, "pooled_allvariants_minP.merged.txt")
  ),
  common = c(
    "single-ancestry" = file.path(BASE_DIR, "EUR10K_common_minP.merged.txt"),
    "multi-ancestry"  = file.path(BASE_DIR, "pooled_common_minP.merged.txt")
  ),
  rare = c(
    "single-ancestry" = file.path(BASE_DIR, "EUR10K_rare_minP.merged.txt"),
    "multi-ancestry"  = file.path(BASE_DIR, "pooled_rare_minP.merged.txt")
  )
)

OUT_DIR <- "C:/Users/ASUS/Desktop/GWAS/gwas/模拟3/results/new_results/real_final_plot"
dir.create(OUT_DIR, recursive = TRUE, showWarnings = FALSE)

PREFIX <- "match_var_size_fpr"

############################################################
# 2. Plot settings
#    Keep legend/style identical to previous single/multi plots
############################################################

COL_SINGLE <- "#1F4E79"
COL_MULTI  <- "#E69F00"

COL_MAIN <- c(
  "single-ancestry" = COL_SINGLE,
  "multi-ancestry"  = COL_MULTI
)

SHAPE_MAIN <- c(
  "single-ancestry" = 21,
  "multi-ancestry"  = 24
)

FILL_MAIN <- c(
  "single-ancestry" = COL_SINGLE,
  "multi-ancestry"  = "white"
)

MAIN_LABEL_LEVELS <- c("single-ancestry", "multi-ancestry")

POINT_SIZE <- 1.25
POINT_STROKE <- 0.45
LEGEND_POINT_SIZE <- 1.45
LEGEND_LINE_WIDTH <- 0.55

# Fixed visual distance between point and connecting curve,
# measured in normalised panel coordinates.
# Increased by 50% from 0.018 to 0.027.
FIXED_POINT_LINE_GAP_NPC <- 0.027

# Legend is placed at the upper-right of each panel.
# Y-axis: Genome-wide false positive rate.

# Horizontal reference line.
REF_Y <- 0.05
REF_LINE_COLOUR <- "#D62728"

# Points shown at these fixed P thresholds.
MARKER_P_FIXED <- c(1e-7, 5e-8, 1e-8, 1e-9, 1e-10)
MARKER_X_FIXED <- -log10(MARKER_P_FIXED)

# Requested x-axis.
X_MIN <- 7
X_MAX <- 10
X_BREAKS <- c(7, 8, 9, 10)

# Smooth-curve resolution.
SMOOTH_N <- 1201

############################################################
# 3. Helper functions
############################################################

fatal <- function(...) {
  stop(paste0(...), call. = FALSE)
}

panel_title <- function(vt, prefix = NULL) {
  txt <- switch(
    vt,
    allvariants = "all variants",
    common      = "common (MAF > 0.01)",
    rare        = "rare (MAF ≤ 0.01)",
    vt
  )

  if (!is.null(prefix)) {
    txt <- paste0(prefix, "  ", txt)
  }

  txt
}

read_lead_p <- function(file, variant_type, method) {
  if (!file.exists(file)) {
    fatal("Input file not found: ", file)
  }

  dt <- fread(file, data.table = TRUE)
  setnames(dt, trimws(names(dt)))

  p_col <- NULL
  candidates <- c("lead_P", "lead_p", "P", "p")

  for (cc in candidates) {
    if (cc %in% names(dt)) {
      p_col <- cc
      break
    }
  }

  if (is.null(p_col)) {
    fatal(
      "Cannot find a P-value column in: ", file,
      "\nCurrent columns: ", paste(names(dt), collapse = ", ")
    )
  }

  p <- suppressWarnings(as.numeric(dt[[p_col]]))
  p <- p[is.finite(p) & p > 0 & p <= 1]

  if (length(p) == 0) {
    fatal("No valid P values in: ", file)
  }

  data.table(
    variant_type = variant_type,
    method = method,
    lead_P = p
  )
}

calc_prop <- function(p_values, p_threshold) {
  mean(p_values < p_threshold, na.rm = TRUE)
}

# Empirical P threshold corresponding to y = 0.05.
# This follows the user's previous quantile-based definition.
calc_y005_threshold <- function(p_values) {
  q <- as.numeric(
    quantile(
      p_values,
      probs = REF_Y,
      na.rm = TRUE,
      names = FALSE,
      type = 7
    )
  )

  data.table(
    P_at_y005 = q,
    neglog10P_at_y005 = -log10(q),
    observed_prop_strict_lt = mean(p_values < q, na.rm = TRUE)
  )
}

make_fixed_points <- function(p_values, variant_type, method) {
  data.table(
    variant_type = variant_type,
    method = method,
    neglog10P = MARKER_X_FIXED,
    P_threshold = MARKER_P_FIXED,
    proportion = vapply(
      MARKER_P_FIXED,
      function(pp) calc_prop(p_values, pp),
      numeric(1)
    ),
    point_type = "fixed_threshold"
  )
}

make_y005_point <- function(p_values, variant_type, method) {
  th <- calc_y005_threshold(p_values)

  data.table(
    variant_type = variant_type,
    method = method,
    neglog10P = th$neglog10P_at_y005,
    P_threshold = th$P_at_y005,
    proportion = REF_Y,
    observed_prop_strict_lt = th$observed_prop_strict_lt,
    point_type = "empirical_y005"
  )
}

# If the empirical y=0.05 threshold exactly coincides with one of the
# fixed thresholds, retain the y=0.05 anchor at that x coordinate.
deduplicate_anchor_points <- function(dt) {
  d <- copy(dt)

  d[, priority := ifelse(point_type == "empirical_y005", 1L, 2L)]
  setorder(d, variant_type, method, neglog10P, priority)

  d <- d[
    ,
    .SD[1],
    by = .(variant_type, method, neglog10P)
  ]

  d[, priority := NULL]
  d[]
}

# Determine y-axis maximum using the two curves at x = 7.
# Round upward to the nearest 0.05 as requested previously.
get_ymax_from_x7 <- function(anchor_dt, vt) {
  d <- anchor_dt[
    variant_type == vt &
      abs(neglog10P - 7) < 1e-10
  ]

  if (nrow(d) == 0) {
    ymax <- 0.10
  } else {
    ymax <- max(d$proportion, na.rm = TRUE)
    ymax <- ceiling(ymax / 0.05) * 0.05
    ymax <- max(ymax, 0.10)
  }

  min(ymax, 1)
}

make_ybreaks <- function(ymax) {
  if (ymax <= 0.10) {
    return(seq(0, ymax, by = 0.025))
  }

  if (ymax <= 0.30) {
    return(seq(0, ymax, by = 0.05))
  }

  if (ymax <= 0.60) {
    return(seq(0, ymax, by = 0.10))
  }

  seq(0, ymax, by = 0.20)
}

# Build smooth curves using ONLY the displayed points.
# No intermediate empirical proportions are used.
build_smooth_curve_from_points <- function(anchor_dt, vt, ymax) {
  d0 <- anchor_dt[variant_type == vt]
  out <- list()

  for (mm in MAIN_LABEL_LEVELS) {
    d <- copy(d0[method == mm])
    d <- d[
      is.finite(neglog10P) &
      is.finite(proportion)
    ]

    if (nrow(d) < 2) {
      next
    }

    setorder(d, neglog10P)

    # Keep anchors relevant to constructing the visible x=7..10 curve.
    # A y=0.05 point outside this range is retained in statistics but
    # cannot be displayed because the requested plotting range is 7..10.
    d_fit <- d[neglog10P >= X_MIN & neglog10P <= X_MAX]

    if (nrow(d_fit) < 2) {
      next
    }

    # Enforce non-increasing proportions as -log10(P) becomes more stringent.
    # In well-formed empirical FPR data this should already hold.
    d_fit[, proportion_for_spline := cummin(proportion)]

    # Monotone cubic Hermite spline. It passes through the anchor points
    # and avoids oscillations typical of an unconstrained cubic spline.
    sf <- splinefun(
      x = d_fit$neglog10P,
      y = d_fit$proportion_for_spline,
      method = "monoH.FC"
    )

    x_grid <- seq(
      min(d_fit$neglog10P),
      max(d_fit$neglog10P),
      length.out = SMOOTH_N
    )

    y_grid <- sf(x_grid)

    # Keep the smooth curve inside the meaningful probability range.
    y_grid <- pmax(pmin(y_grid, 1), 0)

    cur <- data.table(
      variant_type = vt,
      method = mm,
      neglog10P = x_grid,
      proportion = y_grid
    )

    ##########################################################
    # Create a fixed-size blank region around every displayed
    # anchor point using normalised panel coordinates.
    ##########################################################

    anchor_visible <- d[
      neglog10P >= X_MIN &
      neglog10P <= X_MAX
    ]

    x_range <- X_MAX - X_MIN
    y_range <- ymax

    if (!is.finite(y_range) || y_range <= 0) {
      y_range <- 1
    }

    gap_flag <- rep(FALSE, nrow(cur))

    for (ii in seq_len(nrow(anchor_visible))) {
      xp <- anchor_visible$neglog10P[ii]
      yp <- anchor_visible$proportion[ii]

      dist_npc <- sqrt(
        ((cur$neglog10P - xp) / x_range)^2 +
        ((cur$proportion - yp) / y_range)^2
      )

      gap_flag <- gap_flag |
        (is.finite(dist_npc) & dist_npc < FIXED_POINT_LINE_GAP_NPC)
    }

    cur[, keep_curve := !gap_flag]

    # Split kept curve portions into independent path segments so ggplot
    # never reconnects across a point gap.
    cur[, run_id := rleid(keep_curve)]
    cur <- cur[keep_curve == TRUE]
    cur[, segment_id := paste0(mm, "_", run_id)]

    out[[mm]] <- cur
  }

  if (length(out) == 0) {
    return(data.table())
  }

  rbindlist(out, use.names = TRUE, fill = TRUE)
}

gb_theme <- function(base_size = 8, show_legend = TRUE) {
  th <- theme_classic(base_size = base_size, base_family = "sans") +
    theme(
      aspect.ratio = 1,
      axis.line = element_line(linewidth = 0.35, colour = "black"),
      axis.ticks = element_line(linewidth = 0.35, colour = "black"),
      axis.ticks.length = unit(1.6, "mm"),
      axis.title.x = element_text(size = 11.0, colour = "black", margin = margin(t = 5)),
      axis.title.y = element_text(size = 11.0, colour = "black", margin = margin(r = 6), lineheight = 0.95),
      axis.text = element_text(
        size = 9.5,
        colour = "black"
      ),
      plot.title = element_text(size = 11.5, hjust = 0.5, vjust = 1, colour = "black", face = "plain", margin = margin(b = 6)),
      plot.title.position = "panel",
      plot.tag.position = c(0.002, 0.995),
      plot.tag = element_text(size = 11.5, colour = "black", face = "bold", hjust = 0, vjust = 1, margin = margin(0, 0, 0, 0)),
      legend.title = element_blank(),
      legend.text = element_text(
        size = 9.5,
        colour = "black"
      ),
      legend.key.width = unit(0.62, "cm"),
      legend.key.height = unit(0.34, "cm"),
      legend.background = element_blank(),
      legend.box.background = element_blank(),
      legend.key = element_rect(fill = "white", colour = NA),
      legend.margin = margin(0, 0, 0, 0),
      legend.spacing.y = unit(0.055, "cm"),
      panel.border = element_blank(),
      panel.background = element_blank(),
      plot.background = element_rect(fill = "white", colour = NA),
      plot.margin = margin(16, 10, 8, 20)
    )

  if (show_legend) {
    th <- th +
      theme(
        legend.position = "bottom",
        legend.direction = "horizontal",
        legend.justification = "center",
        legend.box = "horizontal",
        legend.box.spacing = unit(5.5, "pt")
      )
  } else {
    th <- th +
      theme(
        legend.position = "none"
      )
  }

  th
}

build_plot <- function(
  anchor_dt,
  variant_type,
  show_legend = TRUE,
  title_prefix = NULL
) {
  vt <- variant_type

  d_point <- copy(
    anchor_dt[
      variant_type == vt &
      neglog10P >= X_MIN &
      neglog10P <= X_MAX
    ]
  )

  if (nrow(d_point) == 0) {
    warning("No visible anchor points for: ", vt)
    return(NULL)
  }

  ymax <- get_ymax_from_x7(anchor_dt, vt)
  ybreaks <- make_ybreaks(ymax)

  d_curve <- build_smooth_curve_from_points(
    anchor_dt = anchor_dt,
    vt = vt,
    ymax = ymax
  )

  if (nrow(d_curve) == 0) {
    warning("No smooth curve could be generated for: ", vt)
    return(NULL)
  }

  d_point[, method := factor(method, levels = MAIN_LABEL_LEVELS)]
  d_curve[, method := factor(method, levels = MAIN_LABEL_LEVELS)]

  p <- ggplot() +

    ##########################################################
    # Smooth connecting curve constructed only from anchor points
    ##########################################################

    geom_line(
      data = d_curve,
      aes(
        x = neglog10P,
        y = proportion,
        colour = method,
        group = segment_id
      ),
      linewidth = LEGEND_LINE_WIDTH,
      lineend = "round",
      show.legend = TRUE,
      na.rm = TRUE
    ) +

    ##########################################################
    # y = 0.05 reference line
    ##########################################################

    geom_hline(
      yintercept = REF_Y,
      colour = REF_LINE_COLOUR,
      linetype = "dashed",
      linewidth = 0.45,
      show.legend = FALSE
    ) +

    ##########################################################
    # Points ONLY at requested P thresholds plus BOTH methods
    # at BOTH empirical y=0.05 x positions
    ##########################################################

    geom_point(
      data = d_point,
      aes(
        x = neglog10P,
        y = proportion,
        colour = method,
        fill = method,
        shape = method
      ),
      size = POINT_SIZE,
      stroke = POINT_STROKE,
      show.legend = TRUE,
      na.rm = TRUE
    ) +

    scale_colour_manual(
      name = NULL,
      values = COL_MAIN,
      breaks = MAIN_LABEL_LEVELS,
      labels = c("Single-ancestry", "Multi-ancestry"),
      drop = FALSE
    ) +

    scale_shape_manual(
      name = NULL,
      values = SHAPE_MAIN,
      breaks = MAIN_LABEL_LEVELS,
      labels = c("Single-ancestry", "Multi-ancestry"),
      drop = FALSE,
      guide = "none"
    ) +

    scale_fill_manual(
      name = NULL,
      values = FILL_MAIN,
      breaks = MAIN_LABEL_LEVELS,
      labels = c("Single-ancestry", "Multi-ancestry"),
      drop = FALSE,
      guide = "none"
    ) +

    ##########################################################
    # Only 7, 8, 9, 10 are shown on x axis
    ##########################################################

    scale_x_continuous(
      limits = c(X_MIN, X_MAX),
      breaks = X_BREAKS,
      labels = c("7", "8", "9", "10"),
      expand = expansion(mult = c(0, 0.02))
    ) +

    scale_y_continuous(
      limits = c(0, ymax),
      breaks = ybreaks,
      expand = expansion(mult = c(0, 0.035)),
      labels = function(x) format(
        x,
        trim = TRUE,
        scientific = FALSE
      )
    ) +

    coord_cartesian(clip = "off") +

    labs(
      x = expression(-log[10](italic(P)~threshold)),
      y = "Genome-wide false positive rate",
      title = panel_title(vt),
      tag = if (!is.null(title_prefix) && nzchar(as.character(title_prefix))) as.character(title_prefix) else NULL
    ) +

    ##########################################################
    # Legend: line + point, identical single/multi style
    ##########################################################

    guides(
      colour = guide_legend(
        nrow = 1,
        byrow = TRUE,
        override.aes = list(
          alpha = 1,
          linewidth = LEGEND_LINE_WIDTH,
          linetype = 1,
          size = LEGEND_POINT_SIZE,
          stroke = POINT_STROKE,
          shape = unname(
            SHAPE_MAIN[MAIN_LABEL_LEVELS]
          ),
          fill = unname(
            FILL_MAIN[MAIN_LABEL_LEVELS]
          )
        )
      )
    ) +

    gb_theme(
      base_size = 8,
      show_legend = show_legend
    )

  p
}

save_plot_pdf_png <- function(
  p,
  out_prefix,
  width = 3.35,
  height = 5.0
) {
  pdf_file <- paste0(out_prefix, ".pdf")
  png_file <- paste0(out_prefix, ".png")

  if (capabilities("cairo")) {
    grDevices::cairo_pdf(
      filename = pdf_file,
      width = width,
      height = height,
      bg = "white"
    )
  } else {
    grDevices::pdf(
      file = pdf_file,
      width = width,
      height = height,
      useDingbats = FALSE,
      bg = "white"
    )
  }

  print(p)
  grDevices::dev.off()

  grDevices::png(
    filename = png_file,
    width = width,
    height = height,
    units = "in",
    res = 600,
    bg = "white"
  )

  print(p)
  grDevices::dev.off()
}

save_combined_three <- function(
  p1,
  p2,
  p3,
  out_prefix,
  width = 10.2,
  height = 5.0
) {
  pdf_file <- paste0(out_prefix, ".pdf")
  png_file <- paste0(out_prefix, ".png")

  get_bottom_legend <- function(p) {
    g <- ggplotGrob(
      p +
        guides(
          colour = guide_legend(
            nrow = 1,
            byrow = TRUE,
            override.aes = list(
              alpha = 1,
              linewidth = LEGEND_LINE_WIDTH,
              linetype = 1,
              size = LEGEND_POINT_SIZE,
              stroke = POINT_STROKE,
              shape = unname(SHAPE_MAIN[MAIN_LABEL_LEVELS]),
              fill = unname(FILL_MAIN[MAIN_LABEL_LEVELS])
            )
          )
        ) +
        theme(
          legend.position = "bottom",
          legend.direction = "horizontal",
          legend.justification = "center",
          legend.box = "horizontal",
          legend.box.spacing = unit(0, "pt")
        )
    )

    idx <- which(grepl("^guide-box", g$layout$name))
    if (length(idx) == 0) return(grid::nullGrob())

    valid <- idx[
      !vapply(
        g$grobs[idx],
        inherits,
        logical(1),
        what = "zeroGrob"
      )
    ]

    if (length(valid) == 0) return(grid::nullGrob())
    g$grobs[[valid[1]]]
  }

  # One shared horizontal legend below the three-panel grouped figure.
  legend <- get_bottom_legend(p3)

  p1_no_legend <- p1 + theme(legend.position = "none")
  p2_no_legend <- p2 + theme(legend.position = "none")
  p3_no_legend <- p3 + theme(legend.position = "none")

  draw_three <- function() {
    grid.newpage()

    pushViewport(
      viewport(
        layout = grid.layout(
          nrow = 3,
          ncol = 3,
          heights = unit.c(
            unit(1, "null"),
            unit(5.5, "pt"),
            grobHeight(legend)
          ),
          widths = unit(c(1, 1, 1), "null"),
          respect = TRUE)
      )
    )

    print(
      p1_no_legend,
      vp = viewport(
        layout.pos.row = 1,
        layout.pos.col = 1
      )
    )

    print(
      p2_no_legend,
      vp = viewport(
        layout.pos.row = 1,
        layout.pos.col = 2
      )
    )

    print(
      p3_no_legend,
      vp = viewport(
        layout.pos.row = 1,
        layout.pos.col = 3
      )
    )

    pushViewport(
      viewport(
        layout.pos.row = 3,
        layout.pos.col = 1:3
      )
    )
    grid.draw(legend)
    popViewport()
  }

  if (capabilities("cairo")) {
    grDevices::cairo_pdf(
      filename = pdf_file,
      width = width,
      height = height,
      bg = "white"
    )
  } else {
    grDevices::pdf(
      file = pdf_file,
      width = width,
      height = height,
      useDingbats = FALSE,
      bg = "white"
    )
  }

  draw_three()
  dev.off()

  grDevices::png(
    filename = png_file,
    width = width,
    height = height,
    units = "in",
    res = 600,
    bg = "white"
  )

  draw_three()
  dev.off()
}

############################################################
# 4. Read input files
############################################################

raw_list <- list()

for (vt in names(FILES)) {
  for (mm in names(FILES[[vt]])) {
    raw_list[[paste(vt, mm, sep = "__")]] <- read_lead_p(
      FILES[[vt]][[mm]],
      variant_type = vt,
      method = mm
    )
  }
}

raw_dt <- rbindlist(
  raw_list,
  use.names = TRUE,
  fill = TRUE
)

raw_summary <- raw_dt[
  ,
  .(
    n = .N,
    min_P = min(lead_P),
    median_P = median(lead_P),
    max_P = max(lead_P)
  ),
  by = .(
    variant_type,
    method
  )
]

fwrite(
  raw_summary,
  file.path(
    OUT_DIR,
    paste0(
      PREFIX,
      "_input_leadP_summary.csv"
    )
  )
)

############################################################
# 5. Fixed threshold anchor points
############################################################

fixed_point_list <- list()

for (vt in unique(raw_dt$variant_type)) {
  for (mm in MAIN_LABEL_LEVELS) {

    pp <- raw_dt[
      variant_type == vt &
      method == mm,
      lead_P
    ]

    fixed_point_list[[paste(vt, mm, sep = "__")]] <- make_fixed_points(
      pp,
      vt,
      mm
    )
  }
}

fixed_point_dt <- rbindlist(
  fixed_point_list,
  use.names = TRUE,
  fill = TRUE
)

fwrite(
  fixed_point_dt,
  file.path(
    OUT_DIR,
    paste0(
      PREFIX,
      "_requested_marker_threshold_proportions.csv"
    )
  )
)

############################################################
# 6. y = 0.05 empirical threshold points
############################################################

y005_list <- list()

for (vt in unique(raw_dt$variant_type)) {
  for (mm in MAIN_LABEL_LEVELS) {

    pp <- raw_dt[
      variant_type == vt &
      method == mm,
      lead_P
    ]

    y005_list[[paste(vt, mm, sep = "__")]] <- make_y005_point(
      pp,
      vt,
      mm
    )
  }
}

y005_dt <- rbindlist(
  y005_list,
  use.names = TRUE,
  fill = TRUE
)

y005_dt[
  ,
  P_at_y005_scientific := format(
    P_threshold,
    scientific = TRUE,
    digits = 6
  )
]

fwrite(
  y005_dt,
  file.path(
    OUT_DIR,
    paste0(
      PREFIX,
      "_empirical_P_threshold_at_y005_single_vs_multi.csv"
    )
  )
)

############################################################
# 7. Evaluate both methods at each y=0.05 anchor threshold
############################################################

cross_eval_list <- list()

for (vt in unique(raw_dt$variant_type)) {

  anchors <- y005_dt[
    variant_type == vt
  ]

  for (anchor_method in MAIN_LABEL_LEVELS) {

    anchor_row <- anchors[
      method == anchor_method
    ]

    if (nrow(anchor_row) != 1) {
      next
    }

    anchor_p <- anchor_row$P_threshold
    anchor_x <- anchor_row$neglog10P

    for (eval_method in MAIN_LABEL_LEVELS) {

      eval_p <- raw_dt[
        variant_type == vt &
        method == eval_method,
        lead_P
      ]

      cross_eval_list[[length(cross_eval_list) + 1]] <- data.table(
        variant_type = vt,
        anchor_method = anchor_method,
        evaluated_method = eval_method,
        anchor_P_threshold = anchor_p,
        anchor_neglog10P = anchor_x,
        proportion_at_anchor = calc_prop(
          eval_p,
          anchor_p
        )
      )
    }
  }
}

cross_eval_dt <- rbindlist(
  cross_eval_list,
  use.names = TRUE,
  fill = TRUE
)

fwrite(
  cross_eval_dt,
  file.path(
    OUT_DIR,
    paste0(
      PREFIX,
      "_cross_method_proportions_at_each_y005_threshold.csv"
    )
  )
)

############################################################
# 8. Build cross-method y=0.05-position points
#
# At the x coordinate where single-ancestry reaches y=0.05,
# also plot the multi-ancestry value.
# At the x coordinate where multi-ancestry reaches y=0.05,
# also plot the single-ancestry value.
############################################################

cross_y005_point_dt <- cross_eval_dt[
  anchor_method != evaluated_method,
  .(
    variant_type,
    method = evaluated_method,
    neglog10P = anchor_neglog10P,
    P_threshold = anchor_P_threshold,
    proportion = proportion_at_anchor,
    point_type = paste0("cross_at_", anchor_method, "_y005")
  )
]

fwrite(
  cross_y005_point_dt,
  file.path(
    OUT_DIR,
    paste0(
      PREFIX,
      "_cross_method_points_at_both_y005_xpositions.csv"
    )
  )
)

############################################################
# 9. Combine anchor points used for BOTH points and curves
############################################################

anchor_dt <- rbindlist(
  list(
    fixed_point_dt[
      ,
      .(
        variant_type,
        method,
        neglog10P,
        P_threshold,
        proportion,
        point_type
      )
    ],
    y005_dt[
      ,
      .(
        variant_type,
        method,
        neglog10P,
        P_threshold,
        proportion,
        point_type
      )
    ],
    cross_y005_point_dt[
      ,
      .(
        variant_type,
        method,
        neglog10P,
        P_threshold,
        proportion,
        point_type
      )
    ]
  ),
  use.names = TRUE,
  fill = TRUE
)

anchor_dt <- deduplicate_anchor_points(anchor_dt)

fwrite(
  anchor_dt,
  file.path(
    OUT_DIR,
    paste0(
      PREFIX,
      "_all_anchor_points_used_for_smooth_curves_with_cross_y005.csv"
    )
  )
)

############################################################
# 10. Draw separate figures
############################################################

p_all <- build_plot(
  anchor_dt,
  "allvariants",
  show_legend = TRUE
)

p_common <- build_plot(
  anchor_dt,
  "common",
  show_legend = TRUE
)

p_rare <- build_plot(
  anchor_dt,
  "rare",
  show_legend = TRUE
)

if (!is.null(p_all)) {
  save_plot_pdf_png(
    p_all,
    file.path(
      OUT_DIR,
      paste0(
        "Fig_",
        PREFIX,
        "_allvariants_single_vs_multi_smooth"
      )
    )
  )
}

if (!is.null(p_common)) {
  save_plot_pdf_png(
    p_common,
    file.path(
      OUT_DIR,
      paste0(
        "Fig_",
        PREFIX,
        "_common_single_vs_multi_smooth"
      )
    )
  )
}

if (!is.null(p_rare)) {
  save_plot_pdf_png(
    p_rare,
    file.path(
      OUT_DIR,
      paste0(
        "Fig_",
        PREFIX,
        "_rare_single_vs_multi_smooth"
      )
    )
  )
}

############################################################
# 11. Grouped figure
#     a/b/c use the same format as previous grouped figures.
#     Each panel retains complete x/y axes and axis titles.
############################################################

p_all_g <- build_plot(
  anchor_dt,
  "allvariants",
  show_legend = FALSE,
  title_prefix = "a"
)

p_common_g <- build_plot(
  anchor_dt,
  "common",
  show_legend = FALSE,
  title_prefix = "b"
)

p_rare_g <- build_plot(
  anchor_dt,
  "rare",
  show_legend = TRUE,
  title_prefix = "c"
)

if (
  !is.null(p_all_g) &&
  !is.null(p_common_g) &&
  !is.null(p_rare_g)
) {
  save_combined_three(
    p_all_g,
    p_common_g,
    p_rare_g,
    file.path(
      OUT_DIR,
      paste0(
        "Fig_",
        PREFIX,
        "_all_common_rare_grouped_smooth"
      )
    )
  )
}

############################################################
# 12. Console summary
############################################################

message("============================================================")
message("[INFO] Analysis completed")
message("[INFO] Output directory:")
message(OUT_DIR)
message("")
message("[INFO] Curves use ONLY these displayed anchor points:")
message("       P = 1e-7, 5e-8, 1e-8, 1e-9, 1e-10")
message("       + single-ancestry empirical y=0.05 threshold")
message("         and multi-ancestry evaluated at that same P threshold")
message("       + multi-ancestry empirical y=0.05 threshold")
message("         and single-ancestry evaluated at that same P threshold")
message("")
message("[INFO] x-axis labels shown only at 7, 8, 9, 10")
message("")
message("[INFO] Empirical y=0.05 thresholds:")
print(
  y005_dt[
    ,
    .(
      variant_type,
      method,
      P_at_y005 = P_threshold,
      neglog10P_at_y005 = neglog10P,
      observed_prop_strict_lt
    )
  ]
)
message("============================================================")


####################################################################################################
# FINAL UNIFIED OUTPUT DIRECTORY
####################################################################################################
message("============================================================")
message("[INFO] Complete plotting workflow finished.")
message("[INFO] This script includes:")
message("       - primary EUR10K vs EUR5K+AFR5K mapping-precision plots")
message("       - different AFR-proportion plots (AFR1K, AFR2K, AFR3K, AFR4K)")
message("       - original-variant-set FPR plots")
message("       - matched-variant-set FPR plots")
message("       - GWAS / fine-mapping MAF-bin plots")
message("       - fine-mapping SuSiE/SuSiEx plots")
message("[INFO] Unified output directory:")
message("C:/Users/ASUS/Desktop/GWAS/gwas/模拟3/results/new_results/real_final_plot")
message("============================================================")







































































# ===== PRESERVED ORIGINAL GWAS MODULE 13 =====

rm(list = ls())
gc()


############################################################
# 1. Packages
############################################################

suppressPackageStartupMessages({
  library(data.table)
  library(ggplot2)
  library(grid)
})


############################################################
# 2. Input files
############################################################

COMMON_SINGLE_FILE <-
  "C:/Users/ASUS/Desktop/GWAS/gwas/模拟3/new_EUR/common_gwas_hsq_sig_merged.txt"

RARE_SINGLE_FILE <-
  "C:/Users/ASUS/Desktop/GWAS/gwas/模拟3/new_EUR/rare_gwas_hsq_sig_merged.txt"

COMMON_MULTI_FILE <-
  "C:/Users/ASUS/Desktop/GWAS/gwas/模拟3/new_pooled/common_pooled_hsq_sig.merged.txt"

RARE_MULTI_FILE <-
  "C:/Users/ASUS/Desktop/GWAS/gwas/模拟3/new_pooled/rare_pooled_hsq_merged.txt"


############################################################
# 3. Output directory
############################################################

OUT_DIR <-
  "C:/Users/ASUS/Desktop/GWAS/gwas/模拟3/results/new_results/real_final_plot"

dir.create(
  OUT_DIR,
  showWarnings = FALSE,
  recursive = TRUE
)


############################################################
# 4. Analysis settings
############################################################

P_THRESHOLD <- 5e-8


############################################################
# 5. Plot settings
#
# Same style as the supplied reference plotting script
############################################################

COL_METHOD <- c(
  "single-ancestry" = "#1F4E79",
  "multi-ancestry"  = "#E69F00"
)

############################################################
# Filled symbols:
#
# single-ancestry = filled circle
# multi-ancestry  = hollow triangle
############################################################

SHAPE_METHOD <- c(
  "single-ancestry" = 21,
  "multi-ancestry"  = 24
)

FILL_METHOD <- c(
  "single-ancestry" = "#1F4E79",
  "multi-ancestry"  = "white"
)

METHOD_LEVELS <- c(
  "single-ancestry",
  "multi-ancestry"
)


############################################################
# Fixed Y-axis
############################################################

Y_LIMITS_FIXED <- c(0, 100)

Y_BREAKS_FIXED <- seq(
  0,
  100,
  by = 20
)


############################################################
# Fixed gap between point and adjacent line segment
############################################################

FIXED_LINE_GAP_NPC <- 0.018


############################################################
# Point and line settings
############################################################

POINT_SIZE <- 1.15

POINT_STROKE <- 0.45

LEGEND_POINT_SIZE <- 1.45

LEGEND_LINE_WIDTH <- 0.55


############################################################
# 6. General helper function
############################################################

fatal <- function(...) {
  stop(
    paste0(...),
    call. = FALSE
  )
}


############################################################
# 7. Check input files
############################################################

INPUT_FILES <- c(
  COMMON_SINGLE_FILE,
  RARE_SINGLE_FILE,
  COMMON_MULTI_FILE,
  RARE_MULTI_FILE
)

missing_files <- INPUT_FILES[
  !file.exists(INPUT_FILES)
]

if (length(missing_files) > 0) {
  
  fatal(
    "The following input files do not exist:\n",
    paste(
      missing_files,
      collapse = "\n"
    )
  )
}


############################################################
# 8. Read one GWAS result and calculate power
############################################################

calc_power <- function(
    file,
    plot_label,
    variant_type
) {
  
  message(
    "============================================================"
  )
  
  message(
    "[INFO] Reading: ",
    file
  )
  
  
  ##########################################################
  # fread automatically detects delimiter
  ##########################################################
  
  dt <- fread(
    file,
    data.table = TRUE,
    check.names = FALSE,
    showProgress = FALSE
  )
  
  
  ##########################################################
  # Clean column names
  ##########################################################
  
  setnames(
    dt,
    trimws(names(dt))
  )
  
  
  message(
    "[INFO] Raw rows: ",
    format(
      nrow(dt),
      big.mark = ","
    )
  )
  
  
  ##########################################################
  # Check required columns
  ##########################################################
  
  if (!("lead_P" %in% names(dt))) {
    
    fatal(
      "Missing required column 'lead_P' in:\n",
      file,
      "\n\nCurrent columns:\n",
      paste(
        names(dt),
        collapse = ", "
      )
    )
  }
  
  
  if (!("hsq" %in% names(dt))) {
    
    fatal(
      "Missing required column 'hsq' in:\n",
      file,
      "\n\nCurrent columns:\n",
      paste(
        names(dt),
        collapse = ", "
      )
    )
  }
  
  
  ##########################################################
  # Convert columns to numeric
  ##########################################################
  
  dt[
    ,
    lead_P := suppressWarnings(
      as.numeric(lead_P)
    )
  ]
  
  dt[
    ,
    hsq := suppressWarnings(
      as.numeric(hsq)
    )
  ]
  
  
  ##########################################################
  # Remove invalid observations
  ##########################################################
  
  dt <- dt[
    is.finite(hsq) &
      is.finite(lead_P) &
      lead_P >= 0 &
      lead_P <= 1
  ]
  
  
  if (nrow(dt) == 0) {
    
    fatal(
      "No valid rows remain after filtering:\n",
      file
    )
  }
  
  
  ##########################################################
  # Genome-wide significance
  ##########################################################
  
  dt[
    ,
    significant :=
      lead_P < P_THRESHOLD
  ]
  
  
  ##########################################################
  # Calculate power at each variance explained level
  ##########################################################
  
  out <- dt[
    ,
    .(
      total = .N,
      
      n_sig = sum(
        significant,
        na.rm = TRUE
      ),
      
      proportion =
        sum(
          significant,
          na.rm = TRUE
        ) /
        .N *
        100
    ),
    by = hsq
  ]
  
  
  ##########################################################
  # Add labels
  ##########################################################
  
  out[
    ,
    plot_label := plot_label
  ]
  
  out[
    ,
    variant_type := variant_type
  ]
  
  out[
    ,
    source_file := basename(file)
  ]
  
  
  ##########################################################
  # Sort by hsq
  ##########################################################
  
  setorder(
    out,
    hsq
  )
  
  
  ##########################################################
  # Information
  ##########################################################
  
  message(
    "[INFO] Valid original rows: ",
    format(
      nrow(dt),
      big.mark = ","
    )
  )
  
  message(
    "[INFO] Number of variance-explained levels: ",
    uniqueN(out$hsq)
  )
  
  
  print(
    out
  )
  
  
  out[]
}


############################################################
# 9. Calculate power
############################################################

############################################################
# Common - Single ancestry
############################################################

common_single <- calc_power(
  file = COMMON_SINGLE_FILE,
  plot_label = "single-ancestry",
  variant_type = "common"
)


############################################################
# Common - Multi ancestry
############################################################

common_multi <- calc_power(
  file = COMMON_MULTI_FILE,
  plot_label = "multi-ancestry",
  variant_type = "common"
)


############################################################
# Rare - Single ancestry
############################################################

rare_single <- calc_power(
  file = RARE_SINGLE_FILE,
  plot_label = "single-ancestry",
  variant_type = "rare"
)


############################################################
# Rare - Multi ancestry
############################################################

rare_multi <- calc_power(
  file = RARE_MULTI_FILE,
  plot_label = "multi-ancestry",
  variant_type = "rare"
)


############################################################
# 10. Combine all results
############################################################

power_all <- rbindlist(
  list(
    common_single,
    common_multi,
    rare_single,
    rare_multi
  ),
  use.names = TRUE,
  fill = TRUE
)


############################################################
# Factor order
############################################################

power_all[
  ,
  plot_label :=
    factor(
      plot_label,
      levels = METHOD_LEVELS
    )
]

power_all[
  ,
  variant_type :=
    factor(
      variant_type,
      levels = c(
        "common",
        "rare"
      )
    )
]


############################################################
# 11. Save summary tables
############################################################

fwrite(
  power_all,
  file.path(
    OUT_DIR,
    "GWAS_power_by_variance_explained_all.csv"
  )
)


fwrite(
  power_all[
    variant_type == "common"
  ],
  file.path(
    OUT_DIR,
    "GWAS_power_by_variance_explained_common.csv"
  )
)


fwrite(
  power_all[
    variant_type == "rare"
  ],
  file.path(
    OUT_DIR,
    "GWAS_power_by_variance_explained_rare.csv"
  )
)


############################################################
# 12. Determine X-axis limits and breaks
#
# Common and rare use exactly the same X-axis.
############################################################

all_hsq <- sort(
  unique(
    power_all$hsq
  )
)


if (length(all_hsq) == 0) {
  
  fatal(
    "No usable hsq values were found."
  )
}


x_max_data <- max(
  all_hsq,
  na.rm = TRUE
)


############################################################
# Show all values if number of hsq settings is small
############################################################

if (length(all_hsq) <= 10) {
  
  X_BREAKS_FIXED <- sort(
    unique(
      c(
        0,
        all_hsq
      )
    )
  )
  
  X_LIMITS_FIXED <- c(
    0,
    x_max_data
  )
  
} else {
  
  X_BREAKS_FIXED <- pretty(
    c(
      0,
      x_max_data
    ),
    n = 5
  )
  
  X_BREAKS_FIXED <- X_BREAKS_FIXED[
    X_BREAKS_FIXED >= 0 &
      X_BREAKS_FIXED <= max(X_BREAKS_FIXED)
  ]
  
  X_LIMITS_FIXED <- c(
    0,
    max(
      X_BREAKS_FIXED,
      na.rm = TRUE
    )
  )
}


############################################################
# Safety check
############################################################

if (
  !is.finite(X_LIMITS_FIXED[2]) ||
  X_LIMITS_FIXED[2] <= 0
) {
  
  fatal(
    "Invalid X-axis range."
  )
}


############################################################
# 13. Build line segments with fixed gaps around points
#
# This follows the reference plotting style:
# lines do not directly touch the symbols.
############################################################

make_gap_segments <- function(
    d,
    x_limits,
    y_limits,
    gap_npc = FIXED_LINE_GAP_NPC
) {
  
  d2 <- copy(d)
  
  
  ##########################################################
  # Valid plotting observations only
  ##########################################################
  
  d2 <- d2[
    is.finite(hsq) &
      is.finite(proportion)
  ]
  
  
  if (nrow(d2) == 0) {
    
    return(
      data.table()
    )
  }
  
  
  ##########################################################
  # Temporary grouping label
  ##########################################################
  
  d2[
    ,
    label_tmp :=
      as.character(
        plot_label
      )
  ]
  
  d2 <- d2[
    label_tmp != ""
  ]
  
  
  if (nrow(d2) == 0) {
    
    return(
      data.table()
    )
  }
  
  
  ##########################################################
  # Axis range
  ##########################################################
  
  x_range <- diff(
    x_limits
  )
  
  y_range <- diff(
    y_limits
  )
  
  
  if (
    !is.finite(x_range) ||
    !is.finite(y_range) ||
    x_range <= 0 ||
    y_range <= 0
  ) {
    
    fatal(
      "Invalid axis limits for line-gap construction."
    )
  }
  
  
  ##########################################################
  # Sort by method and X value
  ##########################################################
  
  setorder(
    d2,
    label_tmp,
    hsq
  )
  
  
  ##########################################################
  # Construct shortened line segments
  ##########################################################
  
  seg <- d2[
    ,
    {
      
      if (.N < 2) {
        
        NULL
        
      } else {
        
        x1 <- hsq[-.N]
        
        x2 <- hsq[-1]
        
        y1 <- proportion[-.N]
        
        y2 <- proportion[-1]
        
        
        ####################################################
        # Differences in data units
        ####################################################
        
        dx_data <- x2 - x1
        
        dy_data <- y2 - y1
        
        
        ####################################################
        # Convert to normalised plotting units
        ####################################################
        
        dx_npc <- dx_data / x_range
        
        dy_npc <- dy_data / y_range
        
        
        len_npc <- sqrt(
          dx_npc^2 +
            dy_npc^2
        )
        
        
        keep <-
          is.finite(len_npc) &
          len_npc > 0
        
        
        if (!any(keep)) {
          
          NULL
          
        } else {
          
          ##################################################
          # Prevent the blank gap from becoming larger
          # than the actual line segment
          ##################################################
          
          shrink_npc <- pmin(
            gap_npc,
            len_npc * 0.45
          )
          
          
          ux_npc <-
            dx_npc /
            len_npc
          
          uy_npc <-
            dy_npc /
            len_npc
          
          
          out <- data.table(
            
            x =
              x1 +
              ux_npc *
              shrink_npc *
              x_range,
            
            y =
              y1 +
              uy_npc *
              shrink_npc *
              y_range,
            
            xend =
              x2 -
              ux_npc *
              shrink_npc *
              x_range,
            
            yend =
              y2 -
              uy_npc *
              shrink_npc *
              y_range,
            
            label =
              label_tmp[1]
          )
          
          
          out[
            keep
          ]
        }
      }
      
    },
    by = label_tmp
  ]
  
  
  ##########################################################
  # Remove temporary grouping column
  ##########################################################
  
  if (nrow(seg) > 0) {
    
    seg[
      ,
      label_tmp := NULL
    ]
  }
  
  
  seg[]
}


############################################################
# 14. Plot theme
#
# Matched to supplied plotting script
############################################################

gb_theme <- function(
    base_size = 8,
    show_legend = TRUE
) {
  
  th <-
    theme_classic(
      base_size = base_size,
      base_family = "sans"
    ) +
    
    theme(
      aspect.ratio = 1,
      
      ######################################################
      # Axis lines
      ######################################################
      
      axis.line =
        element_line(
          linewidth = 0.35,
          colour = "black"
        ),
      
      axis.ticks =
        element_line(
          linewidth = 0.35,
          colour = "black"
        ),
      
      axis.ticks.length =
        unit(
          1.6,
          "mm"
        ),
      
      
      ######################################################
      # Axis titles
      ######################################################
      
      axis.title.x = element_text(size = 11.0, colour = "black", margin = margin(t = 5)),
      
      axis.title.y = element_text(size = 11.0, colour = "black", margin = margin(r = 6), lineheight = 0.95),
      
      
      ######################################################
      # Axis text
      ######################################################
      
      axis.text =
        element_text(
          size = 9.5,
          colour = "black"
        ),
      
      
      ######################################################
      # Panel title
      ######################################################
      
      plot.title = element_text(size = 11.5, hjust = 0.5, vjust = 1, colour = "black", face = "plain", margin = margin(b = 6)),
      plot.title.position = "panel",
      plot.tag.position = c(0.002, 0.995),
      plot.tag = element_text(size = 11.5, colour = "black", face = "bold", hjust = 0, vjust = 1, margin = margin(0, 0, 0, 0)),
      
      
      ######################################################
      # Legend
      ######################################################
      
      legend.title =
        element_blank(),
      
      legend.text =
        element_text(
          size = 9.5,
          colour = "black"
        ),
      
      legend.key.width =
        unit(
          0.78,
          "cm"
        ),
      
      legend.key.height =
        unit(
          0.44,
          "cm"
        ),
      
      legend.background =
        element_blank(),
      
      legend.box.background =
        element_blank(),
      
      legend.key =
        element_rect(
          fill = "white",
          colour = NA
        ),
      
      legend.margin =
        margin(
          0,
          0,
          0,
          0
        ),
      
      legend.spacing.y =
        unit(
          0.11,
          "cm"
        ),
      
      
      ######################################################
      # Panel
      ######################################################
      
      panel.border =
        element_blank(),
      
      panel.background =
        element_blank(),
      
      plot.background =
        element_rect(
          fill = "white",
          colour = NA
        ),
      
      plot.margin = margin(16, 10, 8, 20)
    )
  
  
  ##########################################################
  # Legend position
  ##########################################################
  
  if (show_legend) {
    th <- th +
      theme(
        legend.position = "bottom",
        legend.direction = "horizontal",
        legend.justification = "center",
        legend.box = "horizontal",
        legend.box.spacing = unit(5.5, "pt")
      )
  } else {
    th <- th +
      theme(
        legend.position = "none"
      )
  }
  
  
  th
}


############################################################
# 15. Build one panel
############################################################

build_power_panel <- function(
    dt,
    vt_select,
    panel_prefix,
    show_legend = TRUE
) {
  
  d <- copy(dt)
  
  
  ##########################################################
  # Select common or rare
  ##########################################################
  
  d <- d[
    as.character(variant_type) == vt_select &
      as.character(plot_label) %in% METHOD_LEVELS
  ]
  
  
  if (nrow(d) == 0) {
    
    warning(
      "No plotting data for ",
      vt_select
    )
    
    return(
      NULL
    )
  }
  
  
  ##########################################################
  # Factor order
  ##########################################################
  
  d[
    ,
    plot_label :=
      factor(
        as.character(plot_label),
        levels = METHOD_LEVELS
      )
  ]
  
  
  ##########################################################
  # Sort
  ##########################################################
  
  setorder(
    d,
    plot_label,
    hsq
  )
  
  
  ##########################################################
  # Shortened visible line segments
  ##########################################################
  
  seg <- make_gap_segments(
    d = d,
    x_limits = X_LIMITS_FIXED,
    y_limits = Y_LIMITS_FIXED
  )
  
  
  if (nrow(seg) > 0) {
    
    seg[
      ,
      plot_label :=
        factor(
          label,
          levels = METHOD_LEVELS
        )
    ]
  }
  
  
  ##########################################################
  # Panel title
  ##########################################################
  
  if (vt_select == "common") {
    title_use <- "common (MAF > 0.01)"
  } else {
    title_use <- "rare (MAF ≤ 0.01)"
  }
  tag_use <- panel_prefix
  
  
  ##########################################################
  # Main plot
  ##########################################################
  
  p <- ggplot() +
    
    
    ########################################################
  # Invisible complete lines:
  #
  # These are used only to create the line component
  # of the legend.
  ########################################################
  
  geom_line(
    data = d,
    
    aes(
      x = hsq,
      y = proportion,
      colour = plot_label,
      group = plot_label
    ),
    
    linewidth = LEGEND_LINE_WIDTH,
    
    alpha = 0,
    
    show.legend = TRUE,
    
    na.rm = TRUE
  ) +
    
    
    ########################################################
  # Visible shortened line segments
  ########################################################
  
  geom_segment(
    data = seg,
    
    aes(
      x = x,
      y = y,
      xend = xend,
      yend = yend,
      colour = plot_label,
      group = plot_label
    ),
    
    linewidth = LEGEND_LINE_WIDTH,
    
    lineend = "butt",
    
    show.legend = FALSE,
    
    na.rm = TRUE
  ) +
    
    
    ########################################################
  # Points
  ########################################################
  
  geom_point(
    data = d,
    
    aes(
      x = hsq,
      y = proportion,
      colour = plot_label,
      fill = plot_label,
      shape = plot_label
    ),
    
    size = POINT_SIZE,
    
    stroke = POINT_STROKE,
    
    show.legend = TRUE,
    
    na.rm = TRUE
  ) +
    
    
    ########################################################
  # Colours
  ########################################################
  
  scale_colour_manual(
    name = NULL,
    
    values = COL_METHOD,
    
    breaks = METHOD_LEVELS,
    
    labels = c(
      "Single-ancestry",
      "Multi-ancestry"
    ),
    
    drop = FALSE
  ) +
    
    
    ########################################################
  # Shapes
  ########################################################
  
  scale_shape_manual(
    name = NULL,
    
    values = SHAPE_METHOD,
    
    breaks = METHOD_LEVELS,
    
    labels = c(
      "Single-ancestry",
      "Multi-ancestry"
    ),
    
    drop = FALSE,
    
    guide = "none"
  ) +
    
    
    ########################################################
  # Fill
  ########################################################
  
  scale_fill_manual(
    name = NULL,
    
    values = FILL_METHOD,
    
    breaks = METHOD_LEVELS,
    
    labels = c(
      "Single-ancestry",
      "Multi-ancestry"
    ),
    
    drop = FALSE,
    
    guide = "none"
  ) +
    
    
    ########################################################
  # X axis
  ########################################################
  
  scale_x_continuous(
    limits = X_LIMITS_FIXED,
    
    breaks = X_BREAKS_FIXED,
    
    labels = function(x) {
      
      format(
        x,
        trim = TRUE,
        scientific = FALSE
      )
    },
    
    expand = expansion(
      mult = c(
        0,
        0.02
      )
    )
  ) +
    
    
    ########################################################
  # Y axis
  ########################################################
  
  scale_y_continuous(
    limits = Y_LIMITS_FIXED,
    
    breaks = Y_BREAKS_FIXED,
    
    expand = expansion(
      mult = c(
        0,
        0.06
      )
    )
  ) +
    
    
    ########################################################
  # Axis labels and title
  ########################################################
  
  labs(
    x = "Variance explained",
    y = "Power (%)",
    title = title_use,
    tag = tag_use
  ) +
    
    
    ########################################################
  # Avoid clipping
  ########################################################
  
  coord_cartesian(
    clip = "off"
  ) +
    
    
    ########################################################
  # Legend
  ########################################################
  
  guides(
    
    colour =
      guide_legend(
        
        nrow = 1,
        
        byrow = TRUE,
        
        override.aes = list(
          
          alpha = 1,
          
          linewidth =
            LEGEND_LINE_WIDTH,
          
          linetype = 1,
          
          size =
            LEGEND_POINT_SIZE,
          
          stroke =
            POINT_STROKE,
          
          shape =
            unname(
              SHAPE_METHOD[
                METHOD_LEVELS
              ]
            ),
          
          fill =
            unname(
              FILL_METHOD[
                METHOD_LEVELS
              ]
            )
        )
      )
  ) +
    
    
    ########################################################
  # Theme
  ########################################################
  
  gb_theme(
    base_size = 8,
    show_legend = show_legend
  )
  
  
  p
}


############################################################
# 16. Generate common and rare panels
############################################################

p_common <- build_power_panel(
  dt = power_all,
  vt_select = "common",
  panel_prefix = "a",
  show_legend = TRUE
)


p_rare <- build_power_panel(
  dt = power_all,
  vt_select = "rare",
  panel_prefix = "b",
  show_legend = TRUE
)


############################################################
# Check panels
############################################################

if (
  is.null(p_common) ||
  is.null(p_rare)
) {
  
  fatal(
    "Common or rare panel could not be generated."
  )
}


############################################################
# 17. Combined figure saver
#
# One shared legend centered at bottom
############################################################

save_combined_pdf_png <- function(
    p_left,
    p_right,
    out_prefix,
    width = 7.0,
    height = 5.0
) {
  
  pdf_file <- paste0(
    out_prefix,
    ".pdf"
  )
  
  png_file <- paste0(
    out_prefix,
    ".png"
  )
  
  
  ##########################################################
  # Extract bottom legend
  ##########################################################
  
  get_bottom_legend <- function(p) {
    
    g <- ggplotGrob(
      p +
        theme(
          legend.position = "bottom",
          legend.direction = "horizontal",
          legend.justification = "center",
          legend.box = "horizontal",
          legend.box.spacing = unit(0, "pt")
        )
    )
    
    
    ########################################################
    # Find all guide-box grobs
    ########################################################
    
    idx <- which(
      grepl(
        "^guide-box",
        g$layout$name
      )
    )
    
    
    ########################################################
    # No legend
    ########################################################
    
    if (length(idx) == 0) {
      
      return(
        grid::nullGrob()
      )
    }
    
    
    ########################################################
    # Exclude zeroGrobs
    ########################################################
    
    valid <- idx[
      !vapply(
        g$grobs[idx],
        inherits,
        logical(1),
        what = "zeroGrob"
      )
    ]
    
    
    if (length(valid) == 0) {
      
      return(
        grid::nullGrob()
      )
    }
    
    
    ########################################################
    # IMPORTANT:
    # Correct R double-bracket indexing
    ########################################################
    
    return(
      g$grobs[[valid[1]]]
    )
  }
  
  
  ##########################################################
  # Extract shared legend
  ##########################################################
  
  legend <- get_bottom_legend(
    p_right
  )
  
  
  ##########################################################
  # Remove legends from individual panels
  ##########################################################
  
  p_left_no_legend <-
    p_left +
    theme(
      legend.position = "none"
    )
  
  
  p_right_no_legend <-
    p_right +
    theme(
      legend.position = "none"
    )
  
  
  ##########################################################
  # Draw combined figure
  ##########################################################
  
  draw_combined <- function() {
    
    grid.newpage()
    
    
    ########################################################
    # Layout:
    #
    # row 1:
    # common | rare
    #
    # row 2:
    # shared bottom legend
    ########################################################
    
    pushViewport(
      viewport(
        layout = grid.layout(
          
          nrow = 3,
          
          ncol = 2,
          
          heights = unit.c(
            unit(1, "null"),
            unit(5.5, "pt"),
            grobHeight(legend)
          ),
          widths = unit(
            c(
              1,
              1
            ),
            "null"
          ),
          respect = TRUE)
      )
    )
    
    
    ########################################################
    # Left panel
    ########################################################
    
    print(
      p_left_no_legend,
      
      vp = viewport(
        layout.pos.row = 1,
        layout.pos.col = 1
      )
    )
    
    
    ########################################################
    # Right panel
    ########################################################
    
    print(
      p_right_no_legend,
      
      vp = viewport(
        layout.pos.row = 1,
        layout.pos.col = 2
      )
    )
    
    
    ########################################################
    # Shared legend
    ########################################################
    
    pushViewport(
      viewport(
        layout.pos.row = 3,
        layout.pos.col = 1:2
      )
    )
    
    
    grid.draw(
      legend
    )
    
    
    popViewport()
    
    
    ########################################################
    # Exit the main layout viewport
    ########################################################
    
    popViewport()
  }
  
  
  ##########################################################
  # Add space for legend
  ##########################################################
  
  device_height <- height + 0.35
  
  
  ##########################################################
  # Save PDF
  ##########################################################
  
  if (capabilities("cairo")) {
    
    grDevices::cairo_pdf(
      filename = pdf_file,
      width = width,
      height = device_height,
      bg = "white"
    )
    
  } else {
    
    grDevices::pdf(
      file = pdf_file,
      width = width,
      height = device_height,
      useDingbats = FALSE,
      bg = "white"
    )
  }
  
  
  draw_combined()
  
  grDevices::dev.off()
  
  
  ##########################################################
  # Save PNG
  ##########################################################
  
  grDevices::png(
    filename = png_file,
    width = width,
    height = device_height,
    units = "in",
    res = 600,
    bg = "white"
  )
  
  
  draw_combined()
  
  grDevices::dev.off()
  
  
  ##########################################################
  # Return filenames
  ##########################################################
  
  invisible(
    list(
      pdf = pdf_file,
      png = png_file
    )
  )
}


############################################################
# 18. Save combined common + rare figure
############################################################

OUT_PREFIX <- file.path(
  OUT_DIR,
  "GWAS_power_variance_explained_common_rare"
)


output_files <- save_combined_pdf_png(
  p_left = p_common,
  p_right = p_rare,
  out_prefix = OUT_PREFIX,
  width = 7.0,
  height = 5.0
)


############################################################
# 19. Final report
############################################################

message(
  "============================================================"
)

message(
  "[INFO] ALL POWER ANALYSIS AND PLOTTING FINISHED"
)

message(
  "============================================================"
)

message(
  "[INFO] Output directory:"
)

message(
  OUT_DIR
)

message(
  ""
)

message(
  "[INFO] Combined PDF:"
)

message(
  paste0(
    OUT_PREFIX,
    ".pdf"
  )
)

message(
  ""
)

message(
  "[INFO] Combined PNG:"
)

message(
  paste0(
    OUT_PREFIX,
    ".png"
  )
)

message(
  ""
)

message(
  "[INFO] Combined summary:"
)

message(
  file.path(
    OUT_DIR,
    "GWAS_power_by_variance_explained_all.csv"
  )
)

message(
  ""
)

message(
  "[INFO] Common summary:"
)

message(
  file.path(
    OUT_DIR,
    "GWAS_power_by_variance_explained_common.csv"
  )
)

message(
  ""
)

message(
  "[INFO] Rare summary:"
)

message(
  file.path(
    OUT_DIR,
    "GWAS_power_by_variance_explained_rare.csv"
  )
)

message(
  "============================================================"
)

































############################################################
# SuSiE vs SuSiEx fine-mapping performance
# across variance explained
#
# Common variants
#
# Panel a:
#   Fine-mapping power
#   = causal SNP contained in >=1 credible set
#
# Panel b:
#   Exact identification rate
#   = fine-mapped SNP exactly matches causal SNP
#
# Figure legend:
#   SuSiE  -> Single-ancestry
#   SuSiEx -> Multi-ancestry
#
# No error bars
############################################################





# ===== PRESERVED ORIGINAL GWAS MODULE 16 =====

rm(list = ls())
gc()

suppressPackageStartupMessages({
  library(data.table)
  library(ggplot2)
  library(grid)
})

############################################################
# Ancestry-composition mapping precision plots
#
# Three grouped figures:
#   1. BP:  common + rare
#   2. MAF: common + rare
#   3. LD:  common + rare
#
# Groups:
#   Single-ancestry (EUR10K)
#   EUR9K + AFR1K
#   EUR8K + AFR2K
#   EUR7K + AFR3K
#   EUR6K + AFR4K
#   EUR5K + AFR5K
#
# Figure size:
#   Same as previous two-panel ancestry-composition figures
#   Width  = 7.40 in
#   Main height = 5.0 in
#   + 0.35 in for shared bottom legend
############################################################


############################################################
# 1. Input / output
############################################################

BASE_DIR <- "C:/Users/ASUS/Desktop/GWAS/gwas/模拟3/results/new_results/real_final_plot"

BP_FILE <- file.path(
  BASE_DIR,
  "cumulative_BP_diff_long_Plt5e8.csv"
)

MAF_FILE <- file.path(
  BASE_DIR,
  "cumulative_MAF_diff_long_Plt5e8.csv"
)

LD_FILE <- file.path(
  BASE_DIR,
  "cumulative_LD_r2_long_Plt5e8.csv"
)

OUT_DIR <- BASE_DIR

dir.create(
  OUT_DIR,
  recursive = TRUE,
  showWarnings = FALSE
)


############################################################
# 2. Global visual settings
############################################################

COL_SINGLE <- "#1F4E79"
COL_MULTI  <- "#E69F00"

COL_COMPOSITION <- c(
  "single-ancestry" = COL_SINGLE,
  "EUR9K + AFR1K"   = "#009E73",
  "EUR8K + AFR2K"   = "#56B4E9",
  "EUR7K + AFR3K"   = "#CC79A7",
  "EUR6K + AFR4K"   = "#D55E00",
  "EUR5K + AFR5K"   = COL_MULTI
)

SHAPE_COMPOSITION <- c(
  "single-ancestry" = 21,
  "EUR9K + AFR1K"   = 24,
  "EUR8K + AFR2K"   = 22,
  "EUR7K + AFR3K"   = 23,
  "EUR6K + AFR4K"   = 25,
  "EUR5K + AFR5K"   = 24
)

FILL_COMPOSITION <- c(
  "single-ancestry" = COL_SINGLE,
  "EUR9K + AFR1K"   = "white",
  "EUR8K + AFR2K"   = "white",
  "EUR7K + AFR3K"   = "white",
  "EUR6K + AFR4K"   = "white",
  "EUR5K + AFR5K"   = "white"
)

COMPOSITION_LEVELS <- c(
  "single-ancestry",
  "EUR9K + AFR1K",
  "EUR8K + AFR2K",
  "EUR7K + AFR3K",
  "EUR6K + AFR4K",
  "EUR5K + AFR5K"
)

COMPOSITION_LABELS <- c(
  "Single-ancestry",
  "EUR9K + AFR1K",
  "EUR8K + AFR2K",
  "EUR7K + AFR3K",
  "EUR6K + AFR4K",
  "EUR5K + AFR5K"
)

Y_LIMITS <- c(0, 100)
Y_BREAKS <- seq(0, 100, by = 20)

POINT_SIZE <- 1.25
POINT_STROKE <- 0.45

LINE_WIDTH <- 0.55
LEGEND_POINT_SIZE <- 1.45

# Gap between point marker and adjacent line.
FIXED_LINE_GAP_NPC <- 0.018


############################################################
# 3. General helper functions
############################################################

fatal <- function(...) {
  stop(
    paste0(...),
    call. = FALSE
  )
}


safe_chr <- function(x) {
  x <- as.character(x)
  x[is.na(x)] <- ""
  return(x)
}


panel_title_for_variant <- function(vt) {
  
  if (vt == "common") {
    return("common (MAF > 0.01)")
  }
  
  if (vt == "rare") {
    return("rare (MAF ≤ 0.01)")
  }
  
  return(as.character(vt))
}


############################################################
# 4. Read cumulative file
############################################################

read_cumulative_file <- function(file, metric_label) {
  
  if (!file.exists(file)) {
    fatal(
      "Input file does not exist: ",
      file
    )
  }
  
  dt <- fread(
    file,
    data.table = TRUE
  )
  
  setnames(
    dt,
    trimws(names(dt))
  )
  
  required_cols <- c(
    "variant_type",
    "population",
    "threshold"
  )
  
  missing_cols <- setdiff(
    required_cols,
    names(dt)
  )
  
  if (length(missing_cols) > 0) {
    
    fatal(
      "Missing required columns in file:\n",
      file,
      "\nMissing columns: ",
      paste(missing_cols, collapse = ", "),
      "\nCurrent columns: ",
      paste(names(dt), collapse = ", ")
    )
  }
  
  
  ##########################################################
  # Obtain cumulative percentage
  ##########################################################
  
  if (!("cumulative_percent" %in% names(dt))) {
    
    if ("cumulative_prop" %in% names(dt)) {
      
      dt[
        ,
        cumulative_percent :=
          suppressWarnings(
            as.numeric(cumulative_prop)
          ) * 100
      ]
      
    } else {
      
      fatal(
        "Neither cumulative_percent nor cumulative_prop exists in:\n",
        file
      )
    }
  }
  
  
  ##########################################################
  # Optional upstream columns
  ##########################################################
  
  if (!("analysis_group" %in% names(dt))) {
    dt[, analysis_group := NA_character_]
  }
  
  if (!("ancestry_composition" %in% names(dt))) {
    dt[, ancestry_composition := NA_character_]
  }
  
  
  ##########################################################
  # Standardise
  ##########################################################
  
  dt[, variant_type := tolower(trimws(safe_chr(variant_type)))]
  dt[, population := safe_chr(population)]
  dt[, analysis_group := safe_chr(analysis_group)]
  dt[, ancestry_composition := safe_chr(ancestry_composition)]
  
  dt[
    ,
    threshold :=
      suppressWarnings(
        as.numeric(threshold)
      )
  ]
  
  dt[
    ,
    cumulative_percent :=
      suppressWarnings(
        as.numeric(cumulative_percent)
      )
  ]
  
  dt[
    ,
    cumulative_percent :=
      pmax(
        0,
        pmin(
          100,
          cumulative_percent
        )
      )
  ]
  
  dt[, metric := metric_label]
  
  dt <- dt[
    variant_type %in% c(
      "common",
      "rare"
    )
  ]
  
  dt <- dt[
    is.finite(threshold) &
      is.finite(cumulative_percent)
  ]
  
  if (nrow(dt) == 0) {
    
    fatal(
      "No usable rows detected in:\n",
      file
    )
  }
  
  return(dt[])
}


############################################################
# 5. Standardise ancestry composition
############################################################

normalise_population_fields <- function(dt) {
  
  dt <- copy(dt)
  
  pop <- safe_chr(dt$population)
  ag  <- safe_chr(dt$analysis_group)
  ac  <- safe_chr(dt$ancestry_composition)
  
  key <- tolower(
    paste(
      pop,
      ag,
      ac,
      sep = "|"
    )
  )
  
  ancestry_clean <- rep(
    NA_character_,
    nrow(dt)
  )
  
  
  ##########################################################
  # EUR10K
  ##########################################################
  
  idx_eur10 <- (
    grepl("eur10k", key) |
      grepl("eur10", key) |
      grepl("common_eur_sig", key) |
      grepl("rare_eur_sig", key) |
      tolower(ag) == "eur"
  )
  
  ancestry_clean[
    idx_eur10
  ] <- "EUR10K"
  
  
  ##########################################################
  # EUR9K + AFR1K
  ##########################################################
  
  idx_eur9_afr1 <- grepl(
    "eur9k_afr1k",
    key
  )
  
  ancestry_clean[
    idx_eur9_afr1
  ] <- "EUR9K_AFR1K"
  
  
  ##########################################################
  # EUR8K + AFR2K
  ##########################################################
  
  idx_eur8_afr2 <- grepl(
    "eur8k_afr2k",
    key
  )
  
  ancestry_clean[
    idx_eur8_afr2
  ] <- "EUR8K_AFR2K"
  
  
  ##########################################################
  # EUR7K + AFR3K
  ##########################################################
  
  idx_eur7_afr3 <- grepl(
    "eur7k_afr3k",
    key
  )
  
  ancestry_clean[
    idx_eur7_afr3
  ] <- "EUR7K_AFR3K"
  
  
  ##########################################################
  # EUR6K + AFR4K
  ##########################################################
  
  idx_eur6_afr4 <- grepl(
    "eur6k_afr4k",
    key
  )
  
  ancestry_clean[
    idx_eur6_afr4
  ] <- "EUR6K_AFR4K"
  
  
  ##########################################################
  # EUR5K + AFR5K
  #
  # Primary pooled files may appear as:
  # common_pooled
  # rare_pooled
  # common_pooled_ld
  # rare_pooled_ld
  ##########################################################
  
  idx_eur5_afr5 <- (
    grepl("eur5k_afr5k", key) |
      grepl("common_pooled", key) |
      grepl("rare_pooled", key)
  )
  
  ancestry_clean[
    idx_eur5_afr5
  ] <- "EUR5K_AFR5K"
  
  
  ##########################################################
  # Figure-facing labels
  ##########################################################
  
  plot_label <- rep(
    NA_character_,
    nrow(dt)
  )
  
  plot_label[
    ancestry_clean == "EUR10K"
  ] <- "single-ancestry"
  
  plot_label[
    ancestry_clean == "EUR9K_AFR1K"
  ] <- "EUR9K + AFR1K"
  
  plot_label[
    ancestry_clean == "EUR8K_AFR2K"
  ] <- "EUR8K + AFR2K"
  
  plot_label[
    ancestry_clean == "EUR7K_AFR3K"
  ] <- "EUR7K + AFR3K"
  
  plot_label[
    ancestry_clean == "EUR6K_AFR4K"
  ] <- "EUR6K + AFR4K"
  
  plot_label[
    ancestry_clean == "EUR5K_AFR5K"
  ] <- "EUR5K + AFR5K"
  
  
  dt[
    ,
    ancestry_comp_clean :=
      ancestry_clean
  ]
  
  dt[
    ,
    plot_label_comp :=
      plot_label
  ]
  
  return(dt[])
}


############################################################
# 6. Axis settings
############################################################

metric_axis_settings <- function(
    metric_name,
    variant_type
) {
  
  ##########################################################
  # BP
  ##########################################################
  
  if (metric_name == "BP_diff") {
    
    return(
      list(
        xlab = "Distance (Kb)",
        
        x_transform = function(x) {
          x / 1000
        },
        
        x_breaks = seq(
          0,
          100,
          by = 20
        ),
        
        x_limits = c(
          0,
          100
        )
      )
    )
  }
  
  
  ##########################################################
  # MAF
  ##########################################################
  
  if (metric_name == "MAF_diff") {
    
    if (variant_type == "common") {
      
      return(
        list(
          xlab = "MAF difference",
          
          x_transform = function(x) {
            x
          },
          
          x_breaks = seq(
            0,
            0.05,
            by = 0.01
          ),
          
          x_limits = c(
            0,
            0.05
          )
        )
      )
      
    } else {
      
      return(
        list(
          xlab = "MAF difference",
          
          x_transform = function(x) {
            x
          },
          
          x_breaks = seq(
            0,
            0.003,
            by = 0.001
          ),
          
          x_limits = c(
            0,
            0.003
          )
        )
      )
    }
  }
  
  
  ##########################################################
  # LD
  ##########################################################
  
  if (metric_name == "LD_r2") {
    
    return(
      list(
        xlab = expression(
          LD~"(" * plain(r)^2 * ")"
        ),
        
        x_transform = function(x) {
          x
        },
        
        x_breaks = seq(
          0,
          1,
          by = 0.2
        ),
        
        x_limits = c(
          0,
          1
        )
      )
    )
  }
  
  
  fatal(
    "Unknown metric: ",
    metric_name
  )
}


############################################################
# 7. Build shortened line segments
#
# Uses split() + lapply() instead of nested data.table by={}
# to avoid previous bracket / parenthesis syntax problems.
############################################################

make_gap_segments <- function(
    d,
    label_col,
    x_limits,
    y_limits,
    gap_npc = FIXED_LINE_GAP_NPC
) {
  
  d2 <- copy(d)
  
  d2 <- d2[
    is.finite(x_plot) &
      is.finite(cumulative_percent)
  ]
  
  d2[
    ,
    label_tmp :=
      as.character(
        get(label_col)
      )
  ]
  
  d2 <- d2[
    !is.na(label_tmp) &
      label_tmp != ""
  ]
  
  if (nrow(d2) == 0) {
    return(data.table())
  }
  
  
  x_range <- diff(x_limits)
  y_range <- diff(y_limits)
  
  if (
    !is.finite(x_range) ||
    !is.finite(y_range) ||
    x_range <= 0 ||
    y_range <= 0
  ) {
    
    fatal(
      "Invalid x/y axis range in make_gap_segments()."
    )
  }
  
  
  split_list <- split(
    d2,
    d2$label_tmp
  )
  
  
  segment_list <- lapply(
    names(split_list),
    function(group_name) {
      
      tmp <- as.data.table(
        split_list[[group_name]]
      )
      
      setorder(
        tmp,
        x_plot
      )
      
      
      if (nrow(tmp) < 2) {
        return(NULL)
      }
      
      
      n_tmp <- nrow(tmp)
      
      x1 <- tmp$x_plot[
        1:(n_tmp - 1)
      ]
      
      x2 <- tmp$x_plot[
        2:n_tmp
      ]
      
      y1 <- tmp$cumulative_percent[
        1:(n_tmp - 1)
      ]
      
      y2 <- tmp$cumulative_percent[
        2:n_tmp
      ]
      
      
      dx_data <- x2 - x1
      dy_data <- y2 - y1
      
      dx_npc <- dx_data / x_range
      dy_npc <- dy_data / y_range
      
      len_npc <- sqrt(
        dx_npc^2 +
          dy_npc^2
      )
      
      
      keep <- (
        is.finite(len_npc) &
          len_npc > 0
      )
      
      
      if (!any(keep)) {
        return(NULL)
      }
      
      
      shrink_npc <- pmin(
        gap_npc,
        len_npc * 0.45
      )
      
      
      ux_npc <- dx_npc / len_npc
      uy_npc <- dy_npc / len_npc
      
      
      out <- data.table(
        
        x = x1 +
          ux_npc *
          shrink_npc *
          x_range,
        
        y = y1 +
          uy_npc *
          shrink_npc *
          y_range,
        
        xend = x2 -
          ux_npc *
          shrink_npc *
          x_range,
        
        yend = y2 -
          uy_npc *
          shrink_npc *
          y_range,
        
        label = rep(
          group_name,
          length(x1)
        )
      )
      
      
      out <- out[
        keep
      ]
      
      
      return(out)
    }
  )
  
  
  keep_list <- !vapply(
    segment_list,
    is.null,
    logical(1)
  )
  
  
  segment_list <- segment_list[
    keep_list
  ]
  
  
  if (length(segment_list) == 0) {
    return(data.table())
  }
  
  
  seg <- rbindlist(
    segment_list,
    use.names = TRUE,
    fill = TRUE
  )
  
  
  return(seg[])
}


############################################################
# 8. Theme
############################################################

gb_theme <- function(
    base_size = 8,
    show_legend = TRUE
) {
  
  th <- theme_classic(
    base_size = base_size,
    base_family = "sans"
  ) +
    theme(
      aspect.ratio = 1,
      
      axis.line = element_line(
        linewidth = 0.35,
        colour = "black"
      ),
      
      axis.ticks = element_line(
        linewidth = 0.35,
        colour = "black"
      ),
      
      axis.ticks.length = unit(
        1.6,
        "mm"
      ),
      
      axis.title.x = element_text(size = 11.0, colour = "black", margin = margin(t = 5)),
      
      axis.title.y = element_text(size = 11.0, colour = "black", margin = margin(r = 6), lineheight = 0.95),
      
      axis.text = element_text(
        size = 9.5,
        colour = "black"
      ),
      
      plot.title = element_text(size = 11.5, hjust = 0.5, vjust = 1, colour = "black", face = "plain", margin = margin(b = 6)),
      plot.title.position = "panel",
      plot.tag.position = c(0.002, 0.995),
      plot.tag = element_text(size = 11.5, colour = "black", face = "bold", hjust = 0, vjust = 1, margin = margin(0, 0, 0, 0)),
      
      legend.title = element_blank(),
      
      legend.text = element_text(
        size = 9.5,
        colour = "black"
      ),
      
      legend.key.width = unit(
        0.72,
        "cm"
      ),
      
      legend.key.height = unit(
        0.34,
        "cm"
      ),
      
      legend.spacing.x = unit(
        0.10,
        "cm"
      ),
      
      legend.spacing.y = unit(
        0.05,
        "cm"
      ),
      
      legend.background = element_blank(),
      
      legend.box.background = element_blank(),
      
      legend.key = element_rect(
        fill = "white",
        colour = NA
      ),
      
      legend.margin = margin(
        0,
        0,
        0,
        0
      ),
      
      panel.border = element_blank(),
      
      panel.background = element_blank(),
      
      plot.background = element_rect(
        fill = "white",
        colour = NA
      ),
      
      plot.margin = margin(16, 10, 8, 20)
    )
  
  
  if (show_legend) {
    th <- th +
      theme(
        legend.position = "bottom",
        legend.direction = "horizontal",
        legend.justification = "center",
        legend.box = "horizontal",
        legend.box.spacing = unit(5.5, "pt")
      )
  } else {
    th <- th +
      theme(
        legend.position = "none"
      )
  }
  
  
  return(th)
}


############################################################
# 9. Build one panel
############################################################

build_composition_line <- function(
    dt,
    metric_name,
    vt_select,
    show_legend = TRUE,
    title_prefix = NULL
) {
  
  d <- copy(dt)
  
  
  d <- d[
    variant_type == vt_select &
      !is.na(plot_label_comp)
  ]
  
  
  d <- d[
    plot_label_comp %in%
      COMPOSITION_LEVELS
  ]
  
  
  if (nrow(d) == 0) {
    
    warning(
      "No rows detected for ",
      metric_name,
      " / ",
      vt_select
    )
    
    return(NULL)
  }
  
  
  ##########################################################
  # Factor ordering
  ##########################################################
  
  d[
    ,
    plot_label_comp :=
      factor(
        plot_label_comp,
        levels = COMPOSITION_LEVELS
      )
  ]
  
  
  ##########################################################
  # Axis
  ##########################################################
  
  axis_setting <- metric_axis_settings(
    metric_name,
    vt_select
  )
  
  
  d[
    ,
    x_plot :=
      axis_setting$x_transform(
        threshold
      )
  ]
  
  
  setorder(
    d,
    plot_label_comp,
    x_plot
  )
  
  
  ##########################################################
  # Gapped connecting lines
  ##########################################################
  
  seg <- make_gap_segments(
    d = d,
    label_col = "plot_label_comp",
    x_limits = axis_setting$x_limits,
    y_limits = Y_LIMITS
  )
  
  
  if (nrow(seg) > 0) {
    
    seg[
      ,
      plot_label_comp :=
        factor(
          label,
          levels = COMPOSITION_LEVELS
        )
    ]
  }
  
  
  ##########################################################
  # Title
  ##########################################################
  
  title_text <- panel_title_for_variant(
    vt_select
  )
  tag_use <- if (!is.null(title_prefix) && nzchar(as.character(title_prefix))) as.character(title_prefix) else NULL
  
  
  ##########################################################
  # Base plot
  ##########################################################
  
  p <- ggplot()
  
  
  ##########################################################
  # Invisible full curve, used for legend line
  ##########################################################
  
  p <- p +
    geom_line(
      data = d,
      
      aes(
        x = x_plot,
        y = cumulative_percent,
        colour = plot_label_comp,
        group = plot_label_comp
      ),
      
      linewidth = LINE_WIDTH,
      
      alpha = 0,
      
      show.legend = TRUE,
      
      na.rm = TRUE
    )
  
  
  ##########################################################
  # Visible shortened connecting segments
  ##########################################################
  
  if (nrow(seg) > 0) {
    
    p <- p +
      geom_segment(
        data = seg,
        
        aes(
          x = x,
          y = y,
          xend = xend,
          yend = yend,
          colour = plot_label_comp,
          group = plot_label_comp
        ),
        
        linewidth = LINE_WIDTH,
        
        lineend = "butt",
        
        show.legend = FALSE,
        
        na.rm = TRUE
      )
  }
  
  
  ##########################################################
  # Points
  ##########################################################
  
  p <- p +
    geom_point(
      data = d,
      
      aes(
        x = x_plot,
        y = cumulative_percent,
        colour = plot_label_comp,
        fill = plot_label_comp,
        shape = plot_label_comp
      ),
      
      size = POINT_SIZE,
      
      stroke = POINT_STROKE,
      
      show.legend = TRUE,
      
      na.rm = TRUE
    )
  
  
  ##########################################################
  # Scales
  ##########################################################
  
  p <- p +
    scale_colour_manual(
      name = NULL,
      values = COL_COMPOSITION,
      breaks = COMPOSITION_LEVELS,
      labels = COMPOSITION_LABELS,
      drop = FALSE
    ) +
    
    scale_shape_manual(
      name = NULL,
      values = SHAPE_COMPOSITION,
      breaks = COMPOSITION_LEVELS,
      labels = COMPOSITION_LABELS,
      drop = FALSE,
      guide = "none"
    ) +
    
    scale_fill_manual(
      name = NULL,
      values = FILL_COMPOSITION,
      breaks = COMPOSITION_LEVELS,
      labels = COMPOSITION_LABELS,
      drop = FALSE,
      guide = "none"
    ) +
    
    scale_x_continuous(
      limits = axis_setting$x_limits,
      breaks = axis_setting$x_breaks,
      
      expand = expansion(
        mult = c(
          0,
          0.02
        )
      )
    ) +
    
    scale_y_continuous(
      limits = Y_LIMITS,
      breaks = Y_BREAKS,
      
      expand = expansion(
        mult = c(
          0,
          0.04
        )
      )
    ) +
    
    coord_cartesian(
      clip = "off"
    ) +
    
    labs(
      x = axis_setting$xlab,
      y = "Proportion (%)",
      title = title_text,
      tag = tag_use
    )
  
  
  ##########################################################
  # Legend appearance
  ##########################################################
  
  p <- p +
    guides(
      colour = guide_legend(
        # Six ancestry-composition legend entries are arranged as
        # two rows (three entries per row) to avoid an overly long legend.
        nrow = 2,
        byrow = TRUE,
        
        override.aes = list(
          alpha = 1,
          linewidth = LINE_WIDTH,
          linetype = 1,
          
          size = LEGEND_POINT_SIZE,
          
          stroke = POINT_STROKE,
          
          shape = unname(
            SHAPE_COMPOSITION[
              COMPOSITION_LEVELS
            ]
          ),
          
          fill = unname(
            FILL_COMPOSITION[
              COMPOSITION_LEVELS
            ]
          )
        )
      )
    )
  
  
  p <- p +
    gb_theme(
      base_size = 8,
      show_legend = show_legend
    )
  
  
  return(p)
}


############################################################
# 10. Extract bottom shared legend
############################################################

get_bottom_legend <- function(p) {
  
  p_legend <- p +
    theme(
      legend.position = "bottom",
      legend.direction = "horizontal",
      legend.justification = "center",
      legend.box = "horizontal",
          legend.box.spacing = unit(0, "pt")
    )
  
  
  g <- ggplotGrob(
    p_legend
  )
  
  
  idx <- which(
    grepl(
      "^guide-box",
      g$layout$name
    )
  )
  
  
  if (length(idx) == 0) {
    
    return(
      grid::nullGrob()
    )
  }
  
  
  is_zero <- vapply(
    g$grobs[idx],
    
    function(x) {
      
      inherits(
        x,
        "zeroGrob"
      )
    },
    
    logical(1)
  )
  
  
  valid <- idx[
    !is_zero
  ]
  
  
  if (length(valid) == 0) {
    
    return(
      grid::nullGrob()
    )
  }
  
  
  return(
    g$grobs[[valid[1]]]
  )
}


############################################################
# 11. Save common + rare grouped figure
#
# SAME SIZE AS PREVIOUS TWO-PANEL FIGURES:
#
#   width  = 7.40
#   height = 5.0
#
# Final device height:
#   2.90 + 0.35 = 3.25 in
#
# Therefore each horizontally arranged panel has
# approximately the same width as the previous
# ~3.70-in single panels.
############################################################

save_two_panel <- function(
    p_common,
    p_rare,
    out_prefix,
    width = 7.40,
    height = 5.0
) {
  
  if (
    is.null(p_common) ||
    is.null(p_rare)
  ) {
    
    warning(
      "Cannot save figure because one panel is NULL: ",
      out_prefix
    )
    
    return(
      invisible(NULL)
    )
  }
  
  
  ##########################################################
  # Extract shared legend
  ##########################################################
  
  legend <- get_bottom_legend(
    p_rare
  )
  
  
  p_common_no_legend <- p_common +
    theme(
      legend.position = "none"
    )
  
  
  p_rare_no_legend <- p_rare +
    theme(
      legend.position = "none"
    )
  
  
  ##########################################################
  # Draw function
  ##########################################################
  
  draw_figure <- function() {
    
    grid::grid.newpage()
    
    
    grid::pushViewport(
      grid::viewport(
        
        layout = grid::grid.layout(
          
          nrow = 3,
          
          ncol = 2,
          
          heights = unit.c(
            unit(1, "null"),
            unit(5.5, "pt"),
            grobHeight(legend)
          ),
          widths = grid::unit(
            c(
              1,
              1
            ),
            "null"
          ),
          respect = TRUE)
      )
    )
    
    
    ########################################################
    # Common panel
    ########################################################
    
    print(
      p_common_no_legend,
      
      vp = grid::viewport(
        layout.pos.row = 1,
        layout.pos.col = 1
      )
    )
    
    
    ########################################################
    # Rare panel
    ########################################################
    
    print(
      p_rare_no_legend,
      
      vp = grid::viewport(
        layout.pos.row = 1,
        layout.pos.col = 2
      )
    )
    
    
    ########################################################
    # Shared bottom legend
    ########################################################
    
    grid::pushViewport(
      grid::viewport(
        layout.pos.row = 3,
        layout.pos.col = 1:2
      )
    )
    
    
    grid::grid.draw(
      legend
    )
    
    
    grid::popViewport()
    
    grid::popViewport()
  }
  
  
  ##########################################################
  # Same final height logic as previous grouped figures
  ##########################################################
  
  device_height <- height + 0.35
  
  
  ##########################################################
  # PDF
  ##########################################################
  
  pdf_file <- paste0(
    out_prefix,
    ".pdf"
  )
  
  
  if (capabilities("cairo")) {
    
    grDevices::cairo_pdf(
      filename = pdf_file,
      width = width,
      height = device_height,
      bg = "white"
    )
    
  } else {
    
    grDevices::pdf(
      file = pdf_file,
      width = width,
      height = device_height,
      useDingbats = FALSE,
      bg = "white"
    )
  }
  
  
  draw_figure()
  
  grDevices::dev.off()
  
  
  ##########################################################
  # PNG
  ##########################################################
  
  png_file <- paste0(
    out_prefix,
    ".png"
  )
  
  
  grDevices::png(
    filename = png_file,
    width = width,
    height = device_height,
    units = "in",
    res = 600,
    bg = "white"
  )
  
  
  draw_figure()
  
  grDevices::dev.off()
  
  
  return(
    invisible(
      list(
        pdf = pdf_file,
        png = png_file
      )
    )
  )
}


############################################################
# 12. Read input files
############################################################

message(
  "============================================================"
)

message(
  "[INFO] Reading input files"
)

message(
  "============================================================"
)


bp_dt <- read_cumulative_file(
  BP_FILE,
  "BP_diff"
)


maf_dt <- read_cumulative_file(
  MAF_FILE,
  "MAF_diff"
)


ld_dt <- read_cumulative_file(
  LD_FILE,
  "LD_r2"
)


############################################################
# 13. Standardise ancestry groups
############################################################

bp_dt <- normalise_population_fields(
  bp_dt
)

maf_dt <- normalise_population_fields(
  maf_dt
)

ld_dt <- normalise_population_fields(
  ld_dt
)


############################################################
# 14. Check detected groups
############################################################

all_dt <- rbindlist(
  list(
    bp_dt,
    maf_dt,
    ld_dt
  ),
  use.names = TRUE,
  fill = TRUE
)


detected_groups <- unique(
  all_dt[
    !is.na(plot_label_comp),
    .(
      metric,
      variant_type,
      ancestry_comp_clean,
      plot_label_comp
    )
  ]
)


setorder(
  detected_groups,
  metric,
  variant_type,
  ancestry_comp_clean
)


fwrite(
  detected_groups,
  
  file.path(
    OUT_DIR,
    "CHECK_ancestry_composition_groups_used_for_plots.csv"
  )
)


cat(
  "\n============================================================\n"
)

cat(
  "Detected ancestry groups:\n"
)

print(
  detected_groups
)

cat(
  "============================================================\n\n"
)


############################################################
# 15. Check expected six groups
############################################################

EXPECTED_GROUPS <- c(
  "EUR10K",
  "EUR9K_AFR1K",
  "EUR8K_AFR2K",
  "EUR7K_AFR3K",
  "EUR6K_AFR4K",
  "EUR5K_AFR5K"
)


for (
  metric_i in c(
    "BP_diff",
    "MAF_diff",
    "LD_r2"
  )
) {
  
  for (
    variant_i in c(
      "common",
      "rare"
    )
  ) {
    
    observed <- unique(
      all_dt[
        metric == metric_i &
          variant_type == variant_i &
          !is.na(ancestry_comp_clean),
        ancestry_comp_clean
      ]
    )
    
    
    missing_groups <- setdiff(
      EXPECTED_GROUPS,
      observed
    )
    
    
    if (length(missing_groups) > 0) {
      
      warning(
        "Missing groups for ",
        metric_i,
        " / ",
        variant_i,
        ": ",
        paste(
          missing_groups,
          collapse = ", "
        )
      )
    }
  }
}


############################################################
# Legend layout for the following three ancestry-composition grouped figures:
#   BP / MAF / LD
# Six ancestry groups are displayed in 2 rows × 3 entries.
############################################################

############################################################
# 16. BP figure
# a common
# b rare
############################################################

message(
  "[INFO] Plotting BP figure..."
)


p_bp_common <- build_composition_line(
  dt = bp_dt,
  metric_name = "BP_diff",
  vt_select = "common",
  show_legend = FALSE,
  title_prefix = "a"
)


p_bp_rare <- build_composition_line(
  dt = bp_dt,
  metric_name = "BP_diff",
  vt_select = "rare",
  show_legend = TRUE,
  title_prefix = "b"
)


save_two_panel(
  p_common = p_bp_common,
  
  p_rare = p_bp_rare,
  
  out_prefix = file.path(
    OUT_DIR,
    "BP_ancestry_composition_common_rare_with_EUR5K_AFR5K"
  ),
  
  width = 7.40,
  
  height = 5.0
)


############################################################
# 17. MAF figure
# a common
# b rare
############################################################

message(
  "[INFO] Plotting MAF figure..."
)


p_maf_common <- build_composition_line(
  dt = maf_dt,
  metric_name = "MAF_diff",
  vt_select = "common",
  show_legend = FALSE,
  title_prefix = "a"
)


p_maf_rare <- build_composition_line(
  dt = maf_dt,
  metric_name = "MAF_diff",
  vt_select = "rare",
  show_legend = TRUE,
  title_prefix = "b"
)


save_two_panel(
  p_common = p_maf_common,
  
  p_rare = p_maf_rare,
  
  out_prefix = file.path(
    OUT_DIR,
    "MAF_ancestry_composition_common_rare_with_EUR5K_AFR5K"
  ),
  
  width = 7.40,
  
  height = 5.0
)


############################################################
# 18. LD figure
# a common
# b rare
############################################################

message(
  "[INFO] Plotting LD figure..."
)


p_ld_common <- build_composition_line(
  dt = ld_dt,
  metric_name = "LD_r2",
  vt_select = "common",
  show_legend = FALSE,
  title_prefix = "a"
)


p_ld_rare <- build_composition_line(
  dt = ld_dt,
  metric_name = "LD_r2",
  vt_select = "rare",
  show_legend = TRUE,
  title_prefix = "b"
)


save_two_panel(
  p_common = p_ld_common,
  
  p_rare = p_ld_rare,
  
  out_prefix = file.path(
    OUT_DIR,
    "LD_ancestry_composition_common_rare_with_EUR5K_AFR5K"
  ),
  
  width = 7.40,
  
  height = 5.0
)


############################################################
# 19. Save plotting source tables
############################################################

bp_plot_source <- bp_dt[
  !is.na(plot_label_comp) &
    plot_label_comp %in%
    COMPOSITION_LEVELS
]


maf_plot_source <- maf_dt[
  !is.na(plot_label_comp) &
    plot_label_comp %in%
    COMPOSITION_LEVELS
]


ld_plot_source <- ld_dt[
  !is.na(plot_label_comp) &
    plot_label_comp %in%
    COMPOSITION_LEVELS
]


fwrite(
  bp_plot_source,
  
  file.path(
    OUT_DIR,
    "plot_source_BP_ancestry_composition_with_EUR5K_AFR5K.csv"
  )
)


fwrite(
  maf_plot_source,
  
  file.path(
    OUT_DIR,
    "plot_source_MAF_ancestry_composition_with_EUR5K_AFR5K.csv"
  )
)


fwrite(
  ld_plot_source,
  
  file.path(
    OUT_DIR,
    "plot_source_LD_ancestry_composition_with_EUR5K_AFR5K.csv"
  )
)


############################################################
# 20. Final output
############################################################

cat(
  "\n============================================================\n"
)

cat(
  "[INFO] All ancestry-composition plots finished successfully.\n"
)

cat(
  "\nIncluded groups:\n"
)

cat(
  "  1. Single-ancestry (EUR10K)\n"
)

cat(
  "  2. EUR9K + AFR1K\n"
)

cat(
  "  3. EUR8K + AFR2K\n"
)

cat(
  "  4. EUR7K + AFR3K\n"
)

cat(
  "  5. EUR6K + AFR4K\n"
)

cat(
  "  6. EUR5K + AFR5K\n"
)

cat(
  "\nFigure dimensions:\n"
)

cat(
  "  Width: 7.40 in\n"
)

cat(
  "  Main figure height: 2.90 in\n"
)

cat(
  "  Shared legend addition: 0.35 in\n"
)

cat(
  "  Final device size: 7.40 x 3.25 in\n"
)

cat(
  "\nOutput files:\n"
)

cat(
  "  BP_ancestry_composition_common_rare_with_EUR5K_AFR5K.pdf/png\n"
)

cat(
  "  MAF_ancestry_composition_common_rare_with_EUR5K_AFR5K.pdf/png\n"
)

cat(
  "  LD_ancestry_composition_common_rare_with_EUR5K_AFR5K.pdf/png\n"
)

cat(
  "\nOutput directory:\n"
)

cat(
  OUT_DIR,
  "\n"
)

cat(
  "============================================================\n"
)
























































############################################################
# Recalculate and redraw mapping-precision figures after
# extending simulations from N=1000 to N=5000.
#
# Main GWAS comparison:
#   Single-ancestry = EUR10K
#   Multi-ancestry  = EUR5K + AFR5K pooled GWAS
#
# GWAS outputs:
#   1. BP_diff cumulative curves (common + rare)
#   2. MAF_diff cumulative curves (common + rare)
#   3. LD r2 cumulative curves (common + rare)
#   4. Exact causal identification across causal-MAF bins
#      (common + rare)
#
# Fine-mapping:
#   Single-ancestry = SuSiE (EUR10K)
#   Multi-ancestry  = SuSiEx (EUR5K + AFR5K)
#
# All original 1000 simulations and new add1k 1000 simulations
# are combined. The script checks for exactly 2000 UNIQUE loops
# in every input dataset before any filtering.
#
# Filtering follows the previous script:
#   GWAS         : lead_P < 5e-8
#   Fine-mapping : pip_max > 0.95
#
# Cumulative definitions:
#   BP_diff  : proportion with BP_diff <= threshold
#   MAF_diff : proportion with MAF_diff <= threshold
#   LD r2    : proportion with ld_r2 >= threshold
############################################################




# ===== ACTIVE ORIGINAL/UNMATCHED-VARIANT-SET FPR 5K MODULE =====
# Run this module: it is not a disabled legacy 2K block.
# ===== PRESERVED ORIGINAL GWAS MODULE 24 =====

rm(list = ls())
gc()

suppressPackageStartupMessages({
  library(data.table)
  library(ggplot2)
  library(grid)
})

############################################################
# 1. Paths
############################################################

BASE_DIR <- "C:/Users/ASUS/Desktop/GWAS/gwas/模拟3"

OLD_EUR_DIR <- file.path(BASE_DIR, "new_EUR")
OLD_POOLED_DIR <- file.path(BASE_DIR, "new_pooled")

ADD4K_DIR <- file.path(
  BASE_DIR,
  "new_pooled",
  "add4k_fpr",
  "origin"
)

MERGED5K_DIR <- file.path(
  ADD4K_DIR,
  "merged_5k"
)

OUT_DIR <- file.path(
  BASE_DIR,
  "results",
  "new_results",
  "real_final_plot"
)

dir.create(MERGED5K_DIR, recursive = TRUE, showWarnings = FALSE)
dir.create(OUT_DIR, recursive = TRUE, showWarnings = FALSE)

PREFIX <- "original_var_size_fpr_5k"

############################################################
# 2. Exact input files
############################################################

FILE_INFO <- data.table(
  variant_type = c(
    "allvariants", "allvariants",
    "common", "common",
    "rare", "rare"
  ),
  method = c(
    "single-ancestry", "multi-ancestry",
    "single-ancestry", "multi-ancestry",
    "single-ancestry", "multi-ancestry"
  ),
  old_file = c(
    file.path(OLD_EUR_DIR,    "allvariants_EUR_minP.merged.txt"),
    file.path(OLD_POOLED_DIR, "pooled_allvar_minP.merged.txt"),
    file.path(OLD_EUR_DIR,    "common_EUR_minP.merged.txt"),
    file.path(OLD_POOLED_DIR, "pooled_common_minP.merged.txt"),
    file.path(OLD_EUR_DIR,    "rare_EUR_minP.merged.txt"),
    file.path(OLD_POOLED_DIR, "pooled_rare_minP.merged.txt")
  ),
  new_file = c(
    file.path(ADD4K_DIR, "allvariants_EUR_minP_1001_5000.txt"),
    file.path(ADD4K_DIR, "pooled_allvar_minP_1001_5000.txt"),
    file.path(ADD4K_DIR, "common_EUR_minP_1001_5000.txt"),
    file.path(ADD4K_DIR, "pooled_common_minP_1001_5000.txt"),
    file.path(ADD4K_DIR, "rare_EUR_minP_1001_5000.txt"),
    file.path(ADD4K_DIR, "pooled_rare_minP_1001_5000.txt")
  ),
  merged_file = c(
    file.path(MERGED5K_DIR, "allvariants_EUR_minP_1_5000.txt"),
    file.path(MERGED5K_DIR, "pooled_allvar_minP_1_5000.txt"),
    file.path(MERGED5K_DIR, "common_EUR_minP_1_5000.txt"),
    file.path(MERGED5K_DIR, "pooled_common_minP_1_5000.txt"),
    file.path(MERGED5K_DIR, "rare_EUR_minP_1_5000.txt"),
    file.path(MERGED5K_DIR, "pooled_rare_minP_1_5000.txt")
  )
)

############################################################
# 3. Plot/statistical settings
############################################################

REF_Y <- 0.05

MARKER_P_FIXED <- c(
  1e-7,
  5e-8,
  1e-8,
  1e-9,
  1e-10
)

MARKER_X_FIXED <- -log10(MARKER_P_FIXED)

X_MIN <- 7
X_MAX <- 10
X_BREAKS <- c(7, 8, 9, 10)

SMOOTH_N <- 1201

COL_SINGLE <- "#1F4E79"
COL_MULTI  <- "#E69F00"

COL_MAIN <- c(
  "single-ancestry" = COL_SINGLE,
  "multi-ancestry"  = COL_MULTI
)

SHAPE_MAIN <- c(
  "single-ancestry" = 21,
  "multi-ancestry"  = 24
)

FILL_MAIN <- c(
  "single-ancestry" = COL_SINGLE,
  "multi-ancestry"  = "white"
)

MAIN_LABEL_LEVELS <- c(
  "single-ancestry",
  "multi-ancestry"
)

POINT_SIZE <- 1.25
POINT_STROKE <- 0.45
LEGEND_POINT_SIZE <- 1.45
LEGEND_LINE_WIDTH <- 0.55

FIXED_POINT_LINE_GAP_NPC <- 0.027

REF_LINE_COLOUR <- "#D62728"

############################################################
# 4. General helpers
############################################################

fatal <- function(...) {
  stop(paste0(...), call. = FALSE)
}

panel_title <- function(vt, prefix = NULL) {
  txt <- switch(
    vt,
    allvariants = "all variants",
    common      = "common (MAF > 0.01)",
    rare        = "rare (MAF ≤ 0.01)",
    vt
  )
  
  if (!is.null(prefix)) {
    txt <- paste0(prefix, "  ", txt)
  }
  
  txt
}

check_required_cols <- function(dt, file) {
  required <- c("loop", "lead_SNP", "lead_P")
  missing_cols <- setdiff(required, names(dt))
  
  if (length(missing_cols) > 0) {
    fatal(
      "Missing required columns in:\n", file,
      "\nMissing: ", paste(missing_cols, collapse = ", "),
      "\nCurrent columns: ", paste(names(dt), collapse = ", ")
    )
  }
}

read_minp_file <- function(
    file,
    expected_first_loop,
    expected_last_loop,
    label
) {
  if (!file.exists(file)) {
    fatal("Input file does not exist:\n", file)
  }
  
  dt <- fread(file, data.table = TRUE)
  setnames(dt, trimws(names(dt)))
  check_required_cols(dt, file)
  
  dt[, loop := suppressWarnings(as.integer(loop))]
  dt[, lead_SNP := as.character(lead_SNP)]
  dt[, lead_P := suppressWarnings(as.numeric(lead_P))]
  
  expected_loops <- seq.int(
    expected_first_loop,
    expected_last_loop
  )
  
  expected_n <- length(expected_loops)
  
  if (nrow(dt) != expected_n) {
    fatal(
      label, " has ", nrow(dt), " rows; expected ", expected_n,
      "\nFile: ", file
    )
  }
  
  if (anyNA(dt$loop)) {
    bad_n <- sum(is.na(dt$loop))
    fatal(
      label, " contains ", bad_n, " non-numeric/NA loop IDs.",
      "\nFile: ", file
    )
  }
  
  dup <- dt[
    duplicated(loop) | duplicated(loop, fromLast = TRUE),
    sort(unique(loop))
  ]
  
  if (length(dup) > 0) {
    fatal(
      label, " contains duplicated loop IDs:\n",
      paste(dup, collapse = ", "),
      "\nFile: ", file
    )
  }
  
  observed <- sort(dt$loop)
  
  if (!identical(observed, expected_loops)) {
    missing <- setdiff(expected_loops, observed)
    extra   <- setdiff(observed, expected_loops)
    
    fatal(
      label, " does not contain the expected loop range ",
      expected_first_loop, "-", expected_last_loop, ".",
      "\nMissing loops: ",
      if (length(missing) == 0) "none" else paste(missing, collapse = ", "),
      "\nUnexpected loops: ",
      if (length(extra) == 0) "none" else paste(extra, collapse = ", "),
      "\nFile: ", file
    )
  }
  
  bad_p <- !is.finite(dt$lead_P) |
    dt$lead_P <= 0 |
    dt$lead_P > 1
  
  if (any(bad_p)) {
    bad_loops <- dt[bad_p, loop]
    
    fatal(
      label,
      " contains invalid lead_P values in ",
      length(bad_loops),
      " loop(s).",
      "\nInvalid loop IDs: ",
      paste(head(bad_loops, 50), collapse = ", "),
      if (length(bad_loops) > 50) "\n(first 50 shown)" else "",
      "\nFile: ", file,
      "\nAll 5,000 simulations must have valid lead_P values so that ",
      "the FPR denominator remains exactly 5,000."
    )
  }
  
  setorder(dt, loop)
  dt[]
}

merge_old_new <- function(
    old_file,
    new_file,
    merged_file,
    variant_type,
    method
) {
  label <- paste(variant_type, method, sep = " / ")
  
  message("")
  message("============================================================")
  message("[INFO] Dataset: ", label)
  message("[INFO] Previous 1K: ", old_file)
  message("[INFO] New 4K     : ", new_file)
  message("[INFO] Merged 5K  : ", merged_file)
  message("============================================================")
  
  old_dt <- read_minp_file(
    file = old_file,
    expected_first_loop = 1L,
    expected_last_loop = 1000L,
    label = paste0(label, " previous 1K")
  )
  
  new_dt <- read_minp_file(
    file = new_file,
    expected_first_loop = 1001L,
    expected_last_loop = 5000L,
    label = paste0(label, " new 4K")
  )
  
  if (!setequal(names(old_dt), names(new_dt))) {
    fatal(
      "Column names differ between old and new files for ", label,
      "\nOld columns: ", paste(names(old_dt), collapse = ", "),
      "\nNew columns: ", paste(names(new_dt), collapse = ", ")
    )
  }
  
  setcolorder(new_dt, names(old_dt))
  
  merged <- rbindlist(
    list(old_dt, new_dt),
    use.names = TRUE,
    fill = FALSE
  )
  
  setorder(merged, loop)
  
  if (nrow(merged) != 5000L) {
    fatal(
      "Merged dataset does not contain 5,000 rows for ", label,
      ". Observed: ", nrow(merged)
    )
  }
  
  if (!identical(merged$loop, 1:5000)) {
    fatal(
      "Merged loop IDs are not exactly 1-5000 for ", label
    )
  }
  
  if (anyDuplicated(merged$loop)) {
    fatal(
      "Duplicated loop IDs remain after merging for ", label
    )
  }
  
  if (any(
    !is.finite(merged$lead_P) |
    merged$lead_P <= 0 |
    merged$lead_P > 1
  )) {
    fatal(
      "Invalid lead_P remains after merging for ", label
    )
  }
  
  fwrite(
    merged,
    merged_file,
    sep = "\t",
    quote = FALSE,
    na = "NA"
  )
  
  message(
    "[DONE] ", label,
    ": 1000 + 4000 = ", nrow(merged),
    " simulations"
  )
  
  merged[
    ,
    `:=`(
      variant_type = variant_type,
      method = method
    )
  ]
  
  merged[]
}

############################################################
# 5. Merge previous 1K + new 4K
############################################################

merged_list <- vector("list", nrow(FILE_INFO))

for (i in seq_len(nrow(FILE_INFO))) {
  merged_list[[i]] <- merge_old_new(
    old_file = FILE_INFO$old_file[i],
    new_file = FILE_INFO$new_file[i],
    merged_file = FILE_INFO$merged_file[i],
    variant_type = FILE_INFO$variant_type[i],
    method = FILE_INFO$method[i]
  )
}

raw_dt <- rbindlist(
  merged_list,
  use.names = TRUE,
  fill = TRUE
)

############################################################
# 6. Final merged-data QC
############################################################

merge_qc <- raw_dt[
  ,
  .(
    n_rows = .N,
    n_unique_loops = uniqueN(loop),
    min_loop = min(loop),
    max_loop = max(loop),
    n_valid_lead_P = sum(
      is.finite(lead_P) &
        lead_P > 0 &
        lead_P <= 1
    ),
    min_P = min(lead_P),
    median_P = median(lead_P),
    max_P = max(lead_P)
  ),
  by = .(
    variant_type,
    method
  )
]

merge_qc[
  ,
  qc_pass :=
    n_rows == 5000 &
    n_unique_loops == 5000 &
    min_loop == 1 &
    max_loop == 5000 &
    n_valid_lead_P == 5000
]

fwrite(
  merge_qc,
  file.path(
    OUT_DIR,
    paste0(PREFIX, "_merge_QC.csv")
  )
)

if (any(merge_qc$qc_pass != TRUE)) {
  print(merge_qc)
  fatal("Merged 5K QC failed. See ", PREFIX, "_merge_QC.csv")
}

message("")
message("============================================================")
message("[INFO] All six datasets passed 5K merge QC")
message("[INFO] Every FPR denominator is exactly 5,000")
message("============================================================")

############################################################
# 7. FPR helper functions
############################################################

calc_prop <- function(p_values, p_threshold) {
  mean(p_values < p_threshold)
}

calc_count <- function(p_values, p_threshold) {
  sum(p_values < p_threshold)
}

# Empirical P threshold corresponding to FPR = 0.05.
# This intentionally follows the previous type = 7 quantile definition.
calc_y005_threshold <- function(p_values) {
  q <- as.numeric(
    quantile(
      p_values,
      probs = REF_Y,
      na.rm = FALSE,
      names = FALSE,
      type = 7
    )
  )
  
  data.table(
    P_at_y005 = q,
    neglog10P_at_y005 = -log10(q),
    observed_count_strict_lt = sum(p_values < q),
    observed_prop_strict_lt = mean(p_values < q),
    observed_percent_strict_lt = mean(p_values < q) * 100
  )
}

make_fixed_points <- function(
    p_values,
    variant_type,
    method
) {
  counts <- vapply(
    MARKER_P_FIXED,
    function(pp) calc_count(p_values, pp),
    integer(1)
  )
  
  props <- counts / length(p_values)
  
  data.table(
    variant_type = variant_type,
    method = method,
    n_total = length(p_values),
    n_false_positive = counts,
    neglog10P = MARKER_X_FIXED,
    P_threshold = MARKER_P_FIXED,
    proportion = props,
    percent = props * 100,
    point_type = "fixed_threshold"
  )
}

make_y005_point <- function(
    p_values,
    variant_type,
    method
) {
  th <- calc_y005_threshold(p_values)
  
  data.table(
    variant_type = variant_type,
    method = method,
    n_total = length(p_values),
    n_false_positive = th$observed_count_strict_lt,
    neglog10P = th$neglog10P_at_y005,
    P_threshold = th$P_at_y005,
    proportion = REF_Y,
    percent = REF_Y * 100,
    observed_prop_strict_lt = th$observed_prop_strict_lt,
    observed_percent_strict_lt = th$observed_percent_strict_lt,
    point_type = "empirical_y005"
  )
}

deduplicate_anchor_points <- function(dt) {
  d <- copy(dt)
  
  d[
    ,
    priority := fifelse(
      point_type == "empirical_y005",
      1L,
      2L
    )
  ]
  
  setorder(
    d,
    variant_type,
    method,
    neglog10P,
    priority
  )
  
  d <- d[
    ,
    .SD[1],
    by = .(
      variant_type,
      method,
      neglog10P
    )
  ]
  
  d[, priority := NULL]
  d[]
}

############################################################
# 8. Input lead-P summary
############################################################

raw_summary <- raw_dt[
  ,
  .(
    n = .N,
    min_P = min(lead_P),
    q01_P = as.numeric(quantile(lead_P, 0.01, type = 7)),
    q05_P = as.numeric(quantile(lead_P, 0.05, type = 7)),
    median_P = median(lead_P),
    max_P = max(lead_P)
  ),
  by = .(
    variant_type,
    method
  )
]

fwrite(
  raw_summary,
  file.path(
    OUT_DIR,
    paste0(
      PREFIX,
      "_input_leadP_summary.csv"
    )
  )
)

############################################################
# 9. FPR at fixed P thresholds
############################################################

fixed_point_list <- list()

for (vt in unique(raw_dt$variant_type)) {
  for (mm in MAIN_LABEL_LEVELS) {
    pp <- raw_dt[
      variant_type == vt &
        method == mm,
      lead_P
    ]
    
    if (length(pp) != 5000L) {
      fatal(
        "Expected 5,000 P values for ",
        vt, " / ", mm,
        "; observed ", length(pp)
      )
    }
    
    fixed_point_list[[paste(vt, mm, sep = "__")]] <-
      make_fixed_points(
        pp,
        vt,
        mm
      )
  }
}

fixed_point_dt <- rbindlist(
  fixed_point_list,
  use.names = TRUE,
  fill = TRUE
)

setorder(
  fixed_point_dt,
  variant_type,
  method,
  -P_threshold
)

fwrite(
  fixed_point_dt,
  file.path(
    OUT_DIR,
    paste0(
      PREFIX,
      "_requested_marker_threshold_FPR.csv"
    )
  )
)

############################################################
# 10. Empirical P threshold at FPR = 0.05
############################################################

y005_list <- list()

for (vt in unique(raw_dt$variant_type)) {
  for (mm in MAIN_LABEL_LEVELS) {
    pp <- raw_dt[
      variant_type == vt &
        method == mm,
      lead_P
    ]
    
    y005_list[[paste(vt, mm, sep = "__")]] <-
      make_y005_point(
        pp,
        vt,
        mm
      )
  }
}

y005_dt <- rbindlist(
  y005_list,
  use.names = TRUE,
  fill = TRUE
)

y005_dt[
  ,
  P_at_y005_scientific := format(
    P_threshold,
    scientific = TRUE,
    digits = 6
  )
]

fwrite(
  y005_dt,
  file.path(
    OUT_DIR,
    paste0(
      PREFIX,
      "_empirical_P_threshold_at_FPR005.csv"
    )
  )
)

############################################################
# 11. Cross-evaluate both methods at each empirical FPR=0.05
#     threshold
############################################################

cross_eval_list <- list()

for (vt in unique(raw_dt$variant_type)) {
  
  anchors <- y005_dt[
    variant_type == vt
  ]
  
  for (anchor_method in MAIN_LABEL_LEVELS) {
    
    anchor_row <- anchors[
      method == anchor_method
    ]
    
    if (nrow(anchor_row) != 1L) {
      fatal(
        "Expected exactly one empirical FPR=0.05 threshold for ",
        vt, " / ", anchor_method
      )
    }
    
    anchor_p <- anchor_row$P_threshold
    anchor_x <- anchor_row$neglog10P
    
    for (eval_method in MAIN_LABEL_LEVELS) {
      
      eval_p <- raw_dt[
        variant_type == vt &
          method == eval_method,
        lead_P
      ]
      
      n_fp <- calc_count(
        eval_p,
        anchor_p
      )
      
      cross_eval_list[[length(cross_eval_list) + 1L]] <-
        data.table(
          variant_type = vt,
          anchor_method = anchor_method,
          evaluated_method = eval_method,
          n_total = length(eval_p),
          n_false_positive = n_fp,
          anchor_P_threshold = anchor_p,
          anchor_neglog10P = anchor_x,
          proportion_at_anchor = n_fp / length(eval_p),
          percent_at_anchor = n_fp / length(eval_p) * 100
        )
    }
  }
}

cross_eval_dt <- rbindlist(
  cross_eval_list,
  use.names = TRUE,
  fill = TRUE
)

fwrite(
  cross_eval_dt,
  file.path(
    OUT_DIR,
    paste0(
      PREFIX,
      "_cross_method_FPR_at_each_empirical_FPR005_threshold.csv"
    )
  )
)

############################################################
# 12. Cross-method points at both empirical FPR=0.05 x positions
############################################################

cross_y005_point_dt <- cross_eval_dt[
  anchor_method != evaluated_method,
  .(
    variant_type,
    method = evaluated_method,
    n_total,
    n_false_positive,
    neglog10P = anchor_neglog10P,
    P_threshold = anchor_P_threshold,
    proportion = proportion_at_anchor,
    percent = percent_at_anchor,
    point_type = paste0(
      "cross_at_",
      anchor_method,
      "_y005"
    )
  )
]

fwrite(
  cross_y005_point_dt,
  file.path(
    OUT_DIR,
    paste0(
      PREFIX,
      "_cross_method_points_at_both_FPR005_xpositions.csv"
    )
  )
)

############################################################
# 13. Anchor points used for curves
############################################################

anchor_dt <- rbindlist(
  list(
    fixed_point_dt[
      ,
      .(
        variant_type,
        method,
        n_total,
        n_false_positive,
        neglog10P,
        P_threshold,
        proportion,
        percent,
        point_type
      )
    ],
    y005_dt[
      ,
      .(
        variant_type,
        method,
        n_total,
        n_false_positive,
        neglog10P,
        P_threshold,
        proportion,
        percent,
        point_type
      )
    ],
    cross_y005_point_dt[
      ,
      .(
        variant_type,
        method,
        n_total,
        n_false_positive,
        neglog10P,
        P_threshold,
        proportion,
        percent,
        point_type
      )
    ]
  ),
  use.names = TRUE,
  fill = TRUE
)

anchor_dt <- deduplicate_anchor_points(
  anchor_dt
)

fwrite(
  anchor_dt,
  file.path(
    OUT_DIR,
    paste0(
      PREFIX,
      "_all_anchor_points_used_for_smooth_curves.csv"
    )
  )
)

############################################################
# 14. Plot helpers
############################################################

get_ymax_from_x7 <- function(
    anchor_dt,
    vt
) {
  d <- anchor_dt[
    variant_type == vt &
      abs(neglog10P - 7) < 1e-10
  ]
  
  if (nrow(d) == 0) {
    ymax <- 0.10
  } else {
    ymax <- max(
      d$proportion,
      na.rm = TRUE
    )
    
    ymax <- ceiling(
      ymax / 0.05
    ) * 0.05
    
    ymax <- max(
      ymax,
      0.10
    )
  }
  
  min(
    ymax,
    1
  )
}

make_ybreaks <- function(ymax) {
  if (ymax <= 0.10) {
    return(
      seq(
        0,
        ymax,
        by = 0.025
      )
    )
  }
  
  if (ymax <= 0.30) {
    return(
      seq(
        0,
        ymax,
        by = 0.05
      )
    )
  }
  
  if (ymax <= 0.60) {
    return(
      seq(
        0,
        ymax,
        by = 0.10
      )
    )
  }
  
  seq(
    0,
    ymax,
    by = 0.20
  )
}

build_smooth_curve_from_points <- function(
    anchor_dt,
    vt,
    ymax
) {
  d0 <- anchor_dt[
    variant_type == vt
  ]
  
  out <- list()
  
  for (mm in MAIN_LABEL_LEVELS) {
    
    d <- copy(
      d0[
        method == mm
      ]
    )
    
    d <- d[
      is.finite(neglog10P) &
        is.finite(proportion)
    ]
    
    if (nrow(d) < 2) {
      next
    }
    
    setorder(
      d,
      neglog10P
    )
    
    d_fit <- d[
      neglog10P >= X_MIN &
        neglog10P <= X_MAX
    ]
    
    if (nrow(d_fit) < 2) {
      next
    }
    
    d_fit[
      ,
      proportion_for_spline := cummin(
        proportion
      )
    ]
    
    sf <- splinefun(
      x = d_fit$neglog10P,
      y = d_fit$proportion_for_spline,
      method = "monoH.FC"
    )
    
    x_grid <- seq(
      min(d_fit$neglog10P),
      max(d_fit$neglog10P),
      length.out = SMOOTH_N
    )
    
    y_grid <- sf(
      x_grid
    )
    
    y_grid <- pmax(
      pmin(
        y_grid,
        1
      ),
      0
    )
    
    cur <- data.table(
      variant_type = vt,
      method = mm,
      neglog10P = x_grid,
      proportion = y_grid
    )
    
    anchor_visible <- d[
      neglog10P >= X_MIN &
        neglog10P <= X_MAX
    ]
    
    x_range <- X_MAX - X_MIN
    y_range <- ymax
    
    if (
      !is.finite(y_range) ||
      y_range <= 0
    ) {
      y_range <- 1
    }
    
    gap_flag <- rep(
      FALSE,
      nrow(cur)
    )
    
    for (ii in seq_len(nrow(anchor_visible))) {
      
      xp <- anchor_visible$neglog10P[ii]
      yp <- anchor_visible$proportion[ii]
      
      dist_npc <- sqrt(
        (
          (
            cur$neglog10P - xp
          ) / x_range
        )^2 +
          (
            (
              cur$proportion - yp
            ) / y_range
          )^2
      )
      
      gap_flag <- gap_flag |
        (
          is.finite(dist_npc) &
            dist_npc < FIXED_POINT_LINE_GAP_NPC
        )
    }
    
    cur[
      ,
      keep_curve := !gap_flag
    ]
    
    cur[
      ,
      run_id := rleid(
        keep_curve
      )
    ]
    
    cur <- cur[
      keep_curve == TRUE
    ]
    
    cur[
      ,
      segment_id := paste0(
        mm,
        "_",
        run_id
      )
    ]
    
    out[[mm]] <- cur
  }
  
  if (length(out) == 0) {
    return(
      data.table()
    )
  }
  
  rbindlist(
    out,
    use.names = TRUE,
    fill = TRUE
  )
}

gb_theme <- function(
    base_size = 8,
    show_legend = TRUE
) {
  th <- theme_classic(
    base_size = base_size,
    base_family = "sans"
  ) +
    theme(
      aspect.ratio = 1,
      axis.line = element_line(
        linewidth = 0.35,
        colour = "black"
      ),
      axis.ticks = element_line(
        linewidth = 0.35,
        colour = "black"
      ),
      axis.ticks.length = unit(
        1.6,
        "mm"
      ),
      axis.title.x = element_text(
        size = 11.0,
        colour = "black",
        margin = margin(t = 5)
      ),
      axis.title.y = element_text(
        size = 11.0,
        colour = "black",
        margin = margin(r = 6),
        lineheight = 0.95
      ),
      axis.text = element_text(
        size = 9.5,
        colour = "black"
      ),
      plot.title = element_text(
        size = 11.5,
        hjust = 0.5,
        vjust = 1,
        colour = "black",
        face = "plain",
        margin = margin(b = 6)
      ),
      plot.title.position = "panel",
      plot.tag.position = c(
        0.002,
        0.995
      ),
      plot.tag = element_text(
        size = 11.5,
        colour = "black",
        face = "bold",
        hjust = 0,
        vjust = 1,
        margin = margin(0, 0, 0, 0)
      ),
      legend.title = element_blank(),
      legend.text = element_text(
        size = 9.5,
        colour = "black"
      ),
      legend.key.width = unit(
        0.62,
        "cm"
      ),
      legend.key.height = unit(
        0.34,
        "cm"
      ),
      legend.background = element_blank(),
      legend.box.background = element_blank(),
      legend.key = element_rect(
        fill = "white",
        colour = NA
      ),
      legend.margin = margin(
        0, 0, 0, 0
      ),
      legend.spacing.y = unit(
        0.055,
        "cm"
      ),
      panel.border = element_blank(),
      panel.background = element_blank(),
      plot.background = element_rect(
        fill = "white",
        colour = NA
      ),
      plot.margin = margin(
        16,
        10,
        8,
        20
      )
    )
  
  if (show_legend) {
    th <- th +
      theme(
        legend.position = "bottom",
        legend.direction = "horizontal",
        legend.justification = "center",
        legend.box = "horizontal",
        legend.box.spacing = unit(
          5.5,
          "pt"
        )
      )
  } else {
    th <- th +
      theme(
        legend.position = "none"
      )
  }
  
  th
}

build_plot <- function(
    anchor_dt,
    variant_type,
    show_legend = TRUE,
    title_prefix = NULL
) {
  vt <- variant_type
  
  d_point <- copy(
    anchor_dt[
      variant_type == vt &
        neglog10P >= X_MIN &
        neglog10P <= X_MAX
    ]
  )
  
  if (nrow(d_point) == 0) {
    warning(
      "No visible anchor points for: ",
      vt
    )
    return(NULL)
  }
  
  ymax <- get_ymax_from_x7(
    anchor_dt,
    vt
  )
  
  ybreaks <- make_ybreaks(
    ymax
  )
  
  d_curve <- build_smooth_curve_from_points(
    anchor_dt = anchor_dt,
    vt = vt,
    ymax = ymax
  )
  
  if (nrow(d_curve) == 0) {
    warning(
      "No smooth curve could be generated for: ",
      vt
    )
    return(NULL)
  }
  
  d_point[
    ,
    method := factor(
      method,
      levels = MAIN_LABEL_LEVELS
    )
  ]
  
  d_curve[
    ,
    method := factor(
      method,
      levels = MAIN_LABEL_LEVELS
    )
  ]
  
  p <- ggplot() +
    
    geom_line(
      data = d_curve,
      aes(
        x = neglog10P,
        y = proportion,
        colour = method,
        group = segment_id
      ),
      linewidth = LEGEND_LINE_WIDTH,
      lineend = "round",
      show.legend = TRUE,
      na.rm = TRUE
    ) +
    
    geom_hline(
      yintercept = REF_Y,
      colour = REF_LINE_COLOUR,
      linetype = "dashed",
      linewidth = 0.45,
      show.legend = FALSE
    ) +
    
    geom_point(
      data = d_point,
      aes(
        x = neglog10P,
        y = proportion,
        colour = method,
        fill = method,
        shape = method
      ),
      size = POINT_SIZE,
      stroke = POINT_STROKE,
      show.legend = TRUE,
      na.rm = TRUE
    ) +
    
    scale_colour_manual(
      name = NULL,
      values = COL_MAIN,
      breaks = MAIN_LABEL_LEVELS,
      labels = c(
        "Single-ancestry",
        "Multi-ancestry"
      ),
      drop = FALSE
    ) +
    
    scale_shape_manual(
      name = NULL,
      values = SHAPE_MAIN,
      breaks = MAIN_LABEL_LEVELS,
      labels = c(
        "Single-ancestry",
        "Multi-ancestry"
      ),
      drop = FALSE,
      guide = "none"
    ) +
    
    scale_fill_manual(
      name = NULL,
      values = FILL_MAIN,
      breaks = MAIN_LABEL_LEVELS,
      labels = c(
        "Single-ancestry",
        "Multi-ancestry"
      ),
      drop = FALSE,
      guide = "none"
    ) +
    
    scale_x_continuous(
      limits = c(
        X_MIN,
        X_MAX
      ),
      breaks = X_BREAKS,
      labels = c(
        "7",
        "8",
        "9",
        "10"
      ),
      expand = expansion(
        mult = c(
          0,
          0.02
        )
      )
    ) +
    
    scale_y_continuous(
      limits = c(
        0,
        ymax
      ),
      breaks = ybreaks,
      expand = expansion(
        mult = c(
          0,
          0.035
        )
      ),
      labels = function(x) {
        format(
          x,
          trim = TRUE,
          scientific = FALSE
        )
      }
    ) +
    
    coord_cartesian(
      clip = "off"
    ) +
    
    labs(
      x = expression(
        -log[10](
          italic(P) ~ threshold
        )
      ),
      y = "Genome-wide false positive rate",
      title = panel_title(
        vt
      ),
      tag = if (
        !is.null(title_prefix) &&
        nzchar(
          as.character(
            title_prefix
          )
        )
      ) {
        as.character(
          title_prefix
        )
      } else {
        NULL
      }
    ) +
    
    guides(
      colour = guide_legend(
        nrow = 1,
        byrow = TRUE,
        override.aes = list(
          alpha = 1,
          linewidth = LEGEND_LINE_WIDTH,
          linetype = 1,
          size = LEGEND_POINT_SIZE,
          stroke = POINT_STROKE,
          shape = unname(
            SHAPE_MAIN[
              MAIN_LABEL_LEVELS
            ]
          ),
          fill = unname(
            FILL_MAIN[
              MAIN_LABEL_LEVELS
            ]
          )
        )
      )
    ) +
    
    gb_theme(
      base_size = 8,
      show_legend = show_legend
    )
  
  p
}

############################################################
# 15. Save helpers
############################################################

save_plot_pdf_png <- function(
    p,
    out_prefix,
    width = 4.0,
    height = 5.0
) {
  pdf_file <- paste0(
    out_prefix,
    ".pdf"
  )
  
  png_file <- paste0(
    out_prefix,
    ".png"
  )
  
  if (capabilities("cairo")) {
    grDevices::cairo_pdf(
      filename = pdf_file,
      width = width,
      height = height,
      bg = "white"
    )
  } else {
    grDevices::pdf(
      file = pdf_file,
      width = width,
      height = height,
      useDingbats = FALSE,
      bg = "white"
    )
  }
  
  print(p)
  grDevices::dev.off()
  
  grDevices::png(
    filename = png_file,
    width = width,
    height = height,
    units = "in",
    res = 600,
    bg = "white"
  )
  
  print(p)
  grDevices::dev.off()
}

save_combined_three <- function(
    p1,
    p2,
    p3,
    out_prefix,
    width = 11.8,
    height = 5.0
) {
  pdf_file <- paste0(
    out_prefix,
    ".pdf"
  )
  
  png_file <- paste0(
    out_prefix,
    ".png"
  )
  
  get_bottom_legend <- function(p) {
    g <- ggplotGrob(
      p +
        theme(
          legend.position = "bottom",
          legend.direction = "horizontal",
          legend.justification = "center",
          legend.box = "horizontal",
          legend.box.spacing = unit(
            0,
            "pt"
          )
        )
    )
    
    idx <- which(
      grepl(
        "^guide-box",
        g$layout$name
      )
    )
    
    if (length(idx) == 0) {
      return(
        grid::nullGrob()
      )
    }
    
    valid <- idx[
      !vapply(
        g$grobs[idx],
        inherits,
        logical(1),
        what = "zeroGrob"
      )
    ]
    
    if (length(valid) == 0) {
      return(
        grid::nullGrob()
      )
    }
    
    g$grobs[[valid[1]]]
  }
  
  legend <- get_bottom_legend(
    p3
  )
  
  p1_no_legend <- p1 +
    theme(
      legend.position = "none"
    )
  
  p2_no_legend <- p2 +
    theme(
      legend.position = "none"
    )
  
  p3_no_legend <- p3 +
    theme(
      legend.position = "none"
    )
  
  draw_three <- function() {
    grid.newpage()
    
    pushViewport(
      viewport(
        layout = grid.layout(
          nrow = 3,
          ncol = 3,
          heights = unit.c(
            unit(
              1,
              "null"
            ),
            unit(
              5.5,
              "pt"
            ),
            grobHeight(
              legend
            )
          ),
          widths = unit(
            c(
              1,
              1,
              1
            ),
            "null"
          ),
          respect = TRUE
        )
      )
    )
    
    print(
      p1_no_legend,
      vp = viewport(
        layout.pos.row = 1,
        layout.pos.col = 1
      )
    )
    
    print(
      p2_no_legend,
      vp = viewport(
        layout.pos.row = 1,
        layout.pos.col = 2
      )
    )
    
    print(
      p3_no_legend,
      vp = viewport(
        layout.pos.row = 1,
        layout.pos.col = 3
      )
    )
    
    pushViewport(
      viewport(
        layout.pos.row = 3,
        layout.pos.col = 1:3
      )
    )
    
    grid.draw(
      legend
    )
    
    popViewport()
  }
  
  device_height <- height + 0.35
  
  if (capabilities("cairo")) {
    grDevices::cairo_pdf(
      filename = pdf_file,
      width = width,
      height = device_height,
      bg = "white"
    )
  } else {
    grDevices::pdf(
      file = pdf_file,
      width = width,
      height = device_height,
      useDingbats = FALSE,
      bg = "white"
    )
  }
  
  draw_three()
  grDevices::dev.off()
  
  grDevices::png(
    filename = png_file,
    width = width,
    height = device_height,
    units = "in",
    res = 600,
    bg = "white"
  )
  
  draw_three()
  grDevices::dev.off()
}

############################################################
# 16. Generate separate figures
############################################################

p_all <- build_plot(
  anchor_dt,
  "allvariants",
  show_legend = TRUE
)

p_common <- build_plot(
  anchor_dt,
  "common",
  show_legend = TRUE
)

p_rare <- build_plot(
  anchor_dt,
  "rare",
  show_legend = TRUE
)

if (!is.null(p_all)) {
  save_plot_pdf_png(
    p_all,
    file.path(
      OUT_DIR,
      paste0(
        "Fig_",
        PREFIX,
        "_allvariants_single_vs_multi_smooth"
      )
    )
  )
}

if (!is.null(p_common)) {
  save_plot_pdf_png(
    p_common,
    file.path(
      OUT_DIR,
      paste0(
        "Fig_",
        PREFIX,
        "_common_single_vs_multi_smooth"
      )
    )
  )
}

if (!is.null(p_rare)) {
  save_plot_pdf_png(
    p_rare,
    file.path(
      OUT_DIR,
      paste0(
        "Fig_",
        PREFIX,
        "_rare_single_vs_multi_smooth"
      )
    )
  )
}

############################################################
# 17. Generate grouped all/common/rare figure
############################################################

p_all_g <- build_plot(
  anchor_dt,
  "allvariants",
  show_legend = FALSE,
  title_prefix = "a"
)

p_common_g <- build_plot(
  anchor_dt,
  "common",
  show_legend = FALSE,
  title_prefix = "b"
)

p_rare_g <- build_plot(
  anchor_dt,
  "rare",
  show_legend = TRUE,
  title_prefix = "c"
)

if (
  !is.null(p_all_g) &&
  !is.null(p_common_g) &&
  !is.null(p_rare_g)
) {
  save_combined_three(
    p_all_g,
    p_common_g,
    p_rare_g,
    file.path(
      OUT_DIR,
      paste0(
        "Fig_",
        PREFIX,
        "_all_common_rare_grouped_smooth"
      )
    )
  )
}

############################################################
# 18. Final console summary
############################################################

message("")
message("============================================================")
message("[DONE] Original-variant-set FPR 5K analysis completed")
message("[INFO] Previous simulations : loops 1-1000")
message("[INFO] Added simulations    : loops 1001-5000")
message("[INFO] Total simulations    : 5000 per dataset")
message("[INFO] 5K merged files:")
message(MERGED5K_DIR)
message("[INFO] Statistical tables and figures:")
message(OUT_DIR)
message("")
message("[INFO] Fixed P thresholds:")
message("       1e-7, 5e-8, 1e-8, 1e-9, 1e-10")
message("[INFO] Empirical threshold definition:")
message("       type=7 5% quantile of the 5,000 minimum-P values")
message("============================================================")
message("")

print(
  merge_qc
)

message("")
message("[5K FPR at fixed thresholds]")
print(
  fixed_point_dt[
    ,
    .(
      variant_type,
      method,
      n_total,
      P_threshold,
      n_false_positive,
      FPR = proportion,
      FPR_percent = percent
    )
  ]
)

message("")
message("[Empirical P thresholds at FPR = 0.05]")
print(
  y005_dt[
    ,
    .(
      variant_type,
      method,
      n_total,
      P_at_FPR005 = P_threshold,
      neglog10P_at_FPR005 = neglog10P,
      observed_prop_strict_lt,
      observed_percent_strict_lt
    )
  ]
)


































############################################################
# Rare variants: MAF_diff <= 0.001
# Based on 5,000 GWAS simulations
#
# Single-ancestry vs Multi-ancestry
# GWAS significance: lead_P < 5e-8
############################################################

rm(list = ls())
gc()

suppressPackageStartupMessages({
  library(data.table)
})

############################################################
# 1. Input files
############################################################

BASE <- paste0(
  "C:/Users/ASUS/Desktop/GWAS/gwas/模拟3/",
  "results/new_results/real_final_plot/_prepared_5000"
)

FILES <- c(
  "Single-ancestry" = file.path(
    BASE, "rare_EUR_5k.txt"
  ),
  "Multi-ancestry" = file.path(
    BASE, "rare_pooled_5k.txt"
  )
)

P_THRESHOLD <- 5e-8
MAF_THRESHOLD <- 0.001
EXPECTED_LOOPS <- 1:5000

############################################################
# 2. Read and validate
############################################################

read_data <- function(file, method) {
  
  if (!file.exists(file)) {
    stop("Input file not found: ", file)
  }
  
  dt <- fread(file)
  
  required <- c(
    "loop", "lead_P", "lead_SNP", "MAF_diff"
  )
  
  missing <- setdiff(required, names(dt))
  
  if (length(missing) > 0) {
    stop(
      "Missing columns: ",
      paste(missing, collapse = ", "),
      "\nFile: ", file
    )
  }
  
  dt[, loop := as.integer(loop)]
  dt[, lead_P := as.numeric(lead_P)]
  dt[, MAF_diff := as.numeric(MAF_diff)]
  dt[, lead_SNP := as.character(lead_SNP)]
  
  # Require exactly 5000 simulations
  if (
    nrow(dt) != 5000L ||
    !identical(
      sort(dt$loop),
      EXPECTED_LOOPS
    )
  ) {
    stop(
      method,
      ": Expected exactly loops 1-5000, ",
      "one row per loop.\n",
      "Observed rows: ", nrow(dt),
      "\nUnique loops: ", uniqueN(dt$loop)
    )
  }
  
  return(dt)
}

############################################################
# 3. Calculate exact cumulative proportion
############################################################

results <- list()

for (method in names(FILES)) {
  
  dt <- read_data(
    FILES[[method]],
    method
  )
  
  # Match original GWAS significance filter
  sig <- dt[
    !is.na(lead_P) &
      lead_P < P_THRESHOLD &
      !is.na(lead_SNP) &
      !lead_SNP %in% c(
        "", ".", "NA", "NO_VALID_SNP"
      )
  ]
  
  denominator <- nrow(sig)
  
  # Missing MAF_diff is counted as non-matching
  n_matched <- sum(
    !is.na(sig$MAF_diff) &
      sig$MAF_diff <= MAF_THRESHOLD
  )
  
  results[[method]] <- data.table(
    Method = method,
    Total_simulations = nrow(dt),
    Significant_associations = denominator,
    Missing_MAF_diff = sum(is.na(sig$MAF_diff)),
    MAF_threshold = MAF_THRESHOLD,
    Matched_count = n_matched,
    Matched_percent = if (denominator > 0) {
      n_matched / denominator * 100
    } else {
      NA_real_
    }
  )
}

result_dt <- rbindlist(results)

############################################################
# 4. Print results
############################################################

cat("\n")
cat("====================================================\n")
cat("Rare variants: MAF_diff <= 0.001\n")
cat("Total simulations: 5000\n")
cat("GWAS threshold: lead_P < 5e-8\n")
cat("====================================================\n\n")

print(result_dt)

cat("\n")
cat("Manuscript-ready values:\n\n")

for (i in seq_len(nrow(result_dt))) {
  
  cat(
    result_dt$Method[i],
    ": ",
    sprintf("%.2f%%", result_dt$Matched_percent[i]),
    " (",
    result_dt$Matched_count[i],
    "/",
    result_dt$Significant_associations[i],
    ")\n",
    sep = ""
  )
}

cat("\n")

single <- result_dt[
  Method == "Single-ancestry",
  Matched_percent
]

multi <- result_dt[
  Method == "Multi-ancestry",
  Matched_percent
]

cat(
  "Manuscript replacement:\n",
  sprintf("%.1f%%", single),
  " to ",
  sprintf("%.1f%%", multi),
  "\n",
  sep = ""
)

cat("====================================================\n")



































#!/usr/bin/env Rscript

rm(list = ls())
graphics.off()
gc()

suppressPackageStartupMessages({
  library(data.table)
  library(ggplot2)
  library(grid)
})

############################################################
# SuSiE vs SuSiEx, L=10, common variants
# Previous 2K + added 3K = 5K simulations
# PIP threshold = 0.95
# Panel e = boxplot
############################################################

BASE_DIR <- "C:/Users/ASUS/Desktop/GWAS/gwas/模拟3/new_EUR/susie_final/L为10"

SUSIE_OLD   <- file.path(BASE_DIR, "common_EUR_susie_summary.merged.with_ld_r2.txt")
SUSIEX_OLD  <- file.path(BASE_DIR, "common_susiex_summary.merged.with_ld_r2.txt")
SUSIE_ADD3K <- file.path(BASE_DIR, "susie_merged.txt")
SUSIEX_ADD3K<- file.path(BASE_DIR, "susiex_merged.txt")

MERGED_DIR <- file.path(BASE_DIR, "merged_5k")
dir.create(MERGED_DIR, recursive = TRUE, showWarnings = FALSE)

SUSIE_5K  <- file.path(MERGED_DIR, "common_EUR_susie_summary.merged5k.with_ld_r2.txt")
SUSIEX_5K <- file.path(MERGED_DIR, "common_susiex_summary.merged5k.with_ld_r2.txt")

OUT_DIR <- "C:/Users/ASUS/Desktop/GWAS/gwas/模拟3/results/new_results/real_final_plot/SuSiE_SuSiEx_N5000_PIPgt0.95_6panel"
dir.create(OUT_DIR, recursive = TRUE, showWarnings = FALSE)

EXPECTED_OLD_N <- 2000L
EXPECTED_ADD_N <- 3000L
EXPECTED_N_SIM <- 5000L

PIP_THRESHOLD <- 0.950
CS_EQUAL_TOL <- 1e-12
PIP_EQUAL_TOL <- 1e-12

BP_BREAKS <- seq(0, 100000, length.out = 21)
MAF_BREAKS <- seq(0, 0.05, length.out = 21)
LD_BREAKS <- seq(1, 0, by = -0.05)

FM_Y_LIMITS <- c(95, 100)
FM_Y_BREAKS <- 95:100

METHOD_LEVELS <- c("single-ancestry", "multi-ancestry")
COL_METHOD <- c("single-ancestry"="#1F4E79", "multi-ancestry"="#E69F00")
SHAPE_METHOD <- c("single-ancestry"=21, "multi-ancestry"=24)
FILL_METHOD <- c("single-ancestry"="#1F4E79", "multi-ancestry"="white")

REQUIRED_COLS <- c(
  "loop","method","variant_type","fine_mapped_SNP","fine_mapped_CHR",
  "fine_mapped_BP","fine_mapped_MAF","pip_max","causal_SNP","causal_CHR",
  "causal_BP","causal_MAF","BP_diff","MAF_diff","exact_match",
  "mean_cs_size","n_cs","cs_contains_causal","cs_size_list","run_status","ld_r2"
)

fatal <- function(...) stop(paste0(...), call. = FALSE)
as_num <- function(x) suppressWarnings(as.numeric(x))

as_binary <- function(x) {
  z <- tolower(trimws(as.character(x)))
  out <- rep(NA_integer_, length(z))
  out[z %in% c("1","true","t","yes","y")] <- 1L
  out[z %in% c("0","false","f","no","n")] <- 0L
  num <- suppressWarnings(as.numeric(z))
  idx <- is.na(out) & !is.na(num)
  out[idx] <- as.integer(num[idx] != 0)
  out
}

normalise_variant <- function(x) {
  z <- tolower(trimws(as.character(x)))
  out <- rep(NA_character_, length(z))
  out[grepl("common", z)] <- "common"
  out[grepl("rare", z)] <- "rare"
  out
}

read_stage <- function(file, first_loop, last_loop, expected_n, label) {
  if (!file.exists(file)) fatal("Missing input file:\n", file)
  
  dt <- fread(file, data.table=TRUE, check.names=FALSE, showProgress=FALSE)
  setnames(dt, trimws(names(dt)))
  
  miss <- setdiff(REQUIRED_COLS, names(dt))
  if (length(miss) > 0) {
    fatal(
      "Missing required columns in ", file, "\n",
      paste(miss, collapse=", ")
    )
  }
  
  dt[, loop := suppressWarnings(as.integer(loop))]
  
  if (nrow(dt) != expected_n)
    fatal(label, " rows=", nrow(dt), "; expected ", expected_n)
  
  if (anyNA(dt$loop))
    fatal(label, " contains missing/non-numeric loop IDs.")
  
  if (uniqueN(dt$loop) != expected_n)
    fatal(label, " does not contain ", expected_n, " unique loops.")
  
  expected <- seq.int(first_loop, last_loop)
  observed <- sort(dt$loop)
  
  if (!identical(observed, expected)) {
    miss_loop <- setdiff(expected, observed)
    extra_loop <- setdiff(observed, expected)
    fatal(
      label, " loop range mismatch.",
      "\nMissing: ", if(length(miss_loop)) paste(head(miss_loop,50),collapse=", ") else "none",
      "\nExtra: ", if(length(extra_loop)) paste(head(extra_loop,50),collapse=", ") else "none"
    )
  }
  
  setorder(dt, loop)
  message("[PASS] ", label, ": ", min(dt$loop), "-", max(dt$loop), ", N=", nrow(dt))
  dt
}

merge_method <- function(old_file, add_file, out_file, method_name, ancestry_name) {
  old <- read_stage(old_file, 1L, 2000L, EXPECTED_OLD_N, paste0(method_name," old2K"))
  add <- read_stage(add_file, 2001L, 5000L, EXPECTED_ADD_N, paste0(method_name," add3K"))
  
  dt <- rbindlist(list(old, add), use.names=TRUE, fill=TRUE)
  setorder(dt, loop)
  
  if (nrow(dt) != EXPECTED_N_SIM || uniqueN(dt$loop) != EXPECTED_N_SIM)
    fatal(method_name, " merged N is not 5000.")
  
  if (!identical(dt$loop, 1:5000))
    fatal(method_name, " merged loop IDs are not exactly 1-5000.")
  
  dt[, method := method_name]
  dt[, ancestry_type := ancestry_name]
  dt[, variant_type := normalise_variant(variant_type)]
  dt[is.na(variant_type) | variant_type=="", variant_type := "common"]
  
  if (any(dt$variant_type != "common"))
    fatal(method_name, " contains non-common rows.")
  
  dt[, fine_mapped_SNP := trimws(as.character(fine_mapped_SNP))]
  dt[, causal_SNP := trimws(as.character(causal_SNP))]
  
  for (cc in c(
    "fine_mapped_BP","fine_mapped_MAF","pip_max","causal_BP","causal_MAF",
    "BP_diff","MAF_diff","mean_cs_size","n_cs","ld_r2"
  )) dt[, (cc) := as_num(get(cc))]
  
  dt[, cs_contains_causal := as_binary(cs_contains_causal)]
  
  dt[
    !is.na(fine_mapped_SNP) & !is.na(causal_SNP) &
      fine_mapped_SNP!="" & causal_SNP!="" &
      fine_mapped_SNP==causal_SNP,
    ld_r2 := 1
  ]
  
  fwrite(dt, out_file, sep="\t", quote=FALSE, na="NA")
  message("[SAVED] ", out_file)
  dt
}

############################################################
# 1. Merge to N=5000
############################################################

susie <- merge_method(
  SUSIE_OLD, SUSIE_ADD3K, SUSIE_5K,
  "SuSiE", "single-ancestry"
)

susiex <- merge_method(
  SUSIEX_OLD, SUSIEX_ADD3K, SUSIEX_5K,
  "SuSiEx", "multi-ancestry"
)

############################################################
# 2. Cross-method QC
############################################################

qc_pair <- merge(
  susie[, .(loop, causal_SNP_susie=causal_SNP)],
  susiex[, .(loop, causal_SNP_susiex=causal_SNP)],
  by="loop", all=TRUE, sort=TRUE
)

if (nrow(qc_pair) != 5000L)
  fatal("SuSiE and SuSiEx do not contain identical loop sets.")

mismatch <- qc_pair[
  is.na(causal_SNP_susie) | is.na(causal_SNP_susiex) |
    causal_SNP_susie != causal_SNP_susiex
]

if (nrow(mismatch) > 0) {
  fwrite(mismatch, file.path(OUT_DIR,"ERROR_causal_SNP_mismatch_N5000.csv"))
  fatal("Causal SNP mismatch detected. See ERROR_causal_SNP_mismatch_N5000.csv")
}

fm_all <- rbindlist(list(susie, susiex), use.names=TRUE, fill=TRUE)
fm_all[, ancestry_type := factor(ancestry_type, levels=METHOD_LEVELS)]

count_check <- fm_all[, .(
  n_rows=.N,
  n_unique_loop=uniqueN(loop),
  n_pip_nonmissing=sum(is.finite(pip_max)),
  n_cs_membership_missing=sum(is.na(cs_contains_causal)),
  n_run_OK=sum(run_status=="OK", na.rm=TRUE),
  n_run_NO_CS=sum(run_status=="NO_CS", na.rm=TRUE)
), by=.(method, ancestry_type)]

fwrite(count_check, file.path(OUT_DIR,"CHECK_input_counts_N5000.csv"))

############################################################
# 3. Panels a-c: method-specific PIP > 0.95
############################################################

fm_high <- fm_all[is.finite(pip_max) & pip_max > PIP_THRESHOLD]

high_summary <- fm_all[, .(
  n_total=.N,
  n_PIPgt095=sum(is.finite(pip_max) & pip_max > PIP_THRESHOLD),
  percent_PIPgt095=sum(is.finite(pip_max) & pip_max > PIP_THRESHOLD)/.N*100
), by=.(method, ancestry_type)]

fwrite(high_summary, file.path(OUT_DIR,"FineMapping_PIPgt0.95_summary_N5000.csv"))

make_cum_le <- function(dt, metric, brks) {
  rbindlist(lapply(METHOD_LEVELS, function(mt) {
    x <- dt[ancestry_type==mt][[metric]]
    x <- x[is.finite(x)]
    denom <- length(x)
    cnt <- vapply(brks, function(th) sum(x<=th), integer(1))
    data.table(
      ancestry_type=mt, metric=metric, threshold=brks,
      denominator=denom, cumulative_count=cnt,
      cumulative_percent=if(denom>0) cnt/denom*100 else NA_real_
    )
  }))
}

make_cum_ge <- function(dt, metric, brks) {
  rbindlist(lapply(METHOD_LEVELS, function(mt) {
    x <- dt[ancestry_type==mt][[metric]]
    x <- x[is.finite(x)]
    denom <- length(x)
    cnt <- vapply(brks, function(th) sum(x>=th), integer(1))
    data.table(
      ancestry_type=mt, metric=metric, threshold=brks,
      denominator=denom, cumulative_count=cnt,
      cumulative_percent=if(denom>0) cnt/denom*100 else NA_real_
    )
  }))
}

maf_fm <- make_cum_le(fm_high, "MAF_diff", MAF_BREAKS)
bp_fm  <- make_cum_le(fm_high, "BP_diff", BP_BREAKS)
ld_fm  <- make_cum_ge(fm_high, "ld_r2", LD_BREAKS)

fwrite(maf_fm, file.path(OUT_DIR,"FineMapping_cumulative_MAF_diff_common_PIPgt0.95_N5000.csv"))
fwrite(bp_fm,  file.path(OUT_DIR,"FineMapping_cumulative_BP_diff_common_PIPgt0.95_N5000.csv"))
fwrite(ld_fm,  file.path(OUT_DIR,"FineMapping_cumulative_LD_r2_common_PIPgt0.95_N5000.csv"))

############################################################
# 4. Panel d: fine-mapping power, denominator ALL 5000
############################################################

power_summary <- fm_all[, .(
  n_total=.N,
  n_causal_in_95pct_CS=sum(cs_contains_causal==1L, na.rm=TRUE),
  n_cs_contains_causal_missing=sum(is.na(cs_contains_causal)),
  power_percent=sum(cs_contains_causal==1L, na.rm=TRUE)/.N*100
), by=.(method, ancestry_type)]

setorder(power_summary, ancestry_type)
fwrite(power_summary, file.path(OUT_DIR,"FineMapping_power_cs_contains_causal_N5000.csv"))

############################################################
# 5. Panel e: boxplot
#    PIP > 0.95 applied independently by method
############################################################

cs_long <- fm_all[
  is.finite(pip_max) & pip_max > PIP_THRESHOLD &
    is.finite(mean_cs_size) & mean_cs_size > 0,
  .(loop, ancestry_type, pip_max, cs_size=mean_cs_size)
]

cs_long[, ancestry_type := factor(ancestry_type, levels=METHOD_LEVELS)]

cs_summary <- cs_long[, .(
  n=.N,
  mean_cs_size=mean(cs_size),
  sd_cs_size=sd(cs_size),
  median_cs_size=median(cs_size),
  q25_cs_size=as.numeric(quantile(cs_size,0.25)),
  q75_cs_size=as.numeric(quantile(cs_size,0.75)),
  min_cs_size=min(cs_size),
  max_cs_size=max(cs_size),
  n_CS_gt_100=sum(cs_size>100),
  percent_CS_gt_100=mean(cs_size>100)*100
), by=ancestry_type]

fwrite(cs_long, file.path(OUT_DIR,"PanelE_CS_size_distribution_PIPgt0.95_N5000.csv"))
fwrite(cs_summary, file.path(OUT_DIR,"PanelE_CS_size_summary_PIPgt0.95_N5000.csv"))

############################################################
# 6. Panel f: paired both PIP > 0.95 + equal mean CS
############################################################

single_pair <- fm_high[
  ancestry_type=="single-ancestry",
  .(loop, pip_single=pip_max, cs_single=mean_cs_size)
]

multi_pair <- fm_high[
  ancestry_type=="multi-ancestry",
  .(loop, pip_multi=pip_max, cs_multi=mean_cs_size)
]

paired <- merge(single_pair, multi_pair, by="loop", all=FALSE, sort=TRUE)

paired <- paired[
  is.finite(pip_single) & is.finite(pip_multi) &
    pip_single>PIP_THRESHOLD & pip_multi>PIP_THRESHOLD &
    is.finite(cs_single) & is.finite(cs_multi) &
    cs_single>0 & cs_multi>0
]

fwrite(paired, file.path(OUT_DIR,"FineMapping_common_paired_both_PIPgt0.95_N5000.csv"))

pip_equal <- paired[abs(cs_single-cs_multi)<=CS_EQUAL_TOL]

if (nrow(pip_equal)==0)
  fatal("No equal-CS paired loops remain for panel f.")

pip_equal[, pip_diff_multi_minus_single := pip_multi-pip_single]
pip_equal[, higher_pip_method := fifelse(
  pip_diff_multi_minus_single>PIP_EQUAL_TOL, "multi-ancestry",
  fifelse(pip_diff_multi_minus_single< -PIP_EQUAL_TOL, "single-ancestry","equal")
)]

pip_equal_summary <- pip_equal[, .(
  n_equal_CS=.N,
  n_single_higher=sum(higher_pip_method=="single-ancestry"),
  n_multi_higher=sum(higher_pip_method=="multi-ancestry"),
  n_equal_PIP=sum(higher_pip_method=="equal"),
  percent_single_higher=mean(higher_pip_method=="single-ancestry")*100,
  percent_multi_higher=mean(higher_pip_method=="multi-ancestry")*100,
  percent_equal_PIP=mean(higher_pip_method=="equal")*100,
  mean_pip_single=mean(pip_single),
  mean_pip_multi=mean(pip_multi),
  median_pip_single=median(pip_single),
  median_pip_multi=median(pip_multi)
)]

fwrite(pip_equal, file.path(OUT_DIR,"FineMapping_common_equal_CS_PIPmax_input_PIPgt0.95_N5000.csv"))
fwrite(pip_equal_summary, file.path(OUT_DIR,"FineMapping_common_equal_CS_PIPmax_summary_PIPgt0.95_N5000.csv"))

############################################################
# 7. Plotting helpers
############################################################

axis_settings <- function(metric) {
  if (metric=="MAF_diff") return(list(
    xlab="MAF difference", transform=function(x)x,
    limits=c(0,0.05), breaks=seq(0,0.05,0.01)
  ))
  if (metric=="BP_diff") return(list(
    xlab="Distance (Kb)", transform=function(x)x/1000,
    limits=c(0,100), breaks=seq(0,100,20)
  ))
  if (metric=="ld_r2") return(list(
    xlab=expression(LD~"("*plain(r)^2*")"), transform=function(x)x,
    limits=c(0,1), breaks=seq(0,1,0.2)
  ))
  fatal("Unknown metric: ", metric)
}

gb_theme <- function(show_legend=TRUE) {
  th <- theme_classic(base_size=8, base_family="sans") +
    theme(
      aspect.ratio=1,
      axis.line=element_line(linewidth=0.35, colour="black"),
      axis.ticks=element_line(linewidth=0.35, colour="black"),
      axis.ticks.length=unit(1.6,"mm"),
      axis.title.x=element_text(size=11, colour="black", margin=margin(t=5)),
      axis.title.y=element_text(size=11, colour="black", margin=margin(r=6)),
      axis.text=element_text(size=9.5, colour="black"),
      plot.title=element_text(size=11.5, hjust=0.5, margin=margin(b=6)),
      plot.title.position="panel",
      plot.tag.position=c(0.002,0.9595),
      plot.tag=element_text(size=11.5, face="bold", hjust=0, vjust=1),
      legend.title=element_blank(),
      legend.text=element_text(size=9.5),
      legend.key.width=unit(0.78,"cm"),
      legend.key.height=unit(0.40,"cm"),
      panel.border=element_blank(),
      panel.background=element_blank(),
      plot.background=element_rect(fill="white", colour=NA),
      plot.margin=margin(16,10,8,20)
    )
  if (show_legend) {
    th <- th + theme(
      legend.position="bottom",
      legend.direction="horizontal",
      legend.justification="center",
      legend.box="horizontal",
      legend.box.spacing=unit(5.5,"pt")
    )
  } else {
    th <- th + theme(legend.position="none")
  }
  th
}

build_curve <- function(dt, metric, tag, show_legend=TRUE) {
  d <- copy(dt)
  ax <- axis_settings(metric)
  d[, x_plot := ax$transform(threshold)]
  d[, ancestry_type := factor(ancestry_type, levels=METHOD_LEVELS)]
  
  ggplot(d, aes(x=x_plot, y=cumulative_percent, colour=ancestry_type,
                fill=ancestry_type, shape=ancestry_type, group=ancestry_type)) +
    geom_line(linewidth=0.55, show.legend=TRUE, na.rm=TRUE) +
    geom_point(size=1.25, stroke=0.45, na.rm=TRUE) +
    scale_colour_manual(values=COL_METHOD, breaks=METHOD_LEVELS,
                        labels=c("Single-ancestry","Multi-ancestry"), drop=FALSE) +
    scale_fill_manual(values=FILL_METHOD, breaks=METHOD_LEVELS, guide="none", drop=FALSE) +
    scale_shape_manual(values=SHAPE_METHOD, breaks=METHOD_LEVELS, guide="none", drop=FALSE) +
    scale_x_continuous(limits=ax$limits, breaks=ax$breaks,
                       expand=expansion(mult=c(0,0.02))) +
    scale_y_continuous(breaks=FM_Y_BREAKS, expand=expansion(mult=c(0,0.04))) +
    coord_cartesian(ylim=FM_Y_LIMITS, clip="off") +
    labs(x=ax$xlab, y="Proportion (%)", title="\u00A0", tag=tag) +
    gb_theme(show_legend)
}

build_power <- function(d, tag="d") {
  d <- copy(d)
  d[, ancestry_type := factor(ancestry_type, levels=METHOD_LEVELS)]
  
  ggplot(d, aes(x=ancestry_type, y=power_percent, fill=ancestry_type)) +
    geom_col(width=0.50, colour="black", linewidth=0.35, alpha=0.88) +
    scale_fill_manual(values=COL_METHOD, guide="none") +
    scale_x_discrete(labels=c(
      "single-ancestry"="Single-ancestry",
      "multi-ancestry"="Multi-ancestry"
    )) +
    scale_y_continuous(limits=c(0,100), breaks=seq(0,100,20),
                       expand=expansion(mult=c(0,0.03))) +
    labs(x=NULL, y="Power (%)", title="\u00A0", tag=tag) +
    gb_theme(FALSE)
}

build_cs_boxplot <- function(d, tag="e") {
  d <- copy(d)
  d[, ancestry_type := factor(ancestry_type, levels=METHOD_LEVELS)]
  
  ggplot(d, aes(x=ancestry_type, y=cs_size, fill=ancestry_type)) +
    geom_boxplot(
      width=0.46,
      colour="black",
      linewidth=0.40,
      alpha=0.78,
      outlier.shape=16,
      outlier.size=0.8,
      outlier.alpha=0.32,
      show.legend=FALSE
    ) +
    scale_fill_manual(values=COL_METHOD, guide="none") +
    scale_x_discrete(labels=c(
      "single-ancestry"="Single-ancestry",
      "multi-ancestry"="Multi-ancestry"
    )) +
    scale_y_continuous(
      breaks=seq(0,100,20),
      expand=expansion(mult=c(0,0.02))
    ) +
    coord_cartesian(ylim=c(0,100), clip="on") +
    labs(x=NULL, y="Credible set size", title="\u00A0", tag=tag) +
    gb_theme(FALSE)
}

build_pip_scatter <- function(d, tag="f") {
  d <- copy(d)
  d[, region := fifelse(
    pip_multi > pip_single + PIP_EQUAL_TOL, "multi-ancestry",
    fifelse(pip_multi < pip_single - PIP_EQUAL_TOL, "single-ancestry","equal")
  )]
  
  low <- max(PIP_THRESHOLD, floor(min(c(d$pip_single,d$pip_multi))*100)/100)
  
  ggplot() +
    geom_abline(intercept=0, slope=1, linetype="dashed",
                linewidth=0.45, colour="grey45") +
    geom_point(
      data=d[region=="equal"],
      aes(x=pip_single,y=pip_multi),
      shape=16,size=1.45,colour="grey60",alpha=0.85
    ) +
    geom_point(
      data=d[region!="equal"],
      aes(x=pip_single,y=pip_multi,colour=region),
      shape=16,size=1.55,alpha=0.950
    ) +
    scale_colour_manual(values=COL_METHOD, guide="none") +
    scale_x_continuous(limits=c(low,1), breaks=pretty(c(low,1),n=5)) +
    scale_y_continuous(limits=c(low,1), breaks=pretty(c(low,1),n=5)) +
    coord_fixed(ratio=1, clip="off") +
    labs(
      x="Max PIP in single-ancestry",
      y="Max PIP in multi-ancestry",
      title="\u00A0",
      tag=tag
    ) +
    gb_theme(FALSE)
}

############################################################
# 8. Build panels
############################################################

p_a <- build_curve(maf_fm, "MAF_diff", "a", FALSE)
p_b <- build_curve(bp_fm,  "BP_diff",  "b", FALSE)
p_c <- build_curve(ld_fm,  "ld_r2",    "c", TRUE)
p_d <- build_power(power_summary, "d")
p_e <- build_cs_boxplot(cs_long, "e")
p_f <- build_pip_scatter(pip_equal, "f")

############################################################
# 9. Save helpers
############################################################

save_one <- function(p, prefix, w=5, h=5) {
  pdf(paste0(prefix,".pdf"), width=w, height=h, useDingbats=FALSE, bg="white")
  print(p)
  dev.off()
  
  png(paste0(prefix,".png"), width=w, height=h, units="in", res=600, bg="white")
  print(p)
  dev.off()
}

get_legend <- function(p) {
  g <- ggplotGrob(p + theme(legend.position="bottom"))
  idx <- which(grepl("^guide-box", g$layout$name))
  valid <- idx[!vapply(g$grobs[idx], inherits, logical(1), what="zeroGrob")]
  if (!length(valid)) return(grid::nullGrob())
  g$grobs[[valid[1]]]
}

save_six <- function(p1,p2,p3,p4,p5,p6,prefix,w=13.2,h=10) {
  legend <- get_legend(p3)
  plots <- lapply(list(p1,p2,p3,p4,p5,p6), function(p) {
    p + theme(legend.position="none", aspect.ratio=1, plot.margin=margin(16,10,0,20))
  })
  
  draw <- function() {
    grid.newpage()
    pushViewport(viewport(layout=grid.layout(
      nrow=4,ncol=3,
      heights=unit.c(unit(c(1,1),"null"),unit(5.5,"pt"),grobHeight(legend)),
      widths=unit(c(1,1,1),"null"),
      respect=TRUE
    )))
    print(plots[[1]], vp=viewport(layout.pos.row=1,layout.pos.col=1))
    print(plots[[2]], vp=viewport(layout.pos.row=1,layout.pos.col=2))
    print(plots[[3]], vp=viewport(layout.pos.row=1,layout.pos.col=3))
    print(plots[[4]], vp=viewport(layout.pos.row=2,layout.pos.col=1))
    print(plots[[5]], vp=viewport(layout.pos.row=2,layout.pos.col=2))
    print(plots[[6]], vp=viewport(layout.pos.row=2,layout.pos.col=3))
    pushViewport(viewport(layout.pos.row=4,layout.pos.col=1:3))
    grid.draw(legend)
    popViewport()
    popViewport()
  }
  
  pdf(paste0(prefix,".pdf"), width=w, height=h, useDingbats=FALSE, bg="white")
  draw()
  dev.off()
  
  png(paste0(prefix,".png"), width=w, height=h, units="in", res=600, bg="white")
  draw()
  dev.off()
}

############################################################
# 10. Save individual panels and grouped figure
############################################################

save_one(p_a + theme(legend.position="bottom"),
         file.path(OUT_DIR,"PanelA_MAF_difference_common_PIPgt0.95_N5000"))
save_one(p_b + theme(legend.position="bottom"),
         file.path(OUT_DIR,"PanelB_Distance_common_PIPgt0.95_N5000"))
save_one(p_c,
         file.path(OUT_DIR,"PanelC_LD_r2_common_PIPgt0.95_N5000"))
save_one(p_d,
         file.path(OUT_DIR,"PanelD_FineMapping_power_common_N5000"))
save_one(p_e,
         file.path(OUT_DIR,"PanelE_Credible_set_size_BOXPlot_common_PIPgt0.95_N5000"))
save_one(p_f,
         file.path(OUT_DIR,"PanelF_Equal_CS_PIPmax_common_PIPgt0.95_N5000"))

save_six(
  p_a,p_b,p_c,p_d,p_e,p_f,
  file.path(OUT_DIR,"FineMapping_common_SuSiE_vs_SuSiEx_summary_6panel_PIPgt0.95_N5000")
)

############################################################
# 11. Console report
############################################################

cat("\n============================================================\n")
cat("N=5000 SuSiE vs SuSiEx analysis finished\n")
cat("============================================================\n")
cat("Previous simulations : loops 1-2000\n")
cat("Added simulations    : loops 2001-5000\n")
cat("Total per method     : 5000\n")
cat("PIP filter           : pip_max > 0.95\n")
cat("Panel d denominator  : all 5000 simulations\n")
cat("Panel e              : boxplot; PIP > 0.95 independently by method\n")
cat("Panel f              : paired both-PIP > 0.95 + equal mean CS size\n")
cat("Merged SuSiE file    :", SUSIE_5K, "\n")
cat("Merged SuSiEx file   :", SUSIEX_5K, "\n")
cat("Output directory     :", OUT_DIR, "\n")
cat("============================================================\n\n")

print(count_check)
print(high_summary)
print(power_summary)
print(cs_summary)
print(pip_equal_summary)


























#!/usr/bin/env Rscript

############################################################
# FPR + matched-variant-size FPR | unified 5K analysis/plotting
#
# Goal
# ----
# 1. Plot the original-variant-set FPR.
# 2. Plot the matched-variant-size FPR.
# 3. Use ONE shared plotting system for BOTH analyses so that
#    font sizes, colours, shapes, line widths, margins, figure
#    dimensions, legend format and point-line gaps are identical.
#
# FPR input
# ---------
# Original variant-set minimum-P files:
#   new_pooled/add4k_fpr/origin/merged_5k/allvariants_EUR_minP_1_5000.txt
#   new_pooled/add4k_fpr/origin/merged_5k/common_EUR_minP_1_5000.txt
#   new_pooled/add4k_fpr/origin/merged_5k/rare_EUR_minP_1_5000.txt
#   new_pooled/add4k_fpr/origin/merged_5k/pooled_allvar_minP_1_5000.txt
#   new_pooled/add4k_fpr/origin/merged_5k/pooled_common_minP_1_5000.txt
#   new_pooled/add4k_fpr/origin/merged_5k/pooled_rare_minP_1_5000.txt
#
# matched FPR input
# -----------------
# Original 1K + added 4K = full 5K for each method/variant group.
#
# Shared statistical definition
# -----------------------------
# Genome-wide false-positive rate =
#   proportion of null simulations with minimum P < threshold.
#
# Fixed displayed thresholds:
#   1e-7, 5e-8, 1e-8, 1e-9, 1e-10
#
# Additional displayed anchors:
#   empirical P threshold where each method reaches FPR = 0.05
#   plus cross-evaluation of the other method at that threshold.
#
# Shared plotting parameters are taken from the FPR section of
# the reference script:
#   individual figure: 4.0 x 5.0 inches
#   three-panel figure: 11.8 x 5.35 inches
#   axis title: 11 pt
#   axis text: 9.5 pt
#   panel title/tag: 11.5 pt
#   legend text: 9.5 pt
#   point size: 1.25
#   point stroke: 0.45
#   legend point size: 1.45
#   line width: 0.55
#   point-line gap: 0.027 NPC
#   PNG: 600 dpi
############################################################


rm(list = ls())
graphics.off()
gc()

suppressPackageStartupMessages({
  library(data.table)
  library(ggplot2)
  library(grid)
})


############################################################
# 1. Root directories
############################################################

ROOT <- "C:/Users/ASUS/Desktop/GWAS/gwas/模拟3"

EUR_DIR <- file.path(
  ROOT,
  "new_EUR"
)

POOLED_DIR <- file.path(
  ROOT,
  "new_pooled"
)

MATCH_DIR <- file.path(
  ROOT,
  "match_varsize_FPR"
)

MATCH_ADD4K_DIR <- file.path(
  MATCH_DIR,
  "add_4k"
)

OUT_DIR <- file.path(
  ROOT,
  "results/new_results/real_final_plot"
)

dir.create(
  OUT_DIR,
  recursive = TRUE,
  showWarnings = FALSE
)

MATCH_MERGED_DIR <- file.path(
  OUT_DIR,
  "_match_var_FPR_merged_5k"
)

dir.create(
  MATCH_MERGED_DIR,
  recursive = TRUE,
  showWarnings = FALSE
)


############################################################
# 2. Original-variant-set FPR files
############################################################

FPR_FILES <- list(
  
  allvariants = c(
    "single-ancestry" = "C:/Users/ASUS/Desktop/GWAS/gwas/模拟3/new_pooled/add4k_fpr/origin/merged_5k/allvariants_EUR_minP_1_5000.txt",
    "multi-ancestry" = "C:/Users/ASUS/Desktop/GWAS/gwas/模拟3/new_pooled/add4k_fpr/origin/merged_5k/pooled_allvar_minP_1_5000.txt"
  ),
  
  common = c(
    "single-ancestry" = "C:/Users/ASUS/Desktop/GWAS/gwas/模拟3/new_pooled/add4k_fpr/origin/merged_5k/common_EUR_minP_1_5000.txt",
    "multi-ancestry" = "C:/Users/ASUS/Desktop/GWAS/gwas/模拟3/new_pooled/add4k_fpr/origin/merged_5k/pooled_common_minP_1_5000.txt"
  ),
  
  rare = c(
    "single-ancestry" = "C:/Users/ASUS/Desktop/GWAS/gwas/模拟3/new_pooled/add4k_fpr/origin/merged_5k/rare_EUR_minP_1_5000.txt",
    "multi-ancestry" = "C:/Users/ASUS/Desktop/GWAS/gwas/模拟3/new_pooled/add4k_fpr/origin/merged_5k/pooled_rare_minP_1_5000.txt"
  )
)


############################################################
# 3. Matched-variant-size FPR files
#
# original 1K:
#   *.merged.txt
#
# added 4K:
#   add_4k/*_merged.txt
############################################################

MATCH_FILES <- list(
  
  allvariants = list(
    
    "single-ancestry" = list(
      old = file.path(
        MATCH_DIR,
        "EUR10K_allvariants_minP.merged.txt"
      ),
      add4k = file.path(
        MATCH_ADD4K_DIR,
        "EUR10K_allvariants_minP_merged.txt"
      )
    ),
    
    "multi-ancestry" = list(
      old = file.path(
        MATCH_DIR,
        "pooled_allvariants_minP.merged.txt"
      ),
      add4k = file.path(
        MATCH_ADD4K_DIR,
        "pooled_allvariants_minP_merged.txt"
      )
    )
  ),
  
  common = list(
    
    "single-ancestry" = list(
      old = file.path(
        MATCH_DIR,
        "EUR10K_common_minP.merged.txt"
      ),
      add4k = file.path(
        MATCH_ADD4K_DIR,
        "EUR10K_common_minP_merged.txt"
      )
    ),
    
    "multi-ancestry" = list(
      old = file.path(
        MATCH_DIR,
        "pooled_common_minP.merged.txt"
      ),
      add4k = file.path(
        MATCH_ADD4K_DIR,
        "pooled_common_minP_merged.txt"
      )
    )
  ),
  
  rare = list(
    
    "single-ancestry" = list(
      old = file.path(
        MATCH_DIR,
        "EUR10K_rare_minP.merged.txt"
      ),
      add4k = file.path(
        MATCH_ADD4K_DIR,
        "EUR10K_rare_minP_merged.txt"
      )
    ),
    
    "multi-ancestry" = list(
      old = file.path(
        MATCH_DIR,
        "pooled_rare_minP.merged.txt"
      ),
      add4k = file.path(
        MATCH_ADD4K_DIR,
        "pooled_rare_minP_merged.txt"
      )
    )
  )
)


############################################################
# 4. Simulation/statistical settings
############################################################

N_OLD <- 1000L
N_ADD <- 4000L
N_MATCH_TOTAL <- 5000L

# Original FPR files are expected to contain 5K simulations.
# Keep this TRUE for strict consistency with the current 5K analysis.
STRICT_FPR_N5000 <- TRUE
EXPECTED_FPR_N <- 5000L

REF_Y <- 0.05

MARKER_P_FIXED <- c(
  1e-7,
  5e-8,
  1e-8,
  1e-9,
  1e-10
)

MARKER_X_FIXED <- -log10(
  MARKER_P_FIXED
)

X_MIN <- 7
X_MAX <- 10

X_BREAKS <- c(
  7,
  8,
  9,
  10
)

SMOOTH_N <- 1201


############################################################
# 5. ONE shared plotting specification for FPR + match_FPR
#
# These parameters are used by every single figure.
############################################################

METHODS <- c(
  "single-ancestry",
  "multi-ancestry"
)

COL_SINGLE <- "#1F4E79"
COL_MULTI <- "#E69F00"

COL_MAIN <- c(
  "single-ancestry" = COL_SINGLE,
  "multi-ancestry" = COL_MULTI
)

SHAPE_MAIN <- c(
  "single-ancestry" = 21,
  "multi-ancestry" = 24
)

FILL_MAIN <- c(
  "single-ancestry" = COL_SINGLE,
  "multi-ancestry" = "white"
)

POINT_SIZE <- 1.25
POINT_STROKE <- 0.45
LEGEND_POINT_SIZE <- 1.45
LEGEND_LINE_WIDTH <- 0.55

FIXED_POINT_LINE_GAP_NPC <- 0.027

REF_LINE_COLOUR <- "#D62728"

# Exact dimensions from the FPR plotting section.
SINGLE_WIDTH <- 4.0
SINGLE_HEIGHT <- 5.0

GROUP_WIDTH <- 11.8
GROUP_BASE_HEIGHT <- 5.0
GROUP_EXTRA_HEIGHT <- 0.35
GROUP_DEVICE_HEIGHT <- GROUP_BASE_HEIGHT + GROUP_EXTRA_HEIGHT

PNG_DPI <- 600


############################################################
# 6. Y-scale policy
#
# To make FPR and match_FPR directly comparable, the same
# variant type uses the same y-axis maximum in both analyses.
#
# Example:
#   original common FPR and matched common FPR -> same y-axis
#
# The maximum is determined from BOTH analyses at x = 7 and
# rounded upward exactly as in the previous FPR plotting code.
############################################################

USE_SHARED_Y_BY_VARIANT <- TRUE


############################################################
# 7. Generic helpers
############################################################

fatal <- function(...) {
  stop(
    paste0(...),
    call. = FALSE
  )
}


panel_title <- function(
    variant_type
) {
  
  switch(
    variant_type,
    allvariants = "all variants",
    common = "common (MAF > 0.01)",
    rare = "rare (MAF \u2264 0.01)",
    variant_type
  )
}


detect_p_col <- function(
    dt,
    file
) {
  
  candidates <- c(
    "lead_P",
    "lead_p",
    "min_P",
    "minP",
    "P",
    "p"
  )
  
  hit <- candidates[
    candidates %in% names(
      dt
    )
  ]
  
  if (
    length(
      hit
    ) == 0
  ) {
    
    fatal(
      "Cannot find a P-value column in:\n",
      file,
      "\nCurrent columns: ",
      paste(
        names(
          dt
        ),
        collapse = ", "
      )
    )
  }
  
  hit[1]
}


validate_p <- function(
    p,
    label
) {
  
  bad <- (
    !is.finite(
      p
    ) |
      p <= 0 |
      p > 1
  )
  
  if (
    any(
      bad
    )
  ) {
    
    fatal(
      label,
      ": ",
      sum(
        bad
      ),
      " invalid P values were detected."
    )
  }
  
  invisible(
    TRUE
  )
}


############################################################
# 8. Read original FPR file
############################################################

read_original_fpr <- function(
    file,
    variant_type,
    method
) {
  
  if (
    !file.exists(
      file
    )
  ) {
    fatal(
      "Original FPR input file not found:\n",
      file
    )
  }
  
  dt <- fread(
    file,
    data.table = TRUE,
    check.names = FALSE,
    showProgress = FALSE
  )
  
  setnames(
    dt,
    trimws(
      names(
        dt
      )
    )
  )
  
  p_col <- detect_p_col(
    dt,
    file
  )
  
  p <- suppressWarnings(
    as.numeric(
      dt[[
        p_col
      ]]
    )
  )
  
  validate_p(
    p,
    paste(
      "FPR",
      variant_type,
      method
    )
  )
  
  if (
    STRICT_FPR_N5000 &&
    length(
      p
    ) != EXPECTED_FPR_N
  ) {
    
    fatal(
      "FPR ",
      variant_type,
      " / ",
      method,
      ": expected ",
      EXPECTED_FPR_N,
      " simulations but observed ",
      length(
        p
      ),
      ".\nFile: ",
      file
    )
  }
  
  data.table(
    dataset_type = "FPR",
    variant_type = variant_type,
    method = method,
    loop = seq_along(
      p
    ),
    lead_P = p,
    source_file = file
  )
}


############################################################
# 9. Read one matched-FPR batch
############################################################

read_match_batch <- function(
    file,
    expected_n,
    batch_label
) {
  
  if (
    !file.exists(
      file
    )
  ) {
    fatal(
      "Matched-FPR input file not found:\n",
      file
    )
  }
  
  dt <- fread(
    file,
    data.table = TRUE,
    check.names = FALSE,
    showProgress = FALSE
  )
  
  setnames(
    dt,
    trimws(
      names(
        dt
      )
    )
  )
  
  if (
    !"loop" %in% names(
      dt
    )
  ) {
    fatal(
      "Missing loop column in:\n",
      file
    )
  }
  
  p_col <- detect_p_col(
    dt,
    file
  )
  
  dt[
    ,
    loop := suppressWarnings(
      as.integer(
        loop
      )
    )
  ]
  
  if (
    anyNA(
      dt$loop
    )
  ) {
    fatal(
      batch_label,
      ": invalid loop IDs."
    )
  }
  
  if (
    nrow(
      dt
    ) != expected_n ||
    uniqueN(
      dt$loop
    ) != expected_n
  ) {
    
    fatal(
      batch_label,
      ": expected ",
      expected_n,
      " rows and ",
      expected_n,
      " unique loops, but observed ",
      nrow(
        dt
      ),
      " rows and ",
      uniqueN(
        dt$loop
      ),
      " unique loops."
    )
  }
  
  dt[
    ,
    lead_P_standardised := suppressWarnings(
      as.numeric(
        get(
          p_col
        )
      )
    )
  ]
  
  validate_p(
    dt$lead_P_standardised,
    batch_label
  )
  
  dt[
    ,
    source_loop := loop
  ]
  
  dt[
    ,
    source_batch := batch_label
  ]
  
  message(
    "[PASS] ",
    batch_label,
    " | N=",
    nrow(
      dt
    ),
    " | loops ",
    min(
      dt$loop
    ),
    "-",
    max(
      dt$loop
    )
  )
  
  dt[]
}


############################################################
# 10. Merge matched-FPR original 1K + added 4K
############################################################

merge_match_5k <- function(
    old_file,
    add4k_file,
    variant_type,
    method
) {
  
  label_base <- paste(
    "match_FPR",
    variant_type,
    method
  )
  
  old <- read_match_batch(
    old_file,
    expected_n = N_OLD,
    batch_label = paste0(
      label_base,
      " original1K"
    )
  )
  
  add <- read_match_batch(
    add4k_file,
    expected_n = N_ADD,
    batch_label = paste0(
      label_base,
      " add4K"
    )
  )
  
  old_ids <- sort(
    unique(
      old$loop
    )
  )
  
  if (
    !identical(
      old_ids,
      1:1000
    )
  ) {
    fatal(
      label_base,
      ": original 1K loop IDs must be exactly 1-1000."
    )
  }
  
  add_ids <- sort(
    unique(
      add$loop
    )
  )
  
  if (
    identical(
      add_ids,
      1001:5000
    )
  ) {
    
    message(
      "[INFO] ",
      label_base,
      " add4K already uses loops 1001-5000."
    )
    
  } else if (
    identical(
      add_ids,
      1:4000
    )
  ) {
    
    message(
      "[INFO] ",
      label_base,
      " add4K uses local loops 1-4000; reindexing to 1001-5000."
    )
    
    add[
      ,
      loop := loop + 1000L
    ]
    
  } else {
    
    fatal(
      label_base,
      ": add4K loop numbering must be either 1-4000 or 1001-5000.\n",
      "Observed min/max: ",
      min(
        add_ids
      ),
      "/",
      max(
        add_ids
      )
    )
  }
  
  merged <- rbindlist(
    list(
      old,
      add
    ),
    use.names = TRUE,
    fill = TRUE
  )
  
  setorder(
    merged,
    loop
  )
  
  if (
    nrow(
      merged
    ) != N_MATCH_TOTAL ||
    uniqueN(
      merged$loop
    ) != N_MATCH_TOTAL ||
    !identical(
      merged$loop,
      1:5000
    )
  ) {
    
    fatal(
      label_base,
      ": final matched-FPR N=5000 QC failed."
    )
  }
  
  merged[
    ,
    dataset_type := "match_FPR"
  ]
  
  merged[
    ,
    variant_type := variant_type
  ]
  
  merged[
    ,
    method := method
  ]
  
  merged[
    ,
    lead_P := lead_P_standardised
  ]
  
  method_file_label <- if (
    method == "single-ancestry"
  ) {
    "EUR10K"
  } else {
    "pooled"
  }
  
  merged_file <- file.path(
    MATCH_MERGED_DIR,
    paste0(
      method_file_label,
      "_",
      variant_type,
      "_minP_N5000.tsv"
    )
  )
  
  fwrite(
    merged,
    merged_file,
    sep = "\t",
    quote = FALSE,
    na = "NA"
  )
  
  message(
    "[MERGED] ",
    label_base,
    " -> ",
    merged_file
  )
  
  merged[
    ,
    .(
      dataset_type,
      variant_type,
      method,
      loop,
      lead_P,
      source_loop,
      source_batch
    )
  ]
}


############################################################
# 11. Read original FPR
############################################################

message(
  "============================================================"
)

message(
  "[INFO] Reading original-variant-set FPR"
)

message(
  "============================================================"
)

fpr_list <- list()

for (
  vt in names(
    FPR_FILES
  )
) {
  
  for (
    mm in names(
      FPR_FILES[[
        vt
      ]]
    )
  ) {
    
    fpr_list[[
      paste(
        vt,
        mm,
        sep = "__"
      )
    ]] <- read_original_fpr(
      file = FPR_FILES[[
        vt
      ]][[
        mm
      ]],
      variant_type = vt,
      method = mm
    )
  }
}

fpr_raw <- rbindlist(
  fpr_list,
  use.names = TRUE,
  fill = TRUE
)


############################################################
# 12. Merge/read matched FPR
############################################################

message(
  "============================================================"
)

message(
  "[INFO] Building matched-variant-size FPR N=5000"
)

message(
  "============================================================"
)

match_list <- list()

for (
  vt in names(
    MATCH_FILES
  )
) {
  
  for (
    mm in names(
      MATCH_FILES[[
        vt
      ]]
    )
  ) {
    
    spec <- MATCH_FILES[[
      vt
    ]][[
      mm
    ]]
    
    match_list[[
      paste(
        vt,
        mm,
        sep = "__"
      )
    ]] <- merge_match_5k(
      old_file = spec$old,
      add4k_file = spec$add4k,
      variant_type = vt,
      method = mm
    )
  }
}

match_raw <- rbindlist(
  match_list,
  use.names = TRUE,
  fill = TRUE
)


############################################################
# 13. Input QC summaries
############################################################

input_qc <- rbindlist(
  list(
    fpr_raw,
    match_raw
  ),
  use.names = TRUE,
  fill = TRUE
)[
  ,
  .(
    n = .N,
    n_unique_loop = uniqueN(
      loop
    ),
    min_P = min(
      lead_P
    ),
    median_P = median(
      lead_P
    ),
    max_P = max(
      lead_P
    )
  ),
  by = .(
    dataset_type,
    variant_type,
    method
  )
]

fwrite(
  input_qc,
  file.path(
    OUT_DIR,
    "FPR_and_match_FPR_input_QC_summary.csv"
  )
)


############################################################
# 14. Core FPR statistics
############################################################

calc_prop <- function(
    p_values,
    p_threshold
) {
  
  mean(
    p_values < p_threshold
  )
}


calc_empirical_y005 <- function(
    p_values
) {
  
  q <- as.numeric(
    quantile(
      p_values,
      probs = REF_Y,
      names = FALSE,
      na.rm = FALSE,
      type = 7
    )
  )
  
  data.table(
    P_threshold = q,
    neglog10P = -log10(
      q
    ),
    observed_count_strict_lt = sum(
      p_values < q
    ),
    observed_prop_strict_lt = mean(
      p_values < q
    )
  )
}


############################################################
# 15. Build statistics/anchors for one dataset
############################################################

build_fpr_statistics <- function(
    raw_dt,
    dataset_type,
    output_prefix
) {
  
  fixed_list <- list()
  emp_list <- list()
  
  for (
    vt in c(
      "allvariants",
      "common",
      "rare"
    )
  ) {
    
    for (
      mm in METHODS
    ) {
      
      p <- raw_dt[
        variant_type == vt &
          method == mm,
        lead_P
      ]
      
      if (
        length(
          p
        ) == 0
      ) {
        fatal(
          "No P values for ",
          dataset_type,
          " / ",
          vt,
          " / ",
          mm
        )
      }
      
      counts <- vapply(
        MARKER_P_FIXED,
        function(
    p_threshold
        ) {
          
          sum(
            p < p_threshold
          )
        },
    integer(
      1
    )
      )
      
      fixed_list[[
        paste(
          vt,
          mm,
          sep = "__"
        )
      ]] <- data.table(
        dataset_type = dataset_type,
        variant_type = vt,
        method = mm,
        neglog10P = MARKER_X_FIXED,
        P_threshold = MARKER_P_FIXED,
        n_simulations = length(
          p
        ),
        false_positive_count = counts,
        proportion = counts / length(
          p
        ),
        percent = counts / length(
          p
        ) * 100,
        point_type = "fixed_threshold"
      )
      
      e <- calc_empirical_y005(
        p
      )
      
      emp_list[[
        paste(
          vt,
          mm,
          sep = "__"
        )
      ]] <- data.table(
        dataset_type = dataset_type,
        variant_type = vt,
        method = mm,
        neglog10P = e$neglog10P,
        P_threshold = e$P_threshold,
        n_simulations = length(
          p
        ),
        false_positive_count = REF_Y * length(
          p
        ),
        proportion = REF_Y,
        percent = REF_Y * 100,
        observed_count_strict_lt = e$observed_count_strict_lt,
        observed_prop_strict_lt = e$observed_prop_strict_lt,
        point_type = "empirical_y005"
      )
    }
  }
  
  fixed <- rbindlist(
    fixed_list,
    use.names = TRUE,
    fill = TRUE
  )
  
  emp <- rbindlist(
    emp_list,
    use.names = TRUE,
    fill = TRUE
  )
  
  fwrite(
    fixed,
    file.path(
      OUT_DIR,
      paste0(
        output_prefix,
        "_requested_marker_threshold_proportions.csv"
      )
    )
  )
  
  fwrite(
    emp,
    file.path(
      OUT_DIR,
      paste0(
        output_prefix,
        "_empirical_P_threshold_at_y005.csv"
      )
    )
  )
  
  ##########################################################
  # Conventional genome-wide P < 5e-8
  ##########################################################
  
  fpr_5e8 <- fixed[
    P_threshold == 5e-8,
    .(
      dataset_type,
      variant_type,
      method,
      n_simulations,
      P_threshold,
      false_positive_count,
      GWFPR = proportion,
      GWFPR_percent = percent
    )
  ]
  
  fwrite(
    fpr_5e8,
    file.path(
      OUT_DIR,
      paste0(
        output_prefix,
        "_GWFPR_at_P5e-8.csv"
      )
    )
  )
  
  ##########################################################
  # Cross-evaluate both methods at BOTH empirical thresholds
  ##########################################################
  
  cross_list <- list()
  
  for (
    vt in c(
      "allvariants",
      "common",
      "rare"
    )
  ) {
    
    emp_vt <- emp[
      variant_type == vt
    ]
    
    for (
      anchor_method in METHODS
    ) {
      
      anchor <- emp_vt[
        method == anchor_method
      ]
      
      if (
        nrow(
          anchor
        ) != 1
      ) {
        fatal(
          "Empirical threshold row count != 1 for ",
          dataset_type,
          " / ",
          vt,
          " / ",
          anchor_method
        )
      }
      
      for (
        eval_method in METHODS
      ) {
        
        p <- raw_dt[
          variant_type == vt &
            method == eval_method,
          lead_P
        ]
        
        nfp <- sum(
          p < anchor$P_threshold
        )
        
        cross_list[[
          length(
            cross_list
          ) + 1L
        ]] <- data.table(
          dataset_type = dataset_type,
          variant_type = vt,
          anchor_method = anchor_method,
          evaluated_method = eval_method,
          anchor_P_threshold = anchor$P_threshold,
          anchor_neglog10P = anchor$neglog10P,
          n_simulations = length(
            p
          ),
          false_positive_count = nfp,
          proportion_at_anchor = nfp / length(
            p
          ),
          percent_at_anchor = nfp / length(
            p
          ) * 100
        )
      }
    }
  }
  
  cross <- rbindlist(
    cross_list,
    use.names = TRUE,
    fill = TRUE
  )
  
  fwrite(
    cross,
    file.path(
      OUT_DIR,
      paste0(
        output_prefix,
        "_cross_method_proportions_at_each_y005_threshold.csv"
      )
    )
  )
  
  cross_points <- cross[
    anchor_method != evaluated_method,
    .(
      dataset_type,
      variant_type,
      method = evaluated_method,
      neglog10P = anchor_neglog10P,
      P_threshold = anchor_P_threshold,
      proportion = proportion_at_anchor,
      point_type = paste0(
        "cross_at_",
        anchor_method,
        "_y005"
      )
    )
  ]
  
  ##########################################################
  # All displayed/curve anchors
  ##########################################################
  
  anchor_dt <- rbindlist(
    list(
      
      fixed[
        ,
        .(
          dataset_type,
          variant_type,
          method,
          neglog10P,
          P_threshold,
          proportion,
          point_type
        )
      ],
      
      emp[
        ,
        .(
          dataset_type,
          variant_type,
          method,
          neglog10P,
          P_threshold,
          proportion,
          point_type
        )
      ],
      
      cross_points
    ),
    use.names = TRUE,
    fill = TRUE
  )
  
  # At identical x within one method, prioritise its own empirical y=0.05 anchor.
  anchor_dt[
    ,
    priority := fifelse(
      point_type == "empirical_y005",
      1L,
      2L
    )
  ]
  
  setorder(
    anchor_dt,
    dataset_type,
    variant_type,
    method,
    neglog10P,
    priority
  )
  
  anchor_dt <- anchor_dt[
    ,
    .SD[1],
    by = .(
      dataset_type,
      variant_type,
      method,
      neglog10P
    )
  ]
  
  anchor_dt[
    ,
    priority := NULL
  ]
  
  fwrite(
    anchor_dt,
    file.path(
      OUT_DIR,
      paste0(
        output_prefix,
        "_all_anchor_points.csv"
      )
    )
  )
  
  ##########################################################
  # Final concise summary
  ##########################################################
  
  emp_short <- emp[
    ,
    .(
      dataset_type,
      variant_type,
      method,
      empirical_P_at_GWFPR005 = P_threshold,
      empirical_neglog10P = neglog10P,
      observed_count_strict_lt,
      observed_GWFPR_strict_lt = observed_prop_strict_lt
    )
  ]
  
  final_summary <- merge(
    fpr_5e8[
      ,
      .(
        dataset_type,
        variant_type,
        method,
        N = n_simulations,
        FP_count_at_5e8 = false_positive_count,
        GWFPR_at_5e8 = GWFPR
      )
    ],
    emp_short,
    by = c(
      "dataset_type",
      "variant_type",
      "method"
    ),
    all = TRUE
  )
  
  fwrite(
    final_summary,
    file.path(
      OUT_DIR,
      paste0(
        output_prefix,
        "_FINAL_summary.csv"
      )
    )
  )
  
  list(
    fixed = fixed,
    emp = emp,
    cross = cross,
    anchors = anchor_dt,
    final_summary = final_summary
  )
}


############################################################
# 16. Calculate both analyses
############################################################

fpr_res <- build_fpr_statistics(
  raw_dt = fpr_raw,
  dataset_type = "FPR",
  output_prefix = "FPR_5k"
)

match_res <- build_fpr_statistics(
  raw_dt = match_raw,
  dataset_type = "match_FPR",
  output_prefix = "match_FPR_5k"
)


############################################################
# 17. Combined statistics table
############################################################

combined_final_summary <- rbindlist(
  list(
    fpr_res$final_summary,
    match_res$final_summary
  ),
  use.names = TRUE,
  fill = TRUE
)

combined_final_summary[
  ,
  dataset_order := match(
    dataset_type,
    c(
      "FPR",
      "match_FPR"
    )
  )
]

combined_final_summary[
  ,
  variant_order := match(
    variant_type,
    c(
      "allvariants",
      "common",
      "rare"
    )
  )
]

combined_final_summary[
  ,
  method_order := match(
    method,
    METHODS
  )
]

setorder(
  combined_final_summary,
  dataset_order,
  variant_order,
  method_order
)

combined_final_summary[
  ,
  c(
    "dataset_order",
    "variant_order",
    "method_order"
  ) := NULL
]

fwrite(
  combined_final_summary,
  file.path(
    OUT_DIR,
    "FPR_and_match_FPR_5k_FINAL_summary.csv"
  )
)


############################################################
# 18. Shared y-axis limits between FPR and match_FPR
############################################################

get_anchor_x7_max <- function(
    anchors,
    variant_type
) {
  
  d <- anchors[
    variant_type == variant_type &
      abs(
        neglog10P - 7
      ) < 1e-10
  ]
  
  if (
    nrow(
      d
    ) == 0
  ) {
    return(
      NA_real_
    )
  }
  
  max(
    d$proportion,
    na.rm = TRUE
  )
}


# Avoid data.table name masking by using a dedicated implementation.
calculate_ymax <- function(
    variant_type_value
) {
  
  d1 <- fpr_res$anchors[
    variant_type == variant_type_value &
      abs(
        neglog10P - 7
      ) < 1e-10
  ]
  
  d2 <- match_res$anchors[
    variant_type == variant_type_value &
      abs(
        neglog10P - 7
      ) < 1e-10
  ]
  
  vals <- c(
    d1$proportion,
    d2$proportion
  )
  
  vals <- vals[
    is.finite(
      vals
    )
  ]
  
  if (
    length(
      vals
    ) == 0
  ) {
    ymax <- 0.10
  } else {
    ymax <- max(
      vals
    )
  }
  
  ymax <- ceiling(
    ymax / 0.05
  ) * 0.05
  
  ymax <- max(
    ymax,
    0.10
  )
  
  min(
    ymax,
    1
  )
}


YMAX_SHARED <- c(
  allvariants = calculate_ymax(
    "allvariants"
  ),
  common = calculate_ymax(
    "common"
  ),
  rare = calculate_ymax(
    "rare"
  )
)


make_ybreaks <- function(
    ymax
) {
  
  if (
    ymax <= 0.10
  ) {
    return(
      seq(
        0,
        ymax,
        by = 0.025
      )
    )
  }
  
  if (
    ymax <= 0.30
  ) {
    return(
      seq(
        0,
        ymax,
        by = 0.05
      )
    )
  }
  
  if (
    ymax <= 0.60
  ) {
    return(
      seq(
        0,
        ymax,
        by = 0.10
      )
    )
  }
  
  seq(
    0,
    ymax,
    by = 0.20
  )
}


fwrite(
  data.table(
    variant_type = names(
      YMAX_SHARED
    ),
    shared_ymax = as.numeric(
      YMAX_SHARED
    )
  ),
  file.path(
    OUT_DIR,
    "FPR_and_match_FPR_shared_y_axis_limits.csv"
  )
)


############################################################
# 19. ONE shared theme for ALL figures
############################################################

gb_theme <- function(
    base_size = 8,
    show_legend = TRUE
) {
  
  th <- theme_classic(
    base_size = base_size,
    base_family = "sans"
  ) +
    
    theme(
      aspect.ratio = 1,
      
      axis.line = element_line(
        linewidth = 0.35,
        colour = "black"
      ),
      
      axis.ticks = element_line(
        linewidth = 0.35,
        colour = "black"
      ),
      
      axis.ticks.length = unit(
        1.6,
        "mm"
      ),
      
      axis.title.x = element_text(
        size = 11.0,
        colour = "black",
        margin = margin(
          t = 5
        )
      ),
      
      axis.title.y = element_text(
        size = 11.0,
        colour = "black",
        margin = margin(
          r = 6
        ),
        lineheight = 0.95
      ),
      
      axis.text = element_text(
        size = 9.5,
        colour = "black"
      ),
      
      plot.title = element_text(
        size = 11.5,
        hjust = 0.5,
        vjust = 1,
        colour = "black",
        face = "plain",
        margin = margin(
          b = 6
        )
      ),
      
      plot.title.position = "panel",
      
      plot.tag.position = c(
        0.002,
        0.995
      ),
      
      plot.tag = element_text(
        size = 11.5,
        colour = "black",
        face = "bold",
        hjust = 0,
        vjust = 1,
        margin = margin(
          0,
          0,
          0,
          0
        )
      ),
      
      legend.title = element_blank(),
      
      legend.text = element_text(
        size = 9.5,
        colour = "black"
      ),
      
      legend.key.width = unit(
        0.62,
        "cm"
      ),
      
      legend.key.height = unit(
        0.34,
        "cm"
      ),
      
      legend.background = element_blank(),
      legend.box.background = element_blank(),
      
      legend.key = element_rect(
        fill = "white",
        colour = NA
      ),
      
      legend.margin = margin(
        0,
        0,
        0,
        0
      ),
      
      legend.spacing.y = unit(
        0.055,
        "cm"
      ),
      
      panel.border = element_blank(),
      panel.background = element_blank(),
      
      plot.background = element_rect(
        fill = "white",
        colour = NA
      ),
      
      plot.margin = margin(
        16,
        10,
        8,
        20
      )
    )
  
  if (
    show_legend
  ) {
    
    th <- th +
      theme(
        legend.position = "bottom",
        legend.direction = "horizontal",
        legend.justification = "center",
        legend.box = "horizontal",
        legend.box.spacing = unit(
          5.5,
          "pt"
        )
      )
    
  } else {
    
    th <- th +
      theme(
        legend.position = "none"
      )
  }
  
  th
}


############################################################
# 20. Build smooth curve from displayed anchor points only
############################################################

build_smooth_curve <- function(
    anchors,
    variant_type_value,
    ymax
) {
  
  d0 <- anchors[
    variant_type == variant_type_value
  ]
  
  out <- list()
  
  for (
    mm in METHODS
  ) {
    
    d <- copy(
      d0[
        method == mm &
          is.finite(
            neglog10P
          ) &
          is.finite(
            proportion
          )
      ]
    )
    
    if (
      nrow(
        d
      ) < 2
    ) {
      next
    }
    
    setorder(
      d,
      neglog10P
    )
    
    fit <- d[
      neglog10P >= X_MIN &
        neglog10P <= X_MAX
    ]
    
    if (
      nrow(
        fit
      ) < 2
    ) {
      next
    }
    
    fit[
      ,
      proportion_for_spline := cummin(
        proportion
      )
    ]
    
    spline_function <- splinefun(
      x = fit$neglog10P,
      y = fit$proportion_for_spline,
      method = "monoH.FC"
    )
    
    x_grid <- seq(
      min(
        fit$neglog10P
      ),
      max(
        fit$neglog10P
      ),
      length.out = SMOOTH_N
    )
    
    y_grid <- spline_function(
      x_grid
    )
    
    y_grid <- pmax(
      pmin(
        y_grid,
        1
      ),
      0
    )
    
    curve_dt <- data.table(
      method = mm,
      neglog10P = x_grid,
      proportion = y_grid
    )
    
    ########################################################
    # Fixed point-line gap, identical in every figure
    ########################################################
    
    visible_anchors <- d[
      neglog10P >= X_MIN &
        neglog10P <= X_MAX
    ]
    
    x_range <- X_MAX - X_MIN
    
    y_range <- ymax
    
    if (
      !is.finite(
        y_range
      ) ||
      y_range <= 0
    ) {
      y_range <- 1
    }
    
    gap_flag <- rep(
      FALSE,
      nrow(
        curve_dt
      )
    )
    
    for (
      ii in seq_len(
        nrow(
          visible_anchors
        )
      )
    ) {
      
      x_point <- visible_anchors$neglog10P[
        ii
      ]
      
      y_point <- visible_anchors$proportion[
        ii
      ]
      
      distance_npc <- sqrt(
        (
          (
            curve_dt$neglog10P - x_point
          ) /
            x_range
        )^2 +
          (
            (
              curve_dt$proportion - y_point
            ) /
              y_range
          )^2
      )
      
      gap_flag <- gap_flag |
        (
          is.finite(
            distance_npc
          ) &
            distance_npc <
            FIXED_POINT_LINE_GAP_NPC
        )
    }
    
    curve_dt[
      ,
      keep_curve := !gap_flag
    ]
    
    curve_dt[
      ,
      run_id := rleid(
        keep_curve
      )
    ]
    
    curve_dt <- curve_dt[
      keep_curve == TRUE
    ]
    
    curve_dt[
      ,
      segment_id := paste0(
        mm,
        "_",
        run_id
      )
    ]
    
    out[[
      mm
    ]] <- curve_dt
  }
  
  if (
    length(
      out
    ) == 0
  ) {
    return(
      data.table()
    )
  }
  
  rbindlist(
    out,
    use.names = TRUE,
    fill = TRUE
  )
}


############################################################
# 21. ONE plot builder for BOTH FPR and match_FPR
############################################################

build_plot <- function(
    anchors,
    variant_type_value,
    show_legend = TRUE,
    panel_tag = NULL
) {
  
  points_dt <- copy(
    anchors[
      variant_type == variant_type_value &
        neglog10P >= X_MIN &
        neglog10P <= X_MAX
    ]
  )
  
  if (
    nrow(
      points_dt
    ) == 0
  ) {
    fatal(
      "No visible anchor points for variant type: ",
      variant_type_value
    )
  }
  
  ymax <- if (
    USE_SHARED_Y_BY_VARIANT
  ) {
    unname(
      YMAX_SHARED[
        variant_type_value
      ]
    )
  } else {
    
    ymax_local <- max(
      points_dt[
        abs(
          neglog10P - 7
        ) < 1e-10,
        proportion
      ],
      na.rm = TRUE
    )
    
    ymax_local <- ceiling(
      ymax_local / 0.05
    ) * 0.05
    
    max(
      ymax_local,
      0.10
    )
  }
  
  ybreaks <- make_ybreaks(
    ymax
  )
  
  curve_dt <- build_smooth_curve(
    anchors = anchors,
    variant_type_value = variant_type_value,
    ymax = ymax
  )
  
  if (
    nrow(
      curve_dt
    ) == 0
  ) {
    fatal(
      "No smooth curve generated for variant type: ",
      variant_type_value
    )
  }
  
  points_dt[
    ,
    method := factor(
      method,
      levels = METHODS
    )
  ]
  
  curve_dt[
    ,
    method := factor(
      method,
      levels = METHODS
    )
  ]
  
  ggplot() +
    
    geom_line(
      data = curve_dt,
      aes(
        x = neglog10P,
        y = proportion,
        colour = method,
        group = segment_id
      ),
      linewidth = LEGEND_LINE_WIDTH,
      lineend = "round",
      show.legend = TRUE,
      na.rm = TRUE
    ) +
    
    geom_hline(
      yintercept = REF_Y,
      colour = REF_LINE_COLOUR,
      linetype = "dashed",
      linewidth = 0.45,
      show.legend = FALSE
    ) +
    
    geom_point(
      data = points_dt,
      aes(
        x = neglog10P,
        y = proportion,
        colour = method,
        fill = method,
        shape = method
      ),
      size = POINT_SIZE,
      stroke = POINT_STROKE,
      show.legend = TRUE,
      na.rm = TRUE
    ) +
    
    scale_colour_manual(
      name = NULL,
      values = COL_MAIN,
      breaks = METHODS,
      labels = c(
        "Single-ancestry",
        "Multi-ancestry"
      ),
      drop = FALSE
    ) +
    
    scale_shape_manual(
      name = NULL,
      values = SHAPE_MAIN,
      breaks = METHODS,
      labels = c(
        "Single-ancestry",
        "Multi-ancestry"
      ),
      drop = FALSE,
      guide = "none"
    ) +
    
    scale_fill_manual(
      name = NULL,
      values = FILL_MAIN,
      breaks = METHODS,
      labels = c(
        "Single-ancestry",
        "Multi-ancestry"
      ),
      drop = FALSE,
      guide = "none"
    ) +
    
    scale_x_continuous(
      limits = c(
        X_MIN,
        X_MAX
      ),
      breaks = X_BREAKS,
      labels = c(
        "7",
        "8",
        "9",
        "10"
      ),
      expand = expansion(
        mult = c(
          0,
          0.02
        )
      )
    ) +
    
    scale_y_continuous(
      limits = c(
        0,
        ymax
      ),
      breaks = ybreaks,
      expand = expansion(
        mult = c(
          0,
          0.035
        )
      ),
      labels = function(
    x
      ) {
        
        format(
          x,
          trim = TRUE,
          scientific = FALSE
        )
      }
    ) +
    
    coord_cartesian(
      clip = "off"
    ) +
    
    labs(
      x = expression(
        -log[10](
          italic(
            P
          )~threshold
        )
      ),
      y = "Genome-wide false positive rate",
      title = panel_title(
        variant_type_value
      ),
      tag = panel_tag
    ) +
    
    guides(
      colour = guide_legend(
        nrow = 1,
        byrow = TRUE,
        override.aes = list(
          alpha = 1,
          linewidth = LEGEND_LINE_WIDTH,
          linetype = 1,
          size = LEGEND_POINT_SIZE,
          stroke = POINT_STROKE,
          shape = unname(
            SHAPE_MAIN[
              METHODS
            ]
          ),
          fill = unname(
            FILL_MAIN[
              METHODS
            ]
          )
        )
      )
    ) +
    
    gb_theme(
      base_size = 8,
      show_legend = show_legend
    )
}


############################################################
# 22. ONE single-panel saver for ALL figures
############################################################

save_plot_pdf_png <- function(
    p,
    out_prefix
) {
  
  pdf_file <- paste0(
    out_prefix,
    ".pdf"
  )
  
  png_file <- paste0(
    out_prefix,
    ".png"
  )
  
  if (
    capabilities(
      "cairo"
    )
  ) {
    
    grDevices::cairo_pdf(
      filename = pdf_file,
      width = SINGLE_WIDTH,
      height = SINGLE_HEIGHT,
      bg = "white"
    )
    
  } else {
    
    grDevices::pdf(
      file = pdf_file,
      width = SINGLE_WIDTH,
      height = SINGLE_HEIGHT,
      useDingbats = FALSE,
      bg = "white"
    )
  }
  
  print(
    p
  )
  
  grDevices::dev.off()
  
  grDevices::png(
    filename = png_file,
    width = SINGLE_WIDTH,
    height = SINGLE_HEIGHT,
    units = "in",
    res = PNG_DPI,
    bg = "white"
  )
  
  print(
    p
  )
  
  grDevices::dev.off()
  
  if (
    !file.exists(
      pdf_file
    ) ||
    file.info(
      pdf_file
    )$size <= 0
  ) {
    fatal(
      "PDF figure was not created: ",
      pdf_file
    )
  }
  
  if (
    !file.exists(
      png_file
    ) ||
    file.info(
      png_file
    )$size <= 0
  ) {
    fatal(
      "PNG figure was not created: ",
      png_file
    )
  }
  
  message(
    "[FIGURE SAVED] ",
    pdf_file
  )
  
  message(
    "[FIGURE SAVED] ",
    png_file
  )
}


############################################################
# 23. Extract shared bottom legend
############################################################

get_bottom_legend <- function(
    p
) {
  
  g <- ggplotGrob(
    p +
      
      guides(
        colour = guide_legend(
          nrow = 1,
          byrow = TRUE,
          override.aes = list(
            alpha = 1,
            linewidth = LEGEND_LINE_WIDTH,
            linetype = 1,
            size = LEGEND_POINT_SIZE,
            stroke = POINT_STROKE,
            shape = unname(
              SHAPE_MAIN[
                METHODS
              ]
            ),
            fill = unname(
              FILL_MAIN[
                METHODS
              ]
            )
          )
        )
      ) +
      
      theme(
        legend.position = "bottom",
        legend.direction = "horizontal",
        legend.justification = "center",
        legend.box = "horizontal",
        legend.box.spacing = unit(
          0,
          "pt"
        )
      )
  )
  
  idx <- which(
    grepl(
      "^guide-box",
      g$layout$name
    )
  )
  
  if (
    length(
      idx
    ) == 0
  ) {
    return(
      grid::nullGrob()
    )
  }
  
  valid <- idx[
    !vapply(
      g$grobs[
        idx
      ],
      inherits,
      logical(
        1
      ),
      what = "zeroGrob"
    )
  ]
  
  if (
    length(
      valid
    ) == 0
  ) {
    return(
      grid::nullGrob()
    )
  }
  
  g$grobs[[
    valid[
      1
    ]
  ]]
}


############################################################
# 24. ONE three-panel saver for BOTH FPR and match_FPR
#
# Exact dimensions from original FPR section:
#   width = 11.8
#   base height = 5.0
#   output height = 5.35
############################################################

save_combined_three <- function(
    p1,
    p2,
    p3,
    out_prefix
) {
  
  pdf_file <- paste0(
    out_prefix,
    ".pdf"
  )
  
  png_file <- paste0(
    out_prefix,
    ".png"
  )
  
  legend <- get_bottom_legend(
    p3
  )
  
  p1_no_legend <- p1 +
    theme(
      legend.position = "none"
    )
  
  p2_no_legend <- p2 +
    theme(
      legend.position = "none"
    )
  
  p3_no_legend <- p3 +
    theme(
      legend.position = "none"
    )
  
  draw_three <- function() {
    
    grid.newpage()
    
    pushViewport(
      viewport(
        layout = grid.layout(
          nrow = 3,
          ncol = 3,
          
          heights = unit.c(
            unit(
              1,
              "null"
            ),
            unit(
              5.5,
              "pt"
            ),
            grobHeight(
              legend
            )
          ),
          
          widths = unit(
            c(
              1,
              1,
              1
            ),
            "null"
          ),
          
          respect = TRUE
        )
      )
    )
    
    print(
      p1_no_legend,
      vp = viewport(
        layout.pos.row = 1,
        layout.pos.col = 1
      )
    )
    
    print(
      p2_no_legend,
      vp = viewport(
        layout.pos.row = 1,
        layout.pos.col = 2
      )
    )
    
    print(
      p3_no_legend,
      vp = viewport(
        layout.pos.row = 1,
        layout.pos.col = 3
      )
    )
    
    pushViewport(
      viewport(
        layout.pos.row = 3,
        layout.pos.col = 1:3
      )
    )
    
    grid.draw(
      legend
    )
    
    popViewport()
  }
  
  if (
    capabilities(
      "cairo"
    )
  ) {
    
    grDevices::cairo_pdf(
      filename = pdf_file,
      width = GROUP_WIDTH,
      height = GROUP_DEVICE_HEIGHT,
      bg = "white"
    )
    
  } else {
    
    grDevices::pdf(
      file = pdf_file,
      width = GROUP_WIDTH,
      height = GROUP_DEVICE_HEIGHT,
      useDingbats = FALSE,
      bg = "white"
    )
  }
  
  draw_three()
  grDevices::dev.off()
  
  grDevices::png(
    filename = png_file,
    width = GROUP_WIDTH,
    height = GROUP_DEVICE_HEIGHT,
    units = "in",
    res = PNG_DPI,
    bg = "white"
  )
  
  draw_three()
  grDevices::dev.off()
  
  if (
    !file.exists(
      pdf_file
    ) ||
    file.info(
      pdf_file
    )$size <= 0
  ) {
    fatal(
      "Grouped PDF was not created: ",
      pdf_file
    )
  }
  
  if (
    !file.exists(
      png_file
    ) ||
    file.info(
      png_file
    )$size <= 0
  ) {
    fatal(
      "Grouped PNG was not created: ",
      png_file
    )
  }
  
  message(
    "[FIGURE SAVED] ",
    pdf_file
  )
  
  message(
    "[FIGURE SAVED] ",
    png_file
  )
}


############################################################
# 25. Draw one complete FPR family
############################################################

draw_fpr_family <- function(
    anchors,
    file_prefix
) {
  
  ##########################################################
  # Individual panels
  ##########################################################
  
  p_all <- build_plot(
    anchors = anchors,
    variant_type_value = "allvariants",
    show_legend = TRUE
  )
  
  p_common <- build_plot(
    anchors = anchors,
    variant_type_value = "common",
    show_legend = TRUE
  )
  
  p_rare <- build_plot(
    anchors = anchors,
    variant_type_value = "rare",
    show_legend = TRUE
  )
  
  save_plot_pdf_png(
    p_all,
    file.path(
      OUT_DIR,
      paste0(
        "Fig_",
        file_prefix,
        "_allvariants_single_vs_multi_smooth"
      )
    )
  )
  
  save_plot_pdf_png(
    p_common,
    file.path(
      OUT_DIR,
      paste0(
        "Fig_",
        file_prefix,
        "_common_single_vs_multi_smooth"
      )
    )
  )
  
  save_plot_pdf_png(
    p_rare,
    file.path(
      OUT_DIR,
      paste0(
        "Fig_",
        file_prefix,
        "_rare_single_vs_multi_smooth"
      )
    )
  )
  
  ##########################################################
  # Grouped a/b/c
  ##########################################################
  
  p_a <- build_plot(
    anchors = anchors,
    variant_type_value = "allvariants",
    show_legend = FALSE,
    panel_tag = "a"
  )
  
  p_b <- build_plot(
    anchors = anchors,
    variant_type_value = "common",
    show_legend = FALSE,
    panel_tag = "b"
  )
  
  p_c <- build_plot(
    anchors = anchors,
    variant_type_value = "rare",
    show_legend = TRUE,
    panel_tag = "c"
  )
  
  save_combined_three(
    p_a,
    p_b,
    p_c,
    file.path(
      OUT_DIR,
      paste0(
        "Fig_",
        file_prefix,
        "_all_common_rare_grouped_smooth"
      )
    )
  )
  
  invisible(
    list(
      all = p_all,
      common = p_common,
      rare = p_rare
    )
  )
}


############################################################
# 26. Draw original FPR
############################################################

message(
  "============================================================"
)

message(
  "[INFO] Plotting original FPR"
)

message(
  "============================================================"
)

fpr_plots <- draw_fpr_family(
  anchors = fpr_res$anchors,
  file_prefix = "FPR_5k"
)


############################################################
# 27. Draw matched FPR
############################################################

message(
  "============================================================"
)

message(
  "[INFO] Plotting matched FPR"
)

message(
  "============================================================"
)

match_plots <- draw_fpr_family(
  anchors = match_res$anchors,
  file_prefix = "match_FPR_5k"
)


############################################################
# 28. Final parameter audit
#
# This CSV makes it explicit that both figure families use
# exactly the same graphical parameters.
############################################################

plot_parameter_audit <- data.table(
  parameter = c(
    "axis_title_size",
    "axis_text_size",
    "panel_title_size",
    "panel_tag_size",
    "legend_text_size",
    "axis_line_width",
    "axis_tick_width",
    "axis_tick_length_mm",
    "point_size",
    "point_stroke",
    "legend_point_size",
    "curve_width",
    "reference_line_width",
    "point_line_gap_npc",
    "single_width_in",
    "single_height_in",
    "group_width_in",
    "group_height_in",
    "png_dpi",
    "x_min",
    "x_max"
  ),
  
  FPR = c(
    11.0,
    9.5,
    11.5,
    11.5,
    9.5,
    0.35,
    0.35,
    1.6,
    POINT_SIZE,
    POINT_STROKE,
    LEGEND_POINT_SIZE,
    LEGEND_LINE_WIDTH,
    0.45,
    FIXED_POINT_LINE_GAP_NPC,
    SINGLE_WIDTH,
    SINGLE_HEIGHT,
    GROUP_WIDTH,
    GROUP_DEVICE_HEIGHT,
    PNG_DPI,
    X_MIN,
    X_MAX
  ),
  
  match_FPR = c(
    11.0,
    9.5,
    11.5,
    11.5,
    9.5,
    0.35,
    0.35,
    1.6,
    POINT_SIZE,
    POINT_STROKE,
    LEGEND_POINT_SIZE,
    LEGEND_LINE_WIDTH,
    0.45,
    FIXED_POINT_LINE_GAP_NPC,
    SINGLE_WIDTH,
    SINGLE_HEIGHT,
    GROUP_WIDTH,
    GROUP_DEVICE_HEIGHT,
    PNG_DPI,
    X_MIN,
    X_MAX
  )
)

fwrite(
  plot_parameter_audit,
  file.path(
    OUT_DIR,
    "FPR_and_match_FPR_plot_parameter_audit.csv"
  )
)


############################################################
# 29. Console summary
############################################################

cat(
  "\n============================================================\n"
)

cat(
  "FPR + MATCHED FPR ANALYSIS COMPLETED\n"
)

cat(
  "============================================================\n"
)

cat(
  "All figure families use the SAME plotting parameters.\n\n"
)

cat(
  "Shared per-variant y-axis maxima:\n"
)

print(
  data.table(
    variant_type = names(
      YMAX_SHARED
    ),
    ymax = as.numeric(
      YMAX_SHARED
    )
  )
)

cat(
  "\nCombined statistics:\n"
)

print(
  combined_final_summary
)

cat(
  "\nOutput directory:\n",
  OUT_DIR,
  "\n",
  sep = ""
)

cat(
  "\nMain grouped figures:\n"
)

cat(
  file.path(
    OUT_DIR,
    "Fig_FPR_5k_all_common_rare_grouped_smooth.pdf"
  ),
  "\n"
)

cat(
  file.path(
    OUT_DIR,
    "Fig_match_FPR_5k_all_common_rare_grouped_smooth.pdf"
  ),
  "\n"
)

cat(
  "\nFigure dimensions:\n"
)

cat(
  "Individual: ",
  SINGLE_WIDTH,
  " x ",
  SINGLE_HEIGHT,
  " inches\n",
  sep = ""
)

cat(
  "Grouped: ",
  GROUP_WIDTH,
  " x ",
  GROUP_DEVICE_HEIGHT,
  " inches\n",
  sep = ""
)

cat(
  "PNG: ",
  PNG_DPI,
  " dpi\n",
  sep = ""
)

cat(
  "============================================================\n"
)

