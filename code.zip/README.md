# Simulation Scripts for Single- and Multi-Ancestry GWAS

This repository contains scripts used for simulation-based comparisons of single-ancestry and multi-ancestry GWAS. The workflow includes genotype preparation, PCA, phenotype simulation, GWAS, fine-mapping, false-positive rate analyses, matched variant-size analyses, and result merging.

The scripts are organised into two folders:

```text
main/   Main GWAS and fine-mapping simulation analyses
FPR/    False-positive rate and matched variant-size analyses
```

## Repository structure

### `main/`

| File | Description |
|---|---|
| `all_ana.sh` | Main simulation pipeline for single-ancestry and multi-ancestry GWAS and fine-mapping analyses. |
| `common_pooled_hsq.sh` | Runs heritability-based simulations and pooled GWAS analyses for common variants. |
| `dif_afr_pooled_prepare.sh` | Prepares matched total-sample-size EUR–AFR pooled genotype datasets with different ancestry compositions. |
| `eur_hsq_pc.sh` | Runs heritability-based GWAS and fine-mapping analyses using SuSiE and SuSiEx. |
| `false_variants_pc.sh` | Calculates PCA covariates for EUR10K genotype datasets used in downstream analyses. |
| `FPR_pooled_prepare.sh` | Prepares pooled EUR–AFR genotype datasets used for false-positive rate analyses. |
| `major_merge.sh` | Merges task-level outputs from the main simulation and fine-mapping analyses. |
| `pca.sh` | Generates PC1–PC10 covariates for the main single-ancestry and ancestry-specific genotype datasets. |
| `pooled_difafr_pc.sh` | Calculates PCA covariates for matched total-sample-size EUR–AFR pooled datasets. |
| `pooled_diff_afr.sh` | Runs pooled GWAS simulations across different EUR–AFR ancestry compositions. |
| `pooled_hsq_merge.sh` | Merges common-variant pooled heritability simulation results. |
| `pooled_pca.sh` | Generates PCA covariates for pooled EUR–AFR datasets with different AFR sample sizes. |
| `rare_all_hsq.sh` | Runs rare-variant heritability simulations for single-ancestry, pooled, and meta-analysis settings. |

### `FPR/`

| File | Description |
|---|---|
| `extract.sh` | Constructs matched variant sets and genotype datasets for matched variant-size FPR analyses. |
| `fpr.sh` | Runs additional null simulations for the standard FPR analysis. |
| `match_fpr.sh` | Runs additional null simulations for the matched variant-size FPR analysis. |
| `match_var.sh` | Runs the original matched variant-size FPR simulations. |
| `merge_fpr_results.sh` | Merges task-level outputs from the additional standard FPR simulations. |
| `pca.sh` | Generates PCA covariates for the matched variant-size FPR datasets. |

## Main software

The workflow uses several commonly used tools in statistical genetics, including:

- PLINK
- GCTA
- R
- METAL
- SuSiE
- SuSiEx
- Bash and SLURM

## Notes

The scripts were developed for a Linux HPC environment using SLURM. Software paths, input directories, output directories, and resource settings are cluster-specific and should be modified before reuse on another system.

Scripts are intended to be run as components of the corresponding analysis workflow rather than as standalone general-purpose software.
