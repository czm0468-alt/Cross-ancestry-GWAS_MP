#!/bin/bash
#SBATCH --job-name=merge_EUR_AFR_chr
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=1
#SBATCH --cpus-per-task=16
#SBATCH --mem=200G
#SBATCH --time=72:00:00
#SBATCH --output=/work/home/chengzesong/data/gwas/merge_EUR_AFR_chr_%j.log

############################################################
# Software
############################################################

PLINK1=/work/home/ac3xibpp15/software/bin/plink
PLINK2=/work/home/chengzesong/software/plink2

THREADS=16

# PLINK1 --memory uses MB.
# Only used for PLINK1 --bmerge.
PLINK1_MEMORY_MB=120000

############################################################
# Input pfiles
############################################################

EUR_COMMON=/work/home/chengzesong/data/gwas/EUR/EUR_5k_common
AFR_COMMON=/work/home/chengzesong/data/gwas/AFR/AFR_common

EUR_RARE=/work/home/chengzesong/data/gwas/EUR/EUR_5k_rare
AFR_RARE=/work/home/chengzesong/data/gwas/AFR/AFR_rare

############################################################
# Final output prefixes
############################################################

OUTPUT_ROOT=/work/home/chengzesong/data/gwas

COMMON_OUT=${OUTPUT_ROOT}/EUR5K_AFR_common
RARE_OUT=${OUTPUT_ROOT}/EUR5K_AFR_rare

############################################################
# Temporary directory
############################################################

TMP=${OUTPUT_ROOT}/tmp_merge_EUR_AFR_chr_${SLURM_JOB_ID}

mkdir -p "$TMP"

############################################################
# Fatal-error handler
############################################################

fatal_exit()
{
    echo
    echo "============================================================"
    echo "[FATAL ERROR] $1"
    echo "[INFO] Temporary files retained in:"
    echo "$TMP"
    echo "============================================================"
    exit 1
}

############################################################
# Merge one variant class
#
# Arguments:
#   1. TYPE
#   2. EUR pfile prefix
#   3. AFR pfile prefix
#   4. Final output prefix
############################################################

merge_one_type()
{
    local TYPE=$1
    local EUR_PFILE=$2
    local AFR_PFILE=$3
    local FINAL_OUT=$4

    local TYPE_TMP
    local PFILE_LIST
    local CHR_DIR
    local EUR_CHR
    local AFR_CHR
    local MERGED_BFILE
    local MERGED_PFILE
    local PLINK_EXIT

    TYPE_TMP=$TMP/$TYPE
    PFILE_LIST=$TYPE_TMP/${TYPE}_chromosome_pfiles.list

    mkdir -p "$TYPE_TMP"

    rm -f "$PFILE_LIST"

    echo
    echo "============================================================"
    echo "[INFO] Starting ${TYPE} chromosome-wise merge"
    echo "[INFO] EUR input: $EUR_PFILE"
    echo "[INFO] AFR input: $AFR_PFILE"
    echo "[INFO] Final output: $FINAL_OUT"
    echo "[INFO] Threads: $THREADS"
    echo "[INFO] PLINK1 memory: ${PLINK1_MEMORY_MB} MB"
    echo "============================================================"

    ########################################################
    # Process chromosomes 1-22 separately
    ########################################################

    for CHR in {1..22}; do

        CHR_DIR=$TYPE_TMP/chr${CHR}

        EUR_CHR=$CHR_DIR/EUR_${TYPE}_chr${CHR}
        AFR_CHR=$CHR_DIR/AFR_${TYPE}_chr${CHR}

        MERGED_BFILE=$CHR_DIR/EUR5K_AFR_${TYPE}_chr${CHR}
        MERGED_PFILE=$TYPE_TMP/EUR5K_AFR_${TYPE}_chr${CHR}

        mkdir -p "$CHR_DIR"

        echo
        echo "############################################################"
        echo "[INFO] TYPE=$TYPE chromosome=$CHR"
        echo "[INFO] Start time: $(date)"
        echo "############################################################"

        ####################################################
        # 1. Extract EUR chromosome and convert to bfile
        ####################################################

        "$PLINK2" \
            --pfile "$EUR_PFILE" \
            --chr "$CHR" \
            --make-bed \
            --threads "$THREADS" \
            --out "$EUR_CHR"

        PLINK_EXIT=$?

        if [ "$PLINK_EXIT" -ne 0 ]; then
            fatal_exit "Failed to extract EUR ${TYPE} chromosome ${CHR}"
        fi

        ####################################################
        # 2. Extract AFR chromosome and convert to bfile
        ####################################################

        "$PLINK2" \
            --pfile "$AFR_PFILE" \
            --chr "$CHR" \
            --make-bed \
            --threads "$THREADS" \
            --out "$AFR_CHR"

        PLINK_EXIT=$?

        if [ "$PLINK_EXIT" -ne 0 ]; then
            fatal_exit "Failed to extract AFR ${TYPE} chromosome ${CHR}"
        fi

        ####################################################
        # 3. Merge EUR and AFR samples on this chromosome
        ####################################################

        echo
        echo "[INFO] Running PLINK1 bmerge for ${TYPE} chromosome ${CHR}"
        date

        "$PLINK1" \
            --bfile "$EUR_CHR" \
            --bmerge "${AFR_CHR}.bed" "${AFR_CHR}.bim" "${AFR_CHR}.fam" \
            --memory "$PLINK1_MEMORY_MB" \
            --make-bed \
            --out "$MERGED_BFILE"

        PLINK_EXIT=$?

        if [ "$PLINK_EXIT" -ne 0 ]; then
            echo
            echo "[ERROR] PLINK1 merge failed for ${TYPE} chromosome ${CHR}"

            if [ -f "${MERGED_BFILE}-merge.missnp" ]; then
                echo "[INFO] Mismatch SNP file:"
                echo "${MERGED_BFILE}-merge.missnp"
            fi

            fatal_exit "Failed to merge EUR and AFR ${TYPE} chromosome ${CHR}"
        fi

        ####################################################
        # 4. Convert merged chromosome bfile to pfile
        ####################################################

        "$PLINK2" \
            --bfile "$MERGED_BFILE" \
            --make-pgen \
            --threads "$THREADS" \
            --out "$MERGED_PFILE"

        PLINK_EXIT=$?

        if [ "$PLINK_EXIT" -ne 0 ]; then
            fatal_exit "Failed to convert merged ${TYPE} chromosome ${CHR} to pfile"
        fi

        ####################################################
        # 5. Add pfile prefix to chromosome list
        ####################################################

        printf "%s\n" "$MERGED_PFILE" >> "$PFILE_LIST"

        ####################################################
        # 6. Remove temporary chromosome bfiles
        ####################################################

        rm -rf "$CHR_DIR"

        echo
        echo "[INFO] Completed ${TYPE} chromosome ${CHR}"
        echo "[INFO] Chromosome pfile: $MERGED_PFILE"
        echo "[INFO] End time: $(date)"

    done

    ########################################################
    # Concatenate chromosome pfiles
    ########################################################

    echo
    echo "============================================================"
    echo "[INFO] Concatenating ${TYPE} chromosomes 1-22"
    echo "[INFO] Pfile list: $PFILE_LIST"
    echo "[INFO] Final output: $FINAL_OUT"
    echo "============================================================"

    "$PLINK2" \
        --pmerge-list "$PFILE_LIST" pfile \
        --make-pgen \
        --threads "$THREADS" \
        --out "$FINAL_OUT"

    PLINK_EXIT=$?

    if [ "$PLINK_EXIT" -ne 0 ]; then
        fatal_exit "Failed to concatenate ${TYPE} chromosome pfiles"
    fi

    ########################################################
    # Check final pfile
    ########################################################

    if [ ! -s "${FINAL_OUT}.pgen" ]; then
        fatal_exit "Final ${TYPE} .pgen file is missing or empty"
    fi

    if [ ! -s "${FINAL_OUT}.pvar" ]; then
        fatal_exit "Final ${TYPE} .pvar file is missing or empty"
    fi

    if [ ! -s "${FINAL_OUT}.psam" ]; then
        fatal_exit "Final ${TYPE} .psam file is missing or empty"
    fi

    echo
    echo "============================================================"
    echo "[INFO] ${TYPE} merge completed"
    echo "[INFO] Final pgen: ${FINAL_OUT}.pgen"
    echo "[INFO] Final pvar: ${FINAL_OUT}.pvar"
    echo "[INFO] Final psam: ${FINAL_OUT}.psam"
    echo "============================================================"

    ########################################################
    # Remove chromosome-specific pfiles after final success
    ########################################################

    rm -rf "$TYPE_TMP"
}

############################################################
# Job information
############################################################

echo
echo "============================================================"
echo "[INFO] Chromosome-wise EUR and AFR pfile merge"
echo "[INFO] Job ID: ${SLURM_JOB_ID}"
echo "[INFO] Start time: $(date)"
echo "[INFO] Requested memory: 200G"
echo "[INFO] PLINK1 workspace memory: ${PLINK1_MEMORY_MB} MB"
echo "[INFO] Threads: ${THREADS}"
echo "[INFO] Temporary directory: ${TMP}"
echo "============================================================"

############################################################
# Merge common variants
############################################################

merge_one_type \
    common \
    "$EUR_COMMON" \
    "$AFR_COMMON" \
    "$COMMON_OUT"

############################################################
# Merge rare variants
############################################################

merge_one_type \
    rare \
    "$EUR_RARE" \
    "$AFR_RARE" \
    "$RARE_OUT"

############################################################
# Cleanup
############################################################

rm -rf "$TMP"

############################################################
# Final summary
############################################################

echo
echo "============================================================"
echo "[INFO] All merges completed successfully"
echo "[INFO] End time: $(date)"
echo
echo "[INFO] Common output:"
echo "${COMMON_OUT}.pgen"
echo "${COMMON_OUT}.pvar"
echo "${COMMON_OUT}.psam"
echo
echo "[INFO] Rare output:"
echo "${RARE_OUT}.pgen"
echo "${RARE_OUT}.pvar"
echo "${RARE_OUT}.psam"
echo "============================================================"