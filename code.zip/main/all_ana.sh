#!/bin/bash
#SBATCH --job-name=combined_random_causal
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=1
#SBATCH --cpus-per-task=3
#SBATCH --array=51-100
#SBATCH --output=/work/home/chengzesong/simu_gwas/add1k/logs/add1k_%A_%a.log
#SBATCH --error=/work/home/chengzesong/simu_gwas/add1k/logs/add1k_%A_%a.err

set -euo pipefail
export LC_ALL=C


############################################################
# Combined simulation pipeline
#
# CPU policy:
#   Slurm allocates 16 CPUs per array task. PLINK, PLINK2, GCTA,
#   SuSiEx, data.table, and multithreaded BLAS/OpenMP components are
#   configured to use up to 16 threads where supported.
#
# For each array task:
#   20 simulation loops are run.
#
# With --array=51-100 and the indexing below:
#   task 51  -> loops 1001-1020
#   task 52  -> loops 1021-1040
#   ...
#   task 100 -> loops 1981-2000
#
# For each loop and each variant class (common / rare):
#   1. Build/select one causal SNP from variants shared by
#      EUR5K and AFR5K.
#   2. The causal SNP is selected ONCE for that loop/type.
#   3. Exactly the same causal SNP is then used in:
#        - pooled EUR5K+AFR5K GWAS
#        - EUR5K ancestry-specific GWAS
#        - AFR5K ancestry-specific GWAS
#        - multi-ancestry SuSiEx
#        - EUR10K single-ancestry GWAS
#        - EUR10K SuSiE
#
# Common and rare analyses necessarily draw from different
# variant sets, so each loop has one common causal SNP and one
# rare causal SNP. Within each variant class, all analyses use
# exactly the same causal SNP.
#
# Random causal SNP selection follows the logic of the older
# script: EUR/AFR SNP-ID intersection + shuf -n1.
#
# No METAL/meta-analysis is performed.
############################################################

############################################################
# 1. Basic settings
############################################################

ROOT=/work/home/chengzesong/simu_gwas

TASK_ID=${SLURM_ARRAY_TASK_ID:-}

if [ -z "$TASK_ID" ]; then
    echo "[ERROR] SLURM_ARRAY_TASK_ID is empty"
    echo "[ERROR] Submit this script as an array job: --array=51-100"
    exit 1
fi

LOOPS_PER_ARRAY=20
LOOP_START=$(( (TASK_ID - 1) * LOOPS_PER_ARRAY + 1 ))
LOOP_END=$(( TASK_ID * LOOPS_PER_ARRAY ))

# All retained outputs are under ADD1K_ROOT.
# IMPORTANT: create $ADD1K_ROOT/logs BEFORE submitting with sbatch,
# because Slurm opens the --output/--error files before this script starts.
ADD1K_ROOT=$ROOT/add1k

POOLED_OUT_DIR=$ADD1K_ROOT/pooled_gwas
EUR_OUT_DIR=$ADD1K_ROOT/single_ancestry_gwas
SUSIE_OUT_DIR=$ADD1K_ROOT/susie
SUSIEX_OUT_DIR=$ADD1K_ROOT/susiex
COMPARE_OUT_DIR=$ADD1K_ROOT/susie_vs_susiex
LD_SUMMARY_DIR=$ADD1K_ROOT/ld_summary
LOG_DIR=$ADD1K_ROOT/logs

# All non-LD summaries and all loop-level files are temporary.
TMP=$ADD1K_ROOT/tmp_${SLURM_ARRAY_JOB_ID:-manual}_${TASK_ID}
RAW_DIR=$TMP/raw_before_ld

mkdir -p "$ADD1K_ROOT"
mkdir -p "$POOLED_OUT_DIR"
mkdir -p "$EUR_OUT_DIR"
mkdir -p "$SUSIE_OUT_DIR"
mkdir -p "$SUSIEX_OUT_DIR"
mkdir -p "$COMPARE_OUT_DIR"
mkdir -p "$LD_SUMMARY_DIR"
mkdir -p "$LOG_DIR"
mkdir -p "$RAW_DIR"

THREADS=3
export THREADS

# Allow software linked against OpenMP / multithreaded BLAS to use all
# CPUs allocated to this Slurm task. Programs that are intrinsically
# single-threaded (e.g. awk/shuf and some R code paths) will still use one CPU.
export OMP_NUM_THREADS="$THREADS"
export OPENBLAS_NUM_THREADS="$THREADS"
export MKL_NUM_THREADS="$THREADS"
export BLIS_NUM_THREADS="$THREADS"
export NUMEXPR_NUM_THREADS="$THREADS"
export R_DATATABLE_NUM_THREADS="$THREADS"

PC_NAMES=PC1,PC2,PC3,PC4,PC5,PC6,PC7,PC8,PC9,PC10

############################################################
# 2. Software
############################################################

PLINK=/work/home/ac3xibpp15/software/bin/plink
GCTA=/work/home/shilulu/software/gcta-1.94.4/gcta
RSCRIPT=/public/software/VersionHub/R/4.5.1/Rscript
SUSIEX=/work/home/chengzesong/software/SusieX/SuSiEx-master/bin_static/SuSiEx
PLINK2=/work/home/chengzesong/software/plink2

############################################################
# 3. Genotype datasets
############################################################

# Common
COMMON_EUR=/work/home/chengzesong/data/gwas/EUR/EUR_5k_common_chr1
COMMON_AFR=/work/home/chengzesong/data/gwas/AFR/AFR_common_chr1
COMMON_EUR_FULL=/work/home/chengzesong/data/gwas/EUR/EUR_10k_common_chr1
COMMON_POOLED=/work/home/chengzesong/data/gwas/all_common_chr1

# Rare
RARE_EUR=/work/home/chengzesong/data/gwas/EUR/EUR_5k_rare_chr1
RARE_AFR=/work/home/chengzesong/data/gwas/AFR/AFR_rare_chr1
RARE_EUR_FULL=/work/home/chengzesong/data/gwas/EUR/EUR_10k_rare_chr1
RARE_POOLED=/work/home/chengzesong/data/gwas/all_rare_chr1

############################################################
# 4. PC covariates
############################################################

# Existing PCA files remain input data; they are not copied into add1k.
PCA_DIR=/work/home/chengzesong/simu_gwas/new_eur/PCA

COMMON_EUR_COVAR=$PCA_DIR/EUR_5k_common_chr1.PC1_10.covariates.txt
COMMON_AFR_COVAR=$PCA_DIR/AFR_common_chr1.PC1_10.covariates.txt
COMMON_EUR_FULL_COVAR=$PCA_DIR/EUR_10k_common_chr1.PC1_10.covariates.txt

RARE_EUR_COVAR=$PCA_DIR/EUR_5k_rare_chr1.PC1_10.covariates.txt
RARE_AFR_COVAR=$PCA_DIR/AFR_rare_chr1.PC1_10.covariates.txt
RARE_EUR_FULL_COVAR=$PCA_DIR/EUR_10k_rare_chr1.PC1_10.covariates.txt

# Existing pooled EUR5K+AFR5K PCA, shared by common and rare GWAS.
POOLED_COVAR=/work/home/chengzesong/simu_gwas/new_pooled/pca/EUR5K_AFR5K_genomewide_common_PCA_PC1_PC10.covar

############################################################
# 5. MAF reference
############################################################

MERGED_FRQ=/work/home/chengzesong/data/gwas/EUR_AFR_maf.frq

# LD reference follows the supplied LD script.
REF_BFILE=/work/home/chengzesong/data/gwas/EUR_AFR_merged

############################################################
# 6. Output files
#
# Raw summaries are written only to $RAW_DIR and are deleted
# after LD r2 has been appended successfully.
#
# Retained files are ONLY the *.with_ld_r2.txt results.
############################################################

# Temporary pre-LD GWAS summaries
COMMON_POOLED_OUT=$RAW_DIR/common_pooled_${TASK_ID}_sig.txt
RARE_POOLED_OUT=$RAW_DIR/rare_pooled_${TASK_ID}_sig.txt

COMMON_EUR_OUT=$RAW_DIR/common_EUR_${TASK_ID}_sig.txt
RARE_EUR_OUT=$RAW_DIR/rare_EUR_${TASK_ID}_sig.txt

# Temporary pre-LD fine-mapping summaries
COMMON_SUSIEX_OUT=$RAW_DIR/common_susiex_${TASK_ID}_summary.txt
RARE_SUSIEX_OUT=$RAW_DIR/rare_susiex_${TASK_ID}_summary.txt

COMMON_SUSIE_OUT=$RAW_DIR/common_EUR_${TASK_ID}_susie_summary.txt
RARE_SUSIE_OUT=$RAW_DIR/rare_EUR_${TASK_ID}_susie_summary.txt

# Temporary pre-LD SuSiE-vs-SuSiEx comparison
COMMON_COMPARE_OUT=$RAW_DIR/common_susie_vs_susiex_${TASK_ID}_comparison.txt
RARE_COMPARE_OUT=$RAW_DIR/rare_susie_vs_susiex_${TASK_ID}_comparison.txt

# Final retained GWAS results with LD r2
COMMON_POOLED_FINAL=$POOLED_OUT_DIR/common_pooled_${TASK_ID}_sig.with_ld_r2.txt
RARE_POOLED_FINAL=$POOLED_OUT_DIR/rare_pooled_${TASK_ID}_sig.with_ld_r2.txt

COMMON_EUR_FINAL=$EUR_OUT_DIR/common_EUR_${TASK_ID}_sig.with_ld_r2.txt
RARE_EUR_FINAL=$EUR_OUT_DIR/rare_EUR_${TASK_ID}_sig.with_ld_r2.txt

# Final retained fine-mapping results with LD r2
COMMON_SUSIEX_FINAL=$SUSIEX_OUT_DIR/common_susiex_${TASK_ID}_summary.with_ld_r2.txt
RARE_SUSIEX_FINAL=$SUSIEX_OUT_DIR/rare_susiex_${TASK_ID}_summary.with_ld_r2.txt

COMMON_SUSIE_FINAL=$SUSIE_OUT_DIR/common_EUR_${TASK_ID}_susie_summary.with_ld_r2.txt
RARE_SUSIE_FINAL=$SUSIE_OUT_DIR/rare_EUR_${TASK_ID}_susie_summary.with_ld_r2.txt

# Final retained paired comparisons. These contain BOTH
# susie_ld_r2 and susiex_ld_r2, plus better_mapping_by_LD.
COMMON_COMPARE_FINAL=$COMPARE_OUT_DIR/common_susie_vs_susiex_${TASK_ID}_comparison.with_ld_r2.txt
RARE_COMPARE_FINAL=$COMPARE_OUT_DIR/rare_susie_vs_susiex_${TASK_ID}_comparison.with_ld_r2.txt

LD_SUMMARY_FINAL=$LD_SUMMARY_DIR/ld_r2_summary_${TASK_ID}.tsv

############################################################
# 7. Shared SNP lists for random causal selection
############################################################

COMMON_SHARED=$TMP/common_EUR_AFR_shared.snplist
RARE_SHARED=$TMP/rare_EUR_AFR_shared.snplist

############################################################
# 8. Utility checks
############################################################

check_bfile()
{
    local BFILE=$1
    local LABEL=$2

    if [ ! -f "${BFILE}.bed" ] || [ ! -f "${BFILE}.bim" ] || [ ! -f "${BFILE}.fam" ]; then
        echo "[ERROR] Incomplete bfile for $LABEL: $BFILE"
        exit 1
    fi
}

check_file()
{
    local FILE=$1
    local LABEL=$2

    if [ ! -s "$FILE" ]; then
        echo "[ERROR] Missing or empty $LABEL: $FILE"
        exit 1
    fi
}

check_executable()
{
    local FILE=$1
    local LABEL=$2

    if [ ! -x "$FILE" ]; then
        echo "[ERROR] $LABEL is not executable: $FILE"
        exit 1
    fi
}

check_pc_header()
{
    local FILE=$1
    local LABEL=$2

    local OK
    OK=$(head -1 "$FILE" | awk '
    {
        required["FID"]=1
        required["IID"]=1
        for(i=1;i<=10;i++) required["PC"i]=1

        for(i=1;i<=NF;i++){
            x=$i
            gsub(/^#/,"",x)
            if(x in required) found[x]=1
        }

        ok=1
        for(x in required){
            if(!(x in found)) ok=0
        }
        print ok
    }')

    if [ "$OK" -ne 1 ]; then
        echo "[ERROR] Invalid PC header for $LABEL"
        echo "[ERROR] File: $FILE"
        head -1 "$FILE"
        exit 1
    fi
}

check_sample_match()
{
    local BFILE=$1
    local COVAR=$2
    local LABEL=$3

    awk 'NR>1{print $1"\t"$2}' "$COVAR" | sort -u > "$TMP/${LABEL}.covar.samples"
    awk 'BEGIN{OFS="\t"}{print $1,$2}' "${BFILE}.fam" | sort -u > "$TMP/${LABEL}.bfile.samples"

    local DIFF
    DIFF=$(comm -3 "$TMP/${LABEL}.covar.samples" "$TMP/${LABEL}.bfile.samples" | wc -l)

    if [ "$DIFF" -ne 0 ]; then
        echo "[ERROR] Sample mismatch between bfile and covariate for $LABEL"
        echo "[ERROR] Unmatched entries: $DIFF"
        exit 1
    fi
}

check_inputs()
{
    check_executable "$PLINK" "PLINK"
    check_executable "$GCTA" "GCTA"
    check_executable "$RSCRIPT" "Rscript"
    check_executable "$SUSIEX" "SuSiEx"
    check_executable "$PLINK2" "PLINK2"

    if ! command -v shuf >/dev/null 2>&1; then
        echo "[ERROR] shuf is not available in PATH"
        exit 1
    fi

    check_bfile "$COMMON_EUR" "COMMON_EUR"
    check_bfile "$COMMON_AFR" "COMMON_AFR"
    check_bfile "$COMMON_EUR_FULL" "COMMON_EUR_FULL"
    check_bfile "$COMMON_POOLED" "COMMON_POOLED"

    check_bfile "$RARE_EUR" "RARE_EUR"
    check_bfile "$RARE_AFR" "RARE_AFR"
    check_bfile "$RARE_EUR_FULL" "RARE_EUR_FULL"
    check_bfile "$RARE_POOLED" "RARE_POOLED"

    check_file "$COMMON_EUR_COVAR" "COMMON_EUR_COVAR"
    check_file "$COMMON_AFR_COVAR" "COMMON_AFR_COVAR"
    check_file "$COMMON_EUR_FULL_COVAR" "COMMON_EUR_FULL_COVAR"

    check_file "$RARE_EUR_COVAR" "RARE_EUR_COVAR"
    check_file "$RARE_AFR_COVAR" "RARE_AFR_COVAR"
    check_file "$RARE_EUR_FULL_COVAR" "RARE_EUR_FULL_COVAR"

    check_file "$POOLED_COVAR" "POOLED_COVAR"
    check_file "$MERGED_FRQ" "MERGED_FRQ"
    check_bfile "$REF_BFILE" "REF_BFILE_FOR_LD"

    check_pc_header "$COMMON_EUR_COVAR" "COMMON_EUR_COVAR"
    check_pc_header "$COMMON_AFR_COVAR" "COMMON_AFR_COVAR"
    check_pc_header "$COMMON_EUR_FULL_COVAR" "COMMON_EUR_FULL_COVAR"

    check_pc_header "$RARE_EUR_COVAR" "RARE_EUR_COVAR"
    check_pc_header "$RARE_AFR_COVAR" "RARE_AFR_COVAR"
    check_pc_header "$RARE_EUR_FULL_COVAR" "RARE_EUR_FULL_COVAR"

    check_pc_header "$POOLED_COVAR" "POOLED_COVAR"

    check_sample_match "$COMMON_EUR" "$COMMON_EUR_COVAR" "common_EUR"
    check_sample_match "$COMMON_AFR" "$COMMON_AFR_COVAR" "common_AFR"
    check_sample_match "$COMMON_EUR_FULL" "$COMMON_EUR_FULL_COVAR" "common_EUR_FULL"
    check_sample_match "$COMMON_POOLED" "$POOLED_COVAR" "common_POOLED"

    check_sample_match "$RARE_EUR" "$RARE_EUR_COVAR" "rare_EUR"
    check_sample_match "$RARE_AFR" "$RARE_AFR_COVAR" "rare_AFR"
    check_sample_match "$RARE_EUR_FULL" "$RARE_EUR_FULL_COVAR" "rare_EUR_FULL"
    check_sample_match "$RARE_POOLED" "$POOLED_COVAR" "rare_POOLED"
}

############################################################
# 9. Build EUR-AFR shared SNP lists
#    This follows the random-causal logic in script 3.
############################################################

build_shared_list()
{
    local EUR_BFILE=$1
    local AFR_BFILE=$2
    local OUT=$3
    local LABEL=$4

    # IMPORTANT: sort and comm must use exactly the same collation order.
    # Use explicit temporary sorted files under LC_ALL=C to avoid
    # "comm: file is not in sorted order" on clusters with a non-C locale.
    local EUR_SORTED="$TMP/${LABEL}.EUR.sorted.snplist"
    local AFR_SORTED="$TMP/${LABEL}.AFR.sorted.snplist"

    awk '{gsub(/\r/,"",$2); if($2!="") print $2}' "${EUR_BFILE}.bim" | LC_ALL=C sort --parallel="$THREADS" -u > "$EUR_SORTED"
    awk '{gsub(/\r/,"",$2); if($2!="") print $2}' "${AFR_BFILE}.bim" | LC_ALL=C sort --parallel="$THREADS" -u > "$AFR_SORTED"

    LC_ALL=C comm -12 "$EUR_SORTED" "$AFR_SORTED" > "$OUT"

    rm -f "$EUR_SORTED" "$AFR_SORTED"

    local N
    N=$(wc -l < "$OUT")

    echo "[INFO] $LABEL EUR-AFR shared SNPs: $N"

    if [ "$N" -lt 1 ]; then
        echo "[ERROR] No EUR-AFR shared SNPs for $LABEL"
        exit 1
    fi
}

############################################################
# 10. Pick one random causal SNP for one loop/type
#
# Random draw is from EUR-AFR shared SNPs. To guarantee the
# same causal SNP can be used by every analysis in the merged
# pipeline, the selected SNP is also required to be present in
# the pooled EUR5K+AFR5K dataset and EUR10K dataset.
############################################################

pick_random_causal()
{
    local SHARED_LIST=$1
    local EUR_BFILE=$2
    local AFR_BFILE=$3
    local POOLED_BFILE=$4
    local EUR_FULL_BFILE=$5
    local TYPE=$6
    local LOOP_ID=$7

    local ATTEMPT=0
    local MAX_ATTEMPTS=1000

    while [ "$ATTEMPT" -lt "$MAX_ATTEMPTS" ]; do
        ATTEMPT=$((ATTEMPT + 1))

        local SNP
        SNP=$(shuf -n1 "$SHARED_LIST")

        [ -z "$SNP" ] && continue

        local EUR_INFO AFR_INFO POOLED_INFO FULL_INFO
        EUR_INFO=$(awk -v s="$SNP" '$2==s{print $1" "$4; exit}' "${EUR_BFILE}.bim")
        AFR_INFO=$(awk -v s="$SNP" '$2==s{print $1" "$4; exit}' "${AFR_BFILE}.bim")
        POOLED_INFO=$(awk -v s="$SNP" '$2==s{print $1" "$4; exit}' "${POOLED_BFILE}.bim")
        FULL_INFO=$(awk -v s="$SNP" '$2==s{print $1" "$4; exit}' "${EUR_FULL_BFILE}.bim")

        if [ -z "$EUR_INFO" ] || [ -z "$AFR_INFO" ] || [ -z "$POOLED_INFO" ] || [ -z "$FULL_INFO" ]; then
            continue
        fi

        # Require consistent chromosome and BP across all datasets.
        if [ "$EUR_INFO" != "$AFR_INFO" ] || [ "$EUR_INFO" != "$POOLED_INFO" ] || [ "$EUR_INFO" != "$FULL_INFO" ]; then
            continue
        fi

        local CHR BP
        read -r CHR BP <<< "$EUR_INFO"

        echo "$SNP $CHR $BP"
        return 0
    done

    echo "[ERROR] Could not obtain a valid shared causal SNP after $MAX_ATTEMPTS attempts for type=$TYPE loop=$LOOP_ID" >&2
    return 1
}

############################################################
# 11. Initialise outputs
############################################################

init_outputs()
{
    local GWAS_HEADER
    GWAS_HEADER="loop\tlead_SNP\tlead_CHR\tlead_BP\tlead_A1\tlead_A2\tlead_BETA\tlead_SE\tlead_P\tlead_MAF\tcausal_SNP\tcausal_CHR\tcausal_BP\tcausal_A1\tcausal_A2\tcausal_BETA\tcausal_SE\tcausal_P\tcausal_MAF\tMAF_diff\tBP_diff"

    printf "%b\n" "$GWAS_HEADER" > "$COMMON_POOLED_OUT"
    printf "%b\n" "$GWAS_HEADER" > "$RARE_POOLED_OUT"
    printf "%b\n" "$GWAS_HEADER" > "$COMMON_EUR_OUT"
    printf "%b\n" "$GWAS_HEADER" > "$RARE_EUR_OUT"

    local FM_HEADER
    FM_HEADER="loop\tmethod\tvariant_type\tfine_mapped_SNP\tfine_mapped_CHR\tfine_mapped_BP\tfine_mapped_MAF\tpip_max\tcausal_SNP\tcausal_CHR\tcausal_BP\tcausal_MAF\tBP_diff\tMAF_diff\texact_match\tmean_cs_size\tn_cs"

    printf "%b\n" "$FM_HEADER" > "$COMMON_SUSIEX_OUT"
    printf "%b\n" "$FM_HEADER" > "$RARE_SUSIEX_OUT"
    printf "%b\n" "$FM_HEADER" > "$COMMON_SUSIE_OUT"
    printf "%b\n" "$FM_HEADER" > "$RARE_SUSIE_OUT"

    local CMP_HEADER
    CMP_HEADER="loop\tvariant_type\tsusie_mean_cs_size\tsusiex_mean_cs_size\tcs_size_difference\tsmaller_cs_method\tcs_size_equal\tsusie_pip_max\tsusiex_pip_max\thigher_pip_method_when_cs_equal\tsusie_fine_mapped_SNP\tsusiex_fine_mapped_SNP\tcausal_SNP\tsusie_BP_diff\tsusiex_BP_diff\tsusie_MAF_diff\tsusiex_MAF_diff\tsusie_exact_match\tsusiex_exact_match\tbetter_mapping_by_BP\tbetter_mapping_by_MAF"

    printf "%b\n" "$CMP_HEADER" > "$COMMON_COMPARE_OUT"
    printf "%b\n" "$CMP_HEADER" > "$RARE_COMPARE_OUT"

}

############################################################
# 12. Shared inverse-normal transformation script
############################################################

INVNORM_R=$TMP/invnorm.R

cat > "$INVNORM_R" <<'EOF_R'
phen <- read.table(
    "sim.phen",
    header = FALSE,
    stringsAsFactors = FALSE
)

phen$V3 <- qnorm(
    rank(phen$V3, ties.method = "average") /
        (nrow(phen) + 1)
)

write.table(
    phen,
    file = "sim.phen.invnorm",
    quote = FALSE,
    row.names = FALSE,
    col.names = FALSE
)
EOF_R

############################################################
# 13. General helpers
############################################################

get_maf()
{
    local SNP=$1
    local MAF

    MAF=$(awk -v s="$SNP" '$2==s{print $5; exit}' "$MERGED_FRQ")

    if [ -z "$MAF" ]; then
        echo "NA"
    else
        echo "$MAF"
    fi
}

abs_diff_or_na()
{
    local A=$1
    local B=$2

    if [ "$A" = "NA" ] || [ "$B" = "NA" ] || [ -z "$A" ] || [ -z "$B" ]; then
        echo "NA"
    else
        awk -v a="$A" -v b="$B" 'BEGIN{d=a-b; if(d<0)d=-d; print d}'
    fi
}

write_gwas_result()
{
    local LOOP_ID=$1
    local OUT_FILE=$2
    local LEAD_SNP=$3
    local LEAD_CHR=$4
    local LEAD_BP=$5
    local LEAD_A1=$6
    local LEAD_A2=$7
    local LEAD_BETA=$8
    local LEAD_SE=$9
    local LEAD_P=${10}
    local LEAD_MAF=${11}
    local CAUSAL_SNP=${12}
    local CAUSAL_CHR=${13}
    local CAUSAL_BP=${14}
    local CAUSAL_A1=${15}
    local CAUSAL_A2=${16}
    local CAUSAL_BETA=${17}
    local CAUSAL_SE=${18}
    local CAUSAL_P=${19}
    local CAUSAL_MAF=${20}

    local MAF_DIFF BP_DIFF
    MAF_DIFF=$(abs_diff_or_na "$LEAD_MAF" "$CAUSAL_MAF")
    BP_DIFF=$(abs_diff_or_na "$LEAD_BP" "$CAUSAL_BP")

    printf "%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\n" \
        "$LOOP_ID" "$LEAD_SNP" "$LEAD_CHR" "$LEAD_BP" "$LEAD_A1" "$LEAD_A2" "$LEAD_BETA" "$LEAD_SE" "$LEAD_P" "$LEAD_MAF" \
        "$CAUSAL_SNP" "$CAUSAL_CHR" "$CAUSAL_BP" "$CAUSAL_A1" "$CAUSAL_A2" "$CAUSAL_BETA" "$CAUSAL_SE" "$CAUSAL_P" "$CAUSAL_MAF" \
        "$MAF_DIFF" "$BP_DIFF" \
        >> "$OUT_FILE"
}

write_fm_na()
{
    local LOOP_ID=$1
    local METHOD=$2
    local TYPE=$3
    local OUT_FILE=$4
    local CAUSAL=$5
    local CAUSAL_CHR=$6
    local CAUSAL_BP=$7
    local CAUSAL_MAF=$8

    printf "%s\t%s\t%s\tNA\tNA\tNA\tNA\tNA\t%s\t%s\t%s\t%s\tNA\tNA\t0\tNA\t0\n" \
        "$LOOP_ID" "$METHOD" "$TYPE" \
        "$CAUSAL" "$CAUSAL_CHR" "$CAUSAL_BP" "$CAUSAL_MAF" \
        >> "$OUT_FILE"
}

############################################################
# 14. Run one GWAS in one dataset/window
#
# The causal SNP is PASSED IN as an argument. It is never
# re-sampled inside this function.
############################################################

run_window_gwas()
{
    local LABEL=$1
    local BFILE=$2
    local COVAR=$3
    local CAUSAL=$4
    local CAUSAL_CHR=$5
    local REGION_START=$6
    local REGION_END=$7
    local DIR=$8

    mkdir -p "$DIR"

    "$PLINK" \
        --bfile "$BFILE" \
        --chr "$CAUSAL_CHR" \
        --from-bp "$REGION_START" \
        --to-bp "$REGION_END" \
        --make-bed \
        --threads "$THREADS" \
        --out "$DIR/win"

    if [ ! -f "$DIR/win.bed" ]; then
        echo "[WARNING] Window extraction failed for $LABEL"
        return 1
    fi

    if ! awk -v s="$CAUSAL" '$2==s{found=1; exit} END{exit(found ? 0 : 1)}' "$DIR/win.bim"; then
        echo "[WARNING] Causal SNP absent from $LABEL window: $CAUSAL"
        return 1
    fi

    printf "%s 1\n" "$CAUSAL" > "$DIR/seed"

    "$GCTA" \
        --bfile "$DIR/win" \
        --simu-qt \
        --simu-causal-loci "$DIR/seed" \
        --simu-hsq 0.02 \
        --thread-num "$THREADS" \
        --out "$DIR/sim"

    if [ ! -f "$DIR/sim.phen" ]; then
        echo "[WARNING] GCTA simulation failed for $LABEL"
        return 1
    fi

    (
        cd "$DIR" || exit 1
        "$RSCRIPT" --vanilla "$INVNORM_R"
    )

    if [ ! -f "$DIR/sim.phen.invnorm" ]; then
        echo "[WARNING] Inverse-normal phenotype missing for $LABEL"
        return 1
    fi

    "$PLINK" \
        --bfile "$DIR/win" \
        --pheno "$DIR/sim.phen.invnorm" \
        --covar "$COVAR" \
        --covar-name "$PC_NAMES" \
        --linear hide-covar \
        --allow-no-sex \
        --threads "$THREADS" \
        --out "$DIR/gwas"

    if [ ! -f "$DIR/gwas.assoc.linear" ]; then
        echo "[WARNING] PC-adjusted GWAS failed for $LABEL"
        return 1
    fi

    # Summary statistics for SuSiEx input.
    # SNP A1 A2 BETA SE P N
    awk 'BEGIN{
            OFS="\t";
            print "SNP","A1","A2","BETA","SE","P","N"
         }
         NR==FNR{
            a1[$2]=$5
            a2[$2]=$6
            next
         }
         FNR>1 && $5=="ADD" && $7!="NA" && $8!="NA" && $8!=0 && $9!="NA"{
            se=$7/$8
            if(se<0) se=-se
            print $2,a1[$2],a2[$2],$7,se,$9,$6
         }' \
         "$DIR/win.bim" \
         "$DIR/gwas.assoc.linear" \
         > "$DIR/summary.tsv"

    return 0
}

############################################################
# 15. Extract lead + causal records from one GWAS
############################################################

extract_gwas_result()
{
    local LOOP_ID=$1
    local DIR=$2
    local OUT_FILE=$3
    local CAUSAL=$4
    local CAUSAL_CHR=$5
    local CAUSAL_BP=$6
    local CAUSAL_MAF=$7
    local LABEL=$8

    local GWAS_FILE=$DIR/gwas.assoc.linear

    if [ ! -f "$GWAS_FILE" ]; then
        echo "[WARNING] Missing GWAS file for $LABEL loop=$LOOP_ID"
        return 1
    fi

    local LEAD_LINE
    LEAD_LINE=$(awk 'NR>1 && $5=="ADD" && $7!="NA" && $8!="NA" && $9!="NA"{
        p=$9+0
        if(min=="" || p<min){
            min=p
            line=$1" "$2" "$3" "$4" "$6" "$7" "$8" "$9
        }
    }
    END{if(line!="") print line}' "$GWAS_FILE")

    if [ -z "$LEAD_LINE" ]; then
        echo "[WARNING] No valid lead SNP for $LABEL loop=$LOOP_ID"
        return 1
    fi

    local LEAD_CHR LEAD_SNP LEAD_BP LEAD_A1 LEAD_N LEAD_BETA LEAD_STAT LEAD_P
    read -r LEAD_CHR LEAD_SNP LEAD_BP LEAD_A1 LEAD_N LEAD_BETA LEAD_STAT LEAD_P <<< "$LEAD_LINE"

    local LEAD_A2 LEAD_SE LEAD_MAF
    LEAD_A2=$(awk -v s="$LEAD_SNP" '$2==s{print $6; exit}' "$DIR/win.bim")
    [ -z "$LEAD_A2" ] && LEAD_A2="NA"

    LEAD_SE=$(awk -v b="$LEAD_BETA" -v s="$LEAD_STAT" 'BEGIN{
        if(b!="NA" && s!="NA" && s!=0){
            x=b/s
            if(x<0)x=-x
            print x
        } else {
            print "NA"
        }
    }')

    LEAD_MAF=$(get_maf "$LEAD_SNP")

    local CAUSAL_LINE
    CAUSAL_LINE=$(awk -v s="$CAUSAL" 'NR>1 && $2==s && $5=="ADD"{print $4,$7,$8,$9; exit}' "$GWAS_FILE")

    local CAUSAL_A1 CAUSAL_BETA CAUSAL_STAT CAUSAL_P
    if [ -n "$CAUSAL_LINE" ]; then
        read -r CAUSAL_A1 CAUSAL_BETA CAUSAL_STAT CAUSAL_P <<< "$CAUSAL_LINE"
    else
        CAUSAL_A1="NA"
        CAUSAL_BETA="NA"
        CAUSAL_STAT="NA"
        CAUSAL_P="NA"
    fi

    local CAUSAL_A2 CAUSAL_SE
    CAUSAL_A2=$(awk -v s="$CAUSAL" '$2==s{print $6; exit}' "$DIR/win.bim")
    [ -z "$CAUSAL_A2" ] && CAUSAL_A2="NA"

    CAUSAL_SE=$(awk -v b="$CAUSAL_BETA" -v s="$CAUSAL_STAT" 'BEGIN{
        if(b!="NA" && s!="NA" && s!=0){
            x=b/s
            if(x<0)x=-x
            print x
        } else {
            print "NA"
        }
    }')

    write_gwas_result \
        "$LOOP_ID" "$OUT_FILE" \
        "$LEAD_SNP" "$LEAD_CHR" "$LEAD_BP" "$LEAD_A1" "$LEAD_A2" "$LEAD_BETA" "$LEAD_SE" "$LEAD_P" "$LEAD_MAF" \
        "$CAUSAL" "$CAUSAL_CHR" "$CAUSAL_BP" "$CAUSAL_A1" "$CAUSAL_A2" "$CAUSAL_BETA" "$CAUSAL_SE" "$CAUSAL_P" "$CAUSAL_MAF"

    return 0
}

############################################################
# 16. EUR10K SuSiE
############################################################

run_susie()
{
    local LOOP_ID=$1
    local TYPE=$2
    local DIR=$3
    local CAUSAL=$4
    local CAUSAL_CHR=$5
    local CAUSAL_BP=$6
    local CAUSAL_MAF=$7
    local OUT_FILE=$8

    local FM_START=$(( CAUSAL_BP - 1000000 ))
    local FM_END=$(( CAUSAL_BP + 1000000 ))
    [ "$FM_START" -lt 0 ] && FM_START=0

    local FM_DIR=$DIR/susie
    mkdir -p "$FM_DIR"

    "$PLINK" \
        --bfile "$DIR/win" \
        --chr "$CAUSAL_CHR" \
        --from-bp "$FM_START" \
        --to-bp "$FM_END" \
        --make-bed \
        --threads "$THREADS" \
        --out "$FM_DIR/locus"

    if [ ! -f "$FM_DIR/locus.bim" ]; then
        echo "[WARNING] SuSiE locus extraction failed type=$TYPE loop=$LOOP_ID"
        write_fm_na "$LOOP_ID" "SuSiE" "$TYPE" "$OUT_FILE" "$CAUSAL" "$CAUSAL_CHR" "$CAUSAL_BP" "$CAUSAL_MAF"
        return 1
    fi

    "$PLINK" \
        --bfile "$FM_DIR/locus" \
        --r square gz \
        --threads "$THREADS" \
        --out "$FM_DIR/ld"

    cut -f2 "$FM_DIR/locus.bim" > "$FM_DIR/snp_order.txt"
    cp "$DIR/gwas.assoc.linear" "$FM_DIR/gwas.assoc.linear"

    (
        cd "$FM_DIR" || exit 1

        "$RSCRIPT" --vanilla - <<'EOF_R'
suppressPackageStartupMessages({
    library(data.table)
    library(susieR)
})

threads <- as.integer(Sys.getenv("THREADS"))
if (is.na(threads) || threads < 1L) threads <- 1L
data.table::setDTthreads(threads)

gwas <- fread("gwas.assoc.linear")
setnames(gwas, trimws(names(gwas)))

gwas[, P := as.numeric(P)]
gwas[, BETA := as.numeric(BETA)]
gwas[, STAT := as.numeric(STAT)]
gwas[, NMISS := as.numeric(NMISS)]

gwas <- gwas[
    TEST == "ADD" &
    !is.na(P) &
    !is.na(STAT) &
    !is.na(NMISS)
]

snps0 <- fread("snp_order.txt", header = FALSE)$V1
common <- intersect(snps0, gwas$SNP)

cat("LD SNP:", length(snps0), "\n")
cat("GWAS SNP:", nrow(gwas), "\n")
cat("COMMON SNP:", length(common), "\n")

if (length(common) < 10) {
    stop("ERROR: too few overlapping SNPs")
}

idx <- match(common, snps0)
gwas <- gwas[match(common, SNP)]

R <- as.matrix(fread("ld.ld.gz"))
R <- R[idx, idx, drop = FALSE]

z <- gwas$STAT

fit <- susie_rss(
    z = z,
    R = R,
    n = max(gwas$NMISS, na.rm = TRUE),
    L = 10,
    estimate_residual_variance = TRUE
)

pip_dt <- data.table(SNP = common, PIP = fit$pip)
fwrite(pip_dt, "susie_pip.txt", sep = "\t")

cs <- susie_get_cs(fit)
saveRDS(fit, "susie_fit.rds")
saveRDS(cs, "susie_cs.rds")

if (!is.null(cs$cs) && length(cs$cs) > 0) {
    cs_sizes <- sapply(cs$cs, length)
    mean_cs_size <- mean(cs_sizes)
    n_cs <- length(cs_sizes)
    fwrite(
        data.table(cs = names(cs_sizes), cs_size = as.numeric(cs_sizes)),
        "cs_size_detail.txt",
        sep = "\t"
    )
} else {
    mean_cs_size <- NA_real_
    n_cs <- 0
    fwrite(
        data.table(cs = character(), cs_size = numeric()),
        "cs_size_detail.txt",
        sep = "\t"
    )
}

top <- pip_dt[which.max(PIP)]

fwrite(
    data.table(
        top_snp = top$SNP,
        pip_max = top$PIP,
        mean_cs_size = mean_cs_size,
        n_cs = n_cs
    ),
    "susie_metrics.txt",
    sep = "\t"
)
EOF_R
    ) || {
        echo "[WARNING] SuSiE failed type=$TYPE loop=$LOOP_ID"
        write_fm_na "$LOOP_ID" "SuSiE" "$TYPE" "$OUT_FILE" "$CAUSAL" "$CAUSAL_CHR" "$CAUSAL_BP" "$CAUSAL_MAF"
        return 1
    }

    local TOP_SNP PIP_MAX MEAN_CS_SIZE N_CS
    read -r TOP_SNP PIP_MAX MEAN_CS_SIZE N_CS <<< "$(awk 'NR==2{print $1,$2,$3,$4}' "$FM_DIR/susie_metrics.txt")"

    [ -z "$TOP_SNP" ] && TOP_SNP="NA"
    [ -z "$PIP_MAX" ] && PIP_MAX="NA"
    [ -z "$MEAN_CS_SIZE" ] && MEAN_CS_SIZE="NA"
    [ -z "$N_CS" ] && N_CS="0"

    local TOP_CHR TOP_BP TOP_MAF BP_DIFF MAF_DIFF EXACT_MATCH

    if [ "$TOP_SNP" != "NA" ]; then
        local TOP_INFO
        TOP_INFO=$(awk -v s="$TOP_SNP" '$2==s{print $1" "$4; exit}' "$FM_DIR/locus.bim")
        if [ -n "$TOP_INFO" ]; then
            read -r TOP_CHR TOP_BP <<< "$TOP_INFO"
        else
            TOP_CHR="NA"
            TOP_BP="NA"
        fi
        TOP_MAF=$(get_maf "$TOP_SNP")
    else
        TOP_CHR="NA"
        TOP_BP="NA"
        TOP_MAF="NA"
    fi

    BP_DIFF=$(abs_diff_or_na "$TOP_BP" "$CAUSAL_BP")
    MAF_DIFF=$(abs_diff_or_na "$TOP_MAF" "$CAUSAL_MAF")

    if [ "$TOP_SNP" = "$CAUSAL" ]; then
        EXACT_MATCH=1
    else
        EXACT_MATCH=0
    fi

    printf "%s\tSuSiE\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\n" \
        "$LOOP_ID" "$TYPE" \
        "$TOP_SNP" "$TOP_CHR" "$TOP_BP" "$TOP_MAF" "$PIP_MAX" \
        "$CAUSAL" "$CAUSAL_CHR" "$CAUSAL_BP" "$CAUSAL_MAF" \
        "$BP_DIFF" "$MAF_DIFF" "$EXACT_MATCH" "$MEAN_CS_SIZE" "$N_CS" \
        >> "$OUT_FILE"

    return 0
}

############################################################
# 17. Multi-ancestry SuSiEx
############################################################

run_susiex()
{
    local LOOP_ID=$1
    local TYPE=$2
    local LOOP_DIR=$3
    local EUR_BFILE=$4
    local AFR_BFILE=$5
    local CAUSAL=$6
    local CAUSAL_CHR=$7
    local CAUSAL_BP=$8
    local CAUSAL_MAF=$9
    local OUT_FILE=${10}

    local FM_DIR=$LOOP_DIR/susiex
    mkdir -p "$FM_DIR"

    local FM_START=$(( CAUSAL_BP - 1000000 ))
    local FM_END=$(( CAUSAL_BP + 1000000 ))
    [ "$FM_START" -lt 0 ] && FM_START=0

    local RUN_SUSIEX=1
    local POP BFILE

    for POP in EUR AFR; do
        if [ "$POP" = "EUR" ]; then
            BFILE=$EUR_BFILE
        else
            BFILE=$AFR_BFILE
        fi

        "$PLINK" \
            --bfile "$BFILE" \
            --chr "$CAUSAL_CHR" \
            --from-bp "$FM_START" \
            --to-bp "$FM_END" \
            --make-bed \
            --threads "$THREADS" \
            --out "$FM_DIR/${POP}.fmwin"

        if [ ! -f "$FM_DIR/${POP}.fmwin.bed" ]; then
            echo "[WARNING] SuSiEx window extraction failed for $POP type=$TYPE loop=$LOOP_ID"
            RUN_SUSIEX=0
        fi
    done

    if [ "$RUN_SUSIEX" -eq 1 ]; then
        for POP in EUR AFR; do
            local N
            N=$(wc -l < "$LOOP_DIR/$POP/win.fam")

            awk -v n="$N" 'BEGIN{
                    OFS="\t";
                    print "CHR","SNP","BP","A1","A2","BETA","SE","P","N"
                 }
                 NR==FNR{
                    if(FNR>1){
                        a1[$1]=$2
                        a2[$1]=$3
                        beta[$1]=$4
                        se[$1]=$5
                        p[$1]=$6
                    }
                    next
                 }
                 {
                    snp=$2
                    if(snp in beta && beta[snp]!="NA" && se[snp]!="NA" && p[snp]!="NA" && se[snp]>0){
                        print $1,snp,$4,a1[snp],a2[snp],beta[snp],se[snp],p[snp],n
                    }
                 }' \
                 "$LOOP_DIR/$POP/summary.tsv" \
                 "$FM_DIR/${POP}.fmwin.bim" \
                 > "$FM_DIR/${POP}.susiex.tsv"

            local N_SUM
            N_SUM=$(awk 'NR>1{n++} END{print n+0}' "$FM_DIR/${POP}.susiex.tsv")

            if [ "$N_SUM" -lt 10 ]; then
                echo "[WARNING] Too few SuSiEx SNPs for $POP type=$TYPE loop=$LOOP_ID: $N_SUM"
                RUN_SUSIEX=0
            fi
        done
    fi

    if [ "$RUN_SUSIEX" -eq 1 ]; then
        rm -rf "$FM_DIR/out"
        mkdir -p "$FM_DIR/out"

        local N_EUR N_AFR
        N_EUR=$(wc -l < "$LOOP_DIR/EUR/win.fam")
        N_AFR=$(wc -l < "$LOOP_DIR/AFR/win.fam")

        "$SUSIEX" \
            --sst_file="$FM_DIR/EUR.susiex.tsv,$FM_DIR/AFR.susiex.tsv" \
            --n_gwas="$N_EUR,$N_AFR" \
            --ref_file="$FM_DIR/EUR.fmwin,$FM_DIR/AFR.fmwin" \
            --ld_file="$FM_DIR/out/EUR,$FM_DIR/out/AFR" \
            --out_dir="$FM_DIR/out" \
            --out_name=susiex \
            --chr="$CAUSAL_CHR" \
            --bp="${FM_START},${FM_END}" \
            --chr_col=1,1 \
            --snp_col=2,2 \
            --bp_col=3,3 \
            --a1_col=4,4 \
            --a2_col=5,5 \
            --eff_col=6,6 \
            --se_col=7,7 \
            --pval_col=8,8 \
            --plink="$PLINK" \
            --keep-ambig=TRUE \
            --n_sig=10 \
            --level=0.95 \
            --min_purity=0.5 \
            --threads="$THREADS" || RUN_SUSIEX=0
    fi

    if [ "$RUN_SUSIEX" -ne 1 ]; then
        echo "[WARNING] SuSiEx skipped/failed type=$TYPE loop=$LOOP_ID"
        write_fm_na "$LOOP_ID" "SuSiEx" "$TYPE" "$OUT_FILE" "$CAUSAL" "$CAUSAL_CHR" "$CAUSAL_BP" "$CAUSAL_MAF"
        return 1
    fi

    local SUSIEX_SNP=$FM_DIR/out/susiex.snp
    local SUSIEX_CS=$FM_DIR/out/susiex.cs
    local SUSIEX_SUMMARY=$FM_DIR/out/susiex.summary

    local TOP_SNP TOP_BP PIP_MAX

    if [ -f "$SUSIEX_SNP" ]; then
        read -r TOP_SNP TOP_BP PIP_MAX <<< "$(awk '
            NR==1{next}
            {
                pip=$3+0
                if(max=="" || pip>max){
                    max=pip
                    bp=$1
                    snp=$2
                }
            }
            END{
                if(snp!="") print snp,bp,max
                else print "NA NA NA"
            }' "$SUSIEX_SNP")"
    else
        TOP_SNP="NA"
        TOP_BP="NA"
        PIP_MAX="NA"
    fi

    if [ "$TOP_SNP" = "NA" ] && [ -f "$SUSIEX_SUMMARY" ]; then
        read -r TOP_SNP TOP_BP PIP_MAX <<< "$(awk '
            BEGIN{max=-1}
            /^#/ {next}
            $1=="CS_ID" {next}
            NF>=12 {
                pip=$12+0
                if(pip>max){
                    max=pip
                    snp=$4
                    bp=$5
                }
            }
            END{
                if(max>=0) print snp,bp,max
                else print "NA NA NA"
            }' "$SUSIEX_SUMMARY")"
    fi

    local MEAN_CS_SIZE N_CS

    if [ -f "$SUSIEX_CS" ]; then
        read -r MEAN_CS_SIZE N_CS <<< "$(awk '
            NR==1{next}
            {count[$1]++}
            END{
                n=0
                sum=0
                for(cs in count){
                    n++
                    sum+=count[cs]
                }
                if(n>0) print sum/n,n
                else print "NA 0"
            }' "$SUSIEX_CS")"
    elif [ -f "$SUSIEX_SUMMARY" ]; then
        read -r MEAN_CS_SIZE N_CS <<< "$(awk '
            BEGIN{sum=0; n=0}
            /^#/ {next}
            $1=="CS_ID" {next}
            NF>=2 && $2!="NA" {
                sum += $2
                n++
            }
            END{
                if(n>0) print sum/n,n
                else print "NA 0"
            }' "$SUSIEX_SUMMARY")"
    else
        MEAN_CS_SIZE="NA"
        N_CS="0"
    fi

    [ -z "$TOP_SNP" ] && TOP_SNP="NA"
    [ -z "$TOP_BP" ] && TOP_BP="NA"
    [ -z "$PIP_MAX" ] && PIP_MAX="NA"
    [ -z "$MEAN_CS_SIZE" ] && MEAN_CS_SIZE="NA"
    [ -z "$N_CS" ] && N_CS="0"

    local TOP_CHR TOP_MAF BP_DIFF MAF_DIFF EXACT_MATCH

    if [ "$TOP_SNP" != "NA" ]; then
        TOP_CHR=$(awk -v s="$TOP_SNP" '$2==s{print $1; exit}' "$FM_DIR/EUR.fmwin.bim")
        if [ -z "$TOP_CHR" ]; then
            TOP_CHR=$(awk -v s="$TOP_SNP" '$2==s{print $1; exit}' "$FM_DIR/AFR.fmwin.bim")
        fi
        TOP_MAF=$(get_maf "$TOP_SNP")
    else
        TOP_CHR="NA"
        TOP_MAF="NA"
    fi

    [ -z "$TOP_CHR" ] && TOP_CHR="NA"
    [ -z "$TOP_MAF" ] && TOP_MAF="NA"

    BP_DIFF=$(abs_diff_or_na "$TOP_BP" "$CAUSAL_BP")
    MAF_DIFF=$(abs_diff_or_na "$TOP_MAF" "$CAUSAL_MAF")

    if [ "$TOP_SNP" = "$CAUSAL" ]; then
        EXACT_MATCH=1
    else
        EXACT_MATCH=0
    fi

    printf "%s\tSuSiEx\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\n" \
        "$LOOP_ID" "$TYPE" \
        "$TOP_SNP" "$TOP_CHR" "$TOP_BP" "$TOP_MAF" "$PIP_MAX" \
        "$CAUSAL" "$CAUSAL_CHR" "$CAUSAL_BP" "$CAUSAL_MAF" \
        "$BP_DIFF" "$MAF_DIFF" "$EXACT_MATCH" "$MEAN_CS_SIZE" "$N_CS" \
        >> "$OUT_FILE"

    return 0
}

############################################################
# 18. Pairwise SuSiE vs SuSiEx comparison
############################################################

append_comparison()
{
    local LOOP_ID=$1
    local TYPE=$2
    local SUSIE_OUT=$3
    local SUSIEX_OUT=$4
    local COMPARE_OUT=$5

    local SUSIE_LINE SUSIEX_LINE

    SUSIE_LINE=$(awk -v loop="$LOOP_ID" -v type="$TYPE" 'NR>1 && $1==loop && $3==type{line=$0} END{print line}' "$SUSIE_OUT")
    SUSIEX_LINE=$(awk -v loop="$LOOP_ID" -v type="$TYPE" 'NR>1 && $1==loop && $3==type{line=$0} END{print line}' "$SUSIEX_OUT")

    if [ -z "$SUSIE_LINE" ] || [ -z "$SUSIEX_LINE" ]; then
        echo "[WARNING] Missing SuSiE/SuSiEx line for comparison type=$TYPE loop=$LOOP_ID"
        return 0
    fi

    awk -v sline="$SUSIE_LINE" -v xline="$SUSIEX_LINE" '
    BEGIN{
        FS=OFS="\t"

        split(sline, s, "\t")
        split(xline, x, "\t")

        loop=s[1]
        type=s[3]

        susie_snp=s[4]
        susiex_snp=x[4]
        causal=s[9]

        susie_pip=s[8]
        susiex_pip=x[8]

        susie_bpdiff=s[13]
        susiex_bpdiff=x[13]

        susie_mafdiff=s[14]
        susiex_mafdiff=x[14]

        susie_exact=s[15]
        susiex_exact=x[15]

        susie_cs=s[16]
        susiex_cs=x[16]

        if(susie_cs=="NA" || susiex_cs=="NA"){
            cs_diff="NA"
            smaller="NA"
            cs_equal="NA"
        } else {
            raw_diff=(susie_cs+0)-(susiex_cs+0)
            if(raw_diff<0){
                smaller="SuSiE"
                cs_diff=-raw_diff
            } else if(raw_diff>0){
                smaller="SuSiEx"
                cs_diff=raw_diff
            } else {
                smaller="Equal"
                cs_diff=0
            }
            cs_equal=(cs_diff==0 ? 1 : 0)
        }

        if(cs_equal==1){
            if(susie_pip=="NA" || susiex_pip=="NA"){
                higher_pip="NA"
            } else if((susie_pip+0) > (susiex_pip+0)){
                higher_pip="SuSiE"
            } else if((susie_pip+0) < (susiex_pip+0)){
                higher_pip="SuSiEx"
            } else {
                higher_pip="Equal"
            }
        } else {
            higher_pip="NA"
        }

        if(susie_bpdiff=="NA" || susiex_bpdiff=="NA"){
            better_bp="NA"
        } else if((susie_bpdiff+0) < (susiex_bpdiff+0)){
            better_bp="SuSiE"
        } else if((susie_bpdiff+0) > (susiex_bpdiff+0)){
            better_bp="SuSiEx"
        } else {
            better_bp="Equal"
        }

        if(susie_mafdiff=="NA" || susiex_mafdiff=="NA"){
            better_maf="NA"
        } else if((susie_mafdiff+0) < (susiex_mafdiff+0)){
            better_maf="SuSiE"
        } else if((susie_mafdiff+0) > (susiex_mafdiff+0)){
            better_maf="SuSiEx"
        } else {
            better_maf="Equal"
        }

        print loop,type,susie_cs,susiex_cs,cs_diff,smaller,cs_equal,susie_pip,susiex_pip,higher_pip,susie_snp,susiex_snp,causal,susie_bpdiff,susiex_bpdiff,susie_mafdiff,susiex_mafdiff,susie_exact,susiex_exact,better_bp,better_maf
    }' >> "$COMPARE_OUT"
}

############################################################
# 19. Run complete analysis for one loop and one type
############################################################

run_one_type()
{
    local TYPE=$1
    local LOOP_ID=$2
    local SHARED_LIST=$3
    local EUR_BFILE=$4
    local AFR_BFILE=$5
    local EUR_FULL_BFILE=$6
    local POOLED_BFILE=$7
    local EUR_COVAR=$8
    local AFR_COVAR=$9
    local EUR_FULL_COVAR=${10}
    local POOLED_COVAR_LOCAL=${11}
    local POOLED_OUT=${12}
    local EUR_OUT=${13}
    local SUSIEX_OUT=${14}
    local SUSIE_OUT=${15}
    local COMPARE_OUT=${16}

    local LOOP_DIR=$TMP/${TYPE}_loop_${LOOP_ID}
    mkdir -p "$LOOP_DIR"

    echo
    echo "============================================================"
    echo "[INFO] loop=$LOOP_ID type=$TYPE"
    echo "============================================================"

    ########################################################
    # 1. Draw causal SNP exactly ONCE for this loop/type
    ########################################################

    local CAUSAL CAUSAL_CHR CAUSAL_BP
    local CAUSAL_PICK

    if ! CAUSAL_PICK=$(pick_random_causal \
        "$SHARED_LIST" \
        "$EUR_BFILE" \
        "$AFR_BFILE" \
        "$POOLED_BFILE" \
        "$EUR_FULL_BFILE" \
        "$TYPE" \
        "$LOOP_ID"); then

        echo "[WARNING] Skip type=$TYPE loop=$LOOP_ID because causal selection failed"
        rm -rf "$LOOP_DIR"
        return 0
    fi

    read -r CAUSAL CAUSAL_CHR CAUSAL_BP <<< "$CAUSAL_PICK"

    local CAUSAL_MAF
    CAUSAL_MAF=$(get_maf "$CAUSAL")

    echo "[INFO] causal SNP selected ONCE: $CAUSAL"
    echo "[INFO] causal position: chr${CAUSAL_CHR}:${CAUSAL_BP}"
    echo "[INFO] all analyses below use this same causal SNP"

    local REGION_START REGION_END
    REGION_START=$(( CAUSAL_BP - 20000000 ))
    REGION_END=$(( CAUSAL_BP + 20000000 ))
    [ "$REGION_START" -lt 0 ] && REGION_START=0

    ########################################################
    # 2. EUR5K + AFR5K pooled GWAS
    ########################################################

    if run_window_gwas \
        "${TYPE}_POOLED" \
        "$POOLED_BFILE" \
        "$POOLED_COVAR_LOCAL" \
        "$CAUSAL" \
        "$CAUSAL_CHR" \
        "$REGION_START" \
        "$REGION_END" \
        "$LOOP_DIR/POOLED"; then

        extract_gwas_result \
            "$LOOP_ID" \
            "$LOOP_DIR/POOLED" \
            "$POOLED_OUT" \
            "$CAUSAL" \
            "$CAUSAL_CHR" \
            "$CAUSAL_BP" \
            "$CAUSAL_MAF" \
            "${TYPE}_POOLED" || true
    else
        echo "[WARNING] pooled GWAS failed type=$TYPE loop=$LOOP_ID"
    fi

    ########################################################
    # 3. EUR5K and AFR5K ancestry-specific GWAS
    #    These provide PC-adjusted summary statistics to SuSiEx.
    ########################################################

    local EUR_OK=1
    local AFR_OK=1

    if ! run_window_gwas \
        "${TYPE}_EUR5K" \
        "$EUR_BFILE" \
        "$EUR_COVAR" \
        "$CAUSAL" \
        "$CAUSAL_CHR" \
        "$REGION_START" \
        "$REGION_END" \
        "$LOOP_DIR/EUR"; then
        EUR_OK=0
    fi

    if ! run_window_gwas \
        "${TYPE}_AFR5K" \
        "$AFR_BFILE" \
        "$AFR_COVAR" \
        "$CAUSAL" \
        "$CAUSAL_CHR" \
        "$REGION_START" \
        "$REGION_END" \
        "$LOOP_DIR/AFR"; then
        AFR_OK=0
    fi

    ########################################################
    # 4. SuSiEx
    ########################################################

    if [ "$EUR_OK" -eq 1 ] && [ "$AFR_OK" -eq 1 ]; then
        run_susiex \
            "$LOOP_ID" \
            "$TYPE" \
            "$LOOP_DIR" \
            "$EUR_BFILE" \
            "$AFR_BFILE" \
            "$CAUSAL" \
            "$CAUSAL_CHR" \
            "$CAUSAL_BP" \
            "$CAUSAL_MAF" \
            "$SUSIEX_OUT" || true
    else
        echo "[WARNING] SuSiEx unavailable because EUR5K or AFR5K GWAS failed"
        write_fm_na \
            "$LOOP_ID" "SuSiEx" "$TYPE" "$SUSIEX_OUT" \
            "$CAUSAL" "$CAUSAL_CHR" "$CAUSAL_BP" "$CAUSAL_MAF"
    fi

    ########################################################
    # 5. EUR10K single-ancestry GWAS
    ########################################################

    local EUR_FULL_OK=1

    if run_window_gwas \
        "${TYPE}_EUR10K" \
        "$EUR_FULL_BFILE" \
        "$EUR_FULL_COVAR" \
        "$CAUSAL" \
        "$CAUSAL_CHR" \
        "$REGION_START" \
        "$REGION_END" \
        "$LOOP_DIR/EUR_only"; then

        extract_gwas_result \
            "$LOOP_ID" \
            "$LOOP_DIR/EUR_only" \
            "$EUR_OUT" \
            "$CAUSAL" \
            "$CAUSAL_CHR" \
            "$CAUSAL_BP" \
            "$CAUSAL_MAF" \
            "${TYPE}_EUR10K" || true
    else
        EUR_FULL_OK=0
        echo "[WARNING] EUR10K GWAS failed type=$TYPE loop=$LOOP_ID"
    fi

    ########################################################
    # 6. SuSiE
    ########################################################

    if [ "$EUR_FULL_OK" -eq 1 ]; then
        run_susie \
            "$LOOP_ID" \
            "$TYPE" \
            "$LOOP_DIR/EUR_only" \
            "$CAUSAL" \
            "$CAUSAL_CHR" \
            "$CAUSAL_BP" \
            "$CAUSAL_MAF" \
            "$SUSIE_OUT" || true
    else
        write_fm_na \
            "$LOOP_ID" "SuSiE" "$TYPE" "$SUSIE_OUT" \
            "$CAUSAL" "$CAUSAL_CHR" "$CAUSAL_BP" "$CAUSAL_MAF"
    fi

    ########################################################
    # 7. Paired SuSiE vs SuSiEx comparison
    ########################################################

    append_comparison \
        "$LOOP_ID" \
        "$TYPE" \
        "$SUSIE_OUT" \
        "$SUSIEX_OUT" \
        "$COMPARE_OUT"

    echo "[INFO] completed loop=$LOOP_ID type=$TYPE causal=$CAUSAL"

    rm -rf "$LOOP_DIR"
}

############################################################
# 20. Add LD r2 after ALL 20 loops in this array task finish
#
# Reference implementation follows the supplied LD script:
#   - GWAS: causal_SNP vs lead_SNP
#   - fine-mapping: causal_SNP vs fine_mapped_SNP
#   - reference bfile: EUR_AFR_merged
#   - PLINK2 --r2-unphased
#   - 50 Mb LD window
#
# Raw files remain inside $TMP. Only LD-added final files are
# written under /work/home/chengzesong/simu_gwas/add1k.
############################################################

add_ld_to_array_results()
{
    echo
    echo "============================================================"
    echo "[INFO] All simulation loops finished for array task $TASK_ID"
    echo "[INFO] Starting array-level LD r2 calculation"
    echo "============================================================"

    export PLINK2 REF_BFILE TMP THREADS
    export COMMON_POOLED_OUT RARE_POOLED_OUT COMMON_EUR_OUT RARE_EUR_OUT
    export COMMON_SUSIEX_OUT RARE_SUSIEX_OUT COMMON_SUSIE_OUT RARE_SUSIE_OUT
    export COMMON_COMPARE_OUT RARE_COMPARE_OUT
    export COMMON_POOLED_FINAL RARE_POOLED_FINAL COMMON_EUR_FINAL RARE_EUR_FINAL
    export COMMON_SUSIEX_FINAL RARE_SUSIEX_FINAL COMMON_SUSIE_FINAL RARE_SUSIE_FINAL
    export COMMON_COMPARE_FINAL RARE_COMPARE_FINAL LD_SUMMARY_FINAL
    export TASK_ID

    "$RSCRIPT" --vanilla - <<'EOF_LD_R'
suppressPackageStartupMessages({
    library(data.table)
})

plink2    <- Sys.getenv("PLINK2")
threads   <- as.integer(Sys.getenv("THREADS"))
if (is.na(threads) || threads < 1L) threads <- 1L
data.table::setDTthreads(threads)
ref_bfile <- Sys.getenv("REF_BFILE")
tmp_root  <- file.path(Sys.getenv("TMP"), "array_level_ld")
task_id   <- Sys.getenv("TASK_ID")

dir.create(tmp_root, showWarnings = FALSE, recursive = TRUE)

jobs <- data.table(
    name = c(
        "common_pooled_gwas",
        "rare_pooled_gwas",
        "common_EUR_gwas",
        "rare_EUR_gwas",
        "common_EUR_susie",
        "rare_EUR_susie",
        "common_susiex",
        "rare_susiex"
    ),
    file_type = c(
        "gwas", "gwas",
        "gwas", "gwas",
        "finemap", "finemap",
        "finemap", "finemap"
    ),
    in_file = c(
        Sys.getenv("COMMON_POOLED_OUT"),
        Sys.getenv("RARE_POOLED_OUT"),
        Sys.getenv("COMMON_EUR_OUT"),
        Sys.getenv("RARE_EUR_OUT"),
        Sys.getenv("COMMON_SUSIE_OUT"),
        Sys.getenv("RARE_SUSIE_OUT"),
        Sys.getenv("COMMON_SUSIEX_OUT"),
        Sys.getenv("RARE_SUSIEX_OUT")
    ),
    out_file = c(
        Sys.getenv("COMMON_POOLED_FINAL"),
        Sys.getenv("RARE_POOLED_FINAL"),
        Sys.getenv("COMMON_EUR_FINAL"),
        Sys.getenv("RARE_EUR_FINAL"),
        Sys.getenv("COMMON_SUSIE_FINAL"),
        Sys.getenv("RARE_SUSIE_FINAL"),
        Sys.getenv("COMMON_SUSIEX_FINAL"),
        Sys.getenv("RARE_SUSIEX_FINAL")
    )
)

run_cmd <- function(args, job_name) {
    message("[CMD] ", paste(shQuote(c(plink2, args)), collapse = " "))
    status <- system2(plink2, args = args)
    if (!identical(status, 0L)) {
        stop("PLINK2 command failed for ", job_name, " with exit code ", status)
    }
}

find_ld_file <- function(prefix) {
    candidates <- c(
        paste0(prefix, ".vcor"),
        paste0(prefix, ".unphased.vcor"),
        paste0(prefix, ".ld")
    )
    existing <- candidates[file.exists(candidates)]
    if (length(existing) == 0L) {
        return(NA_character_)
    }
    existing[1L]
}

calc_ld_for_one <- function(job_name, file_type, in_file, out_file) {

    message("")
    message("============================================================")
    message("[INFO] LD job: ", job_name)
    message("[INFO] Input : ", in_file)
    message("[INFO] Output: ", out_file)
    message("============================================================")

    if (!file.exists(in_file)) {
        stop("Input file does not exist: ", in_file)
    }

    df <- fread(in_file)

    if (!("causal_SNP" %in% names(df))) {
        stop("Missing causal_SNP column in: ", in_file)
    }

    if (file_type == "gwas") {
        if (!("lead_SNP" %in% names(df))) {
            stop("GWAS file is missing lead_SNP: ", in_file)
        }
        target_col <- "lead_SNP"
    } else if (file_type == "finemap") {
        if (!("fine_mapped_SNP" %in% names(df))) {
            stop("Fine-mapping file is missing fine_mapped_SNP: ", in_file)
        }
        target_col <- "fine_mapped_SNP"
    } else {
        stop("Unknown file_type: ", file_type)
    }

    df[, causal_SNP := as.character(causal_SNP)]
    df[, target_SNP_for_ld := as.character(get(target_col))]

    bad <- c("", ".", "NA", "NaN")
    df[causal_SNP %in% bad, causal_SNP := NA_character_]
    df[target_SNP_for_ld %in% bad, target_SNP_for_ld := NA_character_]

    snps <- unique(c(df$causal_SNP, df$target_SNP_for_ld))
    snps <- snps[!is.na(snps) & nzchar(snps)]

    job_tmp <- file.path(tmp_root, job_name)
    dir.create(job_tmp, showWarnings = FALSE, recursive = TRUE)

    # If a file contains only a header/no valid SNPs, still produce
    # the final file with ld_r2 = NA.
    if (length(snps) == 0L) {
        df[, ld_r2 := NA_real_]
        df[, target_SNP_for_ld := NULL]
        fwrite(df, out_file, sep = "\t", quote = FALSE, na = "NA")
        unlink(job_tmp, recursive = TRUE, force = TRUE)
        return(invisible(df))
    }

    snplist <- file.path(job_tmp, "snps.list")
    fwrite(
        data.table(SNP = snps),
        snplist,
        sep = "\t",
        quote = FALSE,
        col.names = FALSE
    )

    target_prefix <- file.path(job_tmp, "target")

    run_cmd(
        c(
            "--bfile", ref_bfile,
            "--extract", snplist,
            "--make-bed",
            "--threads", as.character(threads),
            "--out", target_prefix
        ),
        paste0(job_name, "_extract")
    )

    bim_file <- paste0(target_prefix, ".bim")
    if (!file.exists(bim_file)) {
        stop("Extracted BIM file not found: ", bim_file)
    }

    extracted_bim <- fread(bim_file, header = FALSE)

    if (nrow(extracted_bim) == 0L) {
        df[, ld_r2 := fifelse(
            !is.na(causal_SNP) &
            !is.na(target_SNP_for_ld) &
            causal_SNP == target_SNP_for_ld,
            1,
            NA_real_
        )]
        df[, target_SNP_for_ld := NULL]
        fwrite(df, out_file, sep = "\t", quote = FALSE, na = "NA")
        unlink(job_tmp, recursive = TRUE, force = TRUE)
        return(invisible(df))
    }

    ld_prefix <- file.path(job_tmp, "ld")

    run_cmd(
        c(
            "--bfile", target_prefix,
            "--r2-unphased",
            "--ld-window-kb", "50000",
            "--ld-window", "99999999",
            "--ld-window-r2", "0",
            "--threads", as.character(threads),
            "--out", ld_prefix
        ),
        paste0(job_name, "_ld")
    )

    ld_file <- find_ld_file(ld_prefix)
    if (is.na(ld_file)) {
        stop("LD output file not found for: ", job_name)
    }

    ld_raw <- fread(ld_file)

    if (nrow(ld_raw) == 0L) {
        df[, ld_r2 := fifelse(
            !is.na(causal_SNP) &
            !is.na(target_SNP_for_ld) &
            causal_SNP == target_SNP_for_ld,
            1,
            NA_real_
        )]
        df[, target_SNP_for_ld := NULL]
        fwrite(df, out_file, sep = "\t", quote = FALSE, na = "NA")
        unlink(job_tmp, recursive = TRUE, force = TRUE)
        return(invisible(df))
    }

    current_cols <- names(ld_raw)

    if (all(c("ID_A", "ID_B", "UNPHASED_R2") %in% current_cols)) {
        ld <- ld_raw[, .(
            snpA = as.character(ID_A),
            snpB = as.character(ID_B),
            r2 = as.numeric(UNPHASED_R2)
        )]
    } else if (all(c("ID1", "ID2", "R2") %in% current_cols)) {
        ld <- ld_raw[, .(
            snpA = as.character(ID1),
            snpB = as.character(ID2),
            r2 = as.numeric(R2)
        )]
    } else if (all(c("SNP_A", "SNP_B", "R2") %in% current_cols)) {
        ld <- ld_raw[, .(
            snpA = as.character(SNP_A),
            snpB = as.character(SNP_B),
            r2 = as.numeric(R2)
        )]
    } else {
        stop(
            "Unrecognised LD columns for ", job_name, ": ",
            paste(current_cols, collapse = ", ")
        )
    }

    # Unordered SNP-pair key
    ld[, key := fifelse(
        snpA < snpB,
        paste(snpA, snpB, sep = "|"),
        paste(snpB, snpA, sep = "|")
    )]

    ld <- ld[!is.na(key), .(r2 = max(r2, na.rm = TRUE)), by = key]
    ld[!is.finite(r2), r2 := NA_real_]

    df[, key := fifelse(
        is.na(causal_SNP) | is.na(target_SNP_for_ld),
        NA_character_,
        fifelse(
            causal_SNP < target_SNP_for_ld,
            paste(causal_SNP, target_SNP_for_ld, sep = "|"),
            paste(target_SNP_for_ld, causal_SNP, sep = "|")
        )
    )]

    # Preserve original row order explicitly.
    df[, .row_order__ := .I]
    df <- merge(df, ld, by = "key", all.x = TRUE, sort = FALSE)
    setorder(df, .row_order__)

    setnames(df, "r2", "ld_r2")

    df[
        !is.na(causal_SNP) &
        !is.na(target_SNP_for_ld) &
        causal_SNP == target_SNP_for_ld,
        ld_r2 := 1
    ]

    df[, c("key", "target_SNP_for_ld", ".row_order__") := NULL]

    fwrite(
        df,
        out_file,
        sep = "\t",
        quote = FALSE,
        na = "NA"
    )

    message("[DONE] ", job_name,
            "; rows=", nrow(df),
            "; nonmissing LD=", sum(!is.na(df$ld_r2)),
            "; missing LD=", sum(is.na(df$ld_r2)))

    unlink(job_tmp, recursive = TRUE, force = TRUE)
    invisible(df)
}

summary_list <- vector("list", nrow(jobs))

for (i in seq_len(nrow(jobs))) {

    ans <- calc_ld_for_one(
        job_name = jobs$name[i],
        file_type = jobs$file_type[i],
        in_file = jobs$in_file[i],
        out_file = jobs$out_file[i]
    )

    if (nrow(ans) == 0L) {
        summary_list[[i]] <- data.table(
            task_id = task_id,
            name = jobs$name[i],
            file_type = jobs$file_type[i],
            n_rows = 0L,
            n_ld_nonmissing = 0L,
            n_ld_missing = 0L,
            missing_rate = NA_real_,
            mean_ld_r2 = NA_real_,
            median_ld_r2 = NA_real_,
            prop_ld_r2_ge_0.8 = NA_real_,
            prop_ld_r2_ge_0.9 = NA_real_,
            prop_ld_r2_eq_1 = NA_real_
        )
    } else {
        summary_list[[i]] <- data.table(
            task_id = task_id,
            name = jobs$name[i],
            file_type = jobs$file_type[i],
            n_rows = nrow(ans),
            n_ld_nonmissing = sum(!is.na(ans$ld_r2)),
            n_ld_missing = sum(is.na(ans$ld_r2)),
            missing_rate = mean(is.na(ans$ld_r2)),
            mean_ld_r2 = mean(ans$ld_r2, na.rm = TRUE),
            median_ld_r2 = median(ans$ld_r2, na.rm = TRUE),
            prop_ld_r2_ge_0.8 = mean(ans$ld_r2 >= 0.8, na.rm = TRUE),
            prop_ld_r2_ge_0.9 = mean(ans$ld_r2 >= 0.9, na.rm = TRUE),
            prop_ld_r2_eq_1 = mean(ans$ld_r2 == 1, na.rm = TRUE)
        )
    }
}

summary_dt <- rbindlist(summary_list, fill = TRUE)
fwrite(
    summary_dt,
    Sys.getenv("LD_SUMMARY_FINAL"),
    sep = "\t",
    quote = FALSE,
    na = "NA"
)

############################################################
# Add SuSiE and SuSiEx LD r2 to their paired comparison files
############################################################

add_ld_to_comparison <- function(raw_cmp, susie_file, susiex_file, out_file) {

    cmp <- fread(raw_cmp)
    susie <- fread(susie_file)
    susiex <- fread(susiex_file)

    make_key <- function(loop, variant_type, causal) {
        paste(loop, variant_type, causal, sep = "||")
    }

    s_key <- make_key(susie$loop, susie$variant_type, susie$causal_SNP)
    x_key <- make_key(susiex$loop, susiex$variant_type, susiex$causal_SNP)
    c_key <- make_key(cmp$loop, cmp$variant_type, cmp$causal_SNP)

    cmp[, susie_ld_r2 := susie$ld_r2[match(c_key, s_key)]]
    cmp[, susiex_ld_r2 := susiex$ld_r2[match(c_key, x_key)]]

    cmp[, better_mapping_by_LD := fifelse(
        is.na(susie_ld_r2) | is.na(susiex_ld_r2),
        "NA",
        fifelse(
            susie_ld_r2 > susiex_ld_r2,
            "SuSiE",
            fifelse(
                susie_ld_r2 < susiex_ld_r2,
                "SuSiEx",
                "Equal"
            )
        )
    )]

    fwrite(
        cmp,
        out_file,
        sep = "\t",
        quote = FALSE,
        na = "NA"
    )
}

add_ld_to_comparison(
    Sys.getenv("COMMON_COMPARE_OUT"),
    Sys.getenv("COMMON_SUSIE_FINAL"),
    Sys.getenv("COMMON_SUSIEX_FINAL"),
    Sys.getenv("COMMON_COMPARE_FINAL")
)

add_ld_to_comparison(
    Sys.getenv("RARE_COMPARE_OUT"),
    Sys.getenv("RARE_SUSIE_FINAL"),
    Sys.getenv("RARE_SUSIEX_FINAL"),
    Sys.getenv("RARE_COMPARE_FINAL")
)

message("")
message("============================================================")
message("[DONE] Array-level LD r2 calculation completed")
message("[INFO] Only LD-added final results will be retained")
message("============================================================")
EOF_LD_R

    echo "[INFO] LD r2 calculation completed successfully for array task $TASK_ID"
}

############################################################
# 21. Main
############################################################

check_inputs

build_shared_list \
    "$COMMON_EUR" \
    "$COMMON_AFR" \
    "$COMMON_SHARED" \
    "common"

build_shared_list \
    "$RARE_EUR" \
    "$RARE_AFR" \
    "$RARE_SHARED" \
    "rare"

# Remove any stale final files for this task before rerunning.
rm -f \
    "$COMMON_POOLED_FINAL" "$RARE_POOLED_FINAL" \
    "$COMMON_EUR_FINAL" "$RARE_EUR_FINAL" \
    "$COMMON_SUSIEX_FINAL" "$RARE_SUSIEX_FINAL" \
    "$COMMON_SUSIE_FINAL" "$RARE_SUSIE_FINAL" \
    "$COMMON_COMPARE_FINAL" "$RARE_COMPARE_FINAL" \
    "$LD_SUMMARY_FINAL"

init_outputs

echo
echo "============================================================"
echo "[INFO] Combined simulation started"
echo "[INFO] SLURM array task: $TASK_ID"
echo "[INFO] loops per task: $LOOPS_PER_ARRAY"
echo "[INFO] loop range: $LOOP_START-$LOOP_END"
echo "[INFO] causal selection: random from EUR-AFR shared SNPs"
echo "[INFO] pooled GWAS: EUR5K + AFR5K, PC1-PC10 adjusted"
echo "[INFO] single-ancestry GWAS/SuSiE: EUR10K"
echo "[INFO] multi-ancestry fine-mapping: EUR5K + AFR5K SuSiEx"
echo "[INFO] METAL/meta-analysis: disabled"
echo "============================================================"

for ((i=LOOP_START; i<=LOOP_END; i++)); do

    echo
    echo "############################################################"
    echo "[INFO] START LOOP $i"
    echo "############################################################"

    # Common causal SNP: selected once, then reused everywhere.
    run_one_type \
        "common" \
        "$i" \
        "$COMMON_SHARED" \
        "$COMMON_EUR" \
        "$COMMON_AFR" \
        "$COMMON_EUR_FULL" \
        "$COMMON_POOLED" \
        "$COMMON_EUR_COVAR" \
        "$COMMON_AFR_COVAR" \
        "$COMMON_EUR_FULL_COVAR" \
        "$POOLED_COVAR" \
        "$COMMON_POOLED_OUT" \
        "$COMMON_EUR_OUT" \
        "$COMMON_SUSIEX_OUT" \
        "$COMMON_SUSIE_OUT" \
        "$COMMON_COMPARE_OUT"

    # Rare causal SNP: selected once, then reused everywhere.
    run_one_type \
        "rare" \
        "$i" \
        "$RARE_SHARED" \
        "$RARE_EUR" \
        "$RARE_AFR" \
        "$RARE_EUR_FULL" \
        "$RARE_POOLED" \
        "$RARE_EUR_COVAR" \
        "$RARE_AFR_COVAR" \
        "$RARE_EUR_FULL_COVAR" \
        "$POOLED_COVAR" \
        "$RARE_POOLED_OUT" \
        "$RARE_EUR_OUT" \
        "$RARE_SUSIEX_OUT" \
        "$RARE_SUSIE_OUT" \
        "$RARE_COMPARE_OUT"

    echo "############################################################"
    echo "[INFO] END LOOP $i"
    echo "############################################################"

done

############################################################
# 22. Array-level LD analysis
############################################################

add_ld_to_array_results

############################################################
# 23. Cleanup
#
# At this point all final result files already contain LD r2.
# Delete EVERYTHING pre-LD and all loop-level intermediate
# GWAS / phenotype / genotype / LD / fine-mapping files.
############################################################

rm -rf "$TMP"

echo
echo "============================================================"
echo "[INFO] Array task completed: $TASK_ID"
echo "[INFO] Loop range: $LOOP_START-$LOOP_END"
echo "[INFO] CPUs/threads requested: $THREADS"
echo "[INFO] Final retained files all contain LD information."
echo "[INFO] Common pooled GWAS: $COMMON_POOLED_FINAL"
echo "[INFO] Rare pooled GWAS: $RARE_POOLED_FINAL"
echo "[INFO] Common single-ancestry GWAS: $COMMON_EUR_FINAL"
echo "[INFO] Rare single-ancestry GWAS: $RARE_EUR_FINAL"
echo "[INFO] Common SuSiE: $COMMON_SUSIE_FINAL"
echo "[INFO] Rare SuSiE: $RARE_SUSIE_FINAL"
echo "[INFO] Common SuSiEx: $COMMON_SUSIEX_FINAL"
echo "[INFO] Rare SuSiEx: $RARE_SUSIEX_FINAL"
echo "[INFO] Common comparison: $COMMON_COMPARE_FINAL"
echo "[INFO] Rare comparison: $RARE_COMPARE_FINAL"
echo "[INFO] LD summary: $LD_SUMMARY_FINAL"
echo "============================================================"
