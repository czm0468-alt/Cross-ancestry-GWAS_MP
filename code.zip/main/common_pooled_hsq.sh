#!/bin/bash
#SBATCH --job-name=pooled_hsq_common_pc
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=1
#SBATCH --cpus-per-task=6
#SBATCH --array=1-10
#SBATCH --output=/work/home/chengzesong/simu_gwas/logs/pooled_hsq_common_pc_%A_%a.log

############################################################
# Analysis design
#
# Array 1  : loop 1-100
# Array 2  : loop 101-200
# ...
# Array 10 : loop 901-1000
#
# For each hsq and loop:
#   1. Select one common causal variant
#   2. Extract causal variant +/-20 Mb region
#   3. Simulate quantitative phenotype
#   4. Perform inverse-normal transformation
#   5. Run pooled GWAS adjusted for PC1-PC10
#
# Only common variants are analysed.
#
# Pooled sample:
#   EUR 5K + AFR 5K
#
# GWAS model:
#   phenotype ~ SNP + PC1 + ... + PC10
############################################################

############################################################
# Basic settings
############################################################

ROOT=/work/home/chengzesong/simu_gwas
OUT_DIR=$ROOT/new_pooled/pooled_hsq_common_pc

TASK_ID=${SLURM_ARRAY_TASK_ID}

if [ -z "$TASK_ID" ]; then
    echo "[ERROR] SLURM_ARRAY_TASK_ID is empty"
    echo "[ERROR] Submit this script as an array task 1-10"
    exit 1
fi

LOOP_START=$(( (TASK_ID - 1) * 100 + 1 ))
LOOP_END=$(( TASK_ID * 100 ))

TMP=$OUT_DIR/tmp_pooled_hsq_common_pc_${SLURM_ARRAY_JOB_ID}_${TASK_ID}

mkdir -p "$OUT_DIR"
mkdir -p "$TMP"
mkdir -p "$ROOT/logs"

############################################################
# Software paths
############################################################

PLINK=/work/home/ac3xibpp15/software/bin/plink
GCTA=/work/home/shilulu/software/gcta-1.94.4/gcta
RSCRIPT=/public/software/VersionHub/R/4.5.1/Rscript

THREADS=6

############################################################
# EUR 5K + AFR 5K pooled common genotype dataset
############################################################

COMMON_BFILE=/work/home/chengzesong/data/gwas/all_common_chr1

############################################################
# PC1-PC10 covariate file
#
# PCs were calculated in the EUR5K + AFR5K pooled sample
# using genome-wide common variants.
############################################################

PCA_COVAR=/work/home/chengzesong/simu_gwas/new_pooled/pca/EUR5K_AFR5K_genomewide_common_PCA_PC1_PC10.covar

############################################################
# Original UTF-16 common causal variant file
#
# Header:
#   hsq    loop    causal_SNP
############################################################

COMMON_CAUSAL_SOURCE=$ROOT/common_hsq_causal_snp.txt

############################################################
# Convert causal file to task-specific UTF-8 file
############################################################

COMMON_CAUSAL_FILE=$TMP/common_hsq_causal_snp.utf8.txt

iconv -f UTF-16 -t UTF-8 "$COMMON_CAUSAL_SOURCE" | tr -d '\r' > "$COMMON_CAUSAL_FILE"

if [ ! -s "$COMMON_CAUSAL_FILE" ]; then
    echo "[ERROR] Failed to convert common causal variant file"
    exit 1
fi

############################################################
# Pooled MAF reference
############################################################

MERGED_FRQ=/work/home/chengzesong/data/gwas/EUR_AFR_maf.frq

############################################################
# Output file
############################################################

COMMON_OUT=$OUT_DIR/common_pooled_${TASK_ID}_hsq_sig.txt

############################################################
# Input checks
############################################################

if [ ! -f "${COMMON_BFILE}.bed" ] || [ ! -f "${COMMON_BFILE}.bim" ] || [ ! -f "${COMMON_BFILE}.fam" ]; then
    echo "[ERROR] Common BFILE is incomplete:"
    echo "$COMMON_BFILE"
    exit 1
fi

if [ ! -s "$PCA_COVAR" ]; then
    echo "[ERROR] PC1-PC10 covariate file does not exist or is empty:"
    echo "$PCA_COVAR"
    exit 1
fi

if [ ! -s "$MERGED_FRQ" ]; then
    echo "[ERROR] MAF reference does not exist or is empty:"
    echo "$MERGED_FRQ"
    exit 1
fi

############################################################
# Check PC covariate header
############################################################

PC_HEADER_OK=$(head -1 "$PCA_COVAR" | awk '{required["FID"]=1; required["IID"]=1; for(i=1;i<=10;i++)required["PC"i]=1; for(i=1;i<=NF;i++){x=$i; gsub(/^#/,"",x); if(x in required)found[x]=1} ok=1; for(x in required)if(!(x in found))ok=0; print ok}')

if [ "$PC_HEADER_OK" -ne 1 ]; then
    echo "[ERROR] Covariate file must contain FID, IID and PC1-PC10"
    echo "[ERROR] Current header:"
    head -1 "$PCA_COVAR"
    exit 1
fi

############################################################
# Check genotype and PC sample consistency
############################################################

awk 'NR>1{print $1"\t"$2}' "$PCA_COVAR" | sort -u > "$TMP/pca_samples.txt"
awk 'BEGIN{OFS="\t"}{print $1,$2}' "${COMMON_BFILE}.fam" | sort -u > "$TMP/genotype_samples.txt"

N_PCA=$(wc -l < "$TMP/pca_samples.txt")
N_GENOTYPE=$(wc -l < "$TMP/genotype_samples.txt")
N_UNMATCHED=$(comm -3 "$TMP/pca_samples.txt" "$TMP/genotype_samples.txt" | wc -l)

echo
echo "============================================================"
echo "[INFO] Sample matching summary"
echo "[INFO] PCA samples: $N_PCA"
echo "[INFO] Genotype samples: $N_GENOTYPE"
echo "[INFO] Unmatched entries: $N_UNMATCHED"
echo "============================================================"

if [ "$N_UNMATCHED" -ne 0 ]; then
    echo "[ERROR] PC covariate samples do not exactly match genotype samples"
    exit 1
fi

############################################################
# Output header
############################################################

HEADER="hsq\tloop\tlead_SNP\tlead_CHR\tlead_BP\tlead_A1\tlead_A2\tlead_BETA\tlead_SE\tlead_P\tlead_MAF\tcausal_SNP\tcausal_CHR\tcausal_BP\tcausal_A1\tcausal_A2\tcausal_BETA\tcausal_SE\tcausal_P\tcausal_MAF\tMAF_diff\tBP_diff"

printf "%b\n" "$HEADER" > "$COMMON_OUT"

############################################################
# Tab-separated output function
############################################################

write_row()
{
    local IFS=$'\t'
    printf "%s\n" "$*"
}

############################################################
# Heritability values
#
# 0.000, 0.003, 0.006, ..., 0.030
############################################################

HSQ_LIST=$(seq -f "%.3f" 0 0.003 0.030)

############################################################
# Shared inverse-normal transformation script
############################################################

INVNORM_R=$TMP/invnorm.R

cat > "$INVNORM_R" <<'EOF'
phen <- read.table(
    "sim.phen",
    header = FALSE,
    stringsAsFactors = FALSE
)

phen$V3 <- qnorm(
    rank(phen$V3, ties.method = "average") /
        (nrow(phen) + 1)
)

write.table(
    phen,
    file = "sim.phen.invnorm",
    quote = FALSE,
    row.names = FALSE,
    col.names = FALSE
)
EOF

############################################################
# Run one common pooled analysis
############################################################

run_one_pooled_analysis()
{
    local HSQ=$1
    local LOOP_ID=$2

    local LOOP_DIR
    local CAUSAL
    local CAUSAL_INFO
    local CAUSAL_CHR
    local CAUSAL_BP
    local REGION_START
    local REGION_END
    local GWAS_FILE
    local LEAD_LINE
    local LEAD_CHR
    local LEAD_SNP
    local LEAD_BP
    local LEAD_A1
    local LEAD_A2
    local LEAD_N
    local LEAD_BETA
    local LEAD_STAT
    local LEAD_SE
    local LEAD_P
    local LEAD_MAF
    local CAUSAL_LINE
    local CAUSAL_A1
    local CAUSAL_A2
    local CAUSAL_BETA
    local CAUSAL_STAT
    local CAUSAL_SE
    local CAUSAL_P
    local CAUSAL_MAF
    local MAF_DIFF
    local BP_DIFF

    LOOP_DIR=$TMP/common_hsq_${HSQ}_loop_$(printf "%04d" "$LOOP_ID")

    mkdir -p "$LOOP_DIR"

    echo
    echo "============================================================"
    echo "[INFO] Array task: $TASK_ID"
    echo "[INFO] Variant type: common"
    echo "[INFO] hsq: $HSQ"
    echo "[INFO] loop: $LOOP_ID"
    echo "[INFO] Covariates: PC1-PC10"
    echo "[INFO] PC file: $PCA_COVAR"
    echo "============================================================"

    ########################################################
    # 1. Select causal variant matching hsq and loop
    ########################################################

    CAUSAL=$(awk -v h="$HSQ" -v l="$LOOP_ID" 'NR>1 && ($1+0)==(h+0) && ($2+0)==l{gsub(/\r/,"",$3); print $3; exit}' "$COMMON_CAUSAL_FILE")

    if [ -z "$CAUSAL" ]; then
        echo "[WARNING] No common causal variant found for hsq=$HSQ loop=$LOOP_ID"
        rm -rf "$LOOP_DIR"
        return 0
    fi

    echo "[INFO] Causal variant: $CAUSAL"

    ########################################################
    # 2. Obtain causal chromosome and position
    ########################################################

    CAUSAL_INFO=$(awk -v s="$CAUSAL" '$2==s{print $1,$4; exit}' "${COMMON_BFILE}.bim")

    if [ -z "$CAUSAL_INFO" ]; then
        echo "[WARNING] Causal variant not found in ${COMMON_BFILE}.bim: $CAUSAL"
        rm -rf "$LOOP_DIR"
        return 0
    fi

    read -r CAUSAL_CHR CAUSAL_BP <<< "$CAUSAL_INFO"

    ########################################################
    # 3. Define causal variant +/-20 Mb region
    ########################################################

    REGION_START=$(( CAUSAL_BP - 20000000 ))
    REGION_END=$(( CAUSAL_BP + 20000000 ))

    if [ "$REGION_START" -lt 0 ]; then
        REGION_START=0
    fi

    echo "[INFO] Region: chr${CAUSAL_CHR}:${REGION_START}-${REGION_END}"

    ########################################################
    # 4. Extract pooled common genotype region
    ########################################################

    "$PLINK" \
        --bfile "$COMMON_BFILE" \
        --chr "$CAUSAL_CHR" \
        --from-bp "$REGION_START" \
        --to-bp "$REGION_END" \
        --make-bed \
        --threads "$THREADS" \
        --out "$LOOP_DIR/win" \
        >/dev/null 2>&1

    if [ ! -f "$LOOP_DIR/win.bed" ]; then
        echo "[WARNING] Region extraction failed for hsq=$HSQ loop=$LOOP_ID"
        rm -rf "$LOOP_DIR"
        return 0
    fi

    ########################################################
    # 5. Confirm causal variant in extracted region
    ########################################################

    if ! awk -v s="$CAUSAL" '$2==s{found=1; exit} END{exit(found ? 0 : 1)}' "$LOOP_DIR/win.bim"; then
        echo "[WARNING] Causal variant is absent from extracted region: $CAUSAL"
        rm -rf "$LOOP_DIR"
        return 0
    fi

    ########################################################
    # 6. Simulate phenotype in pooled samples
    ########################################################

    printf "%s 1\n" "$CAUSAL" > "$LOOP_DIR/seed"

    "$GCTA" \
        --bfile "$LOOP_DIR/win" \
        --simu-qt \
        --simu-causal-loci "$LOOP_DIR/seed" \
        --simu-hsq "$HSQ" \
        --out "$LOOP_DIR/sim"

    if [ ! -f "$LOOP_DIR/sim.phen" ]; then
        echo "[WARNING] GCTA simulation failed for hsq=$HSQ loop=$LOOP_ID"
        rm -rf "$LOOP_DIR"
        return 0
    fi

    ########################################################
    # 7. Inverse-normal transform phenotype
    ########################################################

    (
        cd "$LOOP_DIR" || exit 1
        "$RSCRIPT" --vanilla "$INVNORM_R"
    )

    if [ ! -f "$LOOP_DIR/sim.phen.invnorm" ]; then
        echo "[WARNING] Inverse-normal transformation failed for hsq=$HSQ loop=$LOOP_ID"
        rm -rf "$LOOP_DIR"
        return 0
    fi

    ########################################################
    # 8. Run pooled GWAS adjusted for PC1-PC10
    #
    # Model:
    #   phenotype ~ SNP + PC1 + ... + PC10
    ########################################################

    "$PLINK" \
        --bfile "$LOOP_DIR/win" \
        --pheno "$LOOP_DIR/sim.phen.invnorm" \
        --covar "$PCA_COVAR" \
        --covar-name PC1,PC2,PC3,PC4,PC5,PC6,PC7,PC8,PC9,PC10 \
        --linear hide-covar \
        --allow-no-sex \
        --threads "$THREADS" \
        --out "$LOOP_DIR/gwas"

    GWAS_FILE=$LOOP_DIR/gwas.assoc.linear

    if [ ! -f "$GWAS_FILE" ]; then
        echo "[WARNING] PC-adjusted pooled GWAS failed for hsq=$HSQ loop=$LOOP_ID"
        rm -rf "$LOOP_DIR"
        return 0
    fi

    ########################################################
    # 9. Extract lead variant
    #
    # PLINK columns:
    #   CHR SNP BP A1 TEST NMISS BETA STAT P
    ########################################################

    LEAD_LINE=$(awk 'NR>1 && $5=="ADD" && $7!="NA" && $8!="NA" && $9!="NA"{p=$9+0; if(min=="" || p<min){min=p; line=$1" "$2" "$3" "$4" "$6" "$7" "$8" "$9}} END{if(line!="")print line}' "$GWAS_FILE")

    if [ -z "$LEAD_LINE" ]; then
        echo "[WARNING] No valid pooled GWAS result for hsq=$HSQ loop=$LOOP_ID"
        rm -rf "$LOOP_DIR"
        return 0
    fi

    read -r LEAD_CHR LEAD_SNP LEAD_BP LEAD_A1 LEAD_N LEAD_BETA LEAD_STAT LEAD_P <<< "$LEAD_LINE"

    LEAD_SE=$(awk -v b="$LEAD_BETA" -v s="$LEAD_STAT" 'BEGIN{if(b!="NA" && s!="NA" && s!=0){v=b/s; if(v<0)v=-v; print v}else{print "NA"}}')

    LEAD_A2=$(awk -v s="$LEAD_SNP" '$2==s{print $6; exit}' "$LOOP_DIR/win.bim")
    [ -z "$LEAD_A2" ] && LEAD_A2="NA"

    ########################################################
    # 10. Extract causal variant GWAS result
    ########################################################

    CAUSAL_LINE=$(awk -v s="$CAUSAL" 'NR>1 && $2==s && $5=="ADD"{print $4,$7,$8,$9; exit}' "$GWAS_FILE")

    if [ -n "$CAUSAL_LINE" ]; then
        read -r CAUSAL_A1 CAUSAL_BETA CAUSAL_STAT CAUSAL_P <<< "$CAUSAL_LINE"
    else
        CAUSAL_A1="NA"
        CAUSAL_BETA="NA"
        CAUSAL_STAT="NA"
        CAUSAL_P="NA"
    fi

    CAUSAL_A2=$(awk -v s="$CAUSAL" '$2==s{print $6; exit}' "$LOOP_DIR/win.bim")
    [ -z "$CAUSAL_A2" ] && CAUSAL_A2="NA"

    CAUSAL_SE=$(awk -v b="$CAUSAL_BETA" -v s="$CAUSAL_STAT" 'BEGIN{if(b!="NA" && s!="NA" && s!=0){v=b/s; if(v<0)v=-v; print v}else{print "NA"}}')

    ########################################################
    # 11. Extract pooled reference MAF
    ########################################################

    LEAD_MAF=$(awk -v s="$LEAD_SNP" '$2==s{print $5; exit}' "$MERGED_FRQ")
    CAUSAL_MAF=$(awk -v s="$CAUSAL" '$2==s{print $5; exit}' "$MERGED_FRQ")

    [ -z "$LEAD_MAF" ] && LEAD_MAF="NA"
    [ -z "$CAUSAL_MAF" ] && CAUSAL_MAF="NA"

    ########################################################
    # 12. Calculate absolute MAF and BP differences
    ########################################################

    if [ "$LEAD_MAF" != "NA" ] && [ "$CAUSAL_MAF" != "NA" ]; then
        MAF_DIFF=$(awk -v a="$LEAD_MAF" -v b="$CAUSAL_MAF" 'BEGIN{d=a-b; if(d<0)d=-d; print d}')
    else
        MAF_DIFF="NA"
    fi

    BP_DIFF=$(( LEAD_BP > CAUSAL_BP ? LEAD_BP - CAUSAL_BP : CAUSAL_BP - LEAD_BP ))

    ########################################################
    # 13. Write common pooled result
    ########################################################

    write_row \
        "$HSQ" \
        "$LOOP_ID" \
        "$LEAD_SNP" \
        "$LEAD_CHR" \
        "$LEAD_BP" \
        "$LEAD_A1" \
        "$LEAD_A2" \
        "$LEAD_BETA" \
        "$LEAD_SE" \
        "$LEAD_P" \
        "$LEAD_MAF" \
        "$CAUSAL" \
        "$CAUSAL_CHR" \
        "$CAUSAL_BP" \
        "$CAUSAL_A1" \
        "$CAUSAL_A2" \
        "$CAUSAL_BETA" \
        "$CAUSAL_SE" \
        "$CAUSAL_P" \
        "$CAUSAL_MAF" \
        "$MAF_DIFF" \
        "$BP_DIFF" \
        >> "$COMMON_OUT"

    echo "[INFO] Lead variant: $LEAD_SNP"
    echo "[INFO] Lead P: $LEAD_P"
    echo "[INFO] Lead pooled MAF: $LEAD_MAF"
    echo "[INFO] Causal pooled MAF: $CAUSAL_MAF"
    echo "[INFO] MAF difference: $MAF_DIFF"
    echo "[INFO] BP difference: $BP_DIFF"
    echo "[INFO] Completed common hsq=$HSQ loop=$LOOP_ID"

    rm -rf "$LOOP_DIR"
}

############################################################
# Main common pooled analysis
############################################################

echo
echo "============================================================"
echo "[INFO] Common pooled hsq analysis started"
echo "[INFO] Array task: $TASK_ID"
echo "[INFO] Loop range: $LOOP_START-$LOOP_END"
echo "[INFO] Heritability values: $HSQ_LIST"
echo "[INFO] GWAS covariates: PC1-PC10"
echo "[INFO] PC file: $PCA_COVAR"
echo "[INFO] Output directory: $OUT_DIR"
echo "============================================================"

for HSQ in $HSQ_LIST; do

    for ((i=LOOP_START; i<=LOOP_END; i++)); do

        echo
        echo "############################################################"
        echo "[INFO] Starting common hsq=$HSQ loop=$i"
        echo "############################################################"

        run_one_pooled_analysis \
            "$HSQ" \
            "$i"

        echo
        echo "############################################################"
        echo "[INFO] Finished common hsq=$HSQ loop=$i"
        echo "############################################################"

    done

done

############################################################
# Cleanup
############################################################

rm -rf "$TMP"

echo
echo "============================================================"
echo "[INFO] Array task $TASK_ID completed"
echo "[INFO] Loop range: $LOOP_START-$LOOP_END"
echo "[INFO] Variant type: common only"
echo "[INFO] GWAS covariates: PC1-PC10"
echo "[INFO] Common pooled output: $COMMON_OUT"
echo "============================================================"