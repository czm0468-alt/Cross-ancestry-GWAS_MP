#!/usr/bin/env bash
#SBATCH --job-name=merge_EUR_AFR_10K
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=1
#SBATCH --cpus-per-task=4
#SBATCH --mem=30G
#SBATCH --time=10:00:00
#SBATCH --array=1
#SBATCH --output=/work/home/chengzesong/simu_gwas/logs/merge_EUR_AFR_10K_%A_%a.log

set -euo pipefail

############################################################
# Software
############################################################

PLINK=/work/home/ac3xibpp15/software/bin/plink

THREADS=4


############################################################
# Input roots
############################################################

EUR_ROOT=/work/home/chengzesong/data/gwas/EUR/extract
AFR_ROOT=/work/home/chengzesong/data/gwas/AFR/extract


############################################################
# Output root
#
# Do not overwrite the previous EUR5K_AFR1K-4K results.
############################################################

OUTPUT_ROOT=/work/home/chengzesong/simu_gwas/diff_afr_matched_10k

mkdir -p "$OUTPUT_ROOT"
mkdir -p /work/home/chengzesong/simu_gwas/logs


############################################################
# Check software
############################################################

if [ ! -x "$PLINK" ]; then
    echo "[ERROR] PLINK is not executable:"
    echo "$PLINK"
    exit 1
fi


############################################################
# Functions
############################################################

check_bfile()
{
    local BFILE=$1
    local LABEL=$2

    if [ ! -s "${BFILE}.bed" ] || [ ! -s "${BFILE}.bim" ] || [ ! -s "${BFILE}.fam" ]; then
        echo "[ERROR] Incomplete bfile for ${LABEL}:"
        echo "$BFILE"
        echo "[CHECK] Required files:"
        echo "${BFILE}.bed"
        echo "${BFILE}.bim"
        echo "${BFILE}.fam"
        exit 1
    fi
}


merge_one()
{
    local TYPE=$1
    local EUR_BFILE=$2
    local AFR_BFILE=$3
    local OUT_PREFIX=$4

    echo
    echo "============================================================"
    echo "[INFO] Starting ${TYPE} merge"
    echo "[INFO] EUR bfile : ${EUR_BFILE}"
    echo "[INFO] AFR bfile : ${AFR_BFILE}"
    echo "[INFO] Output    : ${OUT_PREFIX}"
    echo "============================================================"

    check_bfile "$EUR_BFILE" "EUR ${TYPE}"
    check_bfile "$AFR_BFILE" "AFR ${TYPE}"

    "$PLINK" \
        --bfile "$EUR_BFILE" \
        --bmerge "${AFR_BFILE}.bed" "${AFR_BFILE}.bim" "${AFR_BFILE}.fam" \
        --make-bed \
        --threads "$THREADS" \
        --out "$OUT_PREFIX"

    if [ ! -s "${OUT_PREFIX}.bed" ] || [ ! -s "${OUT_PREFIX}.bim" ] || [ ! -s "${OUT_PREFIX}.fam" ]; then
        echo "[ERROR] Merge failed or output is incomplete:"
        echo "$OUT_PREFIX"
        exit 1
    fi

    N_SAMPLE=$(wc -l < "${OUT_PREFIX}.fam")
    N_SNP=$(wc -l < "${OUT_PREFIX}.bim")

    echo "[DONE] ${TYPE} merge completed"
    echo "[INFO] Output samples: ${N_SAMPLE}"
    echo "[INFO] Output SNPs   : ${N_SNP}"

    if [ "$N_SAMPLE" -ne 10000 ]; then
        echo "[WARNING] Merged sample size is not 10000 for ${OUT_PREFIX}"
        echo "[WARNING] Observed sample size: ${N_SAMPLE}"
    fi
}


############################################################
# Merge AFR 1K, 2K, 3K and 4K with matched EUR sample sizes
############################################################

for K in 1 2 3 4; do

    AFR_SIZE=$(( K * 1000 ))
    EUR_SIZE=$(( 10000 - AFR_SIZE ))

    AFR_LABEL=${K}k
    EUR_LABEL=$(( EUR_SIZE / 1000 ))k

    ########################################################
    # Input bfiles
    #
    # Example:
    #   AFR 1k + EUR 9k
    #   AFR 2k + EUR 8k
    #   AFR 3k + EUR 7k
    #   AFR 4k + EUR 6k
    ########################################################

    EUR_COMMON=${EUR_ROOT}/EUR_common_chr1_${EUR_SIZE}
    EUR_RARE=${EUR_ROOT}/EUR_rare_chr1_${EUR_SIZE}

    AFR_COMMON=${AFR_ROOT}/AFR_common_chr1_${AFR_SIZE}
    AFR_RARE=${AFR_ROOT}/AFR_rare_chr1_${AFR_SIZE}

    ########################################################
    # Output
    ########################################################

    OUTPUT_DIR=${OUTPUT_ROOT}/AFR${AFR_LABEL}_EUR${EUR_LABEL}
    mkdir -p "$OUTPUT_DIR"

    COMMON_OUT=${OUTPUT_DIR}/EUR${EUR_LABEL}_AFR${AFR_LABEL}_common_chr1
    RARE_OUT=${OUTPUT_DIR}/EUR${EUR_LABEL}_AFR${AFR_LABEL}_rare_chr1

    echo
    echo "############################################################"
    echo "[INFO] Matched 10K merge group"
    echo "[INFO] AFR sample group : ${AFR_LABEL} (${AFR_SIZE})"
    echo "[INFO] EUR sample group : ${EUR_LABEL} (${EUR_SIZE})"
    echo "[INFO] Total expected   : 10000"
    echo "[INFO] Output directory : ${OUTPUT_DIR}"
    echo "############################################################"

    ########################################################
    # Merge common variants
    ########################################################

    merge_one \
        "common" \
        "$EUR_COMMON" \
        "$AFR_COMMON" \
        "$COMMON_OUT"

    ########################################################
    # Merge rare variants
    ########################################################

    merge_one \
        "rare" \
        "$EUR_RARE" \
        "$AFR_RARE" \
        "$RARE_OUT"

    echo
    echo "============================================================"
    echo "[INFO] Completed matched merge:"
    echo "[INFO] EUR${EUR_LABEL} + AFR${AFR_LABEL}"
    echo "============================================================"

done


############################################################
# Final message
############################################################

echo
echo "============================================================"
echo "[INFO] All matched EUR-AFR 10K merge tasks completed"
echo "[INFO] Output root:"
echo "$OUTPUT_ROOT"
echo "============================================================"