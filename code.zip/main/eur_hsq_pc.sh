#!/bin/bash
#SBATCH --job-name=hsq_susie_susiex
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=1
#SBATCH --cpus-per-task=6
#SBATCH --array=1-20
#SBATCH --output=/work/home/chengzesong/simu_gwas/logs/hsq_susie_susiex_%A_%a.log

set -euo pipefail

############################################################
# hsq SuSiE / SuSiEx power analysis
#
# Array 1  : loop 1-50
# Array 2  : loop 51-100
# ...
# Array 20 : loop 951-1000
#
# For each hsq and loop:
#   common:
#     EUR 5K GWAS + AFR 5K GWAS -> SuSiEx
#     EUR 10K GWAS              -> SuSiE
#   rare:
#     EUR 5K GWAS + AFR 5K GWAS -> SuSiEx
#     EUR 10K GWAS              -> SuSiE
#
# Pre-converted causal SNP files:
#   /work/home/chengzesong/simu_gwas/new_eur/causal_hsq/common_hsq_causal_snp.utf8.txt
#   /work/home/chengzesong/simu_gwas/new_eur/causal_hsq/rare_hsq_causal_snp.utf8.txt
#
# Causal file format:
#   hsq    loop    causal_SNP
#
# GWAS model:
#   phenotype ~ SNP + PC1 + ... + PC10
#
# Fine-mapping power metrics:
#   exact_match        : max-PIP variant equals causal SNP
#   cs_contains_causal : causal SNP is included in any 95% credible set
#
# Power output per hsq/method/type:
#   exact_identification_power = mean(exact_match)
#   credible_set_power        = mean(cs_contains_causal)
#
# GWAS output columns are kept identical to the original hsq GWAS script.
# GWAS power is written separately and does not alter the GWAS summary file.
############################################################

ROOT=/work/home/chengzesong/simu_gwas
OUT_DIR=$ROOT/new_eur/hsq_susie_susiex_power
GWAS_SUMMARY_DIR=$OUT_DIR/gwas_summary
GWAS_SUMSTATS_DIR=$OUT_DIR/gwas_sumstats
GWAS_POWER_DIR=$OUT_DIR/gwas_power
SUSIE_DIR=$OUT_DIR/susie_power
TMP=$OUT_DIR/tmp_${SLURM_ARRAY_JOB_ID}_${SLURM_ARRAY_TASK_ID}

mkdir -p "$GWAS_SUMMARY_DIR" "$GWAS_SUMSTATS_DIR" "$GWAS_POWER_DIR" "$SUSIE_DIR" "$TMP" "$ROOT/logs"

TASK_ID=${SLURM_ARRAY_TASK_ID}

if [ -z "$TASK_ID" ]; then
    echo "[ERROR] SLURM_ARRAY_TASK_ID is empty"
    echo "[ERROR] Submit this script as an array task 1-20"
    exit 1
fi

LOOPS_PER_ARRAY=50
START=$(( (TASK_ID - 1) * LOOPS_PER_ARRAY + 1 ))
END=$(( TASK_ID * LOOPS_PER_ARRAY ))

PLINK=/work/home/ac3xibpp15/software/bin/plink
GCTA=/work/home/shilulu/software/gcta-1.94.4/gcta
RSCRIPT=/public/software/VersionHub/R/4.5.1/Rscript
SUSIEX=/work/home/chengzesong/software/SusieX/SuSiEx-master/bin_static/SuSiEx
THREADS=6

############################################################
# Genotype bfiles
############################################################

EUR_COMMON=/work/home/chengzesong/data/gwas/EUR/EUR_5k_common_chr1
AFR_COMMON=/work/home/chengzesong/data/gwas/AFR/AFR_common_chr1
EUR_FULL_COMMON=/work/home/chengzesong/data/gwas/EUR/EUR_10k_common_chr1

EUR_RARE=/work/home/chengzesong/data/gwas/EUR/EUR_5k_rare_chr1
AFR_RARE=/work/home/chengzesong/data/gwas/AFR/AFR_rare_chr1
EUR_FULL_RARE=/work/home/chengzesong/data/gwas/EUR/EUR_10k_rare_chr1

############################################################
# PC covariates generated previously
############################################################

PCA_DIR=/work/home/chengzesong/simu_gwas/new_eur/PCA

EUR_COMMON_COVAR=$PCA_DIR/EUR_5k_common_chr1.PC1_10.covariates.txt
AFR_COMMON_COVAR=$PCA_DIR/AFR_common_chr1.PC1_10.covariates.txt
EUR_FULL_COMMON_COVAR=$PCA_DIR/EUR_10k_common_chr1.PC1_10.covariates.txt

EUR_RARE_COVAR=$PCA_DIR/EUR_5k_rare_chr1.PC1_10.covariates.txt
AFR_RARE_COVAR=$PCA_DIR/AFR_rare_chr1.PC1_10.covariates.txt
EUR_FULL_RARE_COVAR=$PCA_DIR/EUR_10k_rare_chr1.PC1_10.covariates.txt

############################################################
# Reference files
############################################################

MERGED_BIM=/work/home/chengzesong/data/gwas/EUR_AFR_merged.bim
MERGED_FRQ=/work/home/chengzesong/data/gwas/EUR_AFR_maf.frq

CAUSAL_DIR=$ROOT/new_eur/causal_hsq
COMMON_CAUSAL_FILE=$CAUSAL_DIR/common_hsq_causal_snp.utf8.txt
RARE_CAUSAL_FILE=$CAUSAL_DIR/rare_hsq_causal_snp.utf8.txt

############################################################
# Checks
############################################################

check_bfile() {
    local BFILE=$1
    if [ ! -s "${BFILE}.bed" ] || [ ! -s "${BFILE}.bim" ] || [ ! -s "${BFILE}.fam" ]; then
        echo "[ERROR] Incomplete bfile: $BFILE"
        exit 1
    fi
}

check_covar() {
    local COVAR=$1
    if [ ! -s "$COVAR" ]; then
        echo "[ERROR] Missing PC covariate file: $COVAR"
        exit 1
    fi
    local OK
    OK=$(head -1 "$COVAR" | awk '{required["FID"]=1; required["IID"]=1; for(i=1;i<=10;i++)required["PC"i]=1; for(i=1;i<=NF;i++){x=$i; gsub(/^#/,"",x); if(x in required)found[x]=1}; ok=1; for(x in required){if(!(x in found))ok=0}; print ok}')
    if [ "$OK" -ne 1 ]; then
        echo "[ERROR] Covariate file must contain FID, IID and PC1-PC10: $COVAR"
        head -1 "$COVAR"
        exit 1
    fi
}

for BFILE in "$EUR_COMMON" "$AFR_COMMON" "$EUR_FULL_COMMON" "$EUR_RARE" "$AFR_RARE" "$EUR_FULL_RARE"; do
    check_bfile "$BFILE"
done

for COVAR in "$EUR_COMMON_COVAR" "$AFR_COMMON_COVAR" "$EUR_FULL_COMMON_COVAR" "$EUR_RARE_COVAR" "$AFR_RARE_COVAR" "$EUR_FULL_RARE_COVAR"; do
    check_covar "$COVAR"
done

for F in "$MERGED_BIM" "$MERGED_FRQ" "$COMMON_CAUSAL_FILE" "$RARE_CAUSAL_FILE"; do
    if [ ! -s "$F" ]; then
        echo "[ERROR] Missing file: $F"
        exit 1
    fi
done

echo "============================================================"
echo "[INFO] Using pre-converted hsq causal SNP files"
echo "[INFO] Common causal file: $COMMON_CAUSAL_FILE"
echo "[INFO] Rare causal file  : $RARE_CAUSAL_FILE"
echo "============================================================"

head -3 "$COMMON_CAUSAL_FILE"
head -3 "$RARE_CAUSAL_FILE"

############################################################
# Output files
############################################################

SUMMARY_HEADER="hsq\tloop\tmethod\tvariant_type\tfine_mapped_snp\tfine_mapped_bp\tfine_mapped_maf\tpip_max\tcausal_snp\tcausal_bp\tcausal_maf\tbp_diff\tmaf_diff\texact_match\tmean_cs_size\tn_cs\tcs_contains_causal"
COMPARE_HEADER="hsq\tloop\tvariant_type\tsusie_mean_cs_size\tsusiex_mean_cs_size\tcs_size_difference\tsmaller_cs_method\tcs_size_equal\tsusie_pip_max\tsusiex_pip_max\thigher_pip_method_when_cs_equal\tsusie_bp_diff\tsusiex_bp_diff\tsusie_maf_diff\tsusiex_maf_diff\tsusie_exact_match\tsusiex_exact_match\tsusie_cs_contains_causal\tsusiex_cs_contains_causal\tbetter_mapping_by_bp\tbetter_mapping_by_maf"
POWER_HEADER="variant_type\thsq\tmethod\tn_all\tn_finemapped\texact_identification_power_all\tcredible_set_power_all\texact_identification_power_finemapped\tcredible_set_power_finemapped"
GWAS_HEADER="hsq\tloop\tlead_SNP\tlead_CHR\tlead_BP\tlead_A1\tlead_A2\tlead_BETA\tlead_SE\tlead_P\tlead_MAF\tcausal_SNP\tcausal_CHR\tcausal_BP\tcausal_A1\tcausal_A2\tcausal_BETA\tcausal_SE\tcausal_P\tcausal_MAF\tMAF_diff\tBP_diff"
GWAS_POWER_HEADER="variant_type\thsq\tn_all\tn_valid_gwas\tlead_gwas_power_all\tcausal_gwas_power_all\texact_causal_lead_power_all\tlead_gwas_power_valid\tcausal_gwas_power_valid\texact_causal_lead_power_valid"

COMMON_SUSIE_OUT=$SUSIE_DIR/common_susie_${TASK_ID}_hsq_summary.txt
RARE_SUSIE_OUT=$SUSIE_DIR/rare_susie_${TASK_ID}_hsq_summary.txt
COMMON_SUSIEX_OUT=$SUSIE_DIR/common_susiex_${TASK_ID}_hsq_summary.txt
RARE_SUSIEX_OUT=$SUSIE_DIR/rare_susiex_${TASK_ID}_hsq_summary.txt
COMMON_COMPARE_OUT=$SUSIE_DIR/common_susie_vs_susiex_${TASK_ID}_hsq_comparison.txt
RARE_COMPARE_OUT=$SUSIE_DIR/rare_susie_vs_susiex_${TASK_ID}_hsq_comparison.txt
COMMON_POWER_OUT=$SUSIE_DIR/common_susie_susiex_${TASK_ID}_hsq_power.txt
RARE_POWER_OUT=$SUSIE_DIR/rare_susie_susiex_${TASK_ID}_hsq_power.txt
COMMON_GWAS_SUMMARY_OUT=$GWAS_SUMMARY_DIR/common_gwas_${TASK_ID}_hsq_sig.txt
RARE_GWAS_SUMMARY_OUT=$GWAS_SUMMARY_DIR/rare_gwas_${TASK_ID}_hsq_sig.txt
COMMON_GWAS_POWER_OUT=$GWAS_POWER_DIR/common_gwas_${TASK_ID}_hsq_power.txt
RARE_GWAS_POWER_OUT=$GWAS_POWER_DIR/rare_gwas_${TASK_ID}_hsq_power.txt

printf "%b\n" "$SUMMARY_HEADER" > "$COMMON_SUSIE_OUT"
printf "%b\n" "$SUMMARY_HEADER" > "$RARE_SUSIE_OUT"
printf "%b\n" "$SUMMARY_HEADER" > "$COMMON_SUSIEX_OUT"
printf "%b\n" "$SUMMARY_HEADER" > "$RARE_SUSIEX_OUT"
printf "%b\n" "$COMPARE_HEADER" > "$COMMON_COMPARE_OUT"
printf "%b\n" "$COMPARE_HEADER" > "$RARE_COMPARE_OUT"
printf "%b\n" "$GWAS_HEADER" > "$COMMON_GWAS_SUMMARY_OUT"
printf "%b\n" "$GWAS_HEADER" > "$RARE_GWAS_SUMMARY_OUT"
printf "%b\n" "$GWAS_POWER_HEADER" > "$COMMON_GWAS_POWER_OUT"
printf "%b\n" "$GWAS_POWER_HEADER" > "$RARE_GWAS_POWER_OUT"

############################################################
# Utility functions
############################################################

write_row() {
    local IFS=$'\t'
    printf "%s\n" "$*"
}

get_causal_snp() {
    local CAUSAL_FILE=$1
    local HSQ=$2
    local LOOP_ID=$3

    awk -v h="$HSQ" -v l="$LOOP_ID" '
        NR > 1 {
            gsub(/\r/, "", $0)
            file_h = sprintf("%.3f", $1 + 0)
            target_h = sprintf("%.3f", h + 0)
            if (file_h == target_h && ($2 + 0) == l) {
                print $3
                exit
            }
        }
    ' "$CAUSAL_FILE"
}

get_maf() {
    local SNP=$1
    awk -v s="$SNP" '$2==s{print $5; exit}' "$MERGED_FRQ"
}

get_bp() {
    local SNP=$1
    local BIM=$2
    local BP
    BP=$(awk -v s="$SNP" '$2==s{print $4; exit}' "$BIM")
    if [ -z "$BP" ]; then
        BP=$(awk -v s="$SNP" '$2==s{print $4; exit}' "$MERGED_BIM")
    fi
    echo "$BP"
}

abs_diff() {
    local A=$1
    local B=$2
    if [ -z "$A" ] || [ -z "$B" ] || [ "$A" = "NA" ] || [ "$B" = "NA" ]; then
        echo "NA"
    else
        awk -v a="$A" -v b="$B" 'BEGIN{d=a-b; if(d<0)d=-d; print d}'
    fi
}

HSQ_LIST=$(seq -f "%.3f" 0 0.003 0.030)

############################################################
# Shared R scripts
############################################################

INVNORM_R=$TMP/invnorm.R
cat > "$INVNORM_R" <<'EOF'
phen <- read.table("sim.phen", header = FALSE, stringsAsFactors = FALSE)
phen$V3 <- qnorm(rank(phen$V3, ties.method = "average") / (nrow(phen) + 1))
write.table(phen, file = "sim.phen.invnorm", quote = FALSE, row.names = FALSE, col.names = FALSE)
EOF

SUSIE_R=$TMP/run_susie.R
cat > "$SUSIE_R" <<'EOF'
suppressPackageStartupMessages({
    library(data.table)
    library(susieR)
})

args <- commandArgs(trailingOnly = TRUE)
gwas_file <- args[1]
ld_file <- args[2]
snp_order_file <- args[3]
causal_snp <- args[4]
out_prefix <- args[5]

gwas <- fread(gwas_file)
setnames(gwas, trimws(names(gwas)))
gwas[, P := as.numeric(P)]
gwas[, BETA := as.numeric(BETA)]
gwas[, STAT := as.numeric(STAT)]
gwas[, NMISS := as.numeric(NMISS)]
gwas <- gwas[!is.na(P) & !is.na(STAT) & !is.na(NMISS)]

snps0 <- fread(snp_order_file, header = FALSE)$V1
common <- intersect(snps0, gwas$SNP)

if (length(common) < 10) {
    fwrite(data.table(fine_mapped_snp="NA", pip_max=NA_real_, mean_cs_size=NA_real_, n_cs=0L, cs_contains_causal=0L), paste0(out_prefix, ".summary.tsv"), sep="\t")
    fwrite(data.table(cs_id=character(), SNP=character()), paste0(out_prefix, ".cs_members.tsv"), sep="\t")
    quit(save="no", status=0)
}

idx <- match(common, snps0)
gwas <- gwas[match(common, SNP)]
R <- as.matrix(fread(ld_file))
R <- R[idx, idx, drop=FALSE]
z <- gwas$STAT

fit <- susie_rss(z=z, R=R, n=max(gwas$NMISS, na.rm=TRUE), L=10, estimate_residual_variance=TRUE)
pip_dt <- data.table(SNP=common, PIP=fit$pip)
fwrite(pip_dt, paste0(out_prefix, ".pip.tsv"), sep="\t")
top <- pip_dt[which.max(PIP)]

cs <- susie_get_cs(fit)
mean_cs_size <- NA_real_
n_cs <- 0L
cs_contains_causal <- 0L

if (!is.null(cs$cs) && length(cs$cs) > 0) {
    cs_sizes <- sapply(cs$cs, length)
    mean_cs_size <- mean(cs_sizes)
    n_cs <- length(cs$cs)
    cs_members <- rbindlist(lapply(seq_along(cs$cs), function(k) {
        data.table(cs_id=names(cs$cs)[k], SNP=common[cs$cs[[k]]])
    }), fill=TRUE)
    fwrite(cs_members, paste0(out_prefix, ".cs_members.tsv"), sep="\t")
    if (causal_snp %in% cs_members$SNP) cs_contains_causal <- 1L
} else {
    fwrite(data.table(cs_id=character(), SNP=character()), paste0(out_prefix, ".cs_members.tsv"), sep="\t")
}

fwrite(data.table(fine_mapped_snp=top$SNP, pip_max=top$PIP, mean_cs_size=mean_cs_size, n_cs=n_cs, cs_contains_causal=cs_contains_causal), paste0(out_prefix, ".summary.tsv"), sep="\t")
EOF

############################################################
# GWAS and sumstats functions
############################################################

run_pop_gwas() {
    local POP=$1
    local BFILE=$2
    local COVAR=$3
    local CAUSAL=$4
    local HSQ=$5
    local CHR=$6
    local START_BP=$7
    local END_BP=$8
    local DIR=$9

    mkdir -p "$DIR"

    "$PLINK" --bfile "$BFILE" --chr "$CHR" --from-bp "$START_BP" --to-bp "$END_BP" --make-bed --threads "$THREADS" --out "$DIR/win" >/dev/null 2>&1
    if [ ! -s "$DIR/win.bim" ]; then
        echo "[WARNING] Window extraction failed for $POP"
        return 1
    fi

    if ! awk -v s="$CAUSAL" '$2==s{found=1; exit} END{exit(found ? 0 : 1)}' "$DIR/win.bim"; then
        echo "[WARNING] Causal SNP absent in $POP window: $CAUSAL"
        return 1
    fi

    printf "%s 1\n" "$CAUSAL" > "$DIR/seed"

    "$GCTA" --bfile "$DIR/win" --simu-qt --simu-causal-loci "$DIR/seed" --simu-hsq "$HSQ" --out "$DIR/sim" >/dev/null 2>&1
    if [ ! -s "$DIR/sim.phen" ]; then
        echo "[WARNING] GCTA simulation failed for $POP"
        return 1
    fi

    (cd "$DIR" && "$RSCRIPT" --vanilla "$INVNORM_R" >/dev/null 2>&1)
    if [ ! -s "$DIR/sim.phen.invnorm" ]; then
        echo "[WARNING] inverse-normal failed for $POP"
        return 1
    fi

    "$PLINK" --bfile "$DIR/win" --pheno "$DIR/sim.phen.invnorm" --covar "$COVAR" --covar-name PC1,PC2,PC3,PC4,PC5,PC6,PC7,PC8,PC9,PC10 --linear hide-covar --allow-no-sex --threads "$THREADS" --out "$DIR/gwas" >/dev/null 2>&1
    if [ ! -s "$DIR/gwas.assoc.linear" ]; then
        echo "[WARNING] GWAS failed for $POP"
        return 1
    fi

    return 0
}

make_sumstats() {
    local BIM=$1
    local GWAS=$2
    local OUT=$3

    awk 'BEGIN{OFS="\t"; print "SNP","A1","A2","BETA","SE","P","N"}
    NR==FNR{a1[$2]=$5; a2[$2]=$6; next}
    FNR>1 && $5=="ADD" && $8!="NA" && $8!=0 && $9!="NA"{
        se=$7/$8; if(se<0)se=-se;
        print $2,a1[$2],a2[$2],$7,se,$9,$6
    }' "$BIM" "$GWAS" > "$OUT"
}

write_gwas_summary() {
    local HSQ=$1
    local LOOP_ID=$2
    local TYPE=$3
    local CAUSAL=$4
    local CAUSAL_CHR=$5
    local CAUSAL_BP=$6
    local GWAS=$7
    local BIM=$8
    local OUT_FILE=$9

    local LEAD_LINE LEAD_CHR LEAD_SNP LEAD_BP LEAD_A1 LEAD_N LEAD_BETA LEAD_STAT LEAD_P
    local LEAD_A2 LEAD_SE LEAD_MAF
    local CAUSAL_LINE CAUSAL_A1 CAUSAL_A2 CAUSAL_BETA CAUSAL_STAT CAUSAL_SE CAUSAL_P CAUSAL_MAF
    local MAF_DIFF BP_DIFF

    LEAD_LINE=$(awk '
        NR > 1 && $5 == "ADD" && $7 != "NA" && $8 != "NA" && $9 != "NA" {
            p = $9 + 0
            if (min == "" || p < min) {
                min = p
                line = $1" "$2" "$3" "$4" "$6" "$7" "$8" "$9
            }
        }
        END { if (line != "") print line }
    ' "$GWAS")

    if [ -z "$LEAD_LINE" ]; then
        write_row "$HSQ" "$LOOP_ID" "NA" "NA" "NA" "NA" "NA" "NA" "NA" "NA" "NA" "$CAUSAL" "$CAUSAL_CHR" "$CAUSAL_BP" "NA" "NA" "NA" "NA" "NA" "NA" "NA" "NA" >> "$OUT_FILE"
        return 0
    fi

    read -r LEAD_CHR LEAD_SNP LEAD_BP LEAD_A1 LEAD_N LEAD_BETA LEAD_STAT LEAD_P <<< "$LEAD_LINE"

    LEAD_A2=$(awk -v s="$LEAD_SNP" '$2==s{print $6; exit}' "$BIM")
    [ -z "$LEAD_A2" ] && LEAD_A2="NA"

    LEAD_SE=$(awk -v b="$LEAD_BETA" -v s="$LEAD_STAT" 'BEGIN{if(b!="NA" && s!="NA" && s!=0){v=b/s; if(v<0)v=-v; print v}else{print "NA"}}')
    LEAD_MAF=$(get_maf "$LEAD_SNP")
    [ -z "$LEAD_MAF" ] && LEAD_MAF="NA"

    CAUSAL_LINE=$(awk -v s="$CAUSAL" '
        NR > 1 && $2 == s && $5 == "ADD" {
            print $4,$7,$8,$9
            exit
        }
    ' "$GWAS")

    if [ -n "$CAUSAL_LINE" ]; then
        read -r CAUSAL_A1 CAUSAL_BETA CAUSAL_STAT CAUSAL_P <<< "$CAUSAL_LINE"
    else
        CAUSAL_A1="NA"
        CAUSAL_BETA="NA"
        CAUSAL_STAT="NA"
        CAUSAL_P="NA"
    fi

    CAUSAL_A2=$(awk -v s="$CAUSAL" '$2==s{print $6; exit}' "$BIM")
    [ -z "$CAUSAL_A2" ] && CAUSAL_A2="NA"

    CAUSAL_SE=$(awk -v b="$CAUSAL_BETA" -v s="$CAUSAL_STAT" 'BEGIN{if(b!="NA" && s!="NA" && s!=0){v=b/s; if(v<0)v=-v; print v}else{print "NA"}}')
    CAUSAL_MAF=$(get_maf "$CAUSAL")
    [ -z "$CAUSAL_MAF" ] && CAUSAL_MAF="NA"

    MAF_DIFF=$(abs_diff "$LEAD_MAF" "$CAUSAL_MAF")
    BP_DIFF=$(abs_diff "$LEAD_BP" "$CAUSAL_BP")

    write_row \
        "$HSQ" \
        "$LOOP_ID" \
        "$LEAD_SNP" \
        "$LEAD_CHR" \
        "$LEAD_BP" \
        "$LEAD_A1" \
        "$LEAD_A2" \
        "$LEAD_BETA" \
        "$LEAD_SE" \
        "$LEAD_P" \
        "$LEAD_MAF" \
        "$CAUSAL" \
        "$CAUSAL_CHR" \
        "$CAUSAL_BP" \
        "$CAUSAL_A1" \
        "$CAUSAL_A2" \
        "$CAUSAL_BETA" \
        "$CAUSAL_SE" \
        "$CAUSAL_P" \
        "$CAUSAL_MAF" \
        "$MAF_DIFF" \
        "$BP_DIFF" \
        >> "$OUT_FILE"
}

############################################################
# SuSiE parser
############################################################

run_susie() {
    local HSQ=$1
    local LOOP_ID=$2
    local TYPE=$3
    local CAUSAL=$4
    local CAUSAL_BP=$5
    local CAUSAL_MAF=$6
    local EUR_FULL_DIR=$7
    local OUT_FILE=$8

    local FM_DIR=$EUR_FULL_DIR/susie
    local START_FM=$(( CAUSAL_BP - 1000000 ))
    local END_FM=$(( CAUSAL_BP + 1000000 ))
    [ "$START_FM" -lt 0 ] && START_FM=0

    mkdir -p "$FM_DIR"

    "$PLINK" --bfile "$EUR_FULL_DIR/win" --chr 1 --from-bp "$START_FM" --to-bp "$END_FM" --make-bed --threads "$THREADS" --out "$FM_DIR/locus" >/dev/null 2>&1
    if [ ! -s "$FM_DIR/locus.bim" ]; then
        write_row "$HSQ" "$LOOP_ID" "SuSiE" "$TYPE" "NA" "NA" "NA" "NA" "$CAUSAL" "$CAUSAL_BP" "$CAUSAL_MAF" "NA" "NA" "0" "NA" "0" "0" >> "$OUT_FILE"
        return 0
    fi

    "$PLINK" --bfile "$FM_DIR/locus" --r square gz --threads "$THREADS" --out "$FM_DIR/ld" >/dev/null 2>&1
    cut -f2 "$FM_DIR/locus.bim" > "$FM_DIR/snp_order.txt"

    "$RSCRIPT" --vanilla "$SUSIE_R" "$EUR_FULL_DIR/gwas.assoc.linear" "$FM_DIR/ld.ld.gz" "$FM_DIR/snp_order.txt" "$CAUSAL" "$FM_DIR/susie" >/dev/null 2>&1 || true

    if [ ! -s "$FM_DIR/susie.summary.tsv" ]; then
        write_row "$HSQ" "$LOOP_ID" "SuSiE" "$TYPE" "NA" "NA" "NA" "NA" "$CAUSAL" "$CAUSAL_BP" "$CAUSAL_MAF" "NA" "NA" "0" "NA" "0" "0" >> "$OUT_FILE"
        return 0
    fi

    read LEAD_SNP PIP_MAX MEAN_CS N_CS CS_CONTAINS <<< $(awk 'NR==2{print $1,$2,$3,$4,$5}' "$FM_DIR/susie.summary.tsv")
    [ -z "$LEAD_SNP" ] && LEAD_SNP="NA"
    [ -z "$PIP_MAX" ] && PIP_MAX="NA"
    [ -z "$MEAN_CS" ] && MEAN_CS="NA"
    [ -z "$N_CS" ] && N_CS="0"
    [ -z "$CS_CONTAINS" ] && CS_CONTAINS="0"

    if [ "$LEAD_SNP" != "NA" ]; then
        LEAD_BP=$(get_bp "$LEAD_SNP" "$FM_DIR/locus.bim")
        LEAD_MAF=$(get_maf "$LEAD_SNP")
        [ -z "$LEAD_BP" ] && LEAD_BP="NA"
        [ -z "$LEAD_MAF" ] && LEAD_MAF="NA"
    else
        LEAD_BP="NA"
        LEAD_MAF="NA"
    fi

    BP_DIFF=$(abs_diff "$LEAD_BP" "$CAUSAL_BP")
    MAF_DIFF=$(abs_diff "$LEAD_MAF" "$CAUSAL_MAF")
    [ "$LEAD_SNP" = "$CAUSAL" ] && EXACT_MATCH=1 || EXACT_MATCH=0

    write_row "$HSQ" "$LOOP_ID" "SuSiE" "$TYPE" "$LEAD_SNP" "$LEAD_BP" "$LEAD_MAF" "$PIP_MAX" "$CAUSAL" "$CAUSAL_BP" "$CAUSAL_MAF" "$BP_DIFF" "$MAF_DIFF" "$EXACT_MATCH" "$MEAN_CS" "$N_CS" "$CS_CONTAINS" >> "$OUT_FILE"
}

############################################################
# SuSiEx parser
############################################################

run_susiex() {
    local HSQ=$1
    local LOOP_ID=$2
    local TYPE=$3
    local CAUSAL=$4
    local CAUSAL_BP=$5
    local CAUSAL_MAF=$6
    local EUR_DIR=$7
    local AFR_DIR=$8
    local OUT_FILE=$9

    local FM_DIR=$(dirname "$EUR_DIR")/susiex
    local START_FM=$(( CAUSAL_BP - 1000000 ))
    local END_FM=$(( CAUSAL_BP + 1000000 ))
    [ "$START_FM" -lt 0 ] && START_FM=0

    mkdir -p "$FM_DIR"
    cp "$EUR_DIR/../EUR.tsv" "$FM_DIR/EUR.tsv"
    cp "$AFR_DIR/../AFR.tsv" "$FM_DIR/AFR.tsv"

    RUN_OK=1

    for POP in EUR AFR; do
        if [ "$POP" = "EUR" ]; then
            SRC_DIR=$EUR_DIR
        else
            SRC_DIR=$AFR_DIR
        fi

        "$PLINK" --bfile "$SRC_DIR/win" --chr 1 --from-bp "$START_FM" --to-bp "$END_FM" --make-bed --threads "$THREADS" --out "$FM_DIR/${POP}.fmwin" >/dev/null 2>&1 || RUN_OK=0
        [ ! -s "$FM_DIR/${POP}.fmwin.bim" ] && RUN_OK=0
    done

    if [ "$RUN_OK" -ne 1 ]; then
        write_row "$HSQ" "$LOOP_ID" "SuSiEx" "$TYPE" "NA" "NA" "NA" "NA" "$CAUSAL" "$CAUSAL_BP" "$CAUSAL_MAF" "NA" "NA" "0" "NA" "0" "0" >> "$OUT_FILE"
        return 0
    fi

    N_EUR=$(wc -l < "$EUR_DIR/win.fam")
    N_AFR=$(wc -l < "$AFR_DIR/win.fam")

    for POP in EUR AFR; do
        if [ "$POP" = "EUR" ]; then
            N=$N_EUR
        else
            N=$N_AFR
        fi

        awk -v n="$N" 'BEGIN{OFS="\t"; print "CHR","SNP","BP","A1","A2","BETA","SE","P","N"}
        NR==FNR{if(FNR>1){a1[$1]=$2; a2[$1]=$3; beta[$1]=$4; se[$1]=$5; p[$1]=$6}; next}
        {snp=$2; if(snp in beta && beta[snp]!="NA" && se[snp]!="NA" && p[snp]!="NA" && se[snp]>0){print 1,snp,$4,a1[snp],a2[snp],beta[snp],se[snp],p[snp],n}}
        ' "$FM_DIR/${POP}.tsv" "$FM_DIR/${POP}.fmwin.bim" > "$FM_DIR/${POP}.susiex.tsv"
    done

    if [ "$(awk 'NR>1{n++} END{print n+0}' "$FM_DIR/EUR.susiex.tsv")" -eq 0 ] || [ "$(awk 'NR>1{n++} END{print n+0}' "$FM_DIR/AFR.susiex.tsv")" -eq 0 ]; then
        write_row "$HSQ" "$LOOP_ID" "SuSiEx" "$TYPE" "NA" "NA" "NA" "NA" "$CAUSAL" "$CAUSAL_BP" "$CAUSAL_MAF" "NA" "NA" "0" "NA" "0" "0" >> "$OUT_FILE"
        return 0
    fi

    rm -rf "$FM_DIR/out"
    mkdir -p "$FM_DIR/out"

    "$SUSIEX" \
        --sst_file="$FM_DIR/EUR.susiex.tsv,$FM_DIR/AFR.susiex.tsv" \
        --n_gwas="$N_EUR,$N_AFR" \
        --ref_file="$FM_DIR/EUR.fmwin,$FM_DIR/AFR.fmwin" \
        --ld_file="$FM_DIR/out/EUR,$FM_DIR/out/AFR" \
        --out_dir="$FM_DIR/out" \
        --out_name=susiex \
        --chr=1 \
        --bp="${START_FM},${END_FM}" \
        --chr_col=1,1 \
        --snp_col=2,2 \
        --bp_col=3,3 \
        --a1_col=4,4 \
        --a2_col=5,5 \
        --eff_col=6,6 \
        --se_col=7,7 \
        --pval_col=8,8 \
        --plink="$PLINK" \
        --keep-ambig=TRUE \
        --n_sig=10 \
        --level=0.95 \
        --min_purity=0.5 \
        --threads=1 >/dev/null 2>&1 || true

    LEAD_SNP="NA"; LEAD_BP="NA"; PIP_MAX="NA"; MEAN_CS="NA"; N_CS="0"; CS_CONTAINS="0"

    if [ -s "$FM_DIR/out/susiex.snp" ]; then
        read LEAD_SNP LEAD_BP PIP_MAX <<< $(awk 'NR==1{next}{pip=$3+0; if(max=="" || pip>max){max=pip; bp=$1; snp=$2}} END{if(snp!="")print snp,bp,max; else print "NA NA NA"}' "$FM_DIR/out/susiex.snp")
    fi

    if [ -s "$FM_DIR/out/susiex.cs" ]; then
        read MEAN_CS N_CS CS_CONTAINS <<< $(awk -v causal="$CAUSAL" 'NR==1{next}{cs=$1; snp=$2; count[cs]++; if(snp==causal)contains=1} END{n=0; sum=0; for(cs in count){n++; sum+=count[cs]}; if(n>0)print sum/n,n,(contains?1:0); else print "NA 0 0"}' "$FM_DIR/out/susiex.cs")
    fi

    if [ "$LEAD_SNP" != "NA" ]; then
        [ -z "$LEAD_BP" ] || [ "$LEAD_BP" = "NA" ] && LEAD_BP=$(get_bp "$LEAD_SNP" "$FM_DIR/EUR.fmwin.bim")
        LEAD_MAF=$(get_maf "$LEAD_SNP")
        [ -z "$LEAD_BP" ] && LEAD_BP="NA"
        [ -z "$LEAD_MAF" ] && LEAD_MAF="NA"
    else
        LEAD_MAF="NA"
    fi

    BP_DIFF=$(abs_diff "$LEAD_BP" "$CAUSAL_BP")
    MAF_DIFF=$(abs_diff "$LEAD_MAF" "$CAUSAL_MAF")
    [ "$LEAD_SNP" = "$CAUSAL" ] && EXACT_MATCH=1 || EXACT_MATCH=0

    write_row "$HSQ" "$LOOP_ID" "SuSiEx" "$TYPE" "$LEAD_SNP" "$LEAD_BP" "$LEAD_MAF" "$PIP_MAX" "$CAUSAL" "$CAUSAL_BP" "$CAUSAL_MAF" "$BP_DIFF" "$MAF_DIFF" "$EXACT_MATCH" "$MEAN_CS" "$N_CS" "$CS_CONTAINS" >> "$OUT_FILE"
}

write_comparison() {
    local HSQ=$1
    local LOOP_ID=$2
    local TYPE=$3
    local SUSIE_LINE_FILE=$4
    local SUSIEX_LINE_FILE=$5
    local OUT_FILE=$6

    S_MEAN=$(awk -F'\t' 'END{print $15}' "$SUSIE_LINE_FILE")
    X_MEAN=$(awk -F'\t' 'END{print $15}' "$SUSIEX_LINE_FILE")
    S_PIP=$(awk -F'\t' 'END{print $8}' "$SUSIE_LINE_FILE")
    X_PIP=$(awk -F'\t' 'END{print $8}' "$SUSIEX_LINE_FILE")
    S_BP=$(awk -F'\t' 'END{print $12}' "$SUSIE_LINE_FILE")
    X_BP=$(awk -F'\t' 'END{print $12}' "$SUSIEX_LINE_FILE")
    S_MAF=$(awk -F'\t' 'END{print $13}' "$SUSIE_LINE_FILE")
    X_MAF=$(awk -F'\t' 'END{print $13}' "$SUSIEX_LINE_FILE")
    S_EXACT=$(awk -F'\t' 'END{print $14}' "$SUSIE_LINE_FILE")
    X_EXACT=$(awk -F'\t' 'END{print $14}' "$SUSIEX_LINE_FILE")
    S_CS_CAUSAL=$(awk -F'\t' 'END{print $17}' "$SUSIE_LINE_FILE")
    X_CS_CAUSAL=$(awk -F'\t' 'END{print $17}' "$SUSIEX_LINE_FILE")

    if [ "$S_MEAN" = "NA" ] || [ "$X_MEAN" = "NA" ]; then
        CS_DIFF="NA"; SMALLER="NA"; CS_EQUAL="NA"
    else
        CS_DIFF=$(awk -v s="$S_MEAN" -v x="$X_MEAN" 'BEGIN{print s-x}')
        SMALLER=$(awk -v s="$S_MEAN" -v x="$X_MEAN" 'BEGIN{if(s<x)print "SuSiE"; else if(x<s)print "SuSiEx"; else print "Equal"}')
        CS_EQUAL=$(awk -v s="$S_MEAN" -v x="$X_MEAN" 'BEGIN{if(s==x)print 1; else print 0}')
    fi

    if [ "$CS_EQUAL" = "1" ]; then
        HIGHER_PIP=$(awk -v s="$S_PIP" -v x="$X_PIP" 'BEGIN{if(s=="NA" || x=="NA")print "NA"; else if(s>x)print "SuSiE"; else if(x>s)print "SuSiEx"; else print "Equal"}')
    else
        HIGHER_PIP="NA"
    fi

    BETTER_BP=$(awk -v s="$S_BP" -v x="$X_BP" 'BEGIN{if(s=="NA" || x=="NA")print "NA"; else if(s<x)print "SuSiE"; else if(x<s)print "SuSiEx"; else print "Equal"}')
    BETTER_MAF=$(awk -v s="$S_MAF" -v x="$X_MAF" 'BEGIN{if(s=="NA" || x=="NA")print "NA"; else if(s<x)print "SuSiE"; else if(x<s)print "SuSiEx"; else print "Equal"}')

    write_row "$HSQ" "$LOOP_ID" "$TYPE" "$S_MEAN" "$X_MEAN" "$CS_DIFF" "$SMALLER" "$CS_EQUAL" "$S_PIP" "$X_PIP" "$HIGHER_PIP" "$S_BP" "$X_BP" "$S_MAF" "$X_MAF" "$S_EXACT" "$X_EXACT" "$S_CS_CAUSAL" "$X_CS_CAUSAL" "$BETTER_BP" "$BETTER_MAF" >> "$OUT_FILE"
}

############################################################
# Main analysis for one hsq-loop-type
############################################################

run_one_type_hsq_loop() {
    local TYPE=$1
    local HSQ=$2
    local LOOP_ID=$3

    if [ "$TYPE" = "common" ]; then
        CAUSAL_FILE=$COMMON_CAUSAL_FILE
        EUR_BFILE=$EUR_COMMON
        AFR_BFILE=$AFR_COMMON
        EUR_FULL_BFILE=$EUR_FULL_COMMON
        EUR_COVAR=$EUR_COMMON_COVAR
        AFR_COVAR=$AFR_COMMON_COVAR
        EUR_FULL_COVAR=$EUR_FULL_COMMON_COVAR
        SUSIE_OUT=$COMMON_SUSIE_OUT
        SUSIEX_OUT=$COMMON_SUSIEX_OUT
        COMPARE_OUT=$COMMON_COMPARE_OUT
        GWAS_SUMMARY_OUT=$COMMON_GWAS_SUMMARY_OUT
    else
        CAUSAL_FILE=$RARE_CAUSAL_FILE
        EUR_BFILE=$EUR_RARE
        AFR_BFILE=$AFR_RARE
        EUR_FULL_BFILE=$EUR_FULL_RARE
        EUR_COVAR=$EUR_RARE_COVAR
        AFR_COVAR=$AFR_RARE_COVAR
        EUR_FULL_COVAR=$EUR_FULL_RARE_COVAR
        SUSIE_OUT=$RARE_SUSIE_OUT
        SUSIEX_OUT=$RARE_SUSIEX_OUT
        COMPARE_OUT=$RARE_COMPARE_OUT
        GWAS_SUMMARY_OUT=$RARE_GWAS_SUMMARY_OUT
    fi

    LOOP_DIR=$TMP/${TYPE}_hsq_${HSQ}_loop_$(printf "%04d" "$LOOP_ID")
    mkdir -p "$LOOP_DIR"

    echo "============================================================"
    echo "[INFO] Type=$TYPE hsq=$HSQ loop=$LOOP_ID"
    echo "============================================================"

    CAUSAL=$(get_causal_snp "$CAUSAL_FILE" "$HSQ" "$LOOP_ID")
    if [ -z "$CAUSAL" ]; then
        echo "[WARNING] No causal SNP for type=$TYPE hsq=$HSQ loop=$LOOP_ID"
        rm -rf "$LOOP_DIR"
        return 0
    fi

    CAUSAL_INFO=$(awk -v s="$CAUSAL" '$2==s{print $1,$4; exit}' "${EUR_BFILE}.bim")
    if [ -z "$CAUSAL_INFO" ]; then
        echo "[WARNING] Causal SNP not in EUR $TYPE bfile: $CAUSAL"
        rm -rf "$LOOP_DIR"
        return 0
    fi

    read -r CHR BP <<< "$CAUSAL_INFO"
    START_BP=$(( BP - 20000000 ))
    END_BP=$(( BP + 20000000 ))
    [ "$START_BP" -lt 0 ] && START_BP=0

    CAUSAL_MAF=$(get_maf "$CAUSAL")
    [ -z "$CAUSAL_MAF" ] && CAUSAL_MAF="NA"

    run_pop_gwas EUR "$EUR_BFILE" "$EUR_COVAR" "$CAUSAL" "$HSQ" "$CHR" "$START_BP" "$END_BP" "$LOOP_DIR/EUR" || { rm -rf "$LOOP_DIR"; return 0; }
    run_pop_gwas AFR "$AFR_BFILE" "$AFR_COVAR" "$CAUSAL" "$HSQ" "$CHR" "$START_BP" "$END_BP" "$LOOP_DIR/AFR" || { rm -rf "$LOOP_DIR"; return 0; }
    run_pop_gwas EUR_FULL "$EUR_FULL_BFILE" "$EUR_FULL_COVAR" "$CAUSAL" "$HSQ" "$CHR" "$START_BP" "$END_BP" "$LOOP_DIR/EUR_FULL" || { rm -rf "$LOOP_DIR"; return 0; }

    # Single-ancestry EUR_FULL GWAS summary. Output columns are kept identical
    # to the original hsq GWAS script, except that the causal SNP is fixed
    # and the GWAS model is adjusted for PC1-PC10.
    write_gwas_summary         "$HSQ"         "$LOOP_ID"         "$TYPE"         "$CAUSAL"         "$CHR"         "$BP"         "$LOOP_DIR/EUR_FULL/gwas.assoc.linear"         "$LOOP_DIR/EUR_FULL/win.bim"         "$GWAS_SUMMARY_OUT"

    make_sumstats "$LOOP_DIR/EUR/win.bim" "$LOOP_DIR/EUR/gwas.assoc.linear" "$LOOP_DIR/EUR.tsv"
    make_sumstats "$LOOP_DIR/AFR/win.bim" "$LOOP_DIR/AFR/gwas.assoc.linear" "$LOOP_DIR/AFR.tsv"

    SUSIE_LINE=$LOOP_DIR/susie_line.tsv
    SUSIEX_LINE=$LOOP_DIR/susiex_line.tsv
    printf "%b\n" "$SUMMARY_HEADER" > "$SUSIE_LINE"
    printf "%b\n" "$SUMMARY_HEADER" > "$SUSIEX_LINE"

    run_susie "$HSQ" "$LOOP_ID" "$TYPE" "$CAUSAL" "$BP" "$CAUSAL_MAF" "$LOOP_DIR/EUR_FULL" "$SUSIE_LINE"
    tail -n 1 "$SUSIE_LINE" >> "$SUSIE_OUT"

    run_susiex "$HSQ" "$LOOP_ID" "$TYPE" "$CAUSAL" "$BP" "$CAUSAL_MAF" "$LOOP_DIR/EUR" "$LOOP_DIR/AFR" "$SUSIEX_LINE"
    tail -n 1 "$SUSIEX_LINE" >> "$SUSIEX_OUT"

    write_comparison "$HSQ" "$LOOP_ID" "$TYPE" "$SUSIE_LINE" "$SUSIEX_LINE" "$COMPARE_OUT"

    rm -rf "$LOOP_DIR"
}



############################################################
# Power summary
############################################################


calculate_gwas_power_metrics() {
    local VARIANT_TYPE=$1
    local SUMMARY_FILE=$2
    local OUT_FILE=$3

    if [ ! -s "$SUMMARY_FILE" ]; then
        return 0
    fi

    awk -F'\t' -v type="$VARIANT_TYPE" '
    BEGIN {
        OFS = "\t"
        threshold = 5e-8
    }
    NR == 1 {
        for (i = 1; i <= NF; i++) {
            col[$i] = i
        }
        next
    }
    {
        hsq = $(col["hsq"])
        n_all[hsq]++

        lead_snp = $(col["lead_SNP"])
        causal_snp = $(col["causal_SNP"])
        lead_p = $(col["lead_P"])
        causal_p = $(col["causal_P"])

        valid = 0
        if (lead_snp != "NA" && lead_snp != "" && lead_p != "NA" && lead_p != "") {
            valid = 1
            n_valid[hsq]++
        }

        if (lead_p != "NA" && lead_p != "" && lead_p + 0 < threshold) {
            lead_sig_all[hsq]++
            if (valid == 1) lead_sig_valid[hsq]++
        }

        if (causal_p != "NA" && causal_p != "" && causal_p + 0 < threshold) {
            causal_sig_all[hsq]++
            if (valid == 1) causal_sig_valid[hsq]++
        }

        if (lead_snp != "NA" && causal_snp != "NA" && lead_snp == causal_snp) {
            exact_all[hsq]++
            if (valid == 1) exact_valid[hsq]++
        }
    }
    END {
        for (h in n_all) {
            lead_power_all = lead_sig_all[h] / n_all[h]
            causal_power_all = causal_sig_all[h] / n_all[h]
            exact_power_all = exact_all[h] / n_all[h]

            if (n_valid[h] > 0) {
                lead_power_valid = lead_sig_valid[h] / n_valid[h]
                causal_power_valid = causal_sig_valid[h] / n_valid[h]
                exact_power_valid = exact_valid[h] / n_valid[h]
            } else {
                lead_power_valid = "NA"
                causal_power_valid = "NA"
                exact_power_valid = "NA"
            }

            print type, h, n_all[h], n_valid[h] + 0, lead_power_all, causal_power_all, exact_power_all, lead_power_valid, causal_power_valid, exact_power_valid
        }
    }
    ' "$SUMMARY_FILE" | sort -k2,2n >> "$OUT_FILE"
}

calculate_power_metrics() {
    local VARIANT_TYPE=$1
    local SUMMARY_FILE=$2
    local OUT_FILE=$3

    if [ ! -s "$SUMMARY_FILE" ]; then
        return 0
    fi

    awk -F'\t' -v type="$VARIANT_TYPE" '
    NR > 1 {
        hsq = $1
        method = $3
        key = hsq SUBSEP method

        n_all[key]++

        if ($5 != "NA" && $5 != "") {
            n_fm[key]++
        }

        if ($14 == 1) {
            exact_all[key]++
            if ($5 != "NA" && $5 != "") {
                exact_fm[key]++
            }
        }

        if ($17 == 1) {
            cs_all[key]++
            if ($5 != "NA" && $5 != "") {
                cs_fm[key]++
            }
        }
    }
    END {
        for (key in n_all) {
            split(key, a, SUBSEP)
            hsq = a[1]
            method = a[2]

            exact_power_all = exact_all[key] / n_all[key]
            cs_power_all = cs_all[key] / n_all[key]

            if (n_fm[key] > 0) {
                exact_power_fm = exact_fm[key] / n_fm[key]
                cs_power_fm = cs_fm[key] / n_fm[key]
            } else {
                exact_power_fm = "NA"
                cs_power_fm = "NA"
            }

            print type, hsq, method, n_all[key], n_fm[key] + 0, exact_power_all, cs_power_all, exact_power_fm, cs_power_fm
        }
    }
    ' OFS='\t' "$SUMMARY_FILE" | sort -k2,2n -k3,3 >> "$OUT_FILE"
}

############################################################
# Main loop
############################################################

echo "============================================================"
echo "[INFO] hsq SuSiE / SuSiEx power analysis started"
echo "[INFO] Array task: $TASK_ID"
echo "[INFO] Loops per array: $LOOPS_PER_ARRAY"
echo "[INFO] Loop range: $START-$END"
echo "[INFO] HSQ values: $HSQ_LIST"
echo "[INFO] Converted causal directory: $CAUSAL_DIR"
echo "[INFO] Output directory: $OUT_DIR"
echo "[INFO] Common power output: $COMMON_POWER_OUT"
echo "[INFO] Rare power output: $RARE_POWER_OUT"
echo "============================================================"

for HSQ in $HSQ_LIST; do
    for ((i=START; i<=END; i++)); do
        run_one_type_hsq_loop common "$HSQ" "$i"
        run_one_type_hsq_loop rare "$HSQ" "$i"
    done
done

echo "============================================================"
echo "[INFO] Calculating hsq-level power summaries"
echo "============================================================"
calculate_gwas_power_metrics common "$COMMON_GWAS_SUMMARY_OUT" "$COMMON_GWAS_POWER_OUT"
calculate_gwas_power_metrics rare "$RARE_GWAS_SUMMARY_OUT" "$RARE_GWAS_POWER_OUT"

calculate_power_metrics common "$COMMON_SUSIE_OUT" "$COMMON_POWER_OUT"
calculate_power_metrics common "$COMMON_SUSIEX_OUT" "$COMMON_POWER_OUT"
calculate_power_metrics rare "$RARE_SUSIE_OUT" "$RARE_POWER_OUT"
calculate_power_metrics rare "$RARE_SUSIEX_OUT" "$RARE_POWER_OUT"

rm -rf "$TMP"

echo "============================================================"
echo "[INFO] hsq SuSiE / SuSiEx power analysis completed"
echo "[INFO] Output directory: $OUT_DIR"
echo "[INFO] Common power output: $COMMON_POWER_OUT"
echo "[INFO] Rare power output: $RARE_POWER_OUT"
echo "============================================================"
