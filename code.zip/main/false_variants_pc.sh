#!/bin/bash
set -euo pipefail

############################################################
# PCA for EUR 10K pfiles
#
# Input pfiles:
#   all variants:
#     /work/home/chengzesong/data/gwas/EUR/EUR_10k_QC
#
#   common variants:
#     /work/home/chengzesong/data/gwas/EUR/EUR_10k_common
#
#   rare variants:
#     /work/home/chengzesong/data/gwas/EUR/EUR_10k_rare
#
# Output:
#   FID IID PC1-PC10 covariate files
#
# Output directory:
#   /work/home/chengzesong/simu_gwas/new_eur/PCA
############################################################


############################################################
# Software
############################################################

PLINK2=/work/home/chengzesong/software/plink2

THREADS=5


############################################################
# Paths
############################################################

ROOT=/work/home/chengzesong/simu_gwas

OUTDIR=$ROOT/new_eur/PCA
TMPDIR=$OUTDIR/tmp_eur10k_pfile_pca

mkdir -p "$OUTDIR"
mkdir -p "$TMPDIR"


############################################################
# Input pfiles
############################################################

EUR_FULL=/work/home/chengzesong/data/gwas/EUR/EUR_10k_QC
EUR_COMMON=/work/home/chengzesong/data/gwas/EUR/EUR_10k_common
EUR_RARE=/work/home/chengzesong/data/gwas/EUR/EUR_10k_rare


############################################################
# Check PLINK2
############################################################

if [ ! -x "$PLINK2" ]; then
    echo "[ERROR] PLINK2 is not executable:"
    echo "$PLINK2"
    exit 1
fi


############################################################
# Function: check pfile
############################################################

check_pfile()
{
    local PFILE=$1
    local LABEL=$2

    if [ ! -s "${PFILE}.pgen" ]; then
        echo "[ERROR] Missing or empty file for $LABEL:"
        echo "${PFILE}.pgen"
        exit 1
    fi

    if [ ! -s "${PFILE}.pvar" ]; then
        echo "[ERROR] Missing or empty file for $LABEL:"
        echo "${PFILE}.pvar"
        exit 1
    fi

    if [ ! -s "${PFILE}.psam" ]; then
        echo "[ERROR] Missing or empty file for $LABEL:"
        echo "${PFILE}.psam"
        exit 1
    fi
}


############################################################
# Function: run PCA for one pfile
############################################################

run_pca()
{
    local LABEL=$1
    local PFILE=$2

    local WORKDIR=$TMPDIR/$LABEL
    local PRUNE_PREFIX=$WORKDIR/${LABEL}.prune
    local PCA_PREFIX=$WORKDIR/${LABEL}.pca
    local FINAL_COVAR=$OUTDIR/${LABEL}.PC1_10.covariates.txt
    local EIGENVAL_OUT=$OUTDIR/${LABEL}.eigenval.txt

    mkdir -p "$WORKDIR"

    echo
    echo "============================================================"
    echo "[INFO] Running PCA"
    echo "[INFO] Label: $LABEL"
    echo "[INFO] PFILE: $PFILE"
    echo "[INFO] Final covariate file: $FINAL_COVAR"
    echo "============================================================"

    check_pfile "$PFILE" "$LABEL"

    ########################################################
    # 1. LD pruning
    #
    # Use only variants with missingness <=5%.
    # Window = 50 variants, step = 5 variants, r2 = 0.2.
    ########################################################

    "$PLINK2" \
        --pfile "$PFILE" \
        --geno 0.05 \
        --indep-pairwise 50 5 0.2 \
        --threads "$THREADS" \
        --out "$PRUNE_PREFIX"

    if [ ! -s "${PRUNE_PREFIX}.prune.in" ]; then
        echo "[ERROR] No variants retained after LD pruning for $LABEL"
        rm -rf "$WORKDIR"
        exit 1
    fi

    N_PRUNED=$(wc -l < "${PRUNE_PREFIX}.prune.in")

    echo "[INFO] Pruned variant count: $N_PRUNED"

    ########################################################
    # 2. PCA
    #
    # PLINK2 eigenvec output normally contains:
    #   #FID IID PC1 PC2 ... PC10
    ########################################################

    "$PLINK2" \
        --pfile "$PFILE" \
        --extract "${PRUNE_PREFIX}.prune.in" \
        --pca 10 \
        --threads "$THREADS" \
        --out "$PCA_PREFIX"

    if [ ! -s "${PCA_PREFIX}.eigenvec" ]; then
        echo "[ERROR] PCA failed for $LABEL"
        rm -rf "$WORKDIR"
        exit 1
    fi

    if [ -s "${PCA_PREFIX}.eigenval" ]; then
        cp "${PCA_PREFIX}.eigenval" "$EIGENVAL_OUT"
    fi

    ########################################################
    # 3. Format final covariate file
    #
    # Output format:
    #   FID IID PC1 PC2 ... PC10
    #
    # PLINK2 eigenvec header may contain #FID.
    # We normalise it to FID.
    ########################################################

    awk '
    BEGIN {
        OFS = "\t"
    }
    NR == 1 {
        for (i = 1; i <= NF; i++) {
            h = $i
            gsub(/^#/, "", h)
            header[i] = h
        }

        print "FID","IID","PC1","PC2","PC3","PC4","PC5","PC6","PC7","PC8","PC9","PC10"
        next
    }
    {
        print $1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12
    }
    ' "${PCA_PREFIX}.eigenvec" > "$FINAL_COVAR"

    if [ ! -s "$FINAL_COVAR" ]; then
        echo "[ERROR] Failed to generate final covariate file for $LABEL"
        rm -rf "$WORKDIR"
        exit 1
    fi

    N_SAMPLE=$(awk 'NR > 1 {n++} END {print n + 0}' "$FINAL_COVAR")

    echo "[DONE] PCA finished for $LABEL"
    echo "[INFO] Sample count: $N_SAMPLE"
    echo "[INFO] Covariate file: $FINAL_COVAR"

    ########################################################
    # 4. Remove intermediate files
    ########################################################

    rm -rf "$WORKDIR"
}


############################################################
# Run PCA
############################################################

run_pca "EUR_10k_QC" "$EUR_FULL"
run_pca "EUR_10k_common" "$EUR_COMMON"
run_pca "EUR_10k_rare" "$EUR_RARE"


############################################################
# Summary
############################################################

SUMMARY=$OUTDIR/EUR_10k_pfile_PCA_covariates.summary.txt

{
    echo -e "label\tpfile\tcovariate_file\teigenval_file\tn_samples\tstatus"

    for LABEL in EUR_10k_QC EUR_10k_common EUR_10k_rare; do

        case "$LABEL" in
            EUR_10k_QC)
                PFILE=$EUR_FULL
                ;;
            EUR_10k_common)
                PFILE=$EUR_COMMON
                ;;
            EUR_10k_rare)
                PFILE=$EUR_RARE
                ;;
        esac

        COVAR=$OUTDIR/${LABEL}.PC1_10.covariates.txt
        EIGENVAL=$OUTDIR/${LABEL}.eigenval.txt

        if [ -s "$COVAR" ]; then
            N_SAMPLE=$(awk 'NR > 1 {n++} END {print n + 0}' "$COVAR")
            echo -e "${LABEL}\t${PFILE}\t${COVAR}\t${EIGENVAL}\t${N_SAMPLE}\tGENERATED"
        else
            echo -e "${LABEL}\t${PFILE}\t${COVAR}\t${EIGENVAL}\tNA\tNOT_GENERATED"
        fi

    done

} > "$SUMMARY"


############################################################
# Cleanup
############################################################

rmdir "$TMPDIR" 2>/dev/null || true


############################################################
# Final message
############################################################

echo
echo "============================================================"
echo "[DONE] EUR 10K PCA finished"
echo "[INFO] Output directory:"
echo "$OUTDIR"
echo
echo "[INFO] Summary file:"
echo "$SUMMARY"
echo
echo "[INFO] Final covariate files:"
ls -lh "$OUTDIR"/EUR_10k_QC.PC1_10.covariates.txt
ls -lh "$OUTDIR"/EUR_10k_common.PC1_10.covariates.txt
ls -lh "$OUTDIR"/EUR_10k_rare.PC1_10.covariates.txt
echo "============================================================"