#!/usr/bin/env bash
set -Eeuo pipefail

export LC_ALL=C

############################################################
# Merge add1k final files by prefix
#
# Input directories:
#   pooled_gwas
#   single_ancestry_gwas
#   susie
#   susiex
#
# Only *.with_ld_r2.txt files are merged.
# Header is retained only once.
#
# Files are sorted by array/task number numerically.
############################################################

ROOT="/work/home/chengzesong/simu_gwas/add1k"

POOLED_DIR="${ROOT}/pooled_gwas"
SINGLE_DIR="${ROOT}/single_ancestry_gwas"
SUSIE_DIR="${ROOT}/susie"
SUSIEX_DIR="${ROOT}/susiex"

############################################################
# Output directories
############################################################

POOLED_OUT="${POOLED_DIR}/merged"
SINGLE_OUT="${SINGLE_DIR}/merged"
SUSIE_OUT="${SUSIE_DIR}/merged"
SUSIEX_OUT="${SUSIEX_DIR}/merged"

mkdir -p \
    "$POOLED_OUT" \
    "$SINGLE_OUT" \
    "$SUSIE_OUT" \
    "$SUSIEX_OUT"


############################################################
# Merge function
#
# Usage:
# merge_files \
#     input_dir \
#     glob_pattern \
#     output_file
############################################################

merge_files()
{
    local INPUT_DIR="$1"
    local PATTERN="$2"
    local OUTPUT_FILE="$3"

    echo
    echo "============================================================"
    echo "[INFO] Input directory : $INPUT_DIR"
    echo "[INFO] Pattern         : $PATTERN"
    echo "[INFO] Output          : $OUTPUT_FILE"
    echo "============================================================"

    ########################################################
    # Find input files
    #
    # sort -V ensures:
    #   *_51_* < *_52_* < ... < *_100_*
    ########################################################

    mapfile -t FILES < <(
        find "$INPUT_DIR" \
            -maxdepth 1 \
            -type f \
            -name "$PATTERN" \
            -print |
        LC_ALL=C sort -V
    )

    local N_FILES=${#FILES[@]}

    echo "[INFO] Number of files found: $N_FILES"

    if [ "$N_FILES" -eq 0 ]; then
        echo "[WARNING] No files found."
        return 0
    fi

    ########################################################
    # Print files in merge order
    ########################################################

    echo "[INFO] Merge order:"

    for f in "${FILES[@]}"; do
        echo "    $(basename "$f")"
    done


    ########################################################
    # Check that all headers are identical
    ########################################################

    local FIRST_HEADER
    FIRST_HEADER=$(head -n 1 "${FILES[0]}" | tr -d '\r')

    for f in "${FILES[@]}"; do

        local CURRENT_HEADER
        CURRENT_HEADER=$(head -n 1 "$f" | tr -d '\r')

        if [ "$CURRENT_HEADER" != "$FIRST_HEADER" ]; then

            echo "[ERROR] Header mismatch:"
            echo "        $f"
            echo
            echo "[EXPECTED]"
            echo "$FIRST_HEADER"
            echo
            echo "[FOUND]"
            echo "$CURRENT_HEADER"

            exit 1
        fi
    done

    echo "[INFO] All headers are identical."


    ########################################################
    # Merge
    #
    # First file:
    #   retain header
    #
    # Remaining files:
    #   skip first line
    ########################################################

    : > "$OUTPUT_FILE"

    awk '
        FNR == 1 {
            if (ARGIND == 1) {
                print
            }
            next
        }
        {
            print
        }
    ' "${FILES[@]}" > "$OUTPUT_FILE"


    ########################################################
    # If current awk does not support ARGIND,
    # fallback to fully portable merge.
    ########################################################

    if [ ! -s "$OUTPUT_FILE" ]; then

        echo "[INFO] ARGIND unavailable; using portable merge method."

        : > "$OUTPUT_FILE"

        head -n 1 "${FILES[0]}" >> "$OUTPUT_FILE"

        for f in "${FILES[@]}"; do
            tail -n +2 "$f" >> "$OUTPUT_FILE"
        done
    fi


    ########################################################
    # QC
    ########################################################

    local N_TOTAL
    local N_DATA

    N_TOTAL=$(wc -l < "$OUTPUT_FILE")
    N_DATA=$((N_TOTAL - 1))

    echo "[DONE] Merge completed."
    echo "[INFO] Number of source files : $N_FILES"
    echo "[INFO] Number of data rows    : $N_DATA"
    echo "[INFO] Final file             : $OUTPUT_FILE"
}


############################################################
# 1. pooled GWAS
############################################################

merge_files \
    "$POOLED_DIR" \
    "common_pooled_*_sig.with_ld_r2.txt" \
    "$POOLED_OUT/common_pooled_sig.merged.with_ld_r2.txt"

merge_files \
    "$POOLED_DIR" \
    "rare_pooled_*_sig.with_ld_r2.txt" \
    "$POOLED_OUT/rare_pooled_sig.merged.with_ld_r2.txt"


############################################################
# 2. single-ancestry EUR GWAS
############################################################

merge_files \
    "$SINGLE_DIR" \
    "common_EUR_*_sig.with_ld_r2.txt" \
    "$SINGLE_OUT/common_EUR_sig.merged.with_ld_r2.txt"

merge_files \
    "$SINGLE_DIR" \
    "rare_EUR_*_sig.with_ld_r2.txt" \
    "$SINGLE_OUT/rare_EUR_sig.merged.with_ld_r2.txt"


############################################################
# 3. SuSiE
############################################################

merge_files \
    "$SUSIE_DIR" \
    "common_EUR_*_susie_summary.with_ld_r2.txt" \
    "$SUSIE_OUT/common_EUR_susie_summary.merged.with_ld_r2.txt"

merge_files \
    "$SUSIE_DIR" \
    "rare_EUR_*_susie_summary.with_ld_r2.txt" \
    "$SUSIE_OUT/rare_EUR_susie_summary.merged.with_ld_r2.txt"


############################################################
# 4. SuSiEx
############################################################

merge_files \
    "$SUSIEX_DIR" \
    "common_susiex_*_summary.with_ld_r2.txt" \
    "$SUSIEX_OUT/common_susiex_summary.merged.with_ld_r2.txt"

merge_files \
    "$SUSIEX_DIR" \
    "rare_susiex_*_summary.with_ld_r2.txt" \
    "$SUSIEX_OUT/rare_susiex_summary.merged.with_ld_r2.txt"


############################################################
# Final summary
############################################################

echo
echo "============================================================"
echo "[DONE] All files merged successfully"
echo "============================================================"

echo
echo "Pooled GWAS:"
echo "  $POOLED_OUT/common_pooled_sig.merged.with_ld_r2.txt"
echo "  $POOLED_OUT/rare_pooled_sig.merged.with_ld_r2.txt"

echo
echo "Single-ancestry GWAS:"
echo "  $SINGLE_OUT/common_EUR_sig.merged.with_ld_r2.txt"
echo "  $SINGLE_OUT/rare_EUR_sig.merged.with_ld_r2.txt"

echo
echo "SuSiE:"
echo "  $SUSIE_OUT/common_EUR_susie_summary.merged.with_ld_r2.txt"
echo "  $SUSIE_OUT/rare_EUR_susie_summary.merged.with_ld_r2.txt"

echo
echo "SuSiEx:"
echo "  $SUSIEX_OUT/common_susiex_summary.merged.with_ld_r2.txt"
echo "  $SUSIEX_OUT/rare_susiex_summary.merged.with_ld_r2.txt"

echo
echo "============================================================"