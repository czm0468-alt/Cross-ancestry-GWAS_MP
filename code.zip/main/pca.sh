#!/bin/bash
set -euo pipefail

############################################################
# PCA for common and rare bfiles
# Keep only final PC1-PC10 covariate files
############################################################


############################################################
# Software paths
############################################################

PLINK="/work/home/ac3xibpp15/software/bin/plink"
GCTA="/work/home/shilulu/software/gcta-1.94.4/gcta"
METAL="/work/home/chengzesong/software/generic-metal/metal"
RSCRIPT="/public/software/VersionHub/R/4.5.1/Rscript"
SUSIEX="/work/home/chengzesong/software/SusieX/SuSiEx-master/bin_static/SuSiEx"


############################################################
# Output directory
############################################################

OUTDIR="/work/home/chengzesong/simu_gwas/new_eur/PCA"
TMPDIR="${OUTDIR}/tmp"

mkdir -p "${OUTDIR}"
mkdir -p "${TMPDIR}"


############################################################
# Input bfile prefixes
############################################################

declare -A BFILES

# ==========================================================
# EUR common / rare
# ==========================================================
BFILES["EUR_5k_common_chr1"]="/work/home/chengzesong/data/gwas/EUR/EUR_5k_common_chr1"
BFILES["EUR_10k_common_chr1"]="/work/home/chengzesong/data/gwas/EUR/EUR_10k_common_chr1"

BFILES["EUR_5k_rare_chr1"]="/work/home/chengzesong/data/gwas/EUR/EUR_5k_rare_chr1"
BFILES["EUR_10k_rare_chr1"]="/work/home/chengzesong/data/gwas/EUR/EUR_10k_rare_chr1"


# ==========================================================
# AFR full common / rare
# ==========================================================
BFILES["AFR_common_chr1"]="/work/home/chengzesong/data/gwas/AFR/AFR_common_chr1"
BFILES["AFR_rare_chr1"]="/work/home/chengzesong/data/gwas/AFR/AFR_rare_chr1"


# ==========================================================
# AFR extract common 1000-4000
# ==========================================================
BFILES["AFR_common_chr1_1000"]="/work/home/chengzesong/data/gwas/AFR/extract/AFR_common_chr1_1000"
BFILES["AFR_common_chr1_2000"]="/work/home/chengzesong/data/gwas/AFR/extract/AFR_common_chr1_2000"
BFILES["AFR_common_chr1_3000"]="/work/home/chengzesong/data/gwas/AFR/extract/AFR_common_chr1_3000"
BFILES["AFR_common_chr1_4000"]="/work/home/chengzesong/data/gwas/AFR/extract/AFR_common_chr1_4000"


# ==========================================================
# AFR extract rare 1000-4000
# 如果你的 rare 文件命名不是 AFR_rare_chr1_1000 这种格式，只改这里
# ==========================================================
BFILES["AFR_rare_chr1_1000"]="/work/home/chengzesong/data/gwas/AFR/extract/AFR_rare_chr1_1000"
BFILES["AFR_rare_chr1_2000"]="/work/home/chengzesong/data/gwas/AFR/extract/AFR_rare_chr1_2000"
BFILES["AFR_rare_chr1_3000"]="/work/home/chengzesong/data/gwas/AFR/extract/AFR_rare_chr1_3000"
BFILES["AFR_rare_chr1_4000"]="/work/home/chengzesong/data/gwas/AFR/extract/AFR_rare_chr1_4000"


############################################################
# Check software
############################################################

check_software() {

    if [[ ! -x "${PLINK}" ]]; then
        echo "[ERROR] PLINK not executable: ${PLINK}"
        exit 1
    fi

    echo "[INFO] PLINK path: ${PLINK}"
    echo "[INFO] GCTA path  : ${GCTA}"
    echo "[INFO] METAL path : ${METAL}"
    echo "[INFO] Rscript    : ${RSCRIPT}"
    echo "[INFO] SuSiEx     : ${SUSIEX}"
}


############################################################
# Check bfile
############################################################

check_bfile() {

    local BFILE="$1"

    if [[ ! -f "${BFILE}.bed" ]]; then
        echo "[ERROR] Missing file: ${BFILE}.bed"
        return 1
    fi

    if [[ ! -f "${BFILE}.bim" ]]; then
        echo "[ERROR] Missing file: ${BFILE}.bim"
        return 1
    fi

    if [[ ! -f "${BFILE}.fam" ]]; then
        echo "[ERROR] Missing file: ${BFILE}.fam"
        return 1
    fi

    return 0
}


############################################################
# Run PCA for one bfile
############################################################

run_pca() {

    local NAME="$1"
    local BFILE="$2"

    local WORKDIR="${TMPDIR}/${NAME}"
    local PRUNE_PREFIX="${WORKDIR}/${NAME}.prune"
    local PCA_PREFIX="${WORKDIR}/${NAME}.pca"

    local FINAL_COVAR="${OUTDIR}/${NAME}.PC1_10.covariates.txt"

    mkdir -p "${WORKDIR}"

    echo "============================================================"
    echo "[INFO] Running PCA"
    echo "[INFO] Name : ${NAME}"
    echo "[INFO] Bfile: ${BFILE}"
    echo "============================================================"

    if ! check_bfile "${BFILE}"; then
        echo "[WARN] Skip ${NAME} because bfile is incomplete."
        rm -rf "${WORKDIR}"
        echo ""
        return 0
    fi


    ########################################################
    # 1. LD pruning
    ########################################################

    "${PLINK}" \
        --bfile "${BFILE}" \
        --geno 0.05 \
        --mind 0.05 \
        --indep-pairwise 50 5 0.2 \
        --out "${PRUNE_PREFIX}"


    if [[ ! -s "${PRUNE_PREFIX}.prune.in" ]]; then
        echo "[ERROR] No SNPs retained after pruning for ${NAME}"
        rm -rf "${WORKDIR}"
        return 1
    fi


    ########################################################
    # 2. PCA
    # PLINK 1.9 eigenvec format:
    # FID IID PC1 PC2 ... PC10
    ########################################################

    "${PLINK}" \
        --bfile "${BFILE}" \
        --extract "${PRUNE_PREFIX}.prune.in" \
        --pca 10 \
        --out "${PCA_PREFIX}"


    if [[ ! -s "${PCA_PREFIX}.eigenvec" ]]; then
        echo "[ERROR] PCA failed for ${NAME}"
        rm -rf "${WORKDIR}"
        return 1
    fi


    ########################################################
    # 3. Format final covariate file
    # Output:
    # FID IID PC1 PC2 ... PC10
    ########################################################

    awk '
    BEGIN {
        OFS = "\t"
        print "FID","IID","PC1","PC2","PC3","PC4","PC5","PC6","PC7","PC8","PC9","PC10"
    }
    {
        print $1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12
    }
    ' "${PCA_PREFIX}.eigenvec" > "${FINAL_COVAR}"


    ########################################################
    # 4. Remove intermediate files
    ########################################################

    rm -rf "${WORKDIR}"

    echo "[DONE] Final covariate file:"
    echo "${FINAL_COVAR}"
    echo ""
}


############################################################
# Main
############################################################

check_software


############################################################
# Run PCA for all bfiles
############################################################

for NAME in "${!BFILES[@]}"; do
    run_pca "${NAME}" "${BFILES[$NAME]}"
done


############################################################
# Summary
############################################################

SUMMARY="${OUTDIR}/PCA_covariate_files.summary.txt"

{
    echo -e "name\tbfile\tcovariate_file\tstatus"

    for NAME in "${!BFILES[@]}"; do

        COVAR_FILE="${OUTDIR}/${NAME}.PC1_10.covariates.txt"

        if [[ -s "${COVAR_FILE}" ]]; then
            echo -e "${NAME}\t${BFILES[$NAME]}\t${COVAR_FILE}\tGENERATED"
        else
            echo -e "${NAME}\t${BFILES[$NAME]}\t${COVAR_FILE}\tNOT_GENERATED"
        fi

    done

} > "${SUMMARY}"


############################################################
# Remove tmp directory if empty
############################################################

rmdir "${TMPDIR}" 2>/dev/null || true


############################################################
# Final message
############################################################

echo "============================================================"
echo "[DONE] All PCA analyses finished"
echo "============================================================"
echo "[INFO] Final output directory:"
echo "${OUTDIR}"
echo ""
echo "[INFO] Summary file:"
echo "${SUMMARY}"
echo ""
echo "[INFO] Final covariate files:"
ls -lh "${OUTDIR}"/*.PC1_10.covariates.txt 2>/dev/null || true