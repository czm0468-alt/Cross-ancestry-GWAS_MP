#!/usr/bin/env bash
#SBATCH --job-name=matched10k_pca
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=1
#SBATCH --cpus-per-task=6
#SBATCH --mem=80G
#SBATCH --time=20:00:00
#SBATCH --array=1
#SBATCH --output=/work/home/chengzesong/simu_gwas/logs/matched10k_pca_%A_%a.log

set -euo pipefail

############################################################
# PCA for matched total sample-size pooled datasets
#
# Input bfiles:
#   EUR9k + AFR1k = 10k
#   EUR8k + AFR2k = 10k
#   EUR7k + AFR3k = 10k
#   EUR6k + AFR4k = 10k
#
# PCA is calculated using the merged common-variant genotype
# dataset for each matched group.
#
# Important:
#   Do not use --mind here.
#   In merged EUR-AFR datasets, --mind 0.05 may remove all
#   samples because of missingness introduced during merging.
#
# Output:
#   FID IID PC1 PC2 ... PC10
############################################################


############################################################
# Software
############################################################

PLINK=/work/home/ac3xibpp15/software/bin/plink
THREADS=6


############################################################
# Paths
############################################################

ROOT=/work/home/chengzesong/simu_gwas
BFILE_ROOT=$ROOT/diff_afr_matched_10k

OUT_DIR=$BFILE_ROOT/pca
TMP_DIR=$OUT_DIR/tmp_matched10k_pca

mkdir -p "$OUT_DIR"
mkdir -p "$TMP_DIR"
mkdir -p "$ROOT/logs"


############################################################
# Check software
############################################################

if [ ! -x "$PLINK" ]; then
    echo "[ERROR] PLINK is not executable:"
    echo "$PLINK"
    exit 1
fi


############################################################
# Functions
############################################################

check_bfile()
{
    local BFILE=$1
    local LABEL=$2

    if [ ! -s "${BFILE}.bed" ] || [ ! -s "${BFILE}.bim" ] || [ ! -s "${BFILE}.fam" ]; then
        echo "[ERROR] Incomplete bfile for ${LABEL}:"
        echo "$BFILE"
        echo "[CHECK] Required files:"
        echo "${BFILE}.bed"
        echo "${BFILE}.bim"
        echo "${BFILE}.fam"
        exit 1
    fi
}


run_pca()
{
    local LABEL=$1
    local BFILE=$2

    local WORK_DIR=$TMP_DIR/$LABEL
    local MISS_PREFIX=$WORK_DIR/${LABEL}.missingness
    local PRUNE_PREFIX=$WORK_DIR/${LABEL}.prune
    local PCA_PREFIX=$WORK_DIR/${LABEL}.pca

    local FINAL_COVAR=$OUT_DIR/${LABEL}_genomewide_common_PCA_PC1_PC10.covar
    local EIGENVAL_OUT=$OUT_DIR/${LABEL}_genomewide_common_PCA.eigenval
    local SUMMARY_OUT=$OUT_DIR/${LABEL}_genomewide_common_PCA.summary.txt

    mkdir -p "$WORK_DIR"

    echo
    echo "============================================================"
    echo "[INFO] Running PCA for matched 10K pooled dataset"
    echo "[INFO] Group: $LABEL"
    echo "[INFO] BFILE: $BFILE"
    echo "[INFO] Output covariate file: $FINAL_COVAR"
    echo "============================================================"

    check_bfile "$BFILE" "$LABEL"

    local N_SAMPLE
    local N_VARIANT

    N_SAMPLE=$(wc -l < "${BFILE}.fam")
    N_VARIANT=$(wc -l < "${BFILE}.bim")

    echo "[INFO] Sample count: $N_SAMPLE"
    echo "[INFO] Variant count before pruning: $N_VARIANT"

    if [ "$N_SAMPLE" -ne 10000 ]; then
        echo "[WARNING] Sample size is not 10000 for $LABEL"
        echo "[WARNING] Observed sample size: $N_SAMPLE"
    fi


    ########################################################
    # 1. Missingness report
    #
    # This does not filter samples.
    # It only helps diagnose missingness after merging.
    ########################################################

    "$PLINK" \
        --bfile "$BFILE" \
        --missing \
        --threads "$THREADS" \
        --out "$MISS_PREFIX"

    if [ -s "${MISS_PREFIX}.imiss" ]; then
        echo "[INFO] Individual missingness summary:"
        awk '
        NR > 1 {
            n++
            sum += $6
            if (min == "" || $6 < min) min = $6
            if (max == "" || $6 > max) max = $6
        }
        END {
            if (n > 0) {
                print "[INFO] N =", n
                print "[INFO] mean F_MISS =", sum / n
                print "[INFO] min F_MISS  =", min
                print "[INFO] max F_MISS  =", max
            }
        }
        ' "${MISS_PREFIX}.imiss"
    fi


    ########################################################
    # 2. LD pruning
    #
    # Do not use --mind here.
    # Apply SNP-level missingness filter before pruning.
    ########################################################

    "$PLINK" \
        --bfile "$BFILE" \
        --geno 0.05 \
        --maf 0.01 \
        --indep-pairwise 50 5 0.2 \
        --threads "$THREADS" \
        --out "$PRUNE_PREFIX"

    if [ ! -s "${PRUNE_PREFIX}.prune.in" ]; then
        echo "[ERROR] No SNPs retained after pruning for $LABEL"
        echo "[DEBUG] Check missingness files:"
        echo "${MISS_PREFIX}.imiss"
        echo "${MISS_PREFIX}.lmiss"
        rm -rf "$WORK_DIR"
        exit 1
    fi

    local N_PRUNED
    N_PRUNED=$(wc -l < "${PRUNE_PREFIX}.prune.in")

    echo "[INFO] Pruned SNP count: $N_PRUNED"


    ########################################################
    # 3. PCA
    ########################################################

    "$PLINK" \
        --bfile "$BFILE" \
        --extract "${PRUNE_PREFIX}.prune.in" \
        --pca 10 \
        --threads "$THREADS" \
        --out "$PCA_PREFIX"

    if [ ! -s "${PCA_PREFIX}.eigenvec" ]; then
        echo "[ERROR] PCA failed for $LABEL"
        rm -rf "$WORK_DIR"
        exit 1
    fi


    ########################################################
    # 4. Format PC1-PC10 covariate file
    ########################################################

    awk '
    BEGIN {
        OFS = "\t"
        print "FID","IID","PC1","PC2","PC3","PC4","PC5","PC6","PC7","PC8","PC9","PC10"
    }
    {
        print $1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12
    }
    ' "${PCA_PREFIX}.eigenvec" > "$FINAL_COVAR"

    if [ ! -s "$FINAL_COVAR" ]; then
        echo "[ERROR] Failed to generate PC covariate file for $LABEL"
        rm -rf "$WORK_DIR"
        exit 1
    fi

    if [ -s "${PCA_PREFIX}.eigenval" ]; then
        cp "${PCA_PREFIX}.eigenval" "$EIGENVAL_OUT"
    fi


    ########################################################
    # 5. Summary
    ########################################################

    local N_PC_SAMPLE
    N_PC_SAMPLE=$(awk 'NR > 1 {n++} END {print n + 0}' "$FINAL_COVAR")

    {
        echo -e "group\tbfile\tn_sample\tn_variant_before_pruning\tn_pruned_variant\tpc_covar_file\teigenval_file"
        echo -e "${LABEL}\t${BFILE}\t${N_SAMPLE}\t${N_VARIANT}\t${N_PRUNED}\t${FINAL_COVAR}\t${EIGENVAL_OUT}"
    } > "$SUMMARY_OUT"


    ########################################################
    # 6. Cleanup
    ########################################################

    rm -rf "$WORK_DIR"

    echo "[DONE] PCA completed for $LABEL"
    echo "[INFO] Final covariate file:"
    echo "$FINAL_COVAR"
}


############################################################
# Main
############################################################

echo
echo "============================================================"
echo "[INFO] Matched 10K pooled PCA started"
echo "[INFO] Input root: $BFILE_ROOT"
echo "[INFO] Output directory: $OUT_DIR"
echo "[INFO] NOTE: --mind is not used"
echo "============================================================"


run_pca \
    "EUR9K_AFR1K" \
    "$BFILE_ROOT/AFR1k_EUR9k/EUR9k_AFR1k_common_chr1"


run_pca \
    "EUR8K_AFR2K" \
    "$BFILE_ROOT/AFR2k_EUR8k/EUR8k_AFR2k_common_chr1"


run_pca \
    "EUR7K_AFR3K" \
    "$BFILE_ROOT/AFR3k_EUR7k/EUR7k_AFR3k_common_chr1"


run_pca \
    "EUR6K_AFR4K" \
    "$BFILE_ROOT/AFR4k_EUR6k/EUR6k_AFR4k_common_chr1"


############################################################
# Overall summary
############################################################

OVERALL_SUMMARY=$OUT_DIR/matched10k_pooled_PCA_PC1_PC10.summary.txt

{
    echo -e "group\tcovariate_file\tstatus\tn_samples"

    for LABEL in \
        EUR9K_AFR1K \
        EUR8K_AFR2K \
        EUR7K_AFR3K \
        EUR6K_AFR4K
    do
        COVAR=$OUT_DIR/${LABEL}_genomewide_common_PCA_PC1_PC10.covar

        if [ -s "$COVAR" ]; then
            N_SAMPLE=$(awk 'NR > 1 {n++} END {print n + 0}' "$COVAR")
            echo -e "${LABEL}\t${COVAR}\tGENERATED\t${N_SAMPLE}"
        else
            echo -e "${LABEL}\t${COVAR}\tNOT_GENERATED\tNA"
        fi
    done

} > "$OVERALL_SUMMARY"


############################################################
# Cleanup tmp root
############################################################

rmdir "$TMP_DIR" 2>/dev/null || true


############################################################
# Final message
############################################################

echo
echo "============================================================"
echo "[DONE] All matched 10K pooled PCA analyses finished"
echo "[INFO] Output directory:"
echo "$OUT_DIR"
echo
echo "[INFO] Final PC covariate files:"
ls -lh "$OUT_DIR"/EUR9K_AFR1K_genomewide_common_PCA_PC1_PC10.covar
ls -lh "$OUT_DIR"/EUR8K_AFR2K_genomewide_common_PCA_PC1_PC10.covar
ls -lh "$OUT_DIR"/EUR7K_AFR3K_genomewide_common_PCA_PC1_PC10.covar
ls -lh "$OUT_DIR"/EUR6K_AFR4K_genomewide_common_PCA_PC1_PC10.covar
echo
echo "[INFO] Overall summary:"
echo "$OVERALL_SUMMARY"
echo "============================================================"