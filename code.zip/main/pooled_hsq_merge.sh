#!/bin/bash

ROOT=/work/home/chengzesong/simu_gwas
OUT=${ROOT}/common_pooled_hsq_sig.txt

head -n 1 "${ROOT}/common_pooled_1_hsq_sig.txt" > "$OUT"

for i in {1..10}; do
    tail -n +2 "${ROOT}/common_pooled_${i}_hsq_sig.txt" >> "$OUT"
done

echo "合并完成：$OUT"
echo "总行数：$(wc -l < "$OUT")"




