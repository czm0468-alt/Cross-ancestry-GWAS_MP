#!/bin/bash
#SBATCH --job-name=pooled_pca_pfile
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=1
#SBATCH --cpus-per-task=8
#SBATCH --mem=100G
#SBATCH --array=1-5
#SBATCH --time=24:00:00
#SBATCH --output=/work/home/chengzesong/simu_gwas/logs/pooled_pca_pfile_%A_%a.log

############################################################
# Analysis design
#
# Array task 1:
#   EUR 5K + AFR 1K
#
# Array task 2:
#   EUR 5K + AFR 2K
#
# Array task 3:
#   EUR 5K + AFR 3K
#
# Array task 4:
#   EUR 5K + AFR 4K
#
# Array task 5:
#   EUR 5K + AFR 5K
#
# For each sample combination:
#   1. Obtain the sample list from the corresponding BFILE
#   2. Extract these samples from the genome-wide common PFILE
#   3. Retain autosomal variants with MAF >= 0.05
#   4. Perform LD pruning
#   5. Calculate PC1-PC10
#
# The resulting PC1-PC10 covariates can be shared by the
# common and rare GWAS conducted in the same sample set.
############################################################

############################################################
# Software
############################################################

PLINK2=/work/home/chengzesong/software/plink2

THREADS=8

############################################################
# Genome-wide common PFILE
############################################################

SOURCE_PFILE=/work/home/chengzesong/data/gwas/EUR5K_AFR_common

############################################################
# Select sample-defining BFILE
############################################################

case "$SLURM_ARRAY_TASK_ID" in

    1)
        LABEL=EUR5K_AFR1K
        SAMPLE_BFILE=/work/home/chengzesong/simu_gwas/diff_afr/1k/EUR5K_AFR1k_common_chr1
        OUT_DIR=/work/home/chengzesong/simu_gwas/diff_afr_pooled/pca
        ;;

    2)
        LABEL=EUR5K_AFR2K
        SAMPLE_BFILE=/work/home/chengzesong/simu_gwas/diff_afr/2k/EUR5K_AFR2k_common_chr1
        OUT_DIR=/work/home/chengzesong/simu_gwas/diff_afr_pooled/pca
        ;;

    3)
        LABEL=EUR5K_AFR3K
        SAMPLE_BFILE=/work/home/chengzesong/simu_gwas/diff_afr/3k/EUR5K_AFR3k_common_chr1
        OUT_DIR=/work/home/chengzesong/simu_gwas/diff_afr_pooled/pca
        ;;

    4)
        LABEL=EUR5K_AFR4K
        SAMPLE_BFILE=/work/home/chengzesong/simu_gwas/diff_afr/4k/EUR5K_AFR4k_common_chr1
        OUT_DIR=/work/home/chengzesong/simu_gwas/diff_afr_pooled/pca
        ;;

    5)
        LABEL=EUR5K_AFR5K
        SAMPLE_BFILE=/work/home/chengzesong/data/gwas/all_common_chr1
        OUT_DIR=/work/home/chengzesong/simu_gwas/new_pooled/pca
        ;;

    *)
        echo "[ERROR] Unsupported array task: $SLURM_ARRAY_TASK_ID"
        exit 1
        ;;

esac

mkdir -p "$OUT_DIR"

############################################################
# Temporary working directory
############################################################

TMP=$OUT_DIR/tmp_${LABEL}_${SLURM_ARRAY_JOB_ID}_${SLURM_ARRAY_TASK_ID}

mkdir -p "$TMP"

############################################################
# Output prefixes
############################################################

KEEP_FILE=$TMP/${LABEL}.keep
SUBSET_PFILE=$TMP/${LABEL}_genomewide_common

PRUNE_PREFIX=$OUT_DIR/${LABEL}_genomewide_common_prune
PCA_PREFIX=$OUT_DIR/${LABEL}_genomewide_common_PCA

COVAR_FILE=${PCA_PREFIX}_PC1_PC10.covar
SUMMARY_FILE=${PCA_PREFIX}_summary.txt

############################################################
# Input checks
############################################################

if [ ! -f "${SOURCE_PFILE}.pgen" ]; then
    echo "[ERROR] Source PGEN does not exist: ${SOURCE_PFILE}.pgen"
    exit 1
fi

if [ ! -f "${SOURCE_PFILE}.psam" ]; then
    echo "[ERROR] Source PSAM does not exist: ${SOURCE_PFILE}.psam"
    exit 1
fi

if [ ! -f "${SOURCE_PFILE}.pvar" ] && [ ! -f "${SOURCE_PFILE}.pvar.zst" ]; then
    echo "[ERROR] Source PVAR does not exist: ${SOURCE_PFILE}.pvar or ${SOURCE_PFILE}.pvar.zst"
    exit 1
fi

if [ ! -f "${SAMPLE_BFILE}.fam" ]; then
    echo "[ERROR] Sample-defining FAM does not exist: ${SAMPLE_BFILE}.fam"
    exit 1
fi

############################################################
# 1. Generate sample keep file
#
# The corresponding pooled BFILE .fam defines the exact
# participants included in each pooled analysis.
############################################################

awk 'BEGIN{OFS="\t"}{print $1,$2}' "${SAMPLE_BFILE}.fam" > "$KEEP_FILE"

if [ ! -s "$KEEP_FILE" ]; then
    echo "[ERROR] Sample keep file was not generated"
    exit 1
fi

N_REQUESTED=$(wc -l < "$KEEP_FILE")

echo
echo "============================================================"
echo "[INFO] PCA analysis started"
echo "[INFO] Array task: $SLURM_ARRAY_TASK_ID"
echo "[INFO] Dataset: $LABEL"
echo "[INFO] Source genome-wide PFILE: $SOURCE_PFILE"
echo "[INFO] Sample-defining BFILE: $SAMPLE_BFILE"
echo "[INFO] Requested samples: $N_REQUESTED"
echo "[INFO] Output directory: $OUT_DIR"
echo "============================================================"

############################################################
# 2. Extract corresponding samples from genome-wide PFILE
#
# Only autosomal variants are retained for PCA.
############################################################

echo
echo "============================================================"
echo "[INFO] Extracting $LABEL samples from genome-wide PFILE"
echo "============================================================"

"$PLINK2" \
    --pfile "$SOURCE_PFILE" \
    --keep "$KEEP_FILE" \
    --autosome \
    --make-pgen \
    --threads "$THREADS" \
    --out "$SUBSET_PFILE"

if [ ! -f "${SUBSET_PFILE}.pgen" ]; then
    echo "[ERROR] Subset PGEN was not generated"
    exit 1
fi

if [ ! -f "${SUBSET_PFILE}.psam" ]; then
    echo "[ERROR] Subset PSAM was not generated"
    exit 1
fi

if [ ! -f "${SUBSET_PFILE}.pvar" ] && [ ! -f "${SUBSET_PFILE}.pvar.zst" ]; then
    echo "[ERROR] Subset PVAR was not generated"
    exit 1
fi

N_EXTRACTED=$(awk '!/^#/{n++} END{print n+0}' "${SUBSET_PFILE}.psam")

echo "[INFO] Requested samples: $N_REQUESTED"
echo "[INFO] Extracted samples: $N_EXTRACTED"

if [ "$N_REQUESTED" -ne "$N_EXTRACTED" ]; then
    echo "[ERROR] Requested and extracted sample numbers differ"
    exit 1
fi

############################################################
# 3. LD pruning
#
# PCA variant set:
#   autosomal common variants
#   MAF >= 0.05 within the current sample combination
#   LD pruning: window 50 variants, step 5, r2 < 0.2
#
# HWE filtering is not applied after pooling ancestries.
############################################################

echo
echo "============================================================"
echo "[INFO] Running LD pruning"
echo "[INFO] Dataset: $LABEL"
echo "============================================================"

"$PLINK2" \
    --pfile "$SUBSET_PFILE" \
    --maf 0.05 \
    --indep-pairwise 50 5 0.2 \
    --threads "$THREADS" \
    --out "$PRUNE_PREFIX"

if [ ! -s "${PRUNE_PREFIX}.prune.in" ]; then
    echo "[ERROR] LD-pruned variant list was not generated"
    exit 1
fi

N_PRUNED=$(wc -l < "${PRUNE_PREFIX}.prune.in")

echo "[INFO] LD-pruned PCA variants: $N_PRUNED"

############################################################
# 4. Calculate PC1-PC10
############################################################

echo
echo "============================================================"
echo "[INFO] Calculating PC1-PC10"
echo "[INFO] Dataset: $LABEL"
echo "============================================================"

"$PLINK2" \
    --pfile "$SUBSET_PFILE" \
    --extract "${PRUNE_PREFIX}.prune.in" \
    --pca 10 approx \
    --threads "$THREADS" \
    --out "$PCA_PREFIX"

if [ ! -s "${PCA_PREFIX}.eigenvec" ]; then
    echo "[ERROR] PCA eigenvector file was not generated"
    exit 1
fi

if [ ! -s "${PCA_PREFIX}.eigenval" ]; then
    echo "[ERROR] PCA eigenvalue file was not generated"
    exit 1
fi

############################################################
# 5. Generate directly usable PLINK covariate file
#
# Input eigenvec:
#   #FID IID PC1 PC2 ... PC10
#
# Output:
#   FID IID PC1 PC2 ... PC10
############################################################

awk 'BEGIN{OFS="\t"} NR==1{gsub(/^#/,"",$1)} {print $1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12}' "${PCA_PREFIX}.eigenvec" > "$COVAR_FILE"

if [ ! -s "$COVAR_FILE" ]; then
    echo "[ERROR] PLINK covariate file was not generated"
    exit 1
fi

N_PCA=$(( $(wc -l < "$COVAR_FILE") - 1 ))

if [ "$N_PCA" -ne "$N_EXTRACTED" ]; then
    echo "[ERROR] PCA sample count differs from extracted sample count"
    echo "[ERROR] Extracted samples: $N_EXTRACTED"
    echo "[ERROR] PCA samples: $N_PCA"
    exit 1
fi

############################################################
# 6. Write analysis summary
############################################################

{
    echo -e "item\tvalue"
    echo -e "dataset\t$LABEL"
    echo -e "source_pfile\t$SOURCE_PFILE"
    echo -e "sample_defining_bfile\t$SAMPLE_BFILE"
    echo -e "requested_samples\t$N_REQUESTED"
    echo -e "extracted_samples\t$N_EXTRACTED"
    echo -e "ld_pruned_variants\t$N_PRUNED"
    echo -e "number_of_PCs\t10"
    echo -e "maf_threshold\t0.05"
    echo -e "ld_pruning\t50_5_0.2"
    echo -e "covariate_file\t$COVAR_FILE"
} > "$SUMMARY_FILE"

############################################################
# 7. Remove temporary extracted genotype files
#
# Final PCA outputs are retained.
# The large temporary subset PFILE is deleted.
############################################################

rm -rf "$TMP"

############################################################
# Final report
############################################################

echo
echo "============================================================"
echo "[INFO] PCA completed"
echo "[INFO] Dataset: $LABEL"
echo "[INFO] Samples: $N_PCA"
echo "[INFO] LD-pruned variants: $N_PRUNED"
echo
echo "[INFO] Eigenvectors:"
echo "${PCA_PREFIX}.eigenvec"
echo
echo "[INFO] Eigenvalues:"
echo "${PCA_PREFIX}.eigenval"
echo
echo "[INFO] Directly usable PC1-PC10 covariate file:"
echo "$COVAR_FILE"
echo
echo "[INFO] Summary:"
echo "$SUMMARY_FILE"
echo "============================================================"