#!/bin/bash
#SBATCH --job-name=sim_meta_rare_hsq
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=1
#SBATCH --cpus-per-task=6
#SBATCH --array=1-10
#SBATCH --output=/work/home/chengzesong/simu_gwas/logs/array_%A_%a.log

############################################################
# Analysis design
#
# Array 1  : loop 1-100
# Array 2  : loop 101-200
# ...
# Array 10 : loop 901-1000
#
# For each hsq and loop:
#   1. Select one causal SNP from variants shared by
#      EUR 5K rare and AFR rare
#   2. EUR 5K + AFR META analysis
#   3. EUR 10K rare analysis
#   4. EUR 5K + AFR pooled rare analysis
#
# Within the same hsq and loop, all three analyses use
# exactly the same causal SNP.
#
# Only the pooled GWAS is adjusted for PC1-PC10.
############################################################

ROOT=/work/home/chengzesong/simu_gwas

TASK_ID=${SLURM_ARRAY_TASK_ID}
LOOP_START=$(( (TASK_ID - 1) * 100 + 1 ))
LOOP_END=$(( TASK_ID * 100 ))

TMP=$ROOT/tmp_rare_hsq_${SLURM_ARRAY_JOB_ID}_${TASK_ID}

mkdir -p "$TMP"

############################################################
# Software
############################################################

PLINK=/work/home/ac3xibpp15/software/bin/plink
GCTA=/work/home/shilulu/software/gcta-1.94.4/gcta
METAL=/work/home/chengzesong/software/generic-metal/metal
RSCRIPT=/public/software/VersionHub/R/4.5.1/Rscript

############################################################
# Genotype datasets
############################################################

# EUR 5K and AFR datasets used in META analysis
EUR=/work/home/chengzesong/data/gwas/EUR/EUR_5k_rare_chr1
AFR=/work/home/chengzesong/data/gwas/AFR/AFR_rare_chr1

# EUR 10K dataset used in EUR-only analysis
EUR_FULL=/work/home/chengzesong/data/gwas/EUR/EUR_10k_rare_chr1

# EUR 5K + AFR pooled genotype
POOLED=/work/home/chengzesong/data/gwas/all_rare_chr1

############################################################
# PC1-PC10 covariates used only in pooled GWAS
############################################################

POOLED_PCA_COVAR=/work/home/chengzesong/simu_gwas/new_pooled/pca/EUR5K_AFR5K_genomewide_common_PCA_PC1_PC10.covar

############################################################
# Annotation and pooled MAF reference
############################################################

MERGED_BIM=/work/home/chengzesong/data/gwas/EUR_AFR_merged.bim
MERGED_FRQ=/work/home/chengzesong/data/gwas/EUR_AFR_maf.frq

############################################################
# Build shared rare SNP list
#
# Causal SNPs are selected only from variants shared by:
#   EUR 5K rare
#   AFR rare
#
# EUR 10K and pooled datasets are not used to define the
# causal SNP candidate list.
############################################################

EUR_IDS=$TMP/EUR_5k_rare.ids
AFR_IDS=$TMP/AFR_rare.ids
COMMON=$TMP/rare_shared_EUR5K_AFR.snplist

awk '{print $2}' "${EUR}.bim" | sort -u > "$EUR_IDS"
awk '{print $2}' "${AFR}.bim" | sort -u > "$AFR_IDS"

comm -12 "$EUR_IDS" "$AFR_IDS" > "$COMMON"

N_COMMON=$(awk 'END{print NR+0}' "$COMMON")

echo
echo "============================================================"
echo "[INFO] Shared rare SNPs available for causal selection"
echo "[INFO] EUR 5K rare + AFR rare: $N_COMMON"
echo "[INFO] Causal list: $COMMON"
echo "============================================================"

if [ "$N_COMMON" -eq 0 ]; then
    echo "[ERROR] No shared rare SNPs were found between EUR 5K and AFR."
    echo "[ERROR] Check whether SNP IDs are consistent between:"
    echo "${EUR}.bim"
    echo "${AFR}.bim"
    rm -rf "$TMP"
    exit 1
fi

############################################################
# Output directory
############################################################

RESULT_DIR=$ROOT/new_pooled/rare_hsq_pc

mkdir -p "$RESULT_DIR"

############################################################
# Output files
############################################################

META_OUT=$RESULT_DIR/rare_meta_hsq_${TASK_ID}_sig.txt
EUR_OUT=$RESULT_DIR/rare_EUR_hsq_${TASK_ID}_sig.txt
POOLED_OUT=$RESULT_DIR/rare_pooled_${TASK_ID}_hsq_sig.txt

############################################################
# Output header
############################################################

HEADER="hsq\tloop\tlead_SNP\tlead_CHR\tlead_BP\tlead_A1\tlead_A2\tlead_BETA\tlead_SE\tlead_P\tlead_MAF\tcausal_SNP\tcausal_CHR\tcausal_BP\tcausal_A1\tcausal_A2\tcausal_BETA\tcausal_SE\tcausal_P\tcausal_MAF\tMAF_diff\tBP_diff"

printf "%b\n" "$HEADER" > "$META_OUT"
printf "%b\n" "$HEADER" > "$EUR_OUT"
printf "%b\n" "$HEADER" > "$POOLED_OUT"

############################################################
# Write one tab-separated output row
############################################################

write_row()
{
    local IFS=$'\t'
    printf "%s\n" "$*"
}

############################################################
# Heritability values
############################################################

HSQ_LIST=$(seq -f "%.3f" 0 0.003 0.030)

############################################################
# Shared inverse-normal transformation script
############################################################

INVNORM_R=$TMP/invnorm.R

cat > "$INVNORM_R" <<'EOF'
phen <- read.table(
    "sim.phen",
    header = FALSE,
    stringsAsFactors = FALSE
)

phen$V3 <- qnorm(
    rank(phen$V3, ties.method = "average") /
        (nrow(phen) + 1)
)

write.table(
    phen,
    file = "sim.phen.invnorm",
    quote = FALSE,
    row.names = FALSE,
    col.names = FALSE
)
EOF

############################################################
# Run one population for META analysis
############################################################

run_meta_population()
{
    local POP=$1
    local BFILE=$2
    local LOOP_DIR=$3
    local CAUSAL=$4
    local CHR=$5
    local REGION_START=$6
    local REGION_END=$7
    local HSQ=$8

    local DIR
    local GWAS_FILE

    DIR=$LOOP_DIR/$POP

    mkdir -p "$DIR"

    echo
    echo "[INFO] Running ${POP} component of META analysis"

    "$PLINK" \
        --bfile "$BFILE" \
        --chr "$CHR" \
        --from-bp "$REGION_START" \
        --to-bp "$REGION_END" \
        --make-bed \
        --out "$DIR/win" \
        >/dev/null 2>&1

    if [ ! -f "$DIR/win.bed" ]; then
        echo "[WARNING] Failed to extract region for ${POP}"
        return 1
    fi

    if ! awk -v s="$CAUSAL" '$2==s{found=1; exit} END{exit(found ? 0 : 1)}' "$DIR/win.bim"; then
        echo "[WARNING] Causal SNP absent from ${POP} extracted window: $CAUSAL"
        return 1
    fi

    printf "%s 1\n" "$CAUSAL" > "$DIR/seed"

    "$GCTA" \
        --bfile "$DIR/win" \
        --simu-qt \
        --simu-causal-loci "$DIR/seed" \
        --simu-hsq "$HSQ" \
        --out "$DIR/sim" \
        >/dev/null 2>&1

    if [ ! -f "$DIR/sim.phen" ]; then
        echo "[WARNING] GCTA simulation failed for ${POP}"
        return 1
    fi

    (
        cd "$DIR" || exit 1
        "$RSCRIPT" --vanilla "$INVNORM_R" >/dev/null 2>&1
    )

    if [ ! -f "$DIR/sim.phen.invnorm" ]; then
        echo "[WARNING] Inverse-normal transformation failed for ${POP}"
        return 1
    fi

    "$PLINK" \
        --bfile "$DIR/win" \
        --pheno "$DIR/sim.phen.invnorm" \
        --linear hide-covar \
        --allow-no-sex \
        --out "$DIR/gwas" \
        >/dev/null 2>&1

    GWAS_FILE=$DIR/gwas.assoc.linear

    if [ ! -f "$GWAS_FILE" ]; then
        echo "[WARNING] GWAS failed for ${POP}"
        return 1
    fi

    awk 'BEGIN{OFS="\t"; print "SNP","A1","A2","BETA","SE","P","N"} NR==FNR{a1[$2]=$5; a2[$2]=$6; next} FNR>1 && $5=="ADD" && $7!="NA" && $8!="NA" && $8!=0 && $9!="NA"{se=$7/$8; if(se<0)se=-se; print $2,a1[$2],a2[$2],$7,se,$9,$6}' "$DIR/win.bim" "$GWAS_FILE" > "$LOOP_DIR/${POP}.tsv"

    if [ "$(awk 'END{print NR+0}' "$LOOP_DIR/${POP}.tsv")" -le 1 ]; then
        echo "[WARNING] No valid METAL input variants for ${POP}"
        return 1
    fi

    return 0
}

############################################################
# Run EUR 5K + AFR META analysis
############################################################

run_meta_analysis()
{
    local LOOP_DIR=$1
    local CAUSAL=$2
    local CAUSAL_CHR=$3
    local CAUSAL_BP=$4
    local REGION_START=$5
    local REGION_END=$6
    local HSQ=$7
    local LOOP_ID=$8

    local META
    local LEAD_LINE
    local LEAD_SNP
    local LEAD_A1
    local LEAD_A2
    local LEAD_BETA
    local LEAD_SE
    local LEAD_P
    local LEAD_CHR
    local LEAD_BP
    local LEAD_MAF
    local CAUSAL_MAF
    local MAF_DIFF
    local BP_DIFF
    local CAUSAL_LINE
    local CAUSAL_A1
    local CAUSAL_A2
    local CAUSAL_BETA
    local CAUSAL_SE
    local CAUSAL_P

    echo
    echo "============================================================"
    echo "[INFO] META analysis"
    echo "[INFO] hsq=$HSQ"
    echo "[INFO] loop=$LOOP_ID"
    echo "[INFO] causal SNP=$CAUSAL"
    echo "============================================================"

    if ! run_meta_population EUR "$EUR" "$LOOP_DIR" "$CAUSAL" "$CAUSAL_CHR" "$REGION_START" "$REGION_END" "$HSQ"; then
        echo "[WARNING] EUR component failed; META analysis skipped"
        return 1
    fi

    if ! run_meta_population AFR "$AFR" "$LOOP_DIR" "$CAUSAL" "$CAUSAL_CHR" "$REGION_START" "$REGION_END" "$HSQ"; then
        echo "[WARNING] AFR component failed; META analysis skipped"
        return 1
    fi

    cat > "$LOOP_DIR/metal.conf" <<EOF
SCHEME STDERR
MARKER SNP
ALLELE A1 A2
EFFECT BETA
STDERR SE
PVALUE P
WEIGHT N
PROCESS EUR.tsv
PROCESS AFR.tsv
OUTFILE METAANALYSIS .TBL
ANALYZE
QUIT
EOF

    (
        cd "$LOOP_DIR" || exit 1
        "$METAL" metal.conf >/dev/null 2>&1
    )

    META=$LOOP_DIR/METAANALYSIS1.TBL

    if [ ! -f "$META" ]; then
        echo "[WARNING] METAL output was not generated"
        return 1
    fi

    LEAD_LINE=$(awk 'NR>1 && $4!="NA" && $5!="NA" && $6!="NA"{print $1,$2,$3,$4,$5,$6}' "$META" | sort -k6,6g | head -1)

    if [ -z "$LEAD_LINE" ]; then
        echo "[WARNING] No valid lead SNP in META result"
        return 1
    fi

    read -r LEAD_SNP LEAD_A1 LEAD_A2 LEAD_BETA LEAD_SE LEAD_P <<< "$LEAD_LINE"

    read -r LEAD_CHR LEAD_BP <<< "$(awk -v s="$LEAD_SNP" '$2==s{print $1,$4; exit}' "$MERGED_BIM")"

    if [ -z "$LEAD_CHR" ] || [ -z "$LEAD_BP" ]; then
        read -r LEAD_CHR LEAD_BP <<< "$(awk -v s="$LEAD_SNP" '$2==s{print $1,$4; exit}' "${EUR}.bim")"
    fi

    if [ -z "$LEAD_CHR" ] || [ -z "$LEAD_BP" ]; then
        read -r LEAD_CHR LEAD_BP <<< "$(awk -v s="$LEAD_SNP" '$2==s{print $1,$4; exit}' "${AFR}.bim")"
    fi

    if [ -z "$LEAD_CHR" ] || [ -z "$LEAD_BP" ]; then
        echo "[WARNING] META lead SNP could not be annotated: $LEAD_SNP"
        return 1
    fi

    CAUSAL_LINE=$(awk -v s="$CAUSAL" 'NR>1 && $1==s{print $2,$3,$4,$5,$6; exit}' "$META")

    if [ -n "$CAUSAL_LINE" ]; then
        read -r CAUSAL_A1 CAUSAL_A2 CAUSAL_BETA CAUSAL_SE CAUSAL_P <<< "$CAUSAL_LINE"
    else
        CAUSAL_A1="NA"
        CAUSAL_A2="NA"
        CAUSAL_BETA="NA"
        CAUSAL_SE="NA"
        CAUSAL_P="NA"
    fi

    LEAD_MAF=$(awk -v s="$LEAD_SNP" '$2==s{print $5; exit}' "$MERGED_FRQ")
    CAUSAL_MAF=$(awk -v s="$CAUSAL" '$2==s{print $5; exit}' "$MERGED_FRQ")

    [ -z "$LEAD_MAF" ] && LEAD_MAF="NA"
    [ -z "$CAUSAL_MAF" ] && CAUSAL_MAF="NA"

    if [ "$LEAD_MAF" != "NA" ] && [ "$CAUSAL_MAF" != "NA" ]; then
        MAF_DIFF=$(awk -v a="$LEAD_MAF" -v b="$CAUSAL_MAF" 'BEGIN{d=a-b; if(d<0)d=-d; print d}')
    else
        MAF_DIFF="NA"
    fi

    BP_DIFF=$(( LEAD_BP > CAUSAL_BP ? LEAD_BP - CAUSAL_BP : CAUSAL_BP - LEAD_BP ))

    write_row \
        "$HSQ" \
        "$LOOP_ID" \
        "$LEAD_SNP" \
        "$LEAD_CHR" \
        "$LEAD_BP" \
        "$LEAD_A1" \
        "$LEAD_A2" \
        "$LEAD_BETA" \
        "$LEAD_SE" \
        "$LEAD_P" \
        "$LEAD_MAF" \
        "$CAUSAL" \
        "$CAUSAL_CHR" \
        "$CAUSAL_BP" \
        "$CAUSAL_A1" \
        "$CAUSAL_A2" \
        "$CAUSAL_BETA" \
        "$CAUSAL_SE" \
        "$CAUSAL_P" \
        "$CAUSAL_MAF" \
        "$MAF_DIFF" \
        "$BP_DIFF" \
        >> "$META_OUT"

    echo "[INFO] META lead SNP: $LEAD_SNP"
    echo "[INFO] META lead P: $LEAD_P"

    return 0
}

############################################################
# Run one single-dataset analysis
#
# Used for:
#   EUR 10K rare
#   EUR 5K + AFR pooled rare
#
# Only pooled GWAS includes PC1-PC10.
############################################################

run_single_analysis()
{
    local ANALYSIS_NAME=$1
    local BFILE=$2
    local OUT_FILE=$3
    local LOOP_DIR=$4
    local CAUSAL=$5
    local CAUSAL_CHR=$6
    local CAUSAL_BP=$7
    local REGION_START=$8
    local REGION_END=$9
    local HSQ=${10}
    local LOOP_ID=${11}

    local DIR
    local GWAS_FILE
    local LEAD_LINE
    local LEAD_CHR
    local LEAD_SNP
    local LEAD_BP
    local LEAD_A1
    local LEAD_A2
    local LEAD_N
    local LEAD_BETA
    local LEAD_STAT
    local LEAD_SE
    local LEAD_P
    local LEAD_MAF
    local CAUSAL_LINE
    local CAUSAL_A1
    local CAUSAL_A2
    local CAUSAL_BETA
    local CAUSAL_STAT
    local CAUSAL_SE
    local CAUSAL_P
    local CAUSAL_MAF
    local MAF_DIFF
    local BP_DIFF

    DIR=$LOOP_DIR/$ANALYSIS_NAME

    mkdir -p "$DIR"

    echo
    echo "============================================================"
    echo "[INFO] Analysis: $ANALYSIS_NAME"
    echo "[INFO] hsq=$HSQ"
    echo "[INFO] loop=$LOOP_ID"
    echo "[INFO] causal SNP=$CAUSAL"

    if [ "$ANALYSIS_NAME" = "pooled" ]; then
        echo "[INFO] Pooled GWAS covariates: PC1-PC10"
        echo "[INFO] Pooled PC file: $POOLED_PCA_COVAR"
    fi

    echo "============================================================"

    "$PLINK" \
        --bfile "$BFILE" \
        --chr "$CAUSAL_CHR" \
        --from-bp "$REGION_START" \
        --to-bp "$REGION_END" \
        --make-bed \
        --out "$DIR/win" \
        >/dev/null 2>&1

    if [ ! -f "$DIR/win.bed" ]; then
        echo "[WARNING] Window extraction failed for $ANALYSIS_NAME"
        return 1
    fi

    if ! awk -v s="$CAUSAL" '$2==s{found=1; exit} END{exit(found ? 0 : 1)}' "$DIR/win.bim"; then
        echo "[WARNING] Causal SNP absent from $ANALYSIS_NAME window: $CAUSAL"
        return 1
    fi

    printf "%s 1\n" "$CAUSAL" > "$DIR/seed"

    "$GCTA" \
        --bfile "$DIR/win" \
        --simu-qt \
        --simu-causal-loci "$DIR/seed" \
        --simu-hsq "$HSQ" \
        --out "$DIR/sim" \
        >/dev/null 2>&1

    if [ ! -f "$DIR/sim.phen" ]; then
        echo "[WARNING] GCTA simulation failed for $ANALYSIS_NAME"
        return 1
    fi

    (
        cd "$DIR" || exit 1
        "$RSCRIPT" --vanilla "$INVNORM_R" >/dev/null 2>&1
    )

    if [ ! -f "$DIR/sim.phen.invnorm" ]; then
        echo "[WARNING] Inverse-normal transformation failed for $ANALYSIS_NAME"
        return 1
    fi

    ########################################################
    # Run GWAS
    #
    # EUR-only:
    #   Original model, unchanged.
    #
    # pooled:
    #   phenotype ~ SNP + PC1 + ... + PC10
    ########################################################

    if [ "$ANALYSIS_NAME" = "pooled" ]; then

        "$PLINK" \
            --bfile "$DIR/win" \
            --pheno "$DIR/sim.phen.invnorm" \
            --covar "$POOLED_PCA_COVAR" \
            --covar-name PC1,PC2,PC3,PC4,PC5,PC6,PC7,PC8,PC9,PC10 \
            --linear hide-covar \
            --allow-no-sex \
            --out "$DIR/gwas" \
            >/dev/null 2>&1

    else

        "$PLINK" \
            --bfile "$DIR/win" \
            --pheno "$DIR/sim.phen.invnorm" \
            --linear hide-covar \
            --allow-no-sex \
            --out "$DIR/gwas" \
            >/dev/null 2>&1

    fi

    GWAS_FILE=$DIR/gwas.assoc.linear

    if [ ! -f "$GWAS_FILE" ]; then
        echo "[WARNING] GWAS failed for $ANALYSIS_NAME"
        return 1
    fi

    LEAD_LINE=$(awk 'NR>1 && $5=="ADD" && $7!="NA" && $8!="NA" && $9!="NA"{print $1,$2,$3,$4,$6,$7,$8,$9}' "$GWAS_FILE" | sort -k8,8g | head -1)

    if [ -z "$LEAD_LINE" ]; then
        echo "[WARNING] No valid lead SNP for $ANALYSIS_NAME"
        return 1
    fi

    read -r LEAD_CHR LEAD_SNP LEAD_BP LEAD_A1 LEAD_N LEAD_BETA LEAD_STAT LEAD_P <<< "$LEAD_LINE"

    LEAD_SE=$(awk -v b="$LEAD_BETA" -v s="$LEAD_STAT" 'BEGIN{if(b!="NA" && s!="NA" && s!=0){v=b/s; if(v<0)v=-v; print v}else{print "NA"}}')

    LEAD_A2=$(awk -v s="$LEAD_SNP" '$2==s{print $6; exit}' "$DIR/win.bim")
    [ -z "$LEAD_A2" ] && LEAD_A2="NA"

    CAUSAL_LINE=$(awk -v s="$CAUSAL" 'NR>1 && $2==s && $5=="ADD"{print $4,$7,$8,$9; exit}' "$GWAS_FILE")

    if [ -n "$CAUSAL_LINE" ]; then
        read -r CAUSAL_A1 CAUSAL_BETA CAUSAL_STAT CAUSAL_P <<< "$CAUSAL_LINE"
    else
        CAUSAL_A1="NA"
        CAUSAL_BETA="NA"
        CAUSAL_STAT="NA"
        CAUSAL_P="NA"
    fi

    CAUSAL_A2=$(awk -v s="$CAUSAL" '$2==s{print $6; exit}' "$DIR/win.bim")
    [ -z "$CAUSAL_A2" ] && CAUSAL_A2="NA"

    CAUSAL_SE=$(awk -v b="$CAUSAL_BETA" -v s="$CAUSAL_STAT" 'BEGIN{if(b!="NA" && s!="NA" && s!=0){v=b/s; if(v<0)v=-v; print v}else{print "NA"}}')

    LEAD_MAF=$(awk -v s="$LEAD_SNP" '$2==s{print $5; exit}' "$MERGED_FRQ")
    CAUSAL_MAF=$(awk -v s="$CAUSAL" '$2==s{print $5; exit}' "$MERGED_FRQ")

    [ -z "$LEAD_MAF" ] && LEAD_MAF="NA"
    [ -z "$CAUSAL_MAF" ] && CAUSAL_MAF="NA"

    if [ "$LEAD_MAF" != "NA" ] && [ "$CAUSAL_MAF" != "NA" ]; then
        MAF_DIFF=$(awk -v a="$LEAD_MAF" -v b="$CAUSAL_MAF" 'BEGIN{d=a-b; if(d<0)d=-d; print d}')
    else
        MAF_DIFF="NA"
    fi

    BP_DIFF=$(( LEAD_BP > CAUSAL_BP ? LEAD_BP - CAUSAL_BP : CAUSAL_BP - LEAD_BP ))

    write_row \
        "$HSQ" \
        "$LOOP_ID" \
        "$LEAD_SNP" \
        "$LEAD_CHR" \
        "$LEAD_BP" \
        "$LEAD_A1" \
        "$LEAD_A2" \
        "$LEAD_BETA" \
        "$LEAD_SE" \
        "$LEAD_P" \
        "$LEAD_MAF" \
        "$CAUSAL" \
        "$CAUSAL_CHR" \
        "$CAUSAL_BP" \
        "$CAUSAL_A1" \
        "$CAUSAL_A2" \
        "$CAUSAL_BETA" \
        "$CAUSAL_SE" \
        "$CAUSAL_P" \
        "$CAUSAL_MAF" \
        "$MAF_DIFF" \
        "$BP_DIFF" \
        >> "$OUT_FILE"

    echo "[INFO] $ANALYSIS_NAME lead SNP: $LEAD_SNP"
    echo "[INFO] $ANALYSIS_NAME lead P: $LEAD_P"

    return 0
}

############################################################
# Main analysis
############################################################

echo
echo "============================================================"
echo "[INFO] Rare hsq simulation started"
echo "[INFO] Array task: $TASK_ID"
echo "[INFO] Loop range: $LOOP_START-$LOOP_END"
echo "[INFO] Shared EUR 5K + AFR rare SNP count: $N_COMMON"
echo "[INFO] META output: $META_OUT"
echo "[INFO] EUR-only output: $EUR_OUT"
echo "[INFO] Pooled output: $POOLED_OUT"
echo "[INFO] Pooled GWAS covariates: PC1-PC10"
echo "[INFO] Pooled PC file: $POOLED_PCA_COVAR"
echo "============================================================"

for HSQ in $HSQ_LIST; do

    for ((LOOP_ID=LOOP_START; LOOP_ID<=LOOP_END; LOOP_ID++)); do

        LOOP_DIR=$TMP/hsq_${HSQ}_loop_$(printf "%04d" "$LOOP_ID")

        mkdir -p "$LOOP_DIR"

        echo
        echo "############################################################"
        echo "[INFO] Starting hsq=$HSQ loop=$LOOP_ID"
        echo "############################################################"

        CAUSAL=$(shuf -n 1 "$COMMON")

        if [ -z "$CAUSAL" ]; then
            echo "[WARNING] Failed to select a causal SNP"
            rm -rf "$LOOP_DIR"
            continue
        fi

        CAUSAL_INFO=$(awk -v s="$CAUSAL" '$2==s{print $1,$4; exit}' "${EUR}.bim")

        if [ -z "$CAUSAL_INFO" ]; then
            echo "[WARNING] Selected causal SNP not found in EUR BIM: $CAUSAL"
            rm -rf "$LOOP_DIR"
            continue
        fi

        read -r CAUSAL_CHR CAUSAL_BP <<< "$CAUSAL_INFO"

        REGION_START=$(( CAUSAL_BP - 20000000 ))
        REGION_END=$(( CAUSAL_BP + 20000000 ))

        if [ "$REGION_START" -lt 0 ]; then
            REGION_START=0
        fi

        echo "[INFO] Shared causal SNP: $CAUSAL"
        echo "[INFO] Causal position: chr${CAUSAL_CHR}:${CAUSAL_BP}"
        echo "[INFO] Analysis window: chr${CAUSAL_CHR}:${REGION_START}-${REGION_END}"

        if ! run_meta_analysis "$LOOP_DIR" "$CAUSAL" "$CAUSAL_CHR" "$CAUSAL_BP" "$REGION_START" "$REGION_END" "$HSQ" "$LOOP_ID"; then
            echo "[WARNING] META analysis failed for hsq=$HSQ loop=$LOOP_ID"
        fi

        if ! run_single_analysis EUR_only "$EUR_FULL" "$EUR_OUT" "$LOOP_DIR" "$CAUSAL" "$CAUSAL_CHR" "$CAUSAL_BP" "$REGION_START" "$REGION_END" "$HSQ" "$LOOP_ID"; then
            echo "[WARNING] EUR-only analysis failed for hsq=$HSQ loop=$LOOP_ID"
        fi

        if ! run_single_analysis pooled "$POOLED" "$POOLED_OUT" "$LOOP_DIR" "$CAUSAL" "$CAUSAL_CHR" "$CAUSAL_BP" "$REGION_START" "$REGION_END" "$HSQ" "$LOOP_ID"; then
            echo "[WARNING] Pooled analysis failed for hsq=$HSQ loop=$LOOP_ID"
        fi

        echo
        echo "############################################################"
        echo "[INFO] Finished hsq=$HSQ loop=$LOOP_ID"
        echo "[INFO] Causal SNP used by all analyses: $CAUSAL"
        echo "############################################################"

        rm -rf "$LOOP_DIR"

    done

done

############################################################
# Cleanup
############################################################

rm -rf "$TMP"

echo
echo "============================================================"
echo "[INFO] Array task $TASK_ID completed"
echo "[INFO] Loop range: $LOOP_START-$LOOP_END"
echo "[INFO] META output: $META_OUT"
echo "[INFO] EUR-only output: $EUR_OUT"
echo "[INFO] Pooled output: $POOLED_OUT"
echo "[INFO] Only pooled GWAS was adjusted for PC1-PC10"
echo "============================================================"